--
-- PostgreSQL database dump
--

-- Dumped from database version 9.1.1
-- Dumped by pg_dump version 9.1.1
-- Started on 2013-02-08 12:36:09

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 267 (class 3079 OID 11638)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2698 (class 0 OID 0)
-- Dependencies: 267
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_with_oids = false;

--
-- TOC entry 161 (class 1259 OID 113840)
-- Dependencies: 5
-- Name: activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE activity (
    activityid integer NOT NULL,
    allowedit boolean NOT NULL,
    isassessment boolean NOT NULL,
    category character varying(255),
    datedeleted timestamp without time zone,
    mapicon character varying(255),
    name character varying(45) NOT NULL,
    reportingfrequency integer NOT NULL,
    sortorder integer NOT NULL,
    databaseid integer NOT NULL,
    locationtypeid integer NOT NULL
);


--
-- TOC entry 162 (class 1259 OID 113846)
-- Dependencies: 5
-- Name: adminentity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE adminentity (
    adminentityid integer NOT NULL,
    x1 double precision,
    x2 double precision,
    y1 double precision,
    y2 double precision,
    code character varying(15),
    name character varying(50) NOT NULL,
    soundex character varying(50),
    adminlevelid integer NOT NULL,
    adminentityparentid integer
);


--
-- TOC entry 163 (class 1259 OID 113849)
-- Dependencies: 5
-- Name: adminlevel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE adminlevel (
    adminlevelid integer NOT NULL,
    allowadd boolean NOT NULL,
    name character varying(30) NOT NULL,
    countryid integer NOT NULL,
    parentid integer
);


--
-- TOC entry 164 (class 1259 OID 113852)
-- Dependencies: 5
-- Name: amendment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE amendment (
    id_amendment integer NOT NULL,
    history_date timestamp without time zone,
    revision integer,
    status character varying(255),
    version integer,
    id_log_frame integer,
    id_project integer
);


--
-- TOC entry 165 (class 1259 OID 113855)
-- Dependencies: 5
-- Name: amendment_history_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE amendment_history_token (
    amendment_id_amendment integer NOT NULL,
    values_id_history_token integer NOT NULL
);


--
-- TOC entry 166 (class 1259 OID 113858)
-- Dependencies: 5
-- Name: attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE attribute (
    attributeid integer NOT NULL,
    datedeleted timestamp without time zone,
    name character varying(50) NOT NULL,
    sortorder integer NOT NULL,
    attributegroupid integer NOT NULL
);


--
-- TOC entry 167 (class 1259 OID 113861)
-- Dependencies: 5
-- Name: attributegroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE attributegroup (
    attributegroupid integer NOT NULL,
    category character varying(50),
    datedeleted timestamp without time zone,
    multipleallowed boolean NOT NULL,
    name character varying(255),
    sortorder integer NOT NULL
);


--
-- TOC entry 168 (class 1259 OID 113864)
-- Dependencies: 5
-- Name: attributegroupinactivity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE attributegroupinactivity (
    attributegroupid integer NOT NULL,
    activityid integer NOT NULL
);


--
-- TOC entry 169 (class 1259 OID 113867)
-- Dependencies: 5
-- Name: attributevalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE attributevalue (
    attributeid integer NOT NULL,
    siteid integer NOT NULL,
    value boolean
);


--
-- TOC entry 170 (class 1259 OID 113870)
-- Dependencies: 5
-- Name: authentication; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE authentication (
    authtoken character varying(32) NOT NULL,
    datecreated timestamp without time zone,
    datelastactive timestamp without time zone,
    userid integer NOT NULL
);


--
-- TOC entry 171 (class 1259 OID 113873)
-- Dependencies: 5
-- Name: budget; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE budget (
    id_budget bigint NOT NULL,
    total_amount real NOT NULL
);


--
-- TOC entry 172 (class 1259 OID 113876)
-- Dependencies: 5
-- Name: budget_distribution_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE budget_distribution_element (
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 173 (class 1259 OID 113879)
-- Dependencies: 5
-- Name: budget_part; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE budget_part (
    id_budget_part bigint NOT NULL,
    amount real NOT NULL,
    label character varying(2048) NOT NULL,
    id_budget_parts_list bigint NOT NULL
);


--
-- TOC entry 174 (class 1259 OID 113885)
-- Dependencies: 5
-- Name: budget_parts_list_value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE budget_parts_list_value (
    id_budget_parts_list bigint NOT NULL,
    id_budget bigint NOT NULL
);


--
-- TOC entry 175 (class 1259 OID 113888)
-- Dependencies: 5
-- Name: category_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE category_element (
    id_category_element integer NOT NULL,
    color_hex character varying(6) NOT NULL,
    label text NOT NULL,
    id_organization integer,
    id_category_type integer NOT NULL
);


--
-- TOC entry 176 (class 1259 OID 113894)
-- Dependencies: 5
-- Name: category_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE category_type (
    id_category_type integer NOT NULL,
    icon_name character varying(8192) NOT NULL,
    label character varying(8192) NOT NULL,
    id_organization integer
);


--
-- TOC entry 177 (class 1259 OID 113900)
-- Dependencies: 5
-- Name: checkbox_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE checkbox_element (
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 178 (class 1259 OID 113903)
-- Dependencies: 5
-- Name: country; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE country (
    countryid integer NOT NULL,
    x1 double precision NOT NULL,
    x2 double precision NOT NULL,
    y1 double precision NOT NULL,
    y2 double precision NOT NULL,
    iso2 character varying(2),
    name character varying(50) NOT NULL
);


--
-- TOC entry 179 (class 1259 OID 113906)
-- Dependencies: 5
-- Name: default_flexible_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE default_flexible_element (
    type character varying(255),
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 180 (class 1259 OID 113909)
-- Dependencies: 5
-- Name: file_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE file_meta (
    id_file integer NOT NULL,
    datedeleted timestamp without time zone,
    name text NOT NULL
);


--
-- TOC entry 181 (class 1259 OID 113915)
-- Dependencies: 5
-- Name: file_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE file_version (
    id_file_version integer NOT NULL,
    added_date timestamp without time zone NOT NULL,
    comments text,
    datedeleted timestamp without time zone,
    extension character varying(1024),
    name text NOT NULL,
    path text NOT NULL,
    size bigint NOT NULL,
    version_number integer NOT NULL,
    id_author integer NOT NULL,
    id_file integer NOT NULL
);


--
-- TOC entry 182 (class 1259 OID 113921)
-- Dependencies: 5
-- Name: files_list_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE files_list_element (
    max_limit integer,
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 183 (class 1259 OID 113924)
-- Dependencies: 2199 2200 5
-- Name: flexible_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE flexible_element (
    id_flexible_element bigint NOT NULL,
    amendable boolean NOT NULL,
    label text,
    validates boolean NOT NULL,
    id_privacy_group integer,
    exportable boolean DEFAULT true NOT NULL,
    globally_exportable boolean DEFAULT true NOT NULL
);


--
-- TOC entry 184 (class 1259 OID 113932)
-- Dependencies: 5
-- Name: global_export; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE global_export (
    id bigint NOT NULL,
    generated_date timestamp without time zone NOT NULL,
    organization_id integer NOT NULL
);


--
-- TOC entry 185 (class 1259 OID 113935)
-- Dependencies: 5
-- Name: global_export_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE global_export_content (
    id bigint NOT NULL,
    csv_content text,
    project_model_name character varying(8192) NOT NULL,
    global_export_id bigint NOT NULL
);


--
-- TOC entry 186 (class 1259 OID 113941)
-- Dependencies: 5
-- Name: global_export_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE global_export_settings (
    id bigint NOT NULL,
    auto_delete_frequency integer,
    auto_export_frequency integer,
    default_organization_export_format character varying(255),
    export_format character varying(255),
    last_export_date timestamp without time zone,
    locale_string character varying(4) NOT NULL,
    organization_id integer NOT NULL
);


--
-- TOC entry 187 (class 1259 OID 113947)
-- Dependencies: 5
-- Name: global_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE global_permission (
    id_global_permission integer NOT NULL,
    permission character varying(255) NOT NULL,
    id_profile integer NOT NULL
);


--
-- TOC entry 188 (class 1259 OID 113950)
-- Dependencies: 5
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2699 (class 0 OID 0)
-- Dependencies: 188
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('hibernate_sequence', 1710, true);


--
-- TOC entry 189 (class 1259 OID 113952)
-- Dependencies: 5
-- Name: history_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE history_token (
    id_history_token integer NOT NULL,
    history_date timestamp without time zone NOT NULL,
    id_element bigint NOT NULL,
    id_project integer NOT NULL,
    change_type character varying(255),
    value text NOT NULL,
    id_user integer
);


--
-- TOC entry 190 (class 1259 OID 113958)
-- Dependencies: 2201 5
-- Name: indicator; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE indicator (
    indicatorid integer NOT NULL,
    aggregation integer NOT NULL,
    category character varying(1024),
    listheader character varying(30),
    collectintervention boolean NOT NULL,
    collectmonitoring boolean NOT NULL,
    datedeleted timestamp without time zone,
    description text,
    name character varying(1024) NOT NULL,
    objective double precision,
    sortorder integer NOT NULL,
    units character varying(15),
    activityid integer,
    databaseid integer,
    id_quality_criterion integer,
    sourceofverification text,
    directdataentryenabled boolean DEFAULT true NOT NULL
);


--
-- TOC entry 191 (class 1259 OID 113965)
-- Dependencies: 5
-- Name: indicator_datasource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE indicator_datasource (
    indicatorid integer NOT NULL,
    indicatorsourceid integer NOT NULL
);


--
-- TOC entry 192 (class 1259 OID 113968)
-- Dependencies: 5
-- Name: indicator_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE indicator_labels (
    indicator_indicatorid integer NOT NULL,
    element character varying(255),
    code integer NOT NULL
);


--
-- TOC entry 193 (class 1259 OID 113971)
-- Dependencies: 5
-- Name: indicatordatasource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE indicatordatasource (
    indicatorid integer NOT NULL,
    indicatorsourceid integer NOT NULL
);


--
-- TOC entry 194 (class 1259 OID 113974)
-- Dependencies: 5
-- Name: indicators_list_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE indicators_list_element (
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 195 (class 1259 OID 113977)
-- Dependencies: 5
-- Name: indicators_list_value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE indicators_list_value (
    id_indicators_list bigint NOT NULL,
    id_indicator integer NOT NULL
);


--
-- TOC entry 196 (class 1259 OID 113980)
-- Dependencies: 5
-- Name: indicatorvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE indicatorvalue (
    indicatorid integer NOT NULL,
    reportingperiodid integer NOT NULL,
    value double precision NOT NULL
);


--
-- TOC entry 197 (class 1259 OID 113983)
-- Dependencies: 5
-- Name: keyquestion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE keyquestion (
    id integer NOT NULL,
    sort_order integer,
    label character varying(255),
    sectionid integer,
    qualitycriterion_id_quality_criterion integer
);


--
-- TOC entry 198 (class 1259 OID 113986)
-- Dependencies: 5
-- Name: layout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE layout (
    id_layout bigint NOT NULL,
    columns_count integer NOT NULL,
    rows_count integer NOT NULL
);


--
-- TOC entry 199 (class 1259 OID 113989)
-- Dependencies: 5
-- Name: layout_constraint; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE layout_constraint (
    id_layout_constraint bigint NOT NULL,
    sort_order integer,
    id_flexible_element bigint NOT NULL,
    id_layout_group bigint NOT NULL
);


--
-- TOC entry 200 (class 1259 OID 113992)
-- Dependencies: 5
-- Name: layout_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE layout_group (
    id_layout_group bigint NOT NULL,
    column_index integer NOT NULL,
    row_index integer NOT NULL,
    title character varying(8192),
    id_layout bigint NOT NULL
);


--
-- TOC entry 201 (class 1259 OID 113998)
-- Dependencies: 5
-- Name: location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE location (
    locationid integer NOT NULL,
    axe character varying(50),
    datecreated timestamp without time zone,
    dateedited timestamp without time zone,
    locationguid character varying(36),
    name character varying(50) NOT NULL,
    x double precision,
    y double precision,
    locationtypeid integer NOT NULL
);


--
-- TOC entry 202 (class 1259 OID 114001)
-- Dependencies: 5
-- Name: locationadminlink; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE locationadminlink (
    adminentityid integer NOT NULL,
    locationid integer NOT NULL
);


--
-- TOC entry 203 (class 1259 OID 114004)
-- Dependencies: 5
-- Name: locationtype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE locationtype (
    locationtypeid integer NOT NULL,
    name character varying(50) NOT NULL,
    reuse boolean NOT NULL,
    boundadminlevelid integer,
    countryid integer NOT NULL
);


--
-- TOC entry 204 (class 1259 OID 114007)
-- Dependencies: 5
-- Name: log_frame; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log_frame (
    id_log_frame integer NOT NULL,
    main_objective text,
    id_log_frame_model integer NOT NULL,
    id_project integer
);


--
-- TOC entry 205 (class 1259 OID 114013)
-- Dependencies: 5
-- Name: log_frame_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log_frame_activity (
    advancement integer,
    enddate timestamp without time zone,
    startdate timestamp without time zone,
    title text,
    id_element integer NOT NULL,
    id_result integer NOT NULL
);


--
-- TOC entry 206 (class 1259 OID 114019)
-- Dependencies: 5
-- Name: log_frame_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log_frame_element (
    id_element integer NOT NULL,
    code integer NOT NULL,
    "position" integer,
    id_group integer,
    risksandassumptions text
);


--
-- TOC entry 207 (class 1259 OID 114025)
-- Dependencies: 5
-- Name: log_frame_expected_result; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log_frame_expected_result (
    intervention_logic text,
    id_element integer NOT NULL,
    id_specific_objective integer NOT NULL
);


--
-- TOC entry 208 (class 1259 OID 114031)
-- Dependencies: 5
-- Name: log_frame_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log_frame_group (
    id_group integer NOT NULL,
    label text,
    type character varying(255),
    id_log_frame integer NOT NULL
);


--
-- TOC entry 209 (class 1259 OID 114037)
-- Dependencies: 5
-- Name: log_frame_indicators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log_frame_indicators (
    log_frame_element_id_element integer NOT NULL,
    indicators_indicatorid integer NOT NULL
);


--
-- TOC entry 210 (class 1259 OID 114040)
-- Dependencies: 5
-- Name: log_frame_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log_frame_model (
    id_log_frame integer NOT NULL,
    a_gp_max integer,
    a_max integer,
    a_per_er_max integer,
    a_per_gp_max integer,
    a_enable_groups boolean,
    er_enable_groups boolean,
    p_enable_groups boolean,
    so_enable_groups boolean,
    er_gp_max integer,
    er_max integer,
    er_per_gp_max integer,
    er_per_so_max integer,
    name character varying(8192) NOT NULL,
    p_gp_max integer,
    p_max integer,
    p_per_gp_max integer,
    so_gp_max integer,
    so_max integer,
    so_per_gp_max integer,
    id_project_model bigint
);


--
-- TOC entry 211 (class 1259 OID 114046)
-- Dependencies: 5
-- Name: log_frame_prerequisite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log_frame_prerequisite (
    id_prerequisite integer NOT NULL,
    code integer NOT NULL,
    content text,
    "position" integer,
    id_group integer,
    id_log_frame integer NOT NULL
);


--
-- TOC entry 212 (class 1259 OID 114052)
-- Dependencies: 5
-- Name: log_frame_specific_objective; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log_frame_specific_objective (
    intervention_logic text,
    id_element integer NOT NULL,
    id_log_frame integer NOT NULL
);


--
-- TOC entry 213 (class 1259 OID 114058)
-- Dependencies: 5
-- Name: message_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE message_element (
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 214 (class 1259 OID 114061)
-- Dependencies: 5
-- Name: monitored_point; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE monitored_point (
    id_monitored_point integer NOT NULL,
    completion_date timestamp without time zone,
    deleted boolean NOT NULL,
    expected_date timestamp without time zone NOT NULL,
    label character varying(8192) NOT NULL,
    id_file integer,
    id_list integer NOT NULL
);


--
-- TOC entry 215 (class 1259 OID 114067)
-- Dependencies: 5
-- Name: monitored_point_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE monitored_point_list (
    id_monitored_point_list integer NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 114070)
-- Dependencies: 5
-- Name: org_unit_banner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE org_unit_banner (
    banner_id integer NOT NULL,
    id_layout bigint NOT NULL,
    id_org_unit_model integer
);


--
-- TOC entry 217 (class 1259 OID 114073)
-- Dependencies: 5
-- Name: org_unit_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE org_unit_details (
    details_id integer NOT NULL,
    id_layout bigint NOT NULL,
    id_org_unit_model integer
);


--
-- TOC entry 218 (class 1259 OID 114076)
-- Dependencies: 5
-- Name: org_unit_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE org_unit_model (
    org_unit_model_id integer NOT NULL,
    can_contain_projects boolean NOT NULL,
    has_budget boolean,
    name character varying(8192) NOT NULL,
    status character varying(255) NOT NULL,
    title character varying(8192) NOT NULL,
    id_organization integer,
    date_deleted date
);


--
-- TOC entry 219 (class 1259 OID 114082)
-- Dependencies: 5
-- Name: organization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE organization (
    id_organization integer NOT NULL,
    logo text,
    name text NOT NULL,
    id_root_org_unit integer
);


--
-- TOC entry 220 (class 1259 OID 114088)
-- Dependencies: 5
-- Name: orgunitpermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE orgunitpermission (
    id integer NOT NULL,
    editall boolean NOT NULL,
    viewall boolean NOT NULL,
    unit_id integer,
    user_userid integer
);


--
-- TOC entry 221 (class 1259 OID 114091)
-- Dependencies: 5
-- Name: partner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE partner (
    partnerid integer NOT NULL,
    calendarid integer,
    deleted timestamp without time zone,
    fullname character varying(64),
    name character varying(16) NOT NULL,
    planned_budget double precision,
    received_budget double precision,
    spend_budget double precision,
    location_locationid integer,
    office_country_id integer,
    id_org_unit_model integer,
    organization_id_organization integer,
    parent_partnerid integer
);


--
-- TOC entry 222 (class 1259 OID 114094)
-- Dependencies: 5
-- Name: partnerindatabase; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE partnerindatabase (
    partnerid integer NOT NULL,
    databaseid integer NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 114097)
-- Dependencies: 5
-- Name: personalcalendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE personalcalendar (
    id integer NOT NULL,
    name character varying(255)
);


--
-- TOC entry 224 (class 1259 OID 114100)
-- Dependencies: 5
-- Name: personalevent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE personalevent (
    id integer NOT NULL,
    calendarid integer,
    datecreated timestamp without time zone,
    datedeleted timestamp without time zone,
    description character varying(255),
    enddate timestamp without time zone,
    startdate timestamp without time zone,
    summary character varying(255)
);


--
-- TOC entry 225 (class 1259 OID 114106)
-- Dependencies: 5
-- Name: phase; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE phase (
    id_phase bigint NOT NULL,
    end_date timestamp without time zone,
    start_date timestamp without time zone,
    id_phase_model bigint NOT NULL,
    id_project integer NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 114109)
-- Dependencies: 5
-- Name: phase_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE phase_model (
    id_phase_model bigint NOT NULL,
    display_order integer,
    guide text,
    name character varying(8192) NOT NULL,
    definition_id integer,
    id_layout bigint,
    id_project_model bigint NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 114115)
-- Dependencies: 5
-- Name: phase_model_definition; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE phase_model_definition (
    id_phase_model_definition integer NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 114118)
-- Dependencies: 5
-- Name: phase_model_sucessors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE phase_model_sucessors (
    id_phase_model bigint NOT NULL,
    id_phase_model_successor bigint NOT NULL
);


--
-- TOC entry 229 (class 1259 OID 114121)
-- Dependencies: 5
-- Name: privacy_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE privacy_group (
    id_privacy_group integer NOT NULL,
    code integer NOT NULL,
    title character varying(8192) NOT NULL,
    id_organization integer
);


--
-- TOC entry 230 (class 1259 OID 114127)
-- Dependencies: 5
-- Name: privacy_group_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE privacy_group_permission (
    id_permission integer NOT NULL,
    permission character varying(255) NOT NULL,
    id_privacy_group integer NOT NULL,
    id_profile integer NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 114130)
-- Dependencies: 5
-- Name: profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE profile (
    id_profile integer NOT NULL,
    name character varying(8196) NOT NULL,
    id_organization integer
);


--
-- TOC entry 232 (class 1259 OID 114136)
-- Dependencies: 5
-- Name: project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE project (
    activity_advancement integer,
    amendment_revision integer,
    amendment_status character varying(255),
    amendment_version integer,
    calendarid integer,
    close_date timestamp without time zone,
    end_date timestamp without time zone,
    planned_budget double precision,
    received_budget double precision,
    spend_budget double precision,
    databaseid integer NOT NULL,
    id_current_phase bigint,
    id_manager integer,
    id_monitored_points_list integer,
    id_project_model bigint,
    id_reminder_list integer
);


--
-- TOC entry 233 (class 1259 OID 114139)
-- Dependencies: 5
-- Name: project_banner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE project_banner (
    id integer NOT NULL,
    id_layout bigint NOT NULL,
    id_project_model bigint
);


--
-- TOC entry 234 (class 1259 OID 114142)
-- Dependencies: 5
-- Name: project_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE project_details (
    id integer NOT NULL,
    id_layout bigint NOT NULL,
    id_project_model bigint
);


--
-- TOC entry 235 (class 1259 OID 114145)
-- Dependencies: 5
-- Name: project_funding; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE project_funding (
    id_funding integer NOT NULL,
    percentage double precision,
    id_project_funded integer NOT NULL,
    id_project_funding integer NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 114148)
-- Dependencies: 5
-- Name: project_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE project_model (
    id_project_model bigint NOT NULL,
    name character varying(8192) NOT NULL,
    status character varying(255) NOT NULL,
    id_root_phase_model bigint,
    date_deleted date
);


--
-- TOC entry 237 (class 1259 OID 114154)
-- Dependencies: 5
-- Name: project_model_visibility; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE project_model_visibility (
    id_visibility integer NOT NULL,
    type character varying(255),
    id_project_model bigint NOT NULL,
    id_organization integer NOT NULL
);


--
-- TOC entry 238 (class 1259 OID 114157)
-- Dependencies: 5
-- Name: project_userlogin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE project_userlogin (
    project_databaseid integer NOT NULL,
    favoriteusers_userid integer NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 114160)
-- Dependencies: 5
-- Name: projectreport; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE projectreport (
    id integer NOT NULL,
    datedeleted timestamp without time zone,
    name character varying(255),
    currentversion_id integer,
    flexibleelement_id_flexible_element bigint,
    model_id integer,
    orgunit_partnerid integer,
    project_databaseid integer
);


--
-- TOC entry 240 (class 1259 OID 114163)
-- Dependencies: 5
-- Name: projectreportmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE projectreportmodel (
    id integer NOT NULL,
    name character varying(255),
    id_organization integer
);


--
-- TOC entry 241 (class 1259 OID 114166)
-- Dependencies: 5
-- Name: projectreportmodelsection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE projectreportmodelsection (
    id integer NOT NULL,
    sort_order integer,
    name character varying(255),
    numberoftextarea integer,
    parentsectionmodelid integer,
    projectmodelid integer
);


--
-- TOC entry 242 (class 1259 OID 114169)
-- Dependencies: 5
-- Name: projectreportversion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE projectreportversion (
    id integer NOT NULL,
    editdate timestamp without time zone,
    phasename character varying(255),
    version integer,
    editor_userid integer,
    report_id integer
);


--
-- TOC entry 243 (class 1259 OID 114172)
-- Dependencies: 5
-- Name: quality_criterion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE quality_criterion (
    id_quality_criterion integer NOT NULL,
    code character varying(8192) NOT NULL,
    label text NOT NULL,
    id_organization integer,
    id_quality_framework integer
);


--
-- TOC entry 244 (class 1259 OID 114178)
-- Dependencies: 5
-- Name: quality_criterion_children; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE quality_criterion_children (
    id_quality_criterion integer,
    id_quality_criterion_child integer NOT NULL
);


--
-- TOC entry 245 (class 1259 OID 114181)
-- Dependencies: 5
-- Name: quality_criterion_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE quality_criterion_type (
    id_criterion_type integer NOT NULL,
    label character varying(8192) NOT NULL,
    level integer NOT NULL,
    id_quality_framework integer NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 114187)
-- Dependencies: 5
-- Name: quality_framework; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE quality_framework (
    id_quality_framework integer NOT NULL,
    label character varying(8192) NOT NULL,
    id_organization integer
);


--
-- TOC entry 247 (class 1259 OID 114193)
-- Dependencies: 5
-- Name: question_choice_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE question_choice_element (
    id_choice bigint NOT NULL,
    label character varying(8192) NOT NULL,
    sort_order integer,
    id_category_element integer,
    id_question bigint NOT NULL
);


--
-- TOC entry 248 (class 1259 OID 114199)
-- Dependencies: 5
-- Name: question_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE question_element (
    is_multiple boolean,
    id_flexible_element bigint NOT NULL,
    id_category_type integer,
    id_quality_criterion integer
);


--
-- TOC entry 249 (class 1259 OID 114202)
-- Dependencies: 5
-- Name: reminder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE reminder (
    id_reminder integer NOT NULL,
    completion_date timestamp without time zone,
    deleted boolean NOT NULL,
    expected_date timestamp without time zone NOT NULL,
    label character varying(8192) NOT NULL,
    id_list integer NOT NULL
);


--
-- TOC entry 250 (class 1259 OID 114208)
-- Dependencies: 5
-- Name: reminder_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE reminder_list (
    id_reminder_list integer NOT NULL
);


--
-- TOC entry 251 (class 1259 OID 114211)
-- Dependencies: 5
-- Name: report_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE report_element (
    model_id integer,
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 252 (class 1259 OID 114214)
-- Dependencies: 5
-- Name: report_list_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE report_list_element (
    model_id integer,
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 253 (class 1259 OID 114217)
-- Dependencies: 5
-- Name: reportingperiod; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE reportingperiod (
    reportingperiodid integer NOT NULL,
    comments text,
    date1 date NOT NULL,
    date2 date NOT NULL,
    datecreated timestamp without time zone NOT NULL,
    datedeleted timestamp without time zone,
    dateedited timestamp without time zone NOT NULL,
    monitoring boolean NOT NULL,
    siteid integer NOT NULL
);


--
-- TOC entry 254 (class 1259 OID 114223)
-- Dependencies: 5
-- Name: reportsubscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE reportsubscription (
    reporttemplateid integer NOT NULL,
    userid integer NOT NULL,
    subscribed boolean NOT NULL,
    invitinguserid integer
);


--
-- TOC entry 255 (class 1259 OID 114226)
-- Dependencies: 5
-- Name: reporttemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE reporttemplate (
    reporttemplateid integer NOT NULL,
    datedeleted timestamp without time zone,
    day integer,
    description text,
    frequency character varying(255),
    title character varying(255),
    visibility integer,
    xml text NOT NULL,
    databaseid integer,
    owneruserid integer NOT NULL
);


--
-- TOC entry 256 (class 1259 OID 114232)
-- Dependencies: 5
-- Name: richtextelement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE richtextelement (
    id integer NOT NULL,
    sort_order integer,
    sectionid integer,
    text text,
    version_id integer
);


--
-- TOC entry 257 (class 1259 OID 114238)
-- Dependencies: 5
-- Name: site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE site (
    siteid integer NOT NULL,
    comments text,
    date1 date,
    date2 date,
    datecreated timestamp without time zone NOT NULL,
    datedeleted timestamp without time zone,
    dateedited timestamp without time zone NOT NULL,
    datesynchronized timestamp without time zone,
    siteguid character varying(36),
    status integer NOT NULL,
    target integer NOT NULL,
    activityid integer,
    assessmentsiteid integer,
    databaseid integer NOT NULL,
    locationid integer NOT NULL,
    partnerid integer NOT NULL
);


--
-- TOC entry 258 (class 1259 OID 114244)
-- Dependencies: 5
-- Name: textarea_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE textarea_element (
    is_decimal boolean,
    length integer,
    max_value bigint,
    min_value bigint,
    type character(1),
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 259 (class 1259 OID 114247)
-- Dependencies: 5
-- Name: triplet_value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE triplet_value (
    id_triplet bigint NOT NULL,
    code text NOT NULL,
    datedeleted timestamp without time zone,
    name text NOT NULL,
    period text NOT NULL
);


--
-- TOC entry 260 (class 1259 OID 114253)
-- Dependencies: 5
-- Name: triplets_list_element; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE triplets_list_element (
    id_flexible_element bigint NOT NULL
);


--
-- TOC entry 261 (class 1259 OID 114256)
-- Dependencies: 5
-- Name: user_unit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE user_unit (
    id_user_unit integer NOT NULL,
    id_org_unit integer NOT NULL,
    id_user integer NOT NULL
);


--
-- TOC entry 262 (class 1259 OID 114259)
-- Dependencies: 5
-- Name: user_unit_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE user_unit_profiles (
    id_user_unit integer NOT NULL,
    id_profile integer NOT NULL
);


--
-- TOC entry 263 (class 1259 OID 114262)
-- Dependencies: 5
-- Name: userdatabase; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE userdatabase (
    databaseid integer NOT NULL,
    datedeleted timestamp without time zone,
    fullname character varying(500),
    lastschemaupdate timestamp without time zone NOT NULL,
    name character varying(16) NOT NULL,
    startdate timestamp without time zone,
    countryid integer NOT NULL,
    owneruserid integer NOT NULL
);


--
-- TOC entry 264 (class 1259 OID 114268)
-- Dependencies: 5
-- Name: userlogin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE userlogin (
    userid integer NOT NULL,
    active boolean,
    changepasswordkey character varying(34),
    datechangepasswordkeyissued timestamp without time zone,
    email character varying(75) NOT NULL,
    firstname character varying(50),
    password character varying(150),
    locale character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    newuser boolean NOT NULL,
    id_organization integer
);


--
-- TOC entry 265 (class 1259 OID 114271)
-- Dependencies: 5
-- Name: userpermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE userpermission (
    userpermissionid integer NOT NULL,
    allowdesign boolean NOT NULL,
    allowedit boolean NOT NULL,
    alloweditall boolean NOT NULL,
    allowmanageallusers boolean NOT NULL,
    allowmanageusers boolean NOT NULL,
    allowview boolean NOT NULL,
    allowviewall boolean NOT NULL,
    lastschemaupdate timestamp without time zone,
    databaseid integer NOT NULL,
    partnerid integer NOT NULL,
    userid integer NOT NULL
);


--
-- TOC entry 266 (class 1259 OID 114274)
-- Dependencies: 5
-- Name: value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE value (
    id_value bigint NOT NULL,
    id_project integer NOT NULL,
    action_last_modif character(1) NOT NULL,
    date_last_modif timestamp without time zone NOT NULL,
    value text,
    id_flexible_element bigint NOT NULL,
    id_user_last_modif integer NOT NULL
);


--
-- TOC entry 2589 (class 0 OID 113840)
-- Dependencies: 161
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY activity (activityid, allowedit, isassessment, category, datedeleted, mapicon, name, reportingfrequency, sortorder, databaseid, locationtypeid) FROM stdin;
\.


--
-- TOC entry 2590 (class 0 OID 113846)
-- Dependencies: 162
-- Data for Name: adminentity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY adminentity (adminentityid, x1, x2, y1, y2, code, name, soundex, adminlevelid, adminentityparentid) FROM stdin;
141796	15.135868439999999	16.553810160000001	-5.025401885	-3.9368420049999999	10	Kinshasa	\N	1	\N
141797	12.187941840000001	16.269254279999998	-6.1598023719999997	-4.298126194	20	Bas Congo	\N	1	\N
141798	15.907705200000001	21.023272080000002	-8.1290649679999998	-0.736009001	30	Bandundu	\N	1	\N
141799	16.503999839999999	24.44404428	-2.5323872600000001	5.1460000189999997	40	Equateur	\N	1	\N
141800	22.24727244	31.306000000000001	-2.1119838240000002	5.3860981539999999	50	Orientale	\N	1	\N
141801	27.22714452	29.992703760000001	-2.0657701780000002	0.95419910900000005	61	Nord Kivu	\N	1	\N
141802	24.598389959999999	28.8017568	-5.0197248810000001	-0.0138	62	Maniema	\N	1	\N
141803	26.810641799999999	29.389096080000002	-5.0103452649999998	-1.588550087	63	Sud Kivu	\N	1	\N
141804	21.744749880000001	30.793182120000001	-13.45599996	-4.9995205839999999	70	Katanga	\N	1	\N
141805	21.83095548	26.270477280000001	-7.9796309179999998	-1.6974750199999999	80	Kasai Oriental	\N	1	\N
141806	19.68013728	23.756244479999999	-7.8959899880000002	-2.3096029269999998	90	Kasai Occidental	\N	1	\N
141807	\N	\N	\N	\N	101	Kinshasa	\N	2	141796
141808	\N	\N	\N	\N	102	Ville de Kinshasa	\N	2	141796
141809	\N	\N	\N	\N	201	Ville de Matadi	\N	2	141797
141810	\N	\N	\N	\N	202	Ville de Boma	\N	2	141797
141811	\N	\N	\N	\N	203	Bas Fleuve	\N	2	141797
141812	\N	\N	\N	\N	204	Cataractes	\N	2	141797
141813	\N	\N	\N	\N	205	Lukaya	\N	2	141797
141814	\N	\N	\N	\N	301	Ville de Bandundu	\N	2	141798
141815	\N	\N	\N	\N	302	Mai Ndombe	\N	2	141798
141816	\N	\N	\N	\N	303	Kwilu	\N	2	141798
141817	\N	\N	\N	\N	304	Ville de Kikwit	\N	2	141798
141818	\N	\N	\N	\N	305	Kwango	\N	2	141798
141819	\N	\N	\N	\N	306	Plateaux	\N	2	141798
141820	\N	\N	\N	\N	401	Ville de Mbandaka	\N	2	141799
141821	\N	\N	\N	\N	402	Equateur	\N	2	141799
141822	\N	\N	\N	\N	403	Sud Ubangi	\N	2	141799
141823	\N	\N	\N	\N	404	Ville de Zongo	\N	2	141799
141824	\N	\N	\N	\N	405	Nord Ubangi	\N	2	141799
141825	\N	\N	\N	\N	406	Mongala	\N	2	141799
141826	\N	\N	\N	\N	407	Tshuapa	\N	2	141799
141827	\N	\N	\N	\N	501	Ville de Kisangani	\N	2	141800
141828	\N	\N	\N	\N	502	Tshopo	\N	2	141800
141829	\N	\N	\N	\N	503	Bas Uele	\N	2	141800
141830	\N	\N	\N	\N	504	Haut Uele	\N	2	141800
141831	\N	\N	\N	\N	505	Ituri	\N	2	141800
141832	\N	\N	\N	\N	611	Ville de Goma	\N	2	141801
141833	\N	\N	\N	\N	612	Nord Kivu	\N	2	141801
141834	\N	\N	\N	\N	613	Ville de Beni	\N	2	141801
141835	\N	\N	\N	\N	614	Ville de Butembo	\N	2	141801
141836	\N	\N	\N	\N	621	Ville de Kindu	\N	2	141802
141837	\N	\N	\N	\N	622	Maniema	\N	2	141802
141838	\N	\N	\N	\N	631	Ville de Bukavu	\N	2	141803
141839	\N	\N	\N	\N	632	Sud Kivu	\N	2	141803
141840	\N	\N	\N	\N	701	Ville de Lubumbashi	\N	2	141804
141841	\N	\N	\N	\N	702	Ville de Likasi	\N	2	141804
141842	\N	\N	\N	\N	703	Kolwezi	\N	2	141804
141843	\N	\N	\N	\N	704	Lualaba	\N	2	141804
141844	\N	\N	\N	\N	705	Haut Lomami	\N	2	141804
141845	\N	\N	\N	\N	706	Tanganika	\N	2	141804
141846	\N	\N	\N	\N	707	Haut Katanga	\N	2	141804
141847	\N	\N	\N	\N	801	Ville de Mbuji Mayi	\N	2	141805
141848	\N	\N	\N	\N	802	Tshilenge	\N	2	141805
141849	\N	\N	\N	\N	803	Sankuru	\N	2	141805
141850	\N	\N	\N	\N	804	Kabinda	\N	2	141805
141851	\N	\N	\N	\N	805	Ville de Mwene Ditu	\N	2	141805
141852	\N	\N	\N	\N	901	Ville de Kananga	\N	2	141806
141853	\N	\N	\N	\N	902	Lulua	\N	2	141806
141854	\N	\N	\N	\N	903	Kasai	\N	2	141806
141855	\N	\N	\N	\N	904	Ville de Tshikapa	\N	2	141806
141856	15.135868439999999	16.553810160000001	-5.025401885	-3.9368420049999999	1010	Communes rurales de Kinshasa	\N	3	141807
141857	15.190449839999999	15.42475728	-4.4487521369999996	-4.2789999359999999	1020	Communes urbaines de Kinshasa	\N	3	141808
141858	13.41379008	13.551150959999999	-5.8956782370000003	-5.7880798870000003	2010	Communes de Matadi	\N	3	141809
141859	12.98432916	13.114369079999999	-5.8834998909999996	-5.7596438809999997	2020	Communes de Boma	\N	3	141810
141860	12.47080536	13.41581184	-5.3284580459999997	-4.6387340090000002	2031	Tshela	\N	3	141811
141861	13.09199652	13.66503228	-5.879226032	-4.9140214880000004	2032	Seke-Banza	\N	3	141811
141862	12.4732188	13.232333880000001	-5.6736570469999998	-5.098485868	2033	Lukula	\N	3	141811
141863	12.187941840000001	13.39757028	-6.1598023719999997	-5.4542595260000004	2034	Muanda	\N	3	141811
141864	14.186390039999999	15.295384800000001	-5.9107748999999998	-4.7682239519999996	2041	Mbanza Ngungu	\N	3	141812
141865	13.474451520000001	14.659898399999999	-5.9254968549999996	-4.953999896	2042	Songololo	\N	3	141812
141866	13.3760142	14.480509319999999	-5.3395300450000001	-4.298126194	2043	Luozi	\N	3	141812
141867	15.057195480000001	16.039938240000001	-5.8859293790000002	-4.860103981	2051	Madimba	\N	3	141813
141868	14.872779359999999	15.835152239999999	-5.1636219710000004	-4.4486259989999999	2052	Kasangulu	\N	3	141813
141869	15.74911728	16.269254279999998	-5.8785019460000001	-4.9584698200000004	2053	Kimvula	\N	3	141813
141870	17.33865012	17.562924720000002	-3.4398099559999999	-3.1917300059999998	3010	Communes de Bandundu	\N	3	141814
141871	16.637024159999999	19.30508172	-2.7608267049999999	-1.1027753600000001	3021	Inongo	\N	3	141815
141872	18.38973996	19.953706319999998	-2.7119428879999998	-0.736009001	3022	Kiri	\N	3	141815
141873	18.84544344	21.023272080000002	-4.398980033	-1.8948337179999999	3023	Oshwe	\N	3	141815
141874	16.963059959999999	19.051949879999999	-3.6703560130000001	-2.2792149570000002	3024	Kutu	\N	3	141815
141875	18.12079224	19.253685239999999	-5.4151286560000003	-3.97882223	3031	Bulungu	\N	3	141816
141876	17.468164439999999	18.660713399999999	-5.8867366370000003	-4.1391239869999996	3032	Masi Manimba	\N	3	141816
141877	16.497505440000001	18.864938160000001	-4.5665585860000002	-3.2936400570000002	3033	Bagata	\N	3	141816
141878	18.672884280000002	20.190669840000002	-5.7549916129999996	-3.659099984	3034	Idiofa	\N	3	141816
141879	18.298721159999999	20.20380012	-6.3913747079999998	-5.1440250010000002	3035	Gungu	\N	3	141816
141880	18.75119724	18.861473159999999	-5.1069985979999997	-5.0076865100000001	3040	Communes de Kikwit	\N	3	141817
141881	16.245908279999998	17.825727239999999	-5.973807474	-4.2331379770000002	3051	Kenge	\N	3	141818
141882	17.27796348	19.396373400000002	-6.9829062579999999	-5.6285998609999996	3052	Feshi	\N	3	141818
141883	17.885000160000001	19.969961399999999	-8.1129999829999999	-6.2816250199999999	3053	Kahemba	\N	3	141818
141884	16.68750228	18.64662336	-8.1290649679999998	-5.8921500529999999	3054	Kasongo Lunda	\N	3	141818
141885	16.139431439999999	17.190237239999998	-6.1394020239999998	-4.8866886110000003	3055	Popokabaka	\N	3	141818
141886	16.172301959999999	16.713730080000001	-3.1790000379999999	-2.1230000260000002	3061	Bolobo	\N	3	141819
141887	15.907705200000001	17.380890000000001	-4.2280079429999997	-3.015430093	3062	Kwamouth	\N	3	141819
141888	16.43223528	17.950346280000002	-3.046019958	-2.0014199939999999	3063	Mushie	\N	3	141819
141889	16.24200012	16.691808600000002	-2.3305782380000002	-1.862830078	3064	Yumbie	\N	3	141819
141890	18.101364480000001	18.39472992	-0.245066957	0.076499999999999999	4010	Communes de Mbandaka	\N	3	141820
141891	19.271249999999998	20.714799240000001	0.352310075	1.7567308189999999	4021	Basankusu	\N	3	141821
142070	\N	\N	\N	\N	203105	Tshela_Banga	\N	4	141860
141892	18.28182996	20.57699916	-0.27447001799999998	1.4580826010000001	4022	Bolomba	\N	3	141821
141893	18.491000039999999	20.28381984	-1.424721184	-0.012500000000000001	4023	Ingende	\N	3	141821
141894	17.499524399999999	18.87099984	-1.479804371	-0.022499999999999999	4024	Bikoro	\N	3	141821
141895	16.503999839999999	17.810309879999998	-2.0012663490000002	-0.555499988	4025	Lukolela	\N	3	141821
141896	18.171011879999998	19.908050039999999	0.48943927999999998	2.0394270209999998	4026	Makanza	\N	3	141821
141897	17.703050040000001	19.449819720000001	-0.563609943	2.126355985	4027	Bomongo	\N	3	141821
141898	19.071382320000001	20.285799839999999	2.7850631699999999	4.0849960320000003	4031	Gemena	\N	3	141822
141899	19.125467279999999	20.91630348	2.003682151	3.1883521469999998	4032	Budjala	\N	3	141822
141900	18.06500016	19.332880200000002	1.9023299819999999	3.1953720209999998	4033	Kungu	\N	3	141822
141901	18.42099984	19.518646319999998	2.7520000150000001	4.7769020790000001	4034	Libenge	\N	3	141822
141902	18.546000119999999	18.867956400000001	3.968717759	4.3866781259999996	4040	Communes de Zongo	\N	3	141823
141903	20.355352199999999	21.96500004	3.5833949829999998	4.6770000349999998	4051	Mobayi Mbongo	\N	3	141824
141904	21.257963279999998	23.53307148	2.9443440540000001	4.2400000760000003	4052	Yakoma	\N	3	141824
141905	19.88787636	22.117367160000001	2.816828031	4.0692710380000001	4053	Businga	\N	3	141824
141906	19.014000119999999	20.40500016	3.8962801499999999	5.1460000189999997	4054	Bosobolo	\N	3	141824
141907	19.813550039999999	21.814903439999998	1.8501499779999999	3.247450003	4061	Lisala	\N	3	141825
141908	21.644220239999999	23.579769240000001	2.0175199859999999	3.3333297919999998	4062	Bumba	\N	3	141825
141909	19.208530079999999	22.491285479999998	0.72561756799999999	2.2162600619999999	4063	Bongandanga	\N	3	141825
141910	19.822960080000001	21.945887280000001	-1.2004599949999999	0.21355997400000001	4071	Boende	\N	3	141826
141911	20.295061199999999	22.278277800000001	-0.043900000000000002	1.235636129	4072	Befale	\N	3	141826
141912	21.56414148	23.356514520000001	-0.40365092600000002	1.7626171500000001	4073	Djolu	\N	3	141826
141913	22.338716399999999	24.44404428	-2.0877900129999998	0.114617003	4074	Ikela	\N	3	141826
141914	21.353720039999999	23.038645320000001	-1.9168038110000001	0.12023992999999999	4075	Bokungu	\N	3	141826
141915	19.43327124	22.22416836	-2.5323872600000001	-0.66469997400000003	4076	Monkoto	\N	3	141826
141916	24.861998159999999	25.521006239999998	0.12382063	0.96328755899999996	5010	Communes de Kisangani	\N	3	141827
141917	24.302187719999999	26.6262264	0.61645836600000004	2.3643620940000001	5021	Banalia	\N	3	141828
141918	25.351345439999999	28.15446816	-0.59617436599999996	2.1942031950000001	5022	Bafwasende	\N	3	141828
141919	24.370482240000001	26.763714360000002	-2.1119838240000002	0.92147865299999998	5023	Ubundu	\N	3	141828
141920	23.25526236	25.14873528	-1.9815548780000001	0.56090782800000005	5024	Opala	\N	3	141828
141921	23.576151240000002	25.043785920000001	-0.38958743200000001	1.1095699779999999	5025	Isangi	\N	3	141828
141922	22.24727244	23.803769880000001	-0.55947792100000004	2.162040041	5026	Yahuma	\N	3	141828
141923	22.680870120000002	25.170073559999999	0.57853634799999998	2.396248575	5027	Basoko	\N	3	141828
141924	24.16626252	25.921026359999999	2.167692052	3.502820066	5031	Buta	\N	3	141829
141925	22.574490839999999	24.866647199999999	2.0756961180000002	3.7714010789999999	5032	Aketi	\N	3	141829
141926	22.44521988	25.544853360000001	3.3936499069999999	5.1128239960000004	5033	Bondo	\N	3	141829
141927	24.693163200000001	27.29470392	3.5045799550000001	5.3860981539999999	5034	Ango	\N	3	141829
141928	25.121720159999999	26.55534132	2.2028560760000002	3.7406499549999999	5035	Bambesa	\N	3	141829
141929	26.124521399999999	27.705705120000001	1.9411913119999999	4.0240700199999999	5036	Poko	\N	3	141829
141930	26.89323624	28.504566359999998	1.896028007	3.3191291110000001	5041	Rungu	\N	3	141830
141931	27.243500040000001	28.54193544	2.9363010439999999	4.0670880450000002	5042	Niangara	\N	3	141830
141932	26.92889856	29.840793479999999	2.8006639849999999	5.2067070089999996	5043	Dungu	\N	3	141830
141933	29.348121240000001	30.5798652	2.5843165699999999	4.3875221719999997	5044	Faradje	\N	3	141830
141934	28.311553799999999	30.194191440000001	2.0557211550000001	3.4839971570000001	5045	Watsha	\N	3	141830
141935	27.194742000000002	28.3738572	1.443248039	2.7485061169999998	5046	Wamba	\N	3	141830
141936	29.289917519999999	30.632539999999999	0.78871801600000002	1.745090152	5051	Irumu	\N	3	141831
141937	27.446990039999999	30.000000239999999	0.51961808899999995	2.5437209890000001	5052	Mambasa	\N	3	141831
141938	29.623023360000001	31.143999999999998	1.4097294659999999	2.4168210000000001	5053	Djugu	\N	3	141831
141939	30.125604240000001	31.306000000000001	1.901	2.891498871	5054	Mahagi	\N	3	141831
141940	30.11187816	30.935999880000001	2.380618401	3.6749999679999998	5055	Aru	\N	3	141831
141941	29.14249212	29.252382839999999	-1.706380002	-1.6104308570000001	6110	Communes de Goma	\N	3	141832
141942	27.22714452	29.068933319999999	-2.0657701780000002	-0.102374994	6122	Walikale	\N	3	141833
141943	27.796600080000001	29.757846959999998	-0.82207255700000004	0.69782784499999995	6123	Lubero	\N	3	141833
141944	28.9987542	29.992703760000001	-0.152484593	0.95419910900000005	6124	Beni	\N	3	141833
141945	28.943838360000001	29.683966680000001	-1.476577469	-0.44543015699999999	6125	Rutshuru	\N	3	141833
141946	28.514481480000001	29.22362244	-1.7818550040000001	-0.970157987	6126	Masisi	\N	3	141833
141947	29.153131559999999	29.48595984	-1.6622870569999999	-1.437764195	6127	Nyiragongo	\N	3	141833
141948	29.35417644	29.55219228	0.37640866299999998	0.58549499800000004	6130	Communes de Beni	\N	3	141834
141949	29.1889404	29.36531124	0.060600000000000001	0.21471058000000001	6140	Communes de Butembo	\N	3	141835
141950	25.854858360000001	25.974161639999998	-3.0421492090000002	-2.9081467179999998	6210	Communes de Kindu	\N	3	141836
141951	26.899645320000001	28.8017568	-5.0197248810000001	-3.820572887	6221	Kabambare	\N	3	141837
141952	24.730530479999999	26.112112199999999	-4.9988539550000004	-3.1646143219999998	6222	Kibombo	\N	3	141837
141953	26.03357424	27.841009679999999	-1.41738002	-0.0138	6223	Lubutu	\N	3	141837
141954	25.880406480000001	27.13515984	-3.9337065949999999	-2.3298629489999998	6224	Pangi	\N	3	141837
141955	25.65714492	27.136711439999999	-5.0011184799999997	-3.3465500480000001	6225	Kasongo	\N	3	141837
141956	25.808605199999999	27.7562502	-2.2679499569999999	-1.1425400290000001	6226	Punia	\N	3	141837
141957	24.598389959999999	26.873700119999999	-3.353408489	-1.766070034	6227	Kindu	\N	3	141837
141958	28.791734040000001	28.89218988	-2.5611686410000001	-2.4675740830000001	6310	Communes de Bukavu	\N	3	141838
141959	28.30146624	29.033951399999999	-2.9987469779999998	-2.4943929890000001	6321	Walungu	\N	3	141839
141960	28.78232148	29.247135119999999	-3.659769968	-2.743856992	6322	Uvira	\N	3	141839
141961	27.822326400000001	29.389096080000002	-5.0103452649999998	-3.5418349170000001	6323	Fizi	\N	3	141839
141962	27.696968640000001	28.89215424	-3.9977564490000002	-2.7862413890000002	6324	Mwenga	\N	3	141839
141963	26.810641799999999	28.377258479999998	-4.0223881419999996	-1.9912210640000001	6325	Shabunda	\N	3	141839
141964	28.151165160000001	29.105690039999999	-2.4850333899999999	-1.621960099	6326	Kalehe	\N	3	141839
141965	28.834939800000001	29.23801452	-2.4988300419999998	-1.588550087	6327	Idjwi	\N	3	141839
141966	28.207483920000001	28.979589959999998	-2.6440383829999998	-2.1264211849999999	6328	Kabare	\N	3	141839
141967	27.299956680000001	27.6360642	-11.83031514	-11.481627100000001	7010	Communes de Lubumbashi	\N	3	141840
141968	26.630733240000001	26.87957244	-11.045499939999999	-10.87974485	7020	Communes de Likasi	\N	3	141841
141969	24.1074792	25.94727	-11.73934691	-9.9806300720000003	7033	Mutshatsha	\N	3	141842
141970	24.980811119999998	27.187976880000001	-11.228709050000001	-9.4871930300000002	7034	Lubudi	\N	3	141842
141971	22.17399984	24.40542816	-11.250999910000001	-9.8270949529999996	7041	Dilolo	\N	3	141843
141972	21.794063399999999	24.575339159999999	-10.103665469999999	-8.6628057389999995	7042	Sandoa	\N	3	141843
141973	21.744749880000001	23.729001480000001	-9.3410498279999992	-7.6372199539999999	7043	Kapanga	\N	3	141843
141974	23.973032159999999	25.934268960000001	-10.129914960000001	-7.1403669179999998	7051	Kamina	\N	3	141844
141975	23.640091200000001	24.668084879999999	-8.7904669989999995	-6.9012159449999997	7052	Kaniama	\N	3	141844
141976	24.593393160000002	26.485658279999999	-8.0444209260000008	-6.1440409640000002	7053	Kabongo	\N	3	141844
141977	25.995929400000001	27.85420044	-8.7812749960000005	-7.3391209699999997	7054	Malemba Nkulu	\N	3	141844
141978	25.478295840000001	26.832539879999999	-9.7225830260000006	-7.9436118779999996	7055	Bukama	\N	3	141844
141979	28.032369840000001	29.708765639999999	-7.1326558760000003	-5.0079999810000002	7061	Kalemie	\N	3	141845
141980	28.395438840000001	30.793182120000001	-8.3954950620000002	-6.497260056	7062	Moba	\N	3	141845
141981	26.006155920000001	28.776650759999999	-8.4123418759999993	-6.4299138820000001	7063	Manono	\N	3	141845
141982	25.930320120000001	28.022367240000001	-6.7097550239999997	-5.6594499709999999	7064	Kabalo	\N	3	141845
141983	26.103601439999998	27.73209924	-5.8655908700000001	-4.9995205839999999	7065	Kongolo	\N	3	141845
141984	27.048592079999999	28.61365932	-6.7092370460000001	-5.0100246139999998	7066	Nyunzu	\N	3	141845
141985	27.204674399999998	28.523571480000001	-12.286999939999999	-10.95834389	7071	Kipushi	\N	3	141846
141986	27.671411519999999	29.810999880000001	-13.45599996	-11.74291682	7072	Sakania	\N	3	141846
141987	26.979945839999999	28.69705008	-11.371813680000001	-9.3626999679999994	7073	Kasenga	\N	3	141846
141988	26.26600608	27.990812519999999	-10.14955187	-8.0762133939999998	7074	Mitwaba	\N	3	141846
141989	27.613115279999999	29.668592520000001	-9.7729939699999999	-7.622684628	7075	Pweto	\N	3	141846
141990	25.484000040000002	27.541030679999999	-12.008999899999999	-10.46096694	7076	Kambove	\N	3	141846
141991	23.530777919999998	23.683859999999999	-6.1725099910000001	-6.0503382759999997	8010	Communes de Mbuji Mayi	\N	3	141847
141992	23.131418400000001	23.52224988	-6.6069179130000002	-5.9783499899999999	8021	Miabi	\N	3	141848
141993	22.948618320000001	23.48106516	-6.3592770200000004	-5.6966399870000002	8022	Kabeya Kamwanga	\N	3	141848
141994	23.364046800000001	23.767210080000002	-6.4190300420000002	-5.6269600310000003	8023	Lupatapata	\N	3	141848
141995	23.63889996	24.174755279999999	-6.4121800179999999	-5.7418029519999996	8024	Katanda	\N	3	141848
141996	23.416509959999999	23.844359879999999	-6.7717393169999998	-6.1580700610000001	8025	Tshilenge	\N	3	141848
141997	22.905082440000001	24.199672320000001	-5.8495169479999998	-4.1688289010000004	8031	Lusambo	\N	3	141849
141998	21.83095548	23.44479084	-4.5483848949999999	-2.300831471	8032	Kole	\N	3	141849
141999	22.102786439999999	24.694308360000001	-3.0960445189999999	-1.6974750199999999	8033	Lomela	\N	3	141849
142000	23.52338748	25.11240012	-4.3843578499999998	-2.3625202500000002	8034	Katako Kombe	\N	3	141849
142001	23.699760120000001	25.02051552	-5.4104594400000003	-3.967078018	8035	Lubefu	\N	3	141849
142002	22.996150199999999	23.980685399999999	-4.2143460179999996	-2.819256947	8036	Lodja	\N	3	141849
142003	23.170541400000001	24.158144159999999	-7.9796309179999998	-6.6448479709999999	8041	Mwene Ditu	\N	3	141850
142004	23.02002324	23.44668012	-6.9183175390000002	-6.4583528750000001	8042	Kamiji	\N	3	141850
142005	23.727922199999998	24.93241956	-7.0587250040000002	-6.3440850199999996	8043	Ngandajika	\N	3	141850
142006	23.955644880000001	25.46685252	-6.8086399630000001	-5.3419167910000001	8044	Kabinda	\N	3	141850
142007	24.515938800000001	26.270477280000001	-6.3203054359999999	-4.8352870130000003	8045	Lubao	\N	3	141850
142008	23.40652176	23.552982	-7.0434116250000001	-6.9313571530000004	8050	Communes de Mwene Ditu	\N	3	141851
142009	22.246509960000001	22.684011479999999	-6.0437285449999996	-5.7481079060000004	9010	Communes de Kananga	\N	3	141852
142010	22.39434	23.280121439999999	-6.9520234939999996	-5.8268509880000003	9021	Dibaya	\N	3	141853
142011	21.653639999999999	23.27366232	-7.8959899880000002	-6.5072300729999997	9022	Luiza	\N	3	141853
142012	21.400459919999999	22.484440079999999	-7.0990070019999996	-5.7029782620000002	9023	Kazumba	\N	3	141853
142013	21.62418984	22.847974199999999	-5.853950062	-4.6196179920000002	9024	Demba	\N	3	141853
142014	22.34762388	23.756244479999999	-5.8501379839999998	-4.1988608899999997	9025	Dibelenge	\N	3	141853
142015	20.833986240000002	21.977262360000001	-6.141717646	-5.0432499809999998	9031	Luebo	\N	3	141854
142016	19.68013728	21.78754992	-7.2989049030000004	-5.7341128609999998	9032	Tshikapa	\N	3	141854
142017	20.032970039999999	21.11252004	-5.9043929210000003	-4.2073799779999996	9033	Ilebo	\N	3	141854
142018	20.627049960000001	22.535791199999998	-5.3436788970000002	-3.9570900889999998	9034	Mweka	\N	3	141854
142019	20.625275519999999	22.221348840000001	-4.1589198989999998	-2.3096029269999998	9035	Dekese	\N	3	141854
142020	20.66368572	20.903163840000001	-6.5353574029999999	-6.3475740009999999	9040	Communes de Tshikapa	\N	3	141855
142021	\N	\N	\N	\N	-12648307	alex test 2	\N	4	141938
142022	\N	\N	\N	\N	-12648198	alex test	\N	4	141938
142023	\N	\N	\N	\N	-12140930	MAMBISA	\N	4	141938
142024	\N	\N	\N	\N	-6079770	Beni Mbau	\N	4	141944
142025	\N	\N	\N	\N	-6079607	Beni Mbau	\N	4	141944
142026	\N	\N	\N	\N	-6078622	Beni Mbau	\N	4	141944
142027	\N	\N	\N	\N	-5937298	Bunyakiri	\N	4	141964
142028	\N	\N	\N	\N	-2426035	Baswagha	\N	4	141944
142029	\N	\N	\N	\N	-2407350	Kalima	\N	4	141964
142030	\N	\N	\N	\N	-1942622	Makabango	\N	4	141963
142031	\N	\N	\N	\N	-1869115	Basitabyale	\N	4	141963
142032	\N	\N	\N	\N	101100	00	\N	4	141857
142033	\N	\N	\N	\N	101200	00	\N	4	141856
142034	\N	\N	\N	\N	101300	00	\N	4	141856
142035	\N	\N	\N	\N	101400	00	\N	4	141856
142036	\N	\N	\N	\N	101500	00	\N	4	141856
142037	\N	\N	\N	\N	101600	00	\N	4	141856
142038	\N	\N	\N	\N	101700	00	\N	4	141856
142039	\N	\N	\N	\N	102100	00	\N	4	141857
142040	\N	\N	\N	\N	102200	00	\N	4	141857
142041	\N	\N	\N	\N	102300	00	\N	4	141857
142042	\N	\N	\N	\N	102400	00	\N	4	141857
142043	\N	\N	\N	\N	102500	00	\N	4	141857
142044	\N	\N	\N	\N	102600	00	\N	4	141857
142045	\N	\N	\N	\N	102700	00	\N	4	141857
142046	\N	\N	\N	\N	103100	00	\N	4	141856
142047	\N	\N	\N	\N	103200	00	\N	4	141856
142048	\N	\N	\N	\N	103300	00	\N	4	141856
142049	\N	\N	\N	\N	103400	00	\N	4	141856
142050	\N	\N	\N	\N	103500	00	\N	4	141856
142051	\N	\N	\N	\N	104100	00	\N	4	141856
142052	\N	\N	\N	\N	104200	00	\N	4	141856
142053	\N	\N	\N	\N	104300	00	\N	4	141856
142054	\N	\N	\N	\N	104400	00	\N	4	141856
142055	\N	\N	\N	\N	104500	00	\N	4	141856
142056	\N	\N	\N	\N	201100	00	\N	4	141858
142057	\N	\N	\N	\N	201200	00	\N	4	141858
142058	\N	\N	\N	\N	201300	00	\N	4	141858
142059	\N	\N	\N	\N	202100	00	\N	4	141859
142060	\N	\N	\N	\N	202200	00	\N	4	141859
142061	\N	\N	\N	\N	202300	00	\N	4	141859
142062	\N	\N	\N	\N	202401	Assolongo	\N	4	141859
142063	\N	\N	\N	\N	202402	De La  Mer	\N	4	141859
142064	\N	\N	\N	\N	202403	Boma_Bungu	\N	4	141859
142065	\N	\N	\N	\N	202451	Moanda	\N	4	141859
142066	\N	\N	\N	\N	203101	Nzobe_Luzi	\N	4	141860
142067	\N	\N	\N	\N	203102	Lubolo	\N	4	141860
142068	\N	\N	\N	\N	203103	Nganda_Nsundi	\N	4	141860
142069	\N	\N	\N	\N	203104	Maduda	\N	4	141860
142071	\N	\N	\N	\N	203106	Loango	\N	4	141860
142072	\N	\N	\N	\N	203107	Bula_Naku	\N	4	141860
142073	\N	\N	\N	\N	203108	Lubuzi	\N	4	141860
142074	\N	\N	\N	\N	203151	Tshela	\N	4	141860
142075	\N	\N	\N	\N	203201	Bundi	\N	4	141861
142076	\N	\N	\N	\N	203202	Mbavu	\N	4	141861
142077	\N	\N	\N	\N	203203	Sumbi	\N	4	141861
142078	\N	\N	\N	\N	203204	Isangila	\N	4	141861
142079	\N	\N	\N	\N	203205	Lufu	\N	4	141861
142080	\N	\N	\N	\N	203251	Seke-Banza	\N	4	141861
142081	\N	\N	\N	\N	203252	Kinzao- Mvuete	\N	4	141861
142082	\N	\N	\N	\N	203253	Inga	\N	4	141861
142083	\N	\N	\N	\N	203301	Kakongo	\N	4	141862
142084	\N	\N	\N	\N	203302	Tsundi_Sud	\N	4	141862
142085	\N	\N	\N	\N	203303	Fubu	\N	4	141862
142086	\N	\N	\N	\N	203304	Tsanga_Sud	\N	4	141862
142087	\N	\N	\N	\N	203305	Patu	\N	4	141862
142088	\N	\N	\N	\N	203351	Lukula	\N	4	141862
142089	\N	\N	\N	\N	203352	Cite Patu	\N	4	141862
142090	\N	\N	\N	\N	204101	Gombe_Sud	\N	4	141864
142091	\N	\N	\N	\N	204102	Kwilu_Ngongo	\N	4	141864
142092	\N	\N	\N	\N	204103	Ntimansi	\N	4	141864
142093	\N	\N	\N	\N	204104	Gombe_Matadi	\N	4	141864
142094	\N	\N	\N	\N	204105	Lunzadi	\N	4	141864
142095	\N	\N	\N	\N	204106	Boko	\N	4	141864
142096	\N	\N	\N	\N	204107	Kivulu	\N	4	141864
142097	\N	\N	\N	\N	204151	Mbanza_Ngungu               ?	\N	4	141864
142098	\N	\N	\N	\N	204201	Palabala	\N	4	141865
142099	\N	\N	\N	\N	204202	Bamboma	\N	4	141865
142100	\N	\N	\N	\N	204203	Luima	\N	4	141865
142101	\N	\N	\N	\N	204204	Wombo	\N	4	141865
142102	\N	\N	\N	\N	204205	Kimpese	\N	4	141865
142103	\N	\N	\N	\N	204251	Songololo	\N	4	141865
142104	\N	\N	\N	\N	204252	Kimpese	\N	4	141865
142105	\N	\N	\N	\N	204301	Mbanza_Mwembe	\N	4	141866
142106	\N	\N	\N	\N	204302	Kinkenge	\N	4	141866
142107	\N	\N	\N	\N	204303	Mongo_Luala	\N	4	141866
142108	\N	\N	\N	\N	204304	Kenge	\N	4	141866
142109	\N	\N	\N	\N	204305	Balari	\N	4	141866
142110	\N	\N	\N	\N	204306	Kivunda	\N	4	141866
142111	\N	\N	\N	\N	204307	Kimbanza	\N	4	141866
142112	\N	\N	\N	\N	204308	Mbanza_Ngoyo	\N	4	141866
142113	\N	\N	\N	\N	204309	Mbanza_Mona	\N	4	141866
142114	\N	\N	\N	\N	204310	Kimumba	\N	4	141866
142115	\N	\N	\N	\N	204351	Luozi	\N	4	141866
142116	\N	\N	\N	\N	205101	Mfidi_Malele	\N	4	141867
142117	\N	\N	\N	\N	205102	Wungu	\N	4	141867
142118	\N	\N	\N	\N	205103	Ngeba	\N	4	141867
142119	\N	\N	\N	\N	205104	Ngufu	\N	4	141867
142120	\N	\N	\N	\N	205105	Mfuma_Kibambi	\N	4	141867
142121	\N	\N	\N	\N	205106	Kinkosi_Luidi	\N	4	141867
142122	\N	\N	\N	\N	205151	Inkisi	\N	4	141867
142123	\N	\N	\N	\N	205152	Kikonka	\N	4	141867
142124	\N	\N	\N	\N	205153	Nkandu	\N	4	141867
142125	\N	\N	\N	\N	205154	Kintanu	\N	4	141867
142126	\N	\N	\N	\N	205201	Luila	\N	4	141868
142127	\N	\N	\N	\N	205202	Kasangulu	\N	4	141868
142128	\N	\N	\N	\N	205203	Lukunga_Mputu	\N	4	141868
142129	\N	\N	\N	\N	205251	Kasangulu	\N	4	141868
142130	\N	\N	\N	\N	205301	Benga	\N	4	141869
142131	\N	\N	\N	\N	205302	Lula_Lumene	\N	4	141869
142132	\N	\N	\N	\N	205303	Lubisi	\N	4	141869
142133	\N	\N	\N	\N	205351	Kimvula	\N	4	141869
142134	\N	\N	\N	\N	301100	00	\N	4	141870
142135	\N	\N	\N	\N	301200	00	\N	4	141870
142136	\N	\N	\N	\N	301300	00	\N	4	141870
142137	\N	\N	\N	\N	302101	Basengele	\N	4	141871
142138	\N	\N	\N	\N	302102	Bolia	\N	4	141871
142139	\N	\N	\N	\N	302103	Inongo	\N	4	141871
142140	\N	\N	\N	\N	302151	Inongo	\N	4	141871
142141	\N	\N	\N	\N	302201	Beronge	\N	4	141872
142142	\N	\N	\N	\N	302202	Lotoy	\N	4	141872
142143	\N	\N	\N	\N	302203	Pendjua	\N	4	141872
142144	\N	\N	\N	\N	302251	Kiri	\N	4	141872
142145	\N	\N	\N	\N	302301	Lukenie	\N	4	141873
142146	\N	\N	\N	\N	302302	E.L.L. Nkaw	\N	4	141873
142147	\N	\N	\N	\N	302303	Lokolama	\N	4	141873
142148	\N	\N	\N	\N	302304	Kangara	\N	4	141873
142149	\N	\N	\N	\N	302351	Oshwe	\N	4	141873
142150	\N	\N	\N	\N	302401	Mfimi	\N	4	141874
142151	\N	\N	\N	\N	302402	Badia	\N	4	141874
142152	\N	\N	\N	\N	302403	Luabu	\N	4	141874
142153	\N	\N	\N	\N	302404	Batere	\N	4	141874
142154	\N	\N	\N	\N	302405	Kemba	\N	4	141874
142155	\N	\N	\N	\N	302451	Kutu	\N	4	141874
142156	\N	\N	\N	\N	302452	Nioki	\N	4	141874
142157	\N	\N	\N	\N	302453	Semendua	\N	4	141874
142158	\N	\N	\N	\N	302501	Baboma_Nord	\N	4	141871
142159	\N	\N	\N	\N	302551	Mushie	\N	4	141871
142160	\N	\N	\N	\N	302601	Bateke_Nord	\N	4	141871
142161	\N	\N	\N	\N	302651	Bolobo	\N	4	141871
142162	\N	\N	\N	\N	302701	Bateke-Sud	\N	4	141871
142163	\N	\N	\N	\N	302751	Kwamouth	\N	4	141871
142164	\N	\N	\N	\N	302801	Banunu (Mongama)	\N	4	141871
142165	\N	\N	\N	\N	302851	Yumbi	\N	4	141871
142166	\N	\N	\N	\N	303101	Kipuka	\N	4	141875
142167	\N	\N	\N	\N	303102	Kwenge	\N	4	141875
142168	\N	\N	\N	\N	303103	Nko	\N	4	141875
142169	\N	\N	\N	\N	303104	Luniungu	\N	4	141875
142170	\N	\N	\N	\N	303105	Kilunda	\N	4	141875
142171	\N	\N	\N	\N	303106	Mikwi	\N	4	141875
142172	\N	\N	\N	\N	303107	Kwilu_Kimbata	\N	4	141875
142173	\N	\N	\N	\N	303108	Dwe	\N	4	141875
142174	\N	\N	\N	\N	303109	Niadi_Nkara	\N	4	141875
142175	\N	\N	\N	\N	303110	Imbongo	\N	4	141875
142176	\N	\N	\N	\N	303151	Bulungu	\N	4	141875
142177	\N	\N	\N	\N	303201	Bindungi	\N	4	141876
142178	\N	\N	\N	\N	303202	Kinzenga	\N	4	141876
142179	\N	\N	\N	\N	303203	Kitoy	\N	4	141876
142180	\N	\N	\N	\N	303204	Mokamo	\N	4	141876
142181	\N	\N	\N	\N	303205	Mosango	\N	4	141876
142182	\N	\N	\N	\N	303206	Pay_Kongila	\N	4	141876
142183	\N	\N	\N	\N	303207	Sungu	\N	4	141876
142184	\N	\N	\N	\N	303208	Kibolo	\N	4	141876
142185	\N	\N	\N	\N	303209	Kinzenzengo	\N	4	141876
142186	\N	\N	\N	\N	303210	Masi_Manimba	\N	4	141876
142187	\N	\N	\N	\N	303251	Masi_Manimba	\N	4	141876
142188	\N	\N	\N	\N	303301	Wamba	\N	4	141877
142189	\N	\N	\N	\N	303302	Kwango_Kasai	\N	4	141877
142190	\N	\N	\N	\N	303303	Kwilu_Ntobere	\N	4	141877
142191	\N	\N	\N	\N	303304	Kizweme	\N	4	141877
142192	\N	\N	\N	\N	303305	Manzasay	\N	4	141877
142193	\N	\N	\N	\N	303351	Bagata	\N	4	141877
142194	\N	\N	\N	\N	303352	Fatundu	\N	4	141877
142195	\N	\N	\N	\N	303401	Yassa_Lokwa	\N	4	141878
142196	\N	\N	\N	\N	303402	Kanga	\N	4	141878
142197	\N	\N	\N	\N	303403	Kalanganda	\N	4	141878
142198	\N	\N	\N	\N	303404	Bulwem	\N	4	141878
142199	\N	\N	\N	\N	303405	Sedzo	\N	4	141878
142200	\N	\N	\N	\N	303406	Mateko	\N	4	141878
142201	\N	\N	\N	\N	303407	Kapia	\N	4	141878
142202	\N	\N	\N	\N	303408	Kipuku	\N	4	141878
142203	\N	\N	\N	\N	303409	Belo	\N	4	141878
142204	\N	\N	\N	\N	303410	Madimbi	\N	4	141878
142205	\N	\N	\N	\N	303411	Musanga_Idiofa	\N	4	141878
142206	\N	\N	\N	\N	303412	Banga	\N	4	141878
142207	\N	\N	\N	\N	303451	Idiofa	\N	4	141878
142208	\N	\N	\N	\N	303452	Mangai	\N	4	141878
142209	\N	\N	\N	\N	303453	Dibaya_Lubue	\N	4	141878
142210	\N	\N	\N	\N	303454	Panu	\N	4	141878
142211	\N	\N	\N	\N	303501	Kobo	\N	4	141879
142212	\N	\N	\N	\N	303502	Mulikalunga	\N	4	141879
142213	\N	\N	\N	\N	303503	Kisunzu	\N	4	141879
142214	\N	\N	\N	\N	303504	Mungindu	\N	4	141879
142215	\N	\N	\N	\N	303505	Kilamba	\N	4	141879
142216	\N	\N	\N	\N	303506	Lukamba	\N	4	141879
142217	\N	\N	\N	\N	303507	Gungu	\N	4	141879
142218	\N	\N	\N	\N	303508	Lozo	\N	4	141879
142219	\N	\N	\N	\N	303509	Ngudi	\N	4	141879
142220	\N	\N	\N	\N	303510	Kilembe	\N	4	141879
142221	\N	\N	\N	\N	303511	Kondo	\N	4	141879
142222	\N	\N	\N	\N	303512	Kandale	\N	4	141879
142223	\N	\N	\N	\N	303551	Gungu	\N	4	141879
142224	\N	\N	\N	\N	304100	00	\N	4	141880
142225	\N	\N	\N	\N	304200	00	\N	4	141880
142226	\N	\N	\N	\N	304300	00	\N	4	141880
142227	\N	\N	\N	\N	304400	00	\N	4	141880
142228	\N	\N	\N	\N	305101	Dinga	\N	4	141881
142229	\N	\N	\N	\N	305102	Bukanga_Lonzo	\N	4	141881
142230	\N	\N	\N	\N	305103	Pelende_Nord	\N	4	141881
142231	\N	\N	\N	\N	305104	Kolokoso	\N	4	141881
142232	\N	\N	\N	\N	305105	Mosamba	\N	4	141881
142233	\N	\N	\N	\N	305151	Kenge	\N	4	141881
142234	\N	\N	\N	\N	305201	Nganaketi	\N	4	141882
142235	\N	\N	\N	\N	305202	Lobo	\N	4	141882
142236	\N	\N	\N	\N	305203	Feshi	\N	4	141882
142237	\N	\N	\N	\N	305204	Mukoso	\N	4	141882
142238	\N	\N	\N	\N	305251	Feshi	\N	4	141882
142239	\N	\N	\N	\N	305301	Kulindji	\N	4	141883
142240	\N	\N	\N	\N	305302	Mwendjila	\N	4	141883
142241	\N	\N	\N	\N	305303	Muloshi	\N	4	141883
142242	\N	\N	\N	\N	305304	Bangu	\N	4	141883
142243	\N	\N	\N	\N	305305	Mwa_Mushiko	\N	4	141883
142244	\N	\N	\N	\N	305306	Bindu	\N	4	141883
142245	\N	\N	\N	\N	305351	Kahemba	\N	4	141883
142246	\N	\N	\N	\N	305401	Kizamba	\N	4	141884
142247	\N	\N	\N	\N	305402	Swa_Tenda	\N	4	141884
142248	\N	\N	\N	\N	305403	Kasongo_Lunda	\N	4	141884
142249	\N	\N	\N	\N	305404	Mawanga	\N	4	141884
142250	\N	\N	\N	\N	305405	Kibunda	\N	4	141884
142251	\N	\N	\N	\N	305406	Panzi	\N	4	141884
142252	\N	\N	\N	\N	305407	Kasa	\N	4	141884
142253	\N	\N	\N	\N	305408	Kingulu	\N	4	141884
142254	\N	\N	\N	\N	305451	Kasongo_Lunda	\N	4	141884
142255	\N	\N	\N	\N	305501	Yonso	\N	4	141885
142256	\N	\N	\N	\N	305502	Popokabaka	\N	4	141885
142257	\N	\N	\N	\N	305503	Lufuna	\N	4	141885
142258	\N	\N	\N	\N	305551	Popokabaka	\N	4	141885
142259	\N	\N	\N	\N	401100	00	\N	4	141890
142260	\N	\N	\N	\N	401200	00	\N	4	141890
142261	\N	\N	\N	\N	402101	Waka_Bokeka	\N	4	141891
142262	\N	\N	\N	\N	402102	Basankusu	\N	4	141891
142263	\N	\N	\N	\N	402103	Gombalo	\N	4	141891
142264	\N	\N	\N	\N	402151	Basankusu	\N	4	141891
142265	\N	\N	\N	\N	402201	Dianga	\N	4	141892
142266	\N	\N	\N	\N	402202	Mampoko	\N	4	141892
142267	\N	\N	\N	\N	402203	Bolomba	\N	4	141892
142268	\N	\N	\N	\N	402204	Busira	\N	4	141892
142269	\N	\N	\N	\N	402205	Lusangania	\N	4	141892
142270	\N	\N	\N	\N	402251	Bolomba	\N	4	141892
142271	\N	\N	\N	\N	402301	Bokatola	\N	4	141893
142272	\N	\N	\N	\N	402302	Duali	\N	4	141893
142273	\N	\N	\N	\N	402303	Eungu	\N	4	141893
142274	\N	\N	\N	\N	402351	Ingende	\N	4	141893
142275	\N	\N	\N	\N	402401	Lac Ntomba	\N	4	141894
142276	\N	\N	\N	\N	402402	Elanga	\N	4	141894
142277	\N	\N	\N	\N	402403	Ekonda	\N	4	141894
142278	\N	\N	\N	\N	402451	Bikoro	\N	4	141894
142279	\N	\N	\N	\N	402501	Banunu	\N	4	141895
142280	\N	\N	\N	\N	402502	Mpama	\N	4	141895
142281	\N	\N	\N	\N	402503	Lusakania	\N	4	141895
142282	\N	\N	\N	\N	402551	Lukolela	\N	4	141895
142283	\N	\N	\N	\N	402601	Ndobo	\N	4	141896
142284	\N	\N	\N	\N	402602	Bangala	\N	4	141896
142285	\N	\N	\N	\N	402603	Mweko	\N	4	141896
142286	\N	\N	\N	\N	402651	Makanza	\N	4	141896
142287	\N	\N	\N	\N	402701	Ngiri	\N	4	141897
142288	\N	\N	\N	\N	402702	Djamba	\N	4	141897
142289	\N	\N	\N	\N	402751	Bomongo	\N	4	141897
142290	\N	\N	\N	\N	403101	Bowase	\N	4	141898
142291	\N	\N	\N	\N	403102	Mbari	\N	4	141898
142292	\N	\N	\N	\N	403103	Nguya	\N	4	141898
142293	\N	\N	\N	\N	403104	Banga_Kungu	\N	4	141898
142294	\N	\N	\N	\N	403151	Gemena	\N	4	141898
142295	\N	\N	\N	\N	403201	Ndolo Liboko	\N	4	141899
142296	\N	\N	\N	\N	403202	Bolingo	\N	4	141899
142297	\N	\N	\N	\N	403203	Banza	\N	4	141899
142298	\N	\N	\N	\N	403204	Likimi      !!!!!	\N	4	141899
142299	\N	\N	\N	\N	403205	Mongala	\N	4	141899
142300	\N	\N	\N	\N	403206	Ngombe_Doko    !!!!!	\N	4	141899
142301	\N	\N	\N	\N	403251	Budjala	\N	4	141899
142302	\N	\N	\N	\N	403301	Dongo	\N	4	141900
142303	\N	\N	\N	\N	403302	Lua	\N	4	141900
142304	\N	\N	\N	\N	403303	Songo	\N	4	141900
142305	\N	\N	\N	\N	403304	Boboma	\N	4	141900
142306	\N	\N	\N	\N	403305	Mwanda	\N	4	141900
142307	\N	\N	\N	\N	403351	Kungu	\N	4	141900
142308	\N	\N	\N	\N	403401	Libenge_Sud	\N	4	141901
142309	\N	\N	\N	\N	403402	Libenge_Centre	\N	4	141901
142310	\N	\N	\N	\N	403403	Libenge_Nord	\N	4	141901
142311	\N	\N	\N	\N	403451	Libenge	\N	4	141901
142312	\N	\N	\N	\N	404100	00	\N	4	141902
142313	\N	\N	\N	\N	404200	00	\N	4	141902
142314	\N	\N	\N	\N	405101	Otto_Mbanza	\N	4	141903
142315	\N	\N	\N	\N	405102	Mobayi_Mbongo	\N	4	141903
142316	\N	\N	\N	\N	405151	Mobayi_Mbongo	\N	4	141903
142317	\N	\N	\N	\N	405201	Abumobanzi	\N	4	141904
142318	\N	\N	\N	\N	405202	Yakoma	\N	4	141904
142319	\N	\N	\N	\N	405203	Wapinda	\N	4	141904
142320	\N	\N	\N	\N	405251	Yakoma	\N	4	141904
142321	\N	\N	\N	\N	405301	Karawa	\N	4	141905
142322	\N	\N	\N	\N	405302	Bodangabo	\N	4	141905
142323	\N	\N	\N	\N	405303	Businga	\N	4	141905
142324	\N	\N	\N	\N	405351	Businga	\N	4	141905
142325	\N	\N	\N	\N	405401	Bosobolo	\N	4	141906
142326	\N	\N	\N	\N	405402	Banda	\N	4	141906
142327	\N	\N	\N	\N	405403	Bili	\N	4	141906
142328	\N	\N	\N	\N	405451	Bosobolo	\N	4	141906
142329	\N	\N	\N	\N	406101	Ngombe_Mombangi	\N	4	141907
142330	\N	\N	\N	\N	406102	Ngombe_Doko	\N	4	141907
142331	\N	\N	\N	\N	406103	Mongala-Motima	\N	4	141907
142332	\N	\N	\N	\N	406151	Lisala	\N	4	141907
142333	\N	\N	\N	\N	406201	Molua	\N	4	141908
142334	\N	\N	\N	\N	406202	Mondjamboli	\N	4	141908
142335	\N	\N	\N	\N	406203	Banda_Yowa	\N	4	141908
142336	\N	\N	\N	\N	406204	Yandongi	\N	4	141908
142337	\N	\N	\N	\N	406205	Loeka	\N	4	141908
142338	\N	\N	\N	\N	406206	Itimbiri	\N	4	141908
142339	\N	\N	\N	\N	406251	Bumba	\N	4	141908
142340	\N	\N	\N	\N	406301	Boso_Melo	\N	4	141909
142341	\N	\N	\N	\N	406302	Boso_Djanoa	\N	4	141909
142342	\N	\N	\N	\N	406303	Boso_Simba	\N	4	141909
142343	\N	\N	\N	\N	406304	Bongandanga	\N	4	141909
142344	\N	\N	\N	\N	406351	Bongandanga	\N	4	141909
142345	\N	\N	\N	\N	407101	Djera	\N	4	141910
142346	\N	\N	\N	\N	407102	Lofoy	\N	4	141910
142347	\N	\N	\N	\N	407103	Bolua	\N	4	141910
142348	\N	\N	\N	\N	407104	Wini	\N	4	141910
142349	\N	\N	\N	\N	407151	Boende	\N	4	141910
142350	\N	\N	\N	\N	407201	Befumbo	\N	4	141911
142351	\N	\N	\N	\N	407202	Lomako	\N	4	141911
142352	\N	\N	\N	\N	407203	Duale	\N	4	141911
142353	\N	\N	\N	\N	407251	Befale	\N	4	141911
142354	\N	\N	\N	\N	407301	Lingomo	\N	4	141912
142355	\N	\N	\N	\N	407302	Yala	\N	4	141912
142356	\N	\N	\N	\N	407303	Djolu	\N	4	141912
142357	\N	\N	\N	\N	407304	Luo	\N	4	141912
142358	\N	\N	\N	\N	407351	Djolu	\N	4	141912
142359	\N	\N	\N	\N	407401	Tumbenga	\N	4	141913
142360	\N	\N	\N	\N	407402	Lokina	\N	4	141913
142361	\N	\N	\N	\N	407403	Loile	\N	4	141913
142362	\N	\N	\N	\N	407404	Lofome	\N	4	141913
142363	\N	\N	\N	\N	407405	Tshuapa	\N	4	141913
142364	\N	\N	\N	\N	407451	Ikela	\N	4	141913
142365	\N	\N	\N	\N	407501	Loombo	\N	4	141914
142366	\N	\N	\N	\N	407502	Luay	\N	4	141914
142367	\N	\N	\N	\N	407503	Luando	\N	4	141914
142368	\N	\N	\N	\N	407504	Lolaka	\N	4	141914
142369	\N	\N	\N	\N	407505	Nkole	\N	4	141914
142370	\N	\N	\N	\N	407551	Bokungu	\N	4	141914
142371	\N	\N	\N	\N	407601	Bianga	\N	4	141915
142372	\N	\N	\N	\N	407602	Mongo	\N	4	141915
142373	\N	\N	\N	\N	407603	Monkoto	\N	4	141915
142374	\N	\N	\N	\N	407651	Monkoto	\N	4	141915
142375	\N	\N	\N	\N	501100	00	\N	4	141916
142376	\N	\N	\N	\N	501200	00	\N	4	141916
142377	\N	\N	\N	\N	501300	00	\N	4	141916
142378	\N	\N	\N	\N	501400	00	\N	4	141916
142379	\N	\N	\N	\N	501500	00	\N	4	141916
142380	\N	\N	\N	\N	501600	00	\N	4	141916
142381	\N	\N	\N	\N	502101	Bamanga	\N	4	141917
142382	\N	\N	\N	\N	502102	Baboro	\N	4	141917
142383	\N	\N	\N	\N	502103	Babwa de Kole	\N	4	141917
142384	\N	\N	\N	\N	502104	Popoy	\N	4	141917
142385	\N	\N	\N	\N	502105	Banalia_ Bangba  ??	\N	4	141917
142386	\N	\N	\N	\N	502151	Banalia	\N	4	141917
142387	\N	\N	\N	\N	502201	Bakumu d'Angumu	\N	4	141918
142388	\N	\N	\N	\N	502202	Barumbi - Opienge	\N	4	141918
142389	\N	\N	\N	\N	502203	Bekenie- Kondolole	\N	4	141918
142390	\N	\N	\N	\N	502204	Bafwandaka	\N	4	141918
142391	\N	\N	\N	\N	502205	Bemile	\N	4	141918
142392	\N	\N	\N	\N	502206	Bakundumu	\N	4	141918
142393	\N	\N	\N	\N	502251	Bafwasende	\N	4	141918
142394	\N	\N	\N	\N	502301	Walengola _ Lowa	\N	4	141919
142395	\N	\N	\N	\N	502302	Mituku _ Basikate	\N	4	141919
142396	\N	\N	\N	\N	502303	Mituku _ Bamoya	\N	4	141919
142397	\N	\N	\N	\N	502304	Walengola_Babina	\N	4	141919
142398	\N	\N	\N	\N	502305	Walengola_ Baleka	\N	4	141919
142399	\N	\N	\N	\N	502306	Bakumu _ Mangongo	\N	4	141919
142400	\N	\N	\N	\N	502307	Bakumu_Mandombe	\N	4	141919
142401	\N	\N	\N	\N	502308	Bakumu_Kilinga	\N	4	141919
142402	\N	\N	\N	\N	502309	Bakumu _D'Obiatuku	\N	4	141919
142403	\N	\N	\N	\N	502310	Walengola_Lilo	\N	4	141919
142404	\N	\N	\N	\N	502311	Kirundu	\N	4	141919
142405	\N	\N	\N	\N	502351	Ubundu	\N	4	141919
142406	\N	\N	\N	\N	502401	Yawende_ Loolo	\N	4	141920
142407	\N	\N	\N	\N	502402	Yeyango	\N	4	141920
142408	\N	\N	\N	\N	502403	Yalingo	\N	4	141920
142409	\N	\N	\N	\N	502404	Yomaie	\N	4	141920
142410	\N	\N	\N	\N	502405	Iye	\N	4	141920
142411	\N	\N	\N	\N	502406	Yapandu	\N	4	141920
142412	\N	\N	\N	\N	502407	Mongo	\N	4	141920
142413	\N	\N	\N	\N	502408	Kembe	\N	4	141920
142414	\N	\N	\N	\N	502409	Balinga_ Lindja	\N	4	141920
142415	\N	\N	\N	\N	502410	Tooli	\N	4	141920
142416	\N	\N	\N	\N	502411	Lobaie	\N	4	141920
142417	\N	\N	\N	\N	502451	Opala	\N	4	141920
142418	\N	\N	\N	\N	502501	Bolomboki	\N	4	141921
142419	\N	\N	\N	\N	502502	Boluolambila	\N	4	141921
142420	\N	\N	\N	\N	502503	Bambelota	\N	4	141921
142421	\N	\N	\N	\N	502504	Lokombe	\N	4	141921
142422	\N	\N	\N	\N	502505	Luete	\N	4	141921
142423	\N	\N	\N	\N	502506	Yawembe-Baonga	\N	4	141921
142424	\N	\N	\N	\N	502507	Turumbu	\N	4	141921
142425	\N	\N	\N	\N	502508	Yaokandja	\N	4	141921
142426	\N	\N	\N	\N	502509	Yalikandja	\N	4	141921
142427	\N	\N	\N	\N	502510	Yaihila	\N	4	141921
142428	\N	\N	\N	\N	502511	Yalikoka- Mboso ?????	\N	4	141921
142429	\N	\N	\N	\N	502512	Kombe	\N	4	141921
142430	\N	\N	\N	\N	502513	Liutua	\N	4	141921
142431	\N	\N	\N	\N	502551	Isangi	\N	4	141921
142432	\N	\N	\N	\N	502552	Yangambi	\N	4	141921
142433	\N	\N	\N	\N	502601	Basoko Lianga 1 Yalokele	\N	4	141922
142434	\N	\N	\N	\N	502602	Bolinga	\N	4	141922
142435	\N	\N	\N	\N	502603	Buma	\N	4	141922
142436	\N	\N	\N	\N	502604	Mombesa	\N	4	141922
142437	\N	\N	\N	\N	502651	Yahuma	\N	4	141922
142438	\N	\N	\N	\N	502701	Lukutu	\N	4	141923
142439	\N	\N	\N	\N	502702	Yaliwasa	\N	4	141923
142440	\N	\N	\N	\N	502703	Mobango Itimbiri	\N	4	141923
142441	\N	\N	\N	\N	502704	Yamandundu	\N	4	141923
142442	\N	\N	\N	\N	502705	Wahanga	\N	4	141923
142443	\N	\N	\N	\N	502706	Bangelema Mongandjo	\N	4	141923
142444	\N	\N	\N	\N	502707	Turumbu	\N	4	141923
142445	\N	\N	\N	\N	502708	Bomenge	\N	4	141923
142446	\N	\N	\N	\N	502751	Basoko	\N	4	141923
142447	\N	\N	\N	\N	502752	Bandu	\N	4	141923
142448	\N	\N	\N	\N	503101	Monganzulu	\N	4	141924
142449	\N	\N	\N	\N	503102	Nguru	\N	4	141924
142450	\N	\N	\N	\N	503103	Mobati	\N	4	141924
142451	\N	\N	\N	\N	503104	Bongita Mobati	\N	4	141924
142452	\N	\N	\N	\N	503105	Bayeu Bogongia	\N	4	141924
142453	\N	\N	\N	\N	503106	Bayeu Bogbama	\N	4	141924
142454	\N	\N	\N	\N	503151	Buta	\N	4	141924
142455	\N	\N	\N	\N	503201	Bodongola	\N	4	141925
142456	\N	\N	\N	\N	503202	Gbongi	\N	4	141925
142457	\N	\N	\N	\N	503203	Mongwandi	\N	4	141925
142458	\N	\N	\N	\N	503204	Avuru _Duma	\N	4	141925
142459	\N	\N	\N	\N	503205	Mobati _Boyele	\N	4	141925
142460	\N	\N	\N	\N	503206	Avuru _Gatanga	\N	4	141925
142461	\N	\N	\N	\N	503207	Mabinza	\N	4	141925
142462	\N	\N	\N	\N	503208	Yoko	\N	4	141925
142463	\N	\N	\N	\N	503251	Aketi	\N	4	141925
142464	\N	\N	\N	\N	503301	Kasa	\N	4	141926
142465	\N	\N	\N	\N	503302	Soa	\N	4	141926
142466	\N	\N	\N	\N	503303	Deni	\N	4	141926
142467	\N	\N	\N	\N	503304	Gaya	\N	4	141926
142468	\N	\N	\N	\N	503305	Goya	\N	4	141926
142469	\N	\N	\N	\N	503306	Gbiamange	\N	4	141926
142470	\N	\N	\N	\N	503307	Boso	\N	4	141926
142471	\N	\N	\N	\N	503308	Gama	\N	4	141926
142472	\N	\N	\N	\N	503309	Duaru	\N	4	141926
142473	\N	\N	\N	\N	503310	Mobenge _ Mondila	\N	4	141926
142474	\N	\N	\N	\N	503351	Bondo	\N	4	141926
142475	\N	\N	\N	\N	503401	Ngindo	\N	4	141927
142476	\N	\N	\N	\N	503402	Sasa	\N	4	141927
142477	\N	\N	\N	\N	503403	Mopoy	\N	4	141927
142478	\N	\N	\N	\N	503404	Ezo	\N	4	141927
142479	\N	\N	\N	\N	503451	Ango	\N	4	141927
142480	\N	\N	\N	\N	503501	Makere 2	\N	4	141928
142481	\N	\N	\N	\N	503502	Makere 1	\N	4	141928
142482	\N	\N	\N	\N	503503	Mondongale	\N	4	141928
142483	\N	\N	\N	\N	503504	Mange	\N	4	141928
142484	\N	\N	\N	\N	503505	Bolungwa	\N	4	141928
142485	\N	\N	\N	\N	503506	Bakete	\N	4	141928
142486	\N	\N	\N	\N	503507	Bokapo	\N	4	141928
142487	\N	\N	\N	\N	503508	Bakere/Bakete	\N	4	141928
142488	\N	\N	\N	\N	503509	Bokiba	\N	4	141928
142489	\N	\N	\N	\N	503551	Bambesa	\N	4	141928
142490	\N	\N	\N	\N	503601	Malele	\N	4	141929
142491	\N	\N	\N	\N	503602	Bakengaie	\N	4	141929
142492	\N	\N	\N	\N	503603	Kembisa	\N	4	141929
142493	\N	\N	\N	\N	503604	Abarambo	\N	4	141929
142494	\N	\N	\N	\N	503605	Madi	\N	4	141929
142495	\N	\N	\N	\N	503606	Soronga	\N	4	141929
142496	\N	\N	\N	\N	503607	Babena	\N	4	141929
142497	\N	\N	\N	\N	503608	Gamu	\N	4	141929
142498	\N	\N	\N	\N	503609	Komendeni	\N	4	141929
142499	\N	\N	\N	\N	503610	Kipate	\N	4	141929
142500	\N	\N	\N	\N	503611	Zune	\N	4	141929
142501	\N	\N	\N	\N	503612	Ngbaradi	\N	4	141929
142502	\N	\N	\N	\N	503613	Mabanga	\N	4	141929
142503	\N	\N	\N	\N	503651	Poko	\N	4	141929
142504	\N	\N	\N	\N	504101	Medje-Mango	\N	4	141930
142505	\N	\N	\N	\N	504102	Mongo_Masi	\N	4	141930
142506	\N	\N	\N	\N	504103	Ndey	\N	4	141930
142507	\N	\N	\N	\N	504104	Azanga	\N	4	141930
142508	\N	\N	\N	\N	504105	Mboli	\N	4	141930
142509	\N	\N	\N	\N	504106	Mayogo_ Magbaie	\N	4	141930
142510	\N	\N	\N	\N	504107	Mayogo_ Mabozo	\N	4	141930
142511	\N	\N	\N	\N	504151	Isiro	\N	4	141930
142512	\N	\N	\N	\N	504201	Bowemi	\N	4	141931
142513	\N	\N	\N	\N	504202	Mangbetu	\N	4	141931
142514	\N	\N	\N	\N	504203	Mangbele	\N	4	141931
142515	\N	\N	\N	\N	504204	Manziga	\N	4	141931
142516	\N	\N	\N	\N	504205	Kopa	\N	4	141931
142517	\N	\N	\N	\N	504206	Kereboro	\N	4	141931
142518	\N	\N	\N	\N	504207	Okondo	\N	4	141931
142519	\N	\N	\N	\N	504251	Niangara	\N	4	141931
142520	\N	\N	\N	\N	504301	Wando	\N	4	141932
142521	\N	\N	\N	\N	504302	Malingindu	\N	4	141932
142522	\N	\N	\N	\N	504303	Ndolomo	\N	4	141932
142523	\N	\N	\N	\N	504351	Dungu	\N	4	141932
142524	\N	\N	\N	\N	504401	Logo _ Ogambi	\N	4	141933
142525	\N	\N	\N	\N	504402	Mondo	\N	4	141933
142526	\N	\N	\N	\N	504403	Kakwa	\N	4	141933
142527	\N	\N	\N	\N	504404	Logo _ Bagela	\N	4	141933
142528	\N	\N	\N	\N	504405	Logo _ Lolia	\N	4	141933
142529	\N	\N	\N	\N	504406	Logo _ Obelela	\N	4	141933
142530	\N	\N	\N	\N	504407	Logo _ Doka	\N	4	141933
142531	\N	\N	\N	\N	504408	Dongo	\N	4	141933
142532	\N	\N	\N	\N	504451	Faradje	\N	4	141933
142533	\N	\N	\N	\N	504452	Aba	\N	4	141933
142534	\N	\N	\N	\N	504501	Ateru-Karu	\N	4	141934
142535	\N	\N	\N	\N	504502	Kebo	\N	4	141934
142536	\N	\N	\N	\N	504503	Andobi	\N	4	141934
142537	\N	\N	\N	\N	504504	Andikofa	\N	4	141934
142538	\N	\N	\N	\N	504505	Gombari	\N	4	141934
142539	\N	\N	\N	\N	504506	Mari - Minza	\N	4	141934
142540	\N	\N	\N	\N	504507	Kibali	\N	4	141934
142541	\N	\N	\N	\N	504508	Mangbutu	\N	4	141934
142542	\N	\N	\N	\N	504509	Walese	\N	4	141934
142543	\N	\N	\N	\N	504551	Watsa	\N	4	141934
142544	\N	\N	\N	\N	504601	Mabudu Malika Baberu	\N	4	141935
142545	\N	\N	\N	\N	504602	Barika - Toriko	\N	4	141935
142546	\N	\N	\N	\N	504603	Timoniko	\N	4	141935
142547	\N	\N	\N	\N	504604	Wadimbisa	\N	4	141935
142548	\N	\N	\N	\N	504605	Makoda	\N	4	141935
142549	\N	\N	\N	\N	504606	Bafwagada	\N	4	141935
142550	\N	\N	\N	\N	504607	Mangbele	\N	4	141935
142551	\N	\N	\N	\N	504608	Maha	\N	4	141935
142552	\N	\N	\N	\N	504609	Bafwakoy	\N	4	141935
142553	\N	\N	\N	\N	504610	Malika Ateru	\N	4	141935
142554	\N	\N	\N	\N	504611	Mahaa  Nord (Malamba) ?????	\N	4	141935
142555	\N	\N	\N	\N	504651	Durunga (Wamba)	\N	4	141935
142556	\N	\N	\N	\N	505101	Walese Vonkutu	\N	4	141936
142557	\N	\N	\N	\N	505102	Basili	\N	4	141936
142558	\N	\N	\N	\N	505103	Bahema D'Irumu	\N	4	141936
142559	\N	\N	\N	\N	505104	Babelebe	\N	4	141936
142560	\N	\N	\N	\N	505105	Baboa_Bakoe	\N	4	141936
142561	\N	\N	\N	\N	505106	Bahema _Sud	\N	4	141936
142562	\N	\N	\N	\N	505107	Walendu _Bindi	\N	4	141936
142563	\N	\N	\N	\N	505108	Bahema_ Mitego	\N	4	141936
142564	\N	\N	\N	\N	505109	Bahema _Boga	\N	4	141936
142565	\N	\N	\N	\N	505110	Baniari _Tchabi	\N	4	141936
142566	\N	\N	\N	\N	505111	Andisoma	\N	4	141936
142567	\N	\N	\N	\N	505112	Mobala	\N	4	141936
142568	\N	\N	\N	\N	505151	Irumu	\N	4	141936
142569	\N	\N	\N	\N	505152	Bunia	\N	4	141936
142570	\N	\N	\N	\N	505201	Bombo	\N	4	141937
142571	\N	\N	\N	\N	505202	Bandaka	\N	4	141937
142572	\N	\N	\N	\N	505203	Walese_ Dese	\N	4	141937
142573	\N	\N	\N	\N	505204	Walese_ Karo	\N	4	141937
142574	\N	\N	\N	\N	505205	Bakwanza	\N	4	141937
142575	\N	\N	\N	\N	505206	Babombi	\N	4	141937
142576	\N	\N	\N	\N	505207	Mambasa	\N	4	141937
142577	\N	\N	\N	\N	505251	Mambasa	\N	4	141937
142578	\N	\N	\N	\N	505301	Bahema_Banywagi	\N	4	141938
142579	\N	\N	\N	\N	505302	Baniari	\N	4	141938
142580	\N	\N	\N	\N	505303	Mabendi	\N	4	141938
142581	\N	\N	\N	\N	505304	Walendu_Pitsi	\N	4	141938
142582	\N	\N	\N	\N	505305	Bahema_Nord	\N	4	141938
142583	\N	\N	\N	\N	505306	Walendu_Tatsi	\N	4	141938
142584	\N	\N	\N	\N	505307	Mambisa	\N	4	141938
142585	\N	\N	\N	\N	505308	Ndo_Okebo	\N	4	141938
142586	\N	\N	\N	\N	505309	Walendo_ Djatsi	\N	4	141938
142587	\N	\N	\N	\N	505310	Bahema_Badjere	\N	4	141938
142588	\N	\N	\N	\N	505351	Djugu	\N	4	141938
142589	\N	\N	\N	\N	505352	Mungbwalu	\N	4	141938
142590	\N	\N	\N	\N	505401	Walendu Watsi	\N	4	141939
142591	\N	\N	\N	\N	505402	Alur -Djuganda	\N	4	141939
142592	\N	\N	\N	\N	505403	War_Palara	\N	4	141939
142593	\N	\N	\N	\N	505404	Anghal 1 - 2	\N	4	141939
142594	\N	\N	\N	\N	505405	Wagongo	\N	4	141939
142595	\N	\N	\N	\N	505406	Mokambo	\N	4	141939
142596	\N	\N	\N	\N	505407	Djukoth 1 - 2	\N	4	141939
142597	\N	\N	\N	\N	505408	Pandoro	\N	4	141939
142598	\N	\N	\N	\N	505451	Mahagi	\N	4	141939
142599	\N	\N	\N	\N	505501	Ndo_Okebo	\N	4	141940
142600	\N	\N	\N	\N	505502	Kaliko_Omi	\N	4	141940
142601	\N	\N	\N	\N	505503	Kakwa	\N	4	141940
142602	\N	\N	\N	\N	505504	Zaki	\N	4	141940
142603	\N	\N	\N	\N	505505	Nio_Kamule	\N	4	141940
142604	\N	\N	\N	\N	505506	Otso	\N	4	141940
142605	\N	\N	\N	\N	505507	Lu	\N	4	141940
142606	\N	\N	\N	\N	505508	Aluru	\N	4	141940
142607	\N	\N	\N	\N	505551	Aru	\N	4	141940
142608	\N	\N	\N	\N	607451	Idjwi	\N	4	141941
142609	\N	\N	\N	\N	611100	00	\N	4	141941
142610	\N	\N	\N	\N	611200	00	\N	4	141941
142611	\N	\N	\N	\N	612201	Bakano	\N	4	141942
142612	\N	\N	\N	\N	612202	Wanyanga	\N	4	141942
142613	\N	\N	\N	\N	612251	Walikale	\N	4	141942
142614	\N	\N	\N	\N	612301	Bapere	\N	4	141943
142615	\N	\N	\N	\N	612302	Baswagha	\N	4	141943
142616	\N	\N	\N	\N	612303	Batangi	\N	4	141943
142617	\N	\N	\N	\N	612304	Bamate	\N	4	141943
142618	\N	\N	\N	\N	612351	Lubero	\N	4	141943
142619	\N	\N	\N	\N	612352	Katwa	\N	4	141943
142620	\N	\N	\N	\N	612354	Kanyabayonga	\N	4	141943
142621	\N	\N	\N	\N	612355	Kayna	\N	4	141943
142622	\N	\N	\N	\N	612356	Kirumba	\N	4	141943
142623	\N	\N	\N	\N	612401	Bashu	\N	4	141944
142624	\N	\N	\N	\N	612402	Beni	\N	4	141944
142625	\N	\N	\N	\N	612403	Watalinga	\N	4	141944
142626	\N	\N	\N	\N	612404	Ruwenzori	\N	4	141944
142627	\N	\N	\N	\N	612452	Mangina	\N	4	141944
142628	\N	\N	\N	\N	612453	Oicha	\N	4	141944
142629	\N	\N	\N	\N	612454	Bulongo	\N	4	141944
142630	\N	\N	\N	\N	612455	Kyondo	\N	4	141944
142631	\N	\N	\N	\N	612456	Lume	\N	4	141944
142632	\N	\N	\N	\N	612501	Bwito	\N	4	141945
142633	\N	\N	\N	\N	612502	Bwisha	\N	4	141945
142634	\N	\N	\N	\N	612551	Kiwanja	\N	4	141945
142635	\N	\N	\N	\N	612601	Bahunde	\N	4	141946
142636	\N	\N	\N	\N	612602	Katoyi	\N	4	141946
142637	\N	\N	\N	\N	612603	Osso Banyungu	\N	4	141946
142638	\N	\N	\N	\N	612604	Bashali	\N	4	141946
142639	\N	\N	\N	\N	612651	Masisi	\N	4	141946
142640	\N	\N	\N	\N	612701	Bukumu	\N	4	141947
142641	\N	\N	\N	\N	613100	00	\N	4	141948
142642	\N	\N	\N	\N	613200	00	\N	4	141948
142643	\N	\N	\N	\N	613300	00	\N	4	141948
142644	\N	\N	\N	\N	613400	00	\N	4	141948
142645	\N	\N	\N	\N	614100	00	\N	4	141949
142646	\N	\N	\N	\N	614200	00	\N	4	141949
142647	\N	\N	\N	\N	614300	00	\N	4	141949
142648	\N	\N	\N	\N	614400	00	\N	4	141949
142649	\N	\N	\N	\N	622101	Bangengele	\N	4	141951
142650	\N	\N	\N	\N	622102	Balanga	\N	4	141951
142651	\N	\N	\N	\N	622103	Ambwe	\N	4	141951
142652	\N	\N	\N	\N	622104	Wasongola	\N	4	141951
142653	\N	\N	\N	\N	622201	Bahina	\N	4	141952
142654	\N	\N	\N	\N	622202	Ankutshu	\N	4	141952
142655	\N	\N	\N	\N	622203	Bakongola	\N	4	141952
142656	\N	\N	\N	\N	622204	Matapa	\N	4	141952
142657	\N	\N	\N	\N	622205	Aluba	\N	4	141952
142658	\N	\N	\N	\N	622251	Kibombo	\N	4	141952
142659	\N	\N	\N	\N	622301	Ulindi	\N	4	141953
142660	\N	\N	\N	\N	622302	Baleka	\N	4	141953
142661	\N	\N	\N	\N	622303	Babira_Bakwame	\N	4	141953
142662	\N	\N	\N	\N	622351	Punia	\N	4	141953
142663	\N	\N	\N	\N	622401	Obokote	\N	4	141954
142664	\N	\N	\N	\N	622402	Bitule	\N	4	141954
142665	\N	\N	\N	\N	622451	Lubutu	\N	4	141954
142666	\N	\N	\N	\N	622501	Wakabango	\N	4	141955
142667	\N	\N	\N	\N	622502	Beia	\N	4	141955
142668	\N	\N	\N	\N	622503	Ikama	\N	4	141955
142669	\N	\N	\N	\N	622504	Babene	\N	4	141955
142670	\N	\N	\N	\N	622551	Pangi	\N	4	141955
142671	\N	\N	\N	\N	622552	Kakutya (Kalima)	\N	4	141955
142672	\N	\N	\N	\N	622601	Basonge 1	\N	4	141956
142673	\N	\N	\N	\N	622602	Benya Samba	\N	4	141956
142674	\N	\N	\N	\N	622603	Wagenia	\N	4	141956
142675	\N	\N	\N	\N	622604	Bakwange	\N	4	141956
142676	\N	\N	\N	\N	622605	Wazimba Wa Maringa	\N	4	141956
142677	\N	\N	\N	\N	622606	Wazimba Wa Mulu	\N	4	141956
142678	\N	\N	\N	\N	622607	Nonda	\N	4	141956
142679	\N	\N	\N	\N	622608	Mamba Kasenga	\N	4	141956
142680	\N	\N	\N	\N	622609	Wazula	\N	4	141956
142681	\N	\N	\N	\N	622610	Basonge 2	\N	4	141956
142682	\N	\N	\N	\N	622651	Kasongo	\N	4	141956
142683	\N	\N	\N	\N	622701	Bahemba	\N	4	141957
142684	\N	\N	\N	\N	622702	Lulindi	\N	4	141957
142685	\N	\N	\N	\N	622703	Wamaza	\N	4	141957
142686	\N	\N	\N	\N	622704	Sarambila	\N	4	141957
142687	\N	\N	\N	\N	622705	Babuyu	\N	4	141957
142688	\N	\N	\N	\N	622706	Kabambare Bahombo	\N	4	141957
142689	\N	\N	\N	\N	622751	Kabambare	\N	4	141957
142690	\N	\N	\N	\N	631100	00	\N	4	141948
142691	\N	\N	\N	\N	631200	00	\N	4	141948
142692	\N	\N	\N	\N	631300	00	\N	4	141948
142693	\N	\N	\N	\N	632101	Ngweshe	\N	4	141959
142694	\N	\N	\N	\N	632102	Kaziba	\N	4	141959
142695	\N	\N	\N	\N	632151	Walungu	\N	4	141959
142696	\N	\N	\N	\N	632201	Bavira	\N	4	141960
142697	\N	\N	\N	\N	632202	Bafulero	\N	4	141960
142698	\N	\N	\N	\N	632203	Plaine de la Ruzizi	\N	4	141960
142699	\N	\N	\N	\N	632251	Uvira	\N	4	141960
142700	\N	\N	\N	\N	632252	Kagando	\N	4	141960
142701	\N	\N	\N	\N	632253	Lemera	\N	4	141960
142702	\N	\N	\N	\N	632254	Luvungi	\N	4	141960
142703	\N	\N	\N	\N	632255	Runingu	\N	4	141960
142704	\N	\N	\N	\N	632256	Sange	\N	4	141960
142705	\N	\N	\N	\N	632301	Ngandja	\N	4	141961
142706	\N	\N	\N	\N	632302	Lulenge	\N	4	141961
142707	\N	\N	\N	\N	632303	Tanganyika	\N	4	141961
142708	\N	\N	\N	\N	632304	Mutambala	\N	4	141961
142709	\N	\N	\N	\N	632351	Fizi	\N	4	141961
142710	\N	\N	\N	\N	632401	Wamuzimu	\N	4	141962
142711	\N	\N	\N	\N	632402	Basile	\N	4	141962
142712	\N	\N	\N	\N	632403	Luindi	\N	4	141962
142713	\N	\N	\N	\N	632404	Burhinyi	\N	4	141962
142714	\N	\N	\N	\N	632405	Luhwindja	\N	4	141962
142715	\N	\N	\N	\N	632406	Itombwe	\N	4	141962
142716	\N	\N	\N	\N	632451	Mwenga	\N	4	141962
142717	\N	\N	\N	\N	632452	Kamituga	\N	4	141962
142718	\N	\N	\N	\N	632501	Wakabango	\N	4	141963
142719	\N	\N	\N	\N	632502	Bakisi	\N	4	141963
142720	\N	\N	\N	\N	632551	Shabunda	\N	4	141963
142721	\N	\N	\N	\N	632601	Bahavu	\N	4	141964
142722	\N	\N	\N	\N	632602	Buloho	\N	4	141964
142723	\N	\N	\N	\N	632651	Kalehe	\N	4	141964
142724	\N	\N	\N	\N	632701	Ntambuka	\N	4	141965
142725	\N	\N	\N	\N	632702	Rubenga	\N	4	141965
142726	\N	\N	\N	\N	632801	Nindja	\N	4	141966
142727	\N	\N	\N	\N	632802	Kabare	\N	4	141966
142728	\N	\N	\N	\N	632851	Kabare	\N	4	141966
142729	\N	\N	\N	\N	701100	00	\N	4	141967
142730	\N	\N	\N	\N	701200	00	\N	4	141967
142731	\N	\N	\N	\N	701300	00	\N	4	141967
142732	\N	\N	\N	\N	701400	00	\N	4	141967
142733	\N	\N	\N	\N	701500	00	\N	4	141967
142734	\N	\N	\N	\N	701600	00	\N	4	141967
142735	\N	\N	\N	\N	701700	00	\N	4	141967
142736	\N	\N	\N	\N	702100	00	\N	4	141968
142737	\N	\N	\N	\N	702200	00	\N	4	141968
142738	\N	\N	\N	\N	702300	00	\N	4	141968
142739	\N	\N	\N	\N	702400	00	\N	4	141968
142740	\N	\N	\N	\N	703100	00	\N	4	141969
142741	\N	\N	\N	\N	703200	00	\N	4	141969
142742	\N	\N	\N	\N	703301	Lufupa	\N	4	141969
142743	\N	\N	\N	\N	703302	Mukuleshi	\N	4	141969
142744	\N	\N	\N	\N	703303	Luilu	\N	4	141969
142745	\N	\N	\N	\N	703351	Mutshatsha	\N	4	141969
142746	\N	\N	\N	\N	703401	Muana Muadi	\N	4	141970
142747	\N	\N	\N	\N	703402	Mazangule	\N	4	141970
142748	\N	\N	\N	\N	703403	Mulumbu	\N	4	141970
142749	\N	\N	\N	\N	703404	Bayeke	\N	4	141970
142750	\N	\N	\N	\N	703451	Lubudi	\N	4	141970
142751	\N	\N	\N	\N	703452	Fungurume	\N	4	141970
142752	\N	\N	\N	\N	703453	Gecamines	\N	4	141970
142753	\N	\N	\N	\N	704101	Ndumba	\N	4	141971
142754	\N	\N	\N	\N	704102	Mwatshisenge	\N	4	141971
142755	\N	\N	\N	\N	704103	Saluseke	\N	4	141971
142756	\N	\N	\N	\N	704104	Muyeye	\N	4	141971
142757	\N	\N	\N	\N	704105	Tshisangama	\N	4	141971
142758	\N	\N	\N	\N	704106	Mutanda	\N	4	141971
142759	\N	\N	\N	\N	704107	Luena	\N	4	141971
142760	\N	\N	\N	\N	704108	Mwakandala	\N	4	141971
142761	\N	\N	\N	\N	704109	Lulua _ Lukoshi	\N	4	141971
142762	\N	\N	\N	\N	704110	Kasaji	\N	4	141971
142763	\N	\N	\N	\N	704111	Divuma	\N	4	141971
142764	\N	\N	\N	\N	704151	Dilolo	\N	4	141971
142765	\N	\N	\N	\N	704201	Mbako	\N	4	141972
142766	\N	\N	\N	\N	704202	Samutoma	\N	4	141972
142767	\N	\N	\N	\N	704203	Tshibamba	\N	4	141972
142768	\N	\N	\N	\N	704204	Muteba	\N	4	141972
142769	\N	\N	\N	\N	704205	Lumanga	\N	4	141972
142770	\N	\N	\N	\N	704206	Kayembe Mukulu	\N	4	141972
142771	\N	\N	\N	\N	704207	Tshipao	\N	4	141972
142772	\N	\N	\N	\N	704208	Sakundundu	\N	4	141972
142773	\N	\N	\N	\N	704251	Sandoa	\N	4	141972
142774	\N	\N	\N	\N	704301	Mwant Yav	\N	4	141973
142775	\N	\N	\N	\N	704351	Kapanga	\N	4	141973
142776	\N	\N	\N	\N	705101	Kinda	\N	4	141974
142777	\N	\N	\N	\N	705102	Kasongo Nyembo	\N	4	141974
142778	\N	\N	\N	\N	705151	Kamina	\N	4	141974
142779	\N	\N	\N	\N	705201	Mutombo Mukulu	\N	4	141975
142780	\N	\N	\N	\N	705251	Kaniama	\N	4	141975
142781	\N	\N	\N	\N	705301	Kayamba   ( A rÃ©partir )	\N	4	141976
142782	\N	\N	\N	\N	705302	Kabongo	\N	4	141976
142783	\N	\N	\N	\N	705303	Nord_Baluba	\N	4	141976
142784	\N	\N	\N	\N	705351	Kabongo	\N	4	141976
142785	\N	\N	\N	\N	705401	Kayumba	\N	4	141977
142786	\N	\N	\N	\N	705402	Nkulu	\N	4	141977
142787	\N	\N	\N	\N	705403	Mwanza	\N	4	141977
142788	\N	\N	\N	\N	705404	Badia	\N	4	141977
142789	\N	\N	\N	\N	705405	Mulongo	\N	4	141977
142790	\N	\N	\N	\N	705406	Museka	\N	4	141977
142791	\N	\N	\N	\N	705451	Malemba_Nkulu	\N	4	141977
142792	\N	\N	\N	\N	705452	Mulongo	\N	4	141977
142793	\N	\N	\N	\N	705501	Kibanda	\N	4	141978
142794	\N	\N	\N	\N	705502	Lualaba	\N	4	141978
142795	\N	\N	\N	\N	705503	Kabondo_Dianda	\N	4	141978
142796	\N	\N	\N	\N	705504	Kapamayi	\N	4	141978
142797	\N	\N	\N	\N	705505	Kinkondja	\N	4	141978
142798	\N	\N	\N	\N	705506	Butumba	\N	4	141978
142799	\N	\N	\N	\N	705551	Bukama	\N	4	141978
142800	\N	\N	\N	\N	705552	Kipamba	\N	4	141978
142801	\N	\N	\N	\N	705553	Kibanda	\N	4	141978
142802	\N	\N	\N	\N	705554	Kinkondja	\N	4	141978
142803	\N	\N	\N	\N	706101	Tumbwe	\N	4	141979
142804	\N	\N	\N	\N	706102	Benze	\N	4	141979
142805	\N	\N	\N	\N	706103	Rutuku	\N	4	141979
142806	\N	\N	\N	\N	706151	Kalemie	\N	4	141979
142807	\N	\N	\N	\N	706152	Kituku	\N	4	141979
142808	\N	\N	\N	\N	706201	Nganye	\N	4	141980
142809	\N	\N	\N	\N	706202	Kansabala	\N	4	141980
142810	\N	\N	\N	\N	706203	Manda	\N	4	141980
142811	\N	\N	\N	\N	706204	Kayabala	\N	4	141980
142812	\N	\N	\N	\N	706205	Bena Tanga	\N	4	141980
142813	\N	\N	\N	\N	706206	Bena_Kamanya	\N	4	141980
142814	\N	\N	\N	\N	706251	Moba	\N	4	141980
142815	\N	\N	\N	\N	706301	Kyofwe	\N	4	141981
142816	\N	\N	\N	\N	706302	Kamalondo	\N	4	141981
142817	\N	\N	\N	\N	706303	Nyemba	\N	4	141981
142818	\N	\N	\N	\N	706304	Luvwa	\N	4	141981
142819	\N	\N	\N	\N	706305	Bakongolo        ????   Gpts	\N	4	141981
142820	\N	\N	\N	\N	706306	Kiluba         ????   Gpts	\N	4	141981
142821	\N	\N	\N	\N	706351	Manono	\N	4	141981
142822	\N	\N	\N	\N	706352	Kanteba	\N	4	141981
142823	\N	\N	\N	\N	706401	Lwela_Luvunguye	\N	4	141982
142824	\N	\N	\N	\N	706402	Lukuswa	\N	4	141982
142825	\N	\N	\N	\N	706451	Kabalo	\N	4	141982
142826	\N	\N	\N	\N	706501	Baluba	\N	4	141983
142827	\N	\N	\N	\N	706502	Bayashi	\N	4	141983
142828	\N	\N	\N	\N	706503	Basonge	\N	4	141983
142829	\N	\N	\N	\N	706504	Munono	\N	4	141983
142830	\N	\N	\N	\N	706505	N'kuvu	\N	4	141983
142831	\N	\N	\N	\N	706506	Yambula	\N	4	141983
142832	\N	\N	\N	\N	706507	Muhona	\N	4	141983
142833	\N	\N	\N	\N	706508	Nyembo	\N	4	141983
142834	\N	\N	\N	\N	706509	Mambwe	\N	4	141983
142835	\N	\N	\N	\N	706551	Kongolo	\N	4	141983
142836	\N	\N	\N	\N	706601	Sud_Lukuga	\N	4	141984
142837	\N	\N	\N	\N	706602	Nord_Lukuga	\N	4	141984
142838	\N	\N	\N	\N	706651	Nyunzu	\N	4	141984
142839	\N	\N	\N	\N	707101	Kaponda	\N	4	141985
142840	\N	\N	\N	\N	707102	Bukanda	\N	4	141985
142841	\N	\N	\N	\N	707103	Kiniama	\N	4	141985
142842	\N	\N	\N	\N	707151	Kipushi	\N	4	141985
142843	\N	\N	\N	\N	707152	Musoshi	\N	4	141985
142844	\N	\N	\N	\N	707201	Balala	\N	4	141986
142845	\N	\N	\N	\N	707202	Balamba	\N	4	141986
142846	\N	\N	\N	\N	707203	Baushi	\N	4	141986
142847	\N	\N	\N	\N	707251	Sakania	\N	4	141986
142848	\N	\N	\N	\N	707252	Mokambo	\N	4	141986
142849	\N	\N	\N	\N	707253	Balamba	\N	4	141986
142850	\N	\N	\N	\N	707301	Kafira	\N	4	141987
142851	\N	\N	\N	\N	707302	Bakunda	\N	4	141987
142852	\N	\N	\N	\N	707303	Lwapula	\N	4	141987
142853	\N	\N	\N	\N	707304	Kisamamba	\N	4	141987
142854	\N	\N	\N	\N	707351	Kasenga	\N	4	141987
142855	\N	\N	\N	\N	707401	Banwenshi	\N	4	141988
142856	\N	\N	\N	\N	707402	Balomotwa	\N	4	141988
142857	\N	\N	\N	\N	707403	Kiona-Ngoyi	\N	4	141988
142858	\N	\N	\N	\N	707451	Mitwaba	\N	4	141988
142859	\N	\N	\N	\N	707501	Moero	\N	4	141989
142860	\N	\N	\N	\N	707502	Kyona-Nzini	\N	4	141989
142861	\N	\N	\N	\N	707503	Mpweto	\N	4	141989
142862	\N	\N	\N	\N	707504	Mwenge	\N	4	141989
142863	\N	\N	\N	\N	707551	Pweto	\N	4	141989
142864	\N	\N	\N	\N	707601	Source du Fleuve Congo	\N	4	141990
142865	\N	\N	\N	\N	707602	Basanga	\N	4	141990
142866	\N	\N	\N	\N	707603	Lufira	\N	4	141990
142867	\N	\N	\N	\N	707651	Kambove	\N	4	141990
142868	\N	\N	\N	\N	707652	Lwambo	\N	4	141990
142869	\N	\N	\N	\N	801100	00	\N	4	141991
142870	\N	\N	\N	\N	801200	00	\N	4	141991
142871	\N	\N	\N	\N	801300	00	\N	4	141991
142872	\N	\N	\N	\N	801400	00	\N	4	141991
142873	\N	\N	\N	\N	801500	00	\N	4	141991
142874	\N	\N	\N	\N	802101	Kakangayi	\N	4	141992
142875	\N	\N	\N	\N	802102	Movo_Nkatshia	\N	4	141992
142876	\N	\N	\N	\N	802103	Tshijiba	\N	4	141992
142877	\N	\N	\N	\N	802104	Tshilundu	\N	4	141992
142878	\N	\N	\N	\N	802151	Miabi	\N	4	141992
142879	\N	\N	\N	\N	802201	Kalela	\N	4	141993
142880	\N	\N	\N	\N	802202	Lac Munkamba	\N	4	141993
142881	\N	\N	\N	\N	802203	Mpemba	\N	4	141993
142882	\N	\N	\N	\N	802204	Mulunguyi	\N	4	141993
142883	\N	\N	\N	\N	802205	Ndomba	\N	4	141993
142884	\N	\N	\N	\N	802251	Kenankuna	\N	4	141993
142885	\N	\N	\N	\N	802301	Kabala	\N	4	141994
142886	\N	\N	\N	\N	802302	Mudiba	\N	4	141994
142887	\N	\N	\N	\N	802303	Mukumbi	\N	4	141994
142888	\N	\N	\N	\N	802304	Mulenda	\N	4	141994
142889	\N	\N	\N	\N	802351	Lupatapata	\N	4	141994
142890	\N	\N	\N	\N	802401	Nsangu	\N	4	141995
142891	\N	\N	\N	\N	802402	Baluba_Lubilanji	\N	4	141995
142892	\N	\N	\N	\N	802403	Mutuayi	\N	4	141995
142893	\N	\N	\N	\N	802404	Tshitolo	\N	4	141995
142894	\N	\N	\N	\N	802451	Katanda	\N	4	141995
142895	\N	\N	\N	\N	802452	Dilunga	\N	4	141995
142896	\N	\N	\N	\N	802501	Kalondji_Sud	\N	4	141996
142897	\N	\N	\N	\N	802502	Lukalaba	\N	4	141996
142898	\N	\N	\N	\N	802503	Kalelu	\N	4	141996
142899	\N	\N	\N	\N	802504	Tshipuka	\N	4	141996
142900	\N	\N	\N	\N	802505	Kampatshi	\N	4	141996
142901	\N	\N	\N	\N	802551	Tshilenge	\N	4	141996
142902	\N	\N	\N	\N	803101	Lubi	\N	4	141997
142903	\N	\N	\N	\N	803102	Entre Lubi et Kundoyi	\N	4	141997
142904	\N	\N	\N	\N	803103	Entre Kundoyi et Miabi	\N	4	141997
142905	\N	\N	\N	\N	803104	Batetela	\N	4	141997
142906	\N	\N	\N	\N	803105	Basonge	\N	4	141997
142907	\N	\N	\N	\N	803106	Sankuru	\N	4	141997
142908	\N	\N	\N	\N	803107	Pania_Mutombo	\N	4	141997
142909	\N	\N	\N	\N	803108	Kashindi	\N	4	141997
142910	\N	\N	\N	\N	803151	Lusambo	\N	4	141997
142911	\N	\N	\N	\N	803201	Basho	\N	4	141998
142912	\N	\N	\N	\N	803202	Ohindo	\N	4	141998
142913	\N	\N	\N	\N	803203	Atshuru	\N	4	141998
142914	\N	\N	\N	\N	803204	Bankutshu_Lukenie	\N	4	141998
142915	\N	\N	\N	\N	803205	Bankutshu_Dibele	\N	4	141998
142916	\N	\N	\N	\N	803206	Batetela_Dibele	\N	4	141998
142917	\N	\N	\N	\N	803251	Kole	\N	4	141998
142918	\N	\N	\N	\N	803301	Okutu	\N	4	141999
142919	\N	\N	\N	\N	803302	Bakela	\N	4	141999
142920	\N	\N	\N	\N	803303	Bahamba 1	\N	4	141999
142921	\N	\N	\N	\N	803304	Batetela	\N	4	141999
142922	\N	\N	\N	\N	803305	Bahamba 2	\N	4	141999
142923	\N	\N	\N	\N	803306	Djonga	\N	4	141999
142924	\N	\N	\N	\N	803351	Lomela	\N	4	141999
142925	\N	\N	\N	\N	803401	Ukulungu	\N	4	142000
142926	\N	\N	\N	\N	803402	Djalo	\N	4	142000
142927	\N	\N	\N	\N	803403	Lonya	\N	4	142000
142928	\N	\N	\N	\N	803404	Ngandu	\N	4	142000
142929	\N	\N	\N	\N	803405	Watambulu_Sud	\N	4	142000
142930	\N	\N	\N	\N	803406	Watambulu_Nord	\N	4	142000
142931	\N	\N	\N	\N	803407	Lomami	\N	4	142000
142932	\N	\N	\N	\N	803408	Basambala	\N	4	142000
142933	\N	\N	\N	\N	803409	Lukumbe	\N	4	142000
142934	\N	\N	\N	\N	803451	Katako_Kombe	\N	4	142000
142935	\N	\N	\N	\N	803501	Basonge	\N	4	142001
142936	\N	\N	\N	\N	803502	Ndjovo	\N	4	142001
142937	\N	\N	\N	\N	803503	Mondja_Ngandu	\N	4	142001
142938	\N	\N	\N	\N	803504	Ngandu_Wuma	\N	4	142001
142939	\N	\N	\N	\N	803551	Lubefu	\N	4	142001
142940	\N	\N	\N	\N	803601	Lukfungu	\N	4	142002
142941	\N	\N	\N	\N	803602	Lutshimba	\N	4	142002
142942	\N	\N	\N	\N	803603	Ahamba_Mange	\N	4	142002
142943	\N	\N	\N	\N	803604	Vungi	\N	4	142002
142944	\N	\N	\N	\N	803605	Watambulu	\N	4	142002
142945	\N	\N	\N	\N	803606	Mambelu Luhembe	\N	4	142002
142946	\N	\N	\N	\N	803607	Kondo_Tshumbe	\N	4	142002
142947	\N	\N	\N	\N	803608	Olemba	\N	4	142002
142948	\N	\N	\N	\N	803609	Batetela Lukenie	\N	4	142002
142949	\N	\N	\N	\N	803651	Lodja	\N	4	142002
142950	\N	\N	\N	\N	804101	Kanutshina	\N	4	142003
142951	\N	\N	\N	\N	804102	Mulundu	\N	4	142003
142952	\N	\N	\N	\N	804103	Kanda_Kanda	\N	4	142003
142953	\N	\N	\N	\N	804104	Katshisungu	\N	4	142003
142954	\N	\N	\N	\N	804105	Mwene-Ditu	\N	4	142003
142955	\N	\N	\N	\N	804151	Mwene-Ditu	\N	4	142003
142956	\N	\N	\N	\N	804152	Luputa	\N	4	142003
142957	\N	\N	\N	\N	804201	Luekeshi	\N	4	142004
142958	\N	\N	\N	\N	804202	Kamiji	\N	4	142004
142959	\N	\N	\N	\N	804301	Ngandajika	\N	4	142005
142960	\N	\N	\N	\N	804302	Tshiyamba	\N	4	142005
142961	\N	\N	\N	\N	804303	Bakwa_Mulumba	\N	4	142005
142962	\N	\N	\N	\N	804304	Bena_Kalambayi	\N	4	142005
142963	\N	\N	\N	\N	804305	Baluba _Shankadi	\N	4	142005
142964	\N	\N	\N	\N	804351	Ngandajika	\N	4	142005
142965	\N	\N	\N	\N	804352	Kalambayi	\N	4	142005
142966	\N	\N	\N	\N	804401	Vunayi	\N	4	142006
142967	\N	\N	\N	\N	804402	Ludimbi_Lukula	\N	4	142006
142968	\N	\N	\N	\N	804403	Lufubu_Lomami	\N	4	142006
142969	\N	\N	\N	\N	804404	Lubangule	\N	4	142006
142970	\N	\N	\N	\N	804405	Lukashi_Lualu	\N	4	142006
142971	\N	\N	\N	\N	804406	Kabinda	\N	4	142006
142972	\N	\N	\N	\N	804451	Kabinda	\N	4	142006
142973	\N	\N	\N	\N	804501	Bekalebwe	\N	4	142007
142974	\N	\N	\N	\N	804502	Tshofa	\N	4	142007
142975	\N	\N	\N	\N	804503	Lubao	\N	4	142007
142976	\N	\N	\N	\N	804504	Kisengwa	\N	4	142007
142977	\N	\N	\N	\N	804551	Lubao	\N	4	142007
142978	\N	\N	\N	\N	901100	00	\N	4	142009
142979	\N	\N	\N	\N	901200	00	\N	4	142009
142980	\N	\N	\N	\N	901300	00	\N	4	142009
142981	\N	\N	\N	\N	901400	00	\N	4	142009
142982	\N	\N	\N	\N	902101	Dibanda	\N	4	142010
142983	\N	\N	\N	\N	902102	Kamuandu	\N	4	142010
142984	\N	\N	\N	\N	902103	Dibatayi	\N	4	142010
142985	\N	\N	\N	\N	902104	Kasangidi	\N	4	142010
142986	\N	\N	\N	\N	902105	Tshishilu	\N	4	142010
142987	\N	\N	\N	\N	902151	Dibaya	\N	4	142010
142988	\N	\N	\N	\N	902152	Tshimbulu	\N	4	142010
142989	\N	\N	\N	\N	902201	Lueta	\N	4	142011
142990	\N	\N	\N	\N	902202	Kabelekese	\N	4	142011
142991	\N	\N	\N	\N	902203	Bambaie	\N	4	142011
142992	\N	\N	\N	\N	902204	Bushimaie	\N	4	142011
142993	\N	\N	\N	\N	902205	Lusanza	\N	4	142011
142994	\N	\N	\N	\N	902206	Loatshi	\N	4	142011
142995	\N	\N	\N	\N	902207	Kalunga	\N	4	142011
142996	\N	\N	\N	\N	902251	Luiza	\N	4	142011
142997	\N	\N	\N	\N	902301	Tshitadi	\N	4	142012
142998	\N	\N	\N	\N	902302	Kafuba	\N	4	142012
142999	\N	\N	\N	\N	902303	Bulungu	\N	4	142012
143000	\N	\N	\N	\N	902304	Matamba	\N	4	142012
143001	\N	\N	\N	\N	902305	Muswaswa	\N	4	142012
143002	\N	\N	\N	\N	902306	Miao	\N	4	142012
143003	\N	\N	\N	\N	902307	Bena_Ngoshi (Mutefu)	\N	4	142012
143004	\N	\N	\N	\N	902308	Kavula	\N	4	142012
143005	\N	\N	\N	\N	902309	Bashi_Mboie	\N	4	142012
143006	\N	\N	\N	\N	902351	Kazumba	\N	4	142012
143007	\N	\N	\N	\N	902401	Lombelo	\N	4	142013
143008	\N	\N	\N	\N	902402	Bena_Mamba	\N	4	142013
143009	\N	\N	\N	\N	902403	Lusonge	\N	4	142013
143010	\N	\N	\N	\N	902404	Muanza_Ngoma	\N	4	142013
143011	\N	\N	\N	\N	902405	Diofwa	\N	4	142013
143012	\N	\N	\N	\N	902406	Tshibungu	\N	4	142013
143013	\N	\N	\N	\N	902407	Tshibote	\N	4	142013
143014	\N	\N	\N	\N	902451	Demba	\N	4	142013
143015	\N	\N	\N	\N	902501	Lubi	\N	4	142014
143016	\N	\N	\N	\N	902502	Lubudi	\N	4	142014
143017	\N	\N	\N	\N	902503	Kundoyi	\N	4	142014
143018	\N	\N	\N	\N	902504	Mashala	\N	4	142014
143019	\N	\N	\N	\N	902505	Lukibu	\N	4	142014
143020	\N	\N	\N	\N	902551	Dimbelenge	\N	4	142014
143021	\N	\N	\N	\N	903101	Kabambaie	\N	4	142015
143022	\N	\N	\N	\N	903102	Djoko_Punda	\N	4	142015
143023	\N	\N	\N	\N	903103	Luebo_Wedi	\N	4	142015
143024	\N	\N	\N	\N	903104	Luebo_Lulengele	\N	4	142015
143025	\N	\N	\N	\N	903151	Luebo	\N	4	142015
143026	\N	\N	\N	\N	903201	Lovua_Longatshimo	\N	4	142016
143027	\N	\N	\N	\N	903202	Lovua_Lushiku	\N	4	142016
143028	\N	\N	\N	\N	903203	Bapende	\N	4	142016
143029	\N	\N	\N	\N	903204	Kasai_Kabambayi	\N	4	142016
143030	\N	\N	\N	\N	903205	Tshikapa	\N	4	142016
143031	\N	\N	\N	\N	903206	Bakwa_Nyambi	\N	4	142016
143032	\N	\N	\N	\N	903207	Kasai_Lunyeka	\N	4	142016
143033	\N	\N	\N	\N	903208	Kasai-Longatshimo	\N	4	142016
143034	\N	\N	\N	\N	903209	Kasadisadi	\N	4	142016
143035	\N	\N	\N	\N	903301	Sud_Banga	\N	4	142017
143036	\N	\N	\N	\N	903302	Mapangu	\N	4	142017
143037	\N	\N	\N	\N	903303	Basongo	\N	4	142017
143038	\N	\N	\N	\N	903304	Ilebo Malu_Malu	\N	4	142017
143039	\N	\N	\N	\N	903351	Ilebo	\N	4	142017
143040	\N	\N	\N	\N	903401	Bakuba_Mweka	\N	4	142018
143041	\N	\N	\N	\N	903451	Mweka	\N	4	142018
143042	\N	\N	\N	\N	903501	Yaelima	\N	4	142019
143043	\N	\N	\N	\N	903502	Ndengese_Ikolombe	\N	4	142019
143044	\N	\N	\N	\N	903551	Dekese	\N	4	142019
143045	\N	\N	\N	\N	-24560446	Alexgroupe	\N	5	142021
143046	\N	\N	\N	\N	-16273698	Bambuba-Kisiki	\N	5	142025
143047	\N	\N	\N	\N	-15928020	LODA	\N	5	142023
143048	\N	\N	\N	\N	-14640166	LONDROMA	\N	5	142023
143049	\N	\N	\N	\N	-12648317	alex test 3	\N	5	142578
143050	\N	\N	\N	\N	-12140951	NDIKPA - ZENGO	\N	5	142023
143051	\N	\N	\N	\N	-7988515	Bambuba Kisiki	\N	5	142024
143052	\N	\N	\N	\N	-6617205	Banade Kainama	\N	5	142025
143053	\N	\N	\N	\N	-6614410	Banade Kainama	\N	5	142025
143054	\N	\N	\N	\N	-6614285	Madiwe	\N	5	142026
143055	\N	\N	\N	\N	-6614159	Banande Kainama	\N	5	142026
143056	\N	\N	\N	\N	-6604578	Banade Kainama	\N	5	142024
143057	\N	\N	\N	\N	-6079858	Madiwe	\N	5	142024
143058	\N	\N	\N	\N	-6079648	Madiwe	\N	5	142025
143059	\N	\N	\N	\N	-6005222	Pakwo	\N	5	142592
143060	\N	\N	\N	\N	-5938094	Batumba	\N	5	142716
143061	\N	\N	\N	\N	-5937319	Munyanjiro	\N	5	142027
143062	\N	\N	\N	\N	-5931297	Tubimbi	\N	5	142695
143063	\N	\N	\N	\N	-2426051	Luongo	\N	5	142028
143064	\N	\N	\N	\N	-2407442	Mafuo	\N	5	142029
143065	\N	\N	\N	\N	10110001	Anciens Combattants	\N	5	142032
143066	\N	\N	\N	\N	10110002	Bangu	\N	5	142032
143067	\N	\N	\N	\N	10110003	Basoko	\N	5	142032
143068	\N	\N	\N	\N	10110004	Camp 2Ã¨ Cite O.U.A.	\N	5	142032
143069	\N	\N	\N	\N	10110005	Camp Badiadingi	\N	5	142032
143070	\N	\N	\N	\N	10110006	Camp Ebeya I	\N	5	142032
143071	\N	\N	\N	\N	10110007	Camp Kin 2	\N	5	142032
143072	\N	\N	\N	\N	10110008	Camp Loano	\N	5	142032
143073	\N	\N	\N	\N	10110009	Camp Tshatshi	\N	5	142032
143074	\N	\N	\N	\N	10110010	Djelo-Binza	\N	5	142032
143075	\N	\N	\N	\N	10110011	Joli Parc	\N	5	142032
143076	\N	\N	\N	\N	10110012	Kinkenda	\N	5	142032
143077	\N	\N	\N	\N	10110013	Kinsuka-Pecheurs	\N	5	142032
143078	\N	\N	\N	\N	10110014	Lisala	\N	5	142032
143079	\N	\N	\N	\N	10110015	Lonzo	\N	5	142032
143080	\N	\N	\N	\N	10110016	Lubudi	\N	5	142032
143081	\N	\N	\N	\N	10110017	Lukunga	\N	5	142032
143082	\N	\N	\N	\N	10110018	Mama Mobutu	\N	5	142032
143083	\N	\N	\N	\N	10110019	Manenga	\N	5	142032
143084	\N	\N	\N	\N	10110020	Mfinda	\N	5	142032
143085	\N	\N	\N	\N	10110021	Mpunda	\N	5	142032
143086	\N	\N	\N	\N	10110022	Ngomba_Kinkusa	\N	5	142032
143087	\N	\N	\N	\N	10110023	Congo (Zaire)	\N	5	142032
143088	\N	\N	\N	\N	10110024	Ebeya II	\N	5	142032
143089	\N	\N	\N	\N	10120001	Itimbiri	\N	5	142033
143090	\N	\N	\N	\N	10120002	Kilimani	\N	5	142033
143091	\N	\N	\N	\N	10120003	Kinkela	\N	5	142033
143092	\N	\N	\N	\N	10120004	Lisala	\N	5	142033
143093	\N	\N	\N	\N	10120005	Lubudi	\N	5	142033
143094	\N	\N	\N	\N	10120006	Nganda	\N	5	142033
143095	\N	\N	\N	\N	10120007	Salongo	\N	5	142033
143096	\N	\N	\N	\N	10120008	Wenze	\N	5	142033
143097	\N	\N	\N	\N	10130001	2Ã¨me Force Navale	\N	5	142034
143098	\N	\N	\N	\N	10130002	Batetela	\N	5	142034
143099	\N	\N	\N	\N	10130003	Cliniques	\N	5	142034
143100	\N	\N	\N	\N	10130004	Commerce	\N	5	142034
143101	\N	\N	\N	\N	10130005	Fleuve	\N	5	142034
143102	\N	\N	\N	\N	10130006	Gare	\N	5	142034
143103	\N	\N	\N	\N	10130007	Golf	\N	5	142034
143104	\N	\N	\N	\N	10130008	Haut_Commandement	\N	5	142034
143105	\N	\N	\N	\N	10130009	RÃ©volution	\N	5	142034
143106	\N	\N	\N	\N	10130010	Trois_Z	\N	5	142034
143107	\N	\N	\N	\N	10130011	Croix-Rouge	\N	5	142034
143108	\N	\N	\N	\N	10130012	Kingabwa	\N	5	142034
143109	\N	\N	\N	\N	10130013	Gondi	\N	5	142034
143110	\N	\N	\N	\N	10140001	Bitshaku_Tshaku	\N	5	142035
143111	\N	\N	\N	\N	10140002	Camp Pilote Mbaki	\N	5	142035
143112	\N	\N	\N	\N	10140003	Camp Prison Ndolo	\N	5	142035
143113	\N	\N	\N	\N	10140004	Funa	\N	5	142035
143114	\N	\N	\N	\N	10140005	Kapinga-Baku	\N	5	142035
143115	\N	\N	\N	\N	10140006	Kasai	\N	5	142035
143116	\N	\N	\N	\N	10140007	Libulu	\N	5	142035
143117	\N	\N	\N	\N	10140008	Mozindo	\N	5	142035
143118	\N	\N	\N	\N	10140009	Ndolo	\N	5	142035
143119	\N	\N	\N	\N	10140010	Tshimanga	\N	5	142035
143120	\N	\N	\N	\N	10150001	Aketi	\N	5	142036
143121	\N	\N	\N	\N	10150002	Boyoma	\N	5	142036
143122	\N	\N	\N	\N	10150003	Djalo	\N	5	142036
143123	\N	\N	\N	\N	10150004	Madimba	\N	5	142036
143124	\N	\N	\N	\N	10150005	Mongala	\N	5	142036
143125	\N	\N	\N	\N	10150006	Ngbaka	\N	5	142036
143126	\N	\N	\N	\N	10150007	Pende	\N	5	142036
143127	\N	\N	\N	\N	10150008	Pont Kasa Vubu	\N	5	142036
143128	\N	\N	\N	\N	10160001	4 Octobre	\N	5	142037
143129	\N	\N	\N	\N	10160002	Camp Lufungula	\N	5	142037
143130	\N	\N	\N	\N	10160003	C.N.E.C.I.	\N	5	142037
143131	\N	\N	\N	\N	10160004	R.T.N.C.	\N	5	142037
143132	\N	\N	\N	\N	10160005	Lokole	\N	5	142037
143133	\N	\N	\N	\N	10160006	Ngunda Lokombe	\N	5	142037
143134	\N	\N	\N	\N	10160007	Paka Djuma	\N	5	142037
143135	\N	\N	\N	\N	10160008	Singa Mopepe	\N	5	142037
143136	\N	\N	\N	\N	10160009	Wenze	\N	5	142037
143137	\N	\N	\N	\N	10170001	C.P.A.( Mushie )	\N	5	142038
143138	\N	\N	\N	\N	10170002	GÃ©nÃ©ral Singa	\N	5	142038
143139	\N	\N	\N	\N	10170003	Kimbondo	\N	5	142038
143140	\N	\N	\N	\N	10170004	Kimwenza	\N	5	142038
143141	\N	\N	\N	\N	10170005	Mama Yemo	\N	5	142038
143142	\N	\N	\N	\N	10170006	Vunda Manenga	\N	5	142038
143143	\N	\N	\N	\N	10170007	Matadi Mayo	\N	5	142038
143144	\N	\N	\N	\N	10170008	Mitendi	\N	5	142038
143145	\N	\N	\N	\N	10170009	Ngansele	\N	5	142038
143146	\N	\N	\N	\N	10170010	Ngombe Lutendele	\N	5	142038
143147	\N	\N	\N	\N	10170011	Ndjili Kilambu	\N	5	142038
143148	\N	\N	\N	\N	10170012	Mama Mobutu	\N	5	142038
143149	\N	\N	\N	\N	10170013	Plateau	\N	5	142038
143150	\N	\N	\N	\N	10170014	Masanga Mbila	\N	5	142038
143151	\N	\N	\N	\N	10210001	Badiadingi	\N	5	142039
143152	\N	\N	\N	\N	10210002	CitÃ© Verte	\N	5	142039
143153	\N	\N	\N	\N	10210003	24 Novembre	\N	5	142039
143154	\N	\N	\N	\N	10210004	Inga	\N	5	142039
143155	\N	\N	\N	\N	10210005	Kalunga	\N	5	142039
143156	\N	\N	\N	\N	10210006	Kinduelo	\N	5	142039
143157	\N	\N	\N	\N	10210007	Konde	\N	5	142039
143158	\N	\N	\N	\N	10210008	Lubudi	\N	5	142039
143159	\N	\N	\N	\N	10210009	Madiata	\N	5	142039
143160	\N	\N	\N	\N	10210010	Mama-Mobutu Sese	\N	5	142039
143161	\N	\N	\N	\N	10210011	Molende	\N	5	142039
143162	\N	\N	\N	\N	10210012	Mwana-Tunu	\N	5	142039
143163	\N	\N	\N	\N	10210013	Ngafani	\N	5	142039
143164	\N	\N	\N	\N	10210014	Nkulu-Pululu	\N	5	142039
143165	\N	\N	\N	\N	10210015	Mbambu	\N	5	142039
143166	\N	\N	\N	\N	10220001	Adoula	\N	5	142040
143167	\N	\N	\N	\N	10220002	Lubudi	\N	5	142040
143168	\N	\N	\N	\N	10220003	Camp Lt Colonel Kokolo	\N	5	142040
143169	\N	\N	\N	\N	10220004	Kasa-Vubu	\N	5	142040
143170	\N	\N	\N	\N	10220005	Lingwala	\N	5	142040
143171	\N	\N	\N	\N	10220006	Bisengo	\N	5	142040
143172	\N	\N	\N	\N	10220007	Lumumba	\N	5	142040
143173	\N	\N	\N	\N	10220008	Makelele	\N	5	142040
143174	\N	\N	\N	\N	10230001	Assossa	\N	5	142041
143175	\N	\N	\N	\N	10230002	Anciens combattants	\N	5	142041
143176	\N	\N	\N	\N	10230003	Lodja	\N	5	142041
143177	\N	\N	\N	\N	10230004	Lubumbashi	\N	5	142041
143178	\N	\N	\N	\N	10230005	O.N.L.	\N	5	142041
143179	\N	\N	\N	\N	10230006	Shaba	\N	5	142041
143180	\N	\N	\N	\N	10230007	Salongo	\N	5	142041
143181	\N	\N	\N	\N	10240001	Matonge 1	\N	5	142042
143182	\N	\N	\N	\N	10240002	Matonge 2	\N	5	142042
143183	\N	\N	\N	\N	10240003	Matonge 3	\N	5	142042
143184	\N	\N	\N	\N	10240004	20 Mai	\N	5	142042
143185	\N	\N	\N	\N	10240005	Kauka 1	\N	5	142042
143186	\N	\N	\N	\N	10240006	Kauka 2	\N	5	142042
143187	\N	\N	\N	\N	10240007	Kauka 3	\N	5	142042
143188	\N	\N	\N	\N	10240008	Yolo Nord 1	\N	5	142042
143189	\N	\N	\N	\N	10240009	Yolo Nord 2	\N	5	142042
143190	\N	\N	\N	\N	10240010	Yolo Nord 3	\N	5	142042
143191	\N	\N	\N	\N	10240011	Yolo Sud 1	\N	5	142042
143192	\N	\N	\N	\N	10240012	Yolo Sud 2	\N	5	142042
143193	\N	\N	\N	\N	10240013	Yolo Sud 3	\N	5	142042
143194	\N	\N	\N	\N	10240014	Yolo Sud 4	\N	5	142042
143195	\N	\N	\N	\N	10240015	Pinzi	\N	5	142042
143196	\N	\N	\N	\N	10240016	Kimbangu 1	\N	5	142042
143197	\N	\N	\N	\N	10240017	Kimbangu 2	\N	5	142042
143198	\N	\N	\N	\N	10240018	Kimbangu 3	\N	5	142042
143199	\N	\N	\N	\N	10250001	Assossa	\N	5	142043
143200	\N	\N	\N	\N	10250002	Diangenda	\N	5	142043
143201	\N	\N	\N	\N	10250003	Diomi	\N	5	142043
143202	\N	\N	\N	\N	10250004	Elengesa	\N	5	142043
143203	\N	\N	\N	\N	10250005	Karthoum	\N	5	142043
143204	\N	\N	\N	\N	10250006	24 Novembre	\N	5	142043
143205	\N	\N	\N	\N	10250007	Peti Peti	\N	5	142043
143206	\N	\N	\N	\N	10250008	Saio	\N	5	142043
143207	\N	\N	\N	\N	10260001	Mongala	\N	5	142044
143208	\N	\N	\N	\N	10260002	Ubangui	\N	5	142044
143209	\N	\N	\N	\N	10260003	Lokoro	\N	5	142044
143210	\N	\N	\N	\N	10260004	Maindombe	\N	5	142044
143211	\N	\N	\N	\N	10260005	Kwango	\N	5	142044
143212	\N	\N	\N	\N	10260006	Lukenie	\N	5	142044
143213	\N	\N	\N	\N	10260007	Kasai	\N	5	142044
143214	\N	\N	\N	\N	10260008	Mfimi	\N	5	142044
143215	\N	\N	\N	\N	10260009	Lt Pilote Mbaki	\N	5	142044
143216	\N	\N	\N	\N	10260010	Dipiya	\N	5	142044
143217	\N	\N	\N	\N	10260011	Ntomba	\N	5	142044
143218	\N	\N	\N	\N	10260012	Mbandaka	\N	5	142044
143219	\N	\N	\N	\N	10260013	Matadi	\N	5	142044
143220	\N	\N	\N	\N	10270001	Bagata	\N	5	142045
143221	\N	\N	\N	\N	10270002	Bolima	\N	5	142045
143222	\N	\N	\N	\N	10270003	Mabulu	\N	5	142045
143223	\N	\N	\N	\N	10270004	Malala	\N	5	142045
143224	\N	\N	\N	\N	10270005	Mawanga	\N	5	142045
143225	\N	\N	\N	\N	10270006	Mfidi	\N	5	142045
143226	\N	\N	\N	\N	10270007	Mikasi	\N	5	142045
143227	\N	\N	\N	\N	10270008	Salongo	\N	5	142045
143228	\N	\N	\N	\N	10270009	Selo	\N	5	142045
143229	\N	\N	\N	\N	10270010	Tampa	\N	5	142045
143230	\N	\N	\N	\N	10270011	Uele	\N	5	142045
143231	\N	\N	\N	\N	10310001	Echangeur	\N	5	142046
143232	\N	\N	\N	\N	10310002	Ecole	\N	5	142046
143233	\N	\N	\N	\N	10310003	Camp Mobutu	\N	5	142046
143234	\N	\N	\N	\N	10310004	Camp Osso	\N	5	142046
143235	\N	\N	\N	\N	10310005	Commercial	\N	5	142046
143236	\N	\N	\N	\N	10310006	Foire	\N	5	142046
143237	\N	\N	\N	\N	10310007	Gombele	\N	5	142046
143238	\N	\N	\N	\N	10310008	Kemi	\N	5	142046
143239	\N	\N	\N	\N	10310009	Kimpwanza	\N	5	142046
143240	\N	\N	\N	\N	10310010	Livulu	\N	5	142046
143241	\N	\N	\N	\N	10310011	Madrandele	\N	5	142046
143242	\N	\N	\N	\N	10310012	Masano	\N	5	142046
143243	\N	\N	\N	\N	10310013	Mbanza-Lemba	\N	5	142046
143244	\N	\N	\N	\N	10310014	Molo	\N	5	142046
143245	\N	\N	\N	\N	10310015	Salongo	\N	5	142046
143246	\N	\N	\N	\N	10320001	Baobab	\N	5	142047
143247	\N	\N	\N	\N	10320002	Bulambemba	\N	5	142047
143248	\N	\N	\N	\N	10320003	Luyi	\N	5	142047
143249	\N	\N	\N	\N	10320004	Mateba	\N	5	142047
143250	\N	\N	\N	\N	10320005	Mukulwa	\N	5	142047
143251	\N	\N	\N	\N	10320006	Mpila	\N	5	142047
143252	\N	\N	\N	\N	10330001	Agricole	\N	5	142048
143253	\N	\N	\N	\N	10330002	Industriel	\N	5	142048
143254	\N	\N	\N	\N	10330003	GÃ©nÃ©ral Masiala	\N	5	142048
143255	\N	\N	\N	\N	10330004	Kingabwa	\N	5	142048
143256	\N	\N	\N	\N	10330005	Mayulu	\N	5	142048
143257	\N	\N	\N	\N	10330006	Mbamu	\N	5	142048
143258	\N	\N	\N	\N	10330007	Mateba	\N	5	142048
143259	\N	\N	\N	\N	10330008	Mfumu-Mvula	\N	5	142048
143260	\N	\N	\N	\N	10330009	Mombele	\N	5	142048
143261	\N	\N	\N	\N	10330010	Mososo	\N	5	142048
143262	\N	\N	\N	\N	10330011	Nzadi	\N	5	142048
143263	\N	\N	\N	\N	10330012	RÃ©sidentiel	\N	5	142048
143264	\N	\N	\N	\N	10330013	Salongo	\N	5	142048
143265	\N	\N	\N	\N	10330014	Ndanu	\N	5	142048
143266	\N	\N	\N	\N	10340001	Totaka	\N	5	142049
143267	\N	\N	\N	\N	10340002	Basuki	\N	5	142049
143268	\N	\N	\N	\N	10340003	Lunionzo	\N	5	142049
143269	\N	\N	\N	\N	10340004	Lumumba	\N	5	142049
143270	\N	\N	\N	\N	10340005	Lukunga	\N	5	142049
143271	\N	\N	\N	\N	10340006	Malemba	\N	5	142049
143272	\N	\N	\N	\N	10340007	Maziba	\N	5	142049
143273	\N	\N	\N	\N	10340008	Loeka	\N	5	142049
143274	\N	\N	\N	\N	10340009	Vivi	\N	5	142049
143275	\N	\N	\N	\N	10340010	Lubefu	\N	5	142049
143276	\N	\N	\N	\N	10340011	Sankuru	\N	5	142049
143277	\N	\N	\N	\N	10340012	Sumbuka	\N	5	142049
143278	\N	\N	\N	\N	10340013	Mbumba_Mpoko	\N	5	142049
143279	\N	\N	\N	\N	10340014	Dondo	\N	5	142049
143280	\N	\N	\N	\N	10350001	Amba	\N	5	142050
143281	\N	\N	\N	\N	10350002	Bikanga	\N	5	142050
143282	\N	\N	\N	\N	10350003	Dingi-Dingi	\N	5	142050
143283	\N	\N	\N	\N	10350004	La Paix	\N	5	142050
143284	\N	\N	\N	\N	10350005	Kitomesa	\N	5	142050
143285	\N	\N	\N	\N	10350006	Kisenso Gare	\N	5	142050
143286	\N	\N	\N	\N	10350007	Mama- Mobutu	\N	5	142050
143287	\N	\N	\N	\N	10350008	Mbuku	\N	5	142050
143288	\N	\N	\N	\N	10350009	Ngomba	\N	5	142050
143289	\N	\N	\N	\N	10350010	Nsola	\N	5	142050
143290	\N	\N	\N	\N	10350011	Mission	\N	5	142050
143291	\N	\N	\N	\N	10350012	27 Octobre	\N	5	142050
143292	\N	\N	\N	\N	10350013	Regideso	\N	5	142050
143293	\N	\N	\N	\N	10350014	RÃ©volution	\N	5	142050
143294	\N	\N	\N	\N	10410001	Inga	\N	5	142051
143295	\N	\N	\N	\N	10410002	Mongala	\N	5	142051
143296	\N	\N	\N	\N	10410003	Ubangui	\N	5	142051
143297	\N	\N	\N	\N	10410004	Makasi	\N	5	142051
143298	\N	\N	\N	\N	10410005	Bandundu	\N	5	142051
143299	\N	\N	\N	\N	10410006	Goma	\N	5	142051
143300	\N	\N	\N	\N	10410007	Tshuapa	\N	5	142051
143301	\N	\N	\N	\N	10410008	Kivu	\N	5	142051
143302	\N	\N	\N	\N	10410009	Kasai	\N	5	142051
143303	\N	\N	\N	\N	10410010	Haut-Congo	\N	5	142051
143304	\N	\N	\N	\N	10410011	Bilombe	\N	5	142051
143305	\N	\N	\N	\N	10410012	Equateur	\N	5	142051
143306	\N	\N	\N	\N	10410013	Katanga	\N	5	142051
143307	\N	\N	\N	\N	10420001	Abattoir	\N	5	142052
143308	\N	\N	\N	\N	10420002	Boba	\N	5	142052
143309	\N	\N	\N	\N	10420003	Efoloko	\N	5	142052
143310	\N	\N	\N	\N	10420004	Imbali	\N	5	142052
143311	\N	\N	\N	\N	10420005	Kasai	\N	5	142052
143312	\N	\N	\N	\N	10420006	Kimbangu	\N	5	142052
143313	\N	\N	\N	\N	10420007	Kivu	\N	5	142052
143314	\N	\N	\N	\N	10420008	Lokari	\N	5	142052
143315	\N	\N	\N	\N	10420009	Lubamba	\N	5	142052
143316	\N	\N	\N	\N	10420010	Mafuta-Kizola	\N	5	142052
143317	\N	\N	\N	\N	10420011	Mandiangu	\N	5	142052
143318	\N	\N	\N	\N	10420012	Mapela	\N	5	142052
143319	\N	\N	\N	\N	10420013	Matadi	\N	5	142052
143320	\N	\N	\N	\N	10420014	Mfumu-Nsuka	\N	5	142052
143321	\N	\N	\N	\N	10420015	Nzuzi wa Mbombo	\N	5	142052
143322	\N	\N	\N	\N	10420016	Pelende	\N	5	142052
143323	\N	\N	\N	\N	10420017	Sans-Fil	\N	5	142052
143324	\N	\N	\N	\N	10420018	Tshangu	\N	5	142052
143325	\N	\N	\N	\N	10420019	Tshuenge	\N	5	142052
143326	\N	\N	\N	\N	10420020	TÃ©lÃ©vision	\N	5	142052
143327	\N	\N	\N	\N	10420021	Zaire (Congo)	\N	5	142052
143328	\N	\N	\N	\N	10430001	Bahumbu	\N	5	142053
143329	\N	\N	\N	\N	10430002	Bamboma	\N	5	142053
143330	\N	\N	\N	\N	10430003	Boma	\N	5	142053
143331	\N	\N	\N	\N	10430004	Biyela	\N	5	142053
143332	\N	\N	\N	\N	10430005	Disasi	\N	5	142053
143333	\N	\N	\N	\N	10430006	Esanga	\N	5	142053
143334	\N	\N	\N	\N	10430007	Kamba-Mulumba	\N	5	142053
143335	\N	\N	\N	\N	10430008	Kikimi	\N	5	142053
143336	\N	\N	\N	\N	10430009	Kisantu	\N	5	142053
143337	\N	\N	\N	\N	10430010	Kingasani 2	\N	5	142053
143338	\N	\N	\N	\N	10430011	Kasa-Vubu	\N	5	142053
143339	\N	\N	\N	\N	10430012	Kutu	\N	5	142053
143340	\N	\N	\N	\N	10430013	Luebo	\N	5	142053
143341	\N	\N	\N	\N	10430014	Malonda	\N	5	142053
143342	\N	\N	\N	\N	10430015	Mangana	\N	5	142053
143343	\N	\N	\N	\N	10430016	Maviokele	\N	5	142053
143344	\N	\N	\N	\N	10430017	Marechal	\N	5	142053
143345	\N	\N	\N	\N	10430018	Mikondo	\N	5	142053
143346	\N	\N	\N	\N	10430019	Mokali	\N	5	142053
143347	\N	\N	\N	\N	10430020	Mulie	\N	5	142053
143348	\N	\N	\N	\N	10430021	Mfumu-Nkento	\N	5	142053
143349	\N	\N	\N	\N	10430022	Mbwala	\N	5	142053
143350	\N	\N	\N	\N	10430023	Ngamazita	\N	5	142053
143351	\N	\N	\N	\N	10430024	Ngandu	\N	5	142053
143352	\N	\N	\N	\N	10430025	Ngampani	\N	5	142053
143353	\N	\N	\N	\N	10430026	Nsanga	\N	5	142053
143354	\N	\N	\N	\N	10430027	Nsumabua	\N	5	142053
143355	\N	\N	\N	\N	10430028	Salongo	\N	5	142053
143356	\N	\N	\N	\N	10430029	Sakombi	\N	5	142053
143357	\N	\N	\N	\N	10430030	Revolution	\N	5	142053
143358	\N	\N	\N	\N	10440001	Kinkole PÃªcheurs	\N	5	142054
143359	\N	\N	\N	\N	10440002	Kinkole Bahumbu	\N	5	142054
143360	\N	\N	\N	\N	10440003	Domaine de Nsele	\N	5	142054
143361	\N	\N	\N	\N	10440004	Mikonga	\N	5	142054
143362	\N	\N	\N	\N	10440005	Dingi Dingi	\N	5	142054
143363	\N	\N	\N	\N	10440006	Mpasa 1	\N	5	142054
143364	\N	\N	\N	\N	10440007	Mpasa 2	\N	5	142054
143365	\N	\N	\N	\N	10440008	Bibwa	\N	5	142054
143366	\N	\N	\N	\N	10440009	Buma	\N	5	142054
143367	\N	\N	\N	\N	10440010	Mikondo Civil	\N	5	142054
143368	\N	\N	\N	\N	10440011	Kindobo	\N	5	142054
143369	\N	\N	\N	\N	10440012	Mikala	\N	5	142054
143370	\N	\N	\N	\N	10440013	Fleuve	\N	5	142054
143371	\N	\N	\N	\N	10450001	Bankana	\N	5	142055
143372	\N	\N	\N	\N	10450002	Bu	\N	5	142055
143373	\N	\N	\N	\N	10450003	Dumi	\N	5	142055
143374	\N	\N	\N	\N	10450004	Kingankati	\N	5	142055
143375	\N	\N	\N	\N	10450005	Kingumu	\N	5	142055
143376	\N	\N	\N	\N	10450006	Kinzuono	\N	5	142055
143377	\N	\N	\N	\N	10450007	Kikimi	\N	5	142055
143378	\N	\N	\N	\N	10450008	Kimpoko	\N	5	142055
143379	\N	\N	\N	\N	10450009	Maindombe	\N	5	142055
143380	\N	\N	\N	\N	10450010	Maluku	\N	5	142055
143381	\N	\N	\N	\N	10450011	Mangengenge	\N	5	142055
143382	\N	\N	\N	\N	10450012	Menkao	\N	5	142055
143383	\N	\N	\N	\N	10450013	Mongata	\N	5	142055
143384	\N	\N	\N	\N	10450014	Monako	\N	5	142055
143385	\N	\N	\N	\N	10450015	Mue	\N	5	142055
143386	\N	\N	\N	\N	10450016	Ngana	\N	5	142055
143387	\N	\N	\N	\N	10450017	Nguma	\N	5	142055
143388	\N	\N	\N	\N	10450018	Yosso	\N	5	142055
143389	\N	\N	\N	\N	10450019	You	\N	5	142055
143390	\N	\N	\N	\N	10450020	Kinsi	\N	5	142055
143391	\N	\N	\N	\N	20110001	Soyo	\N	5	142056
143392	\N	\N	\N	\N	20110002	Salongo	\N	5	142056
143393	\N	\N	\N	\N	20110003	Ville_ Haute	\N	5	142056
143394	\N	\N	\N	\N	20110004	Ville_ Basse	\N	5	142056
143395	\N	\N	\N	\N	20110005	Tshimpi	\N	5	142056
143396	\N	\N	\N	\N	20120001	Kitomesa	\N	5	142057
143397	\N	\N	\N	\N	20120002	Nzanza	\N	5	142057
143398	\N	\N	\N	\N	20120003	Banana	\N	5	142057
143399	\N	\N	\N	\N	20120004	Nzinga Lutete	\N	5	142057
143400	\N	\N	\N	\N	20120005	Dibua_Nsakala	\N	5	142057
143401	\N	\N	\N	\N	20120006	Nsakala_Nsimba	\N	5	142057
143402	\N	\N	\N	\N	20120007	Lieutenant Mpaka	\N	5	142057
143403	\N	\N	\N	\N	20130001	Ngadi	\N	5	142058
143404	\N	\N	\N	\N	20130002	Mbuzi	\N	5	142058
143405	\N	\N	\N	\N	20130003	Mongo	\N	5	142058
143406	\N	\N	\N	\N	20130004	Mpozo	\N	5	142058
143407	\N	\N	\N	\N	20130005	Mvuzi	\N	5	142058
143408	\N	\N	\N	\N	20210001	Guzi	\N	5	142059
143409	\N	\N	\N	\N	20210002	Lovo	\N	5	142059
143410	\N	\N	\N	\N	20210003	Luki	\N	5	142059
143411	\N	\N	\N	\N	20210004	Seka-Mbote	\N	5	142059
143412	\N	\N	\N	\N	20210005	Tshutuzi	\N	5	142059
143413	\N	\N	\N	\N	20210006	Bunionzi	\N	5	142059
143414	\N	\N	\N	\N	20220001	Lukunga	\N	5	142060
143415	\N	\N	\N	\N	20220002	Tadi	\N	5	142060
143416	\N	\N	\N	\N	20220003	Kutu	\N	5	142060
143417	\N	\N	\N	\N	20220004	Kimbangu	\N	5	142060
143418	\N	\N	\N	\N	20220005	Bunzi	\N	5	142060
143419	\N	\N	\N	\N	20220006	Mao	\N	5	142060
143420	\N	\N	\N	\N	20220007	Ngomuila	\N	5	142060
143421	\N	\N	\N	\N	20230001	Boma	\N	5	142061
143422	\N	\N	\N	\N	20230002	Kikuku	\N	5	142061
143423	\N	\N	\N	\N	20230003	Minkondo	\N	5	142061
143424	\N	\N	\N	\N	20230004	Mvuangu	\N	5	142061
143425	\N	\N	\N	\N	20240101	Kinlau	\N	5	142062
143426	\N	\N	\N	\N	20240102	Malela	\N	5	142062
143427	\N	\N	\N	\N	20240103	Hors Milieu Coutumier	\N	5	142062
143428	\N	\N	\N	\N	20240201	Kamba Bonde	\N	5	142063
143429	\N	\N	\N	\N	20240202	Makayi-Niema	\N	5	142063
143430	\N	\N	\N	\N	20240203	Malemba	\N	5	142063
143431	\N	\N	\N	\N	20240204	Mamputu	\N	5	142063
143432	\N	\N	\N	\N	20240205	Matamba-Makanzi	\N	5	142063
143433	\N	\N	\N	\N	20240206	Matamba-Mangoyo	\N	5	142063
143434	\N	\N	\N	\N	20240207	Muanda	\N	5	142063
143435	\N	\N	\N	\N	20240208	Nsiamfumu	\N	5	142063
143436	\N	\N	\N	\N	20240209	Nzemba	\N	5	142063
143437	\N	\N	\N	\N	20240210	Sulu	\N	5	142063
143438	\N	\N	\N	\N	20240211	Tende	\N	5	142063
143439	\N	\N	\N	\N	20240212	Tshikayi	\N	5	142063
143440	\N	\N	\N	\N	20240213	Tshimbanza	\N	5	142063
143441	\N	\N	\N	\N	20240214	Yema	\N	5	142063
143442	\N	\N	\N	\N	20240215	Poste Commercial	\N	5	142063
143443	\N	\N	\N	\N	20240216	Mission	\N	5	142063
143444	\N	\N	\N	\N	20240217	Centre Administratif	\N	5	142063
143445	\N	\N	\N	\N	20240301	Binda-Loanda	\N	5	142064
143446	\N	\N	\N	\N	20240302	Kinkakasa	\N	5	142064
143447	\N	\N	\N	\N	20240303	Kinkalado	\N	5	142064
143448	\N	\N	\N	\N	20240304	Lamba-Nteye	\N	5	142064
143449	\N	\N	\N	\N	20240305	Lemba-Nkazu	\N	5	142064
143450	\N	\N	\N	\N	20240306	Lolo-Vevolo	\N	5	142064
143451	\N	\N	\N	\N	20240307	Lunga-Vasa	\N	5	142064
143452	\N	\N	\N	\N	20240308	Lusanga-Muanza	\N	5	142064
143453	\N	\N	\N	\N	20240309	Manzadi	\N	5	142064
143454	\N	\N	\N	\N	20240310	Mateba	\N	5	142064
143455	\N	\N	\N	\N	20240311	Mbungu	\N	5	142064
143456	\N	\N	\N	\N	20240312	Sumba Kituti	\N	5	142064
143457	\N	\N	\N	\N	20245101	Banana	\N	5	142065
143458	\N	\N	\N	\N	20245102	Malamba_Bendo 2	\N	5	142065
143459	\N	\N	\N	\N	20245103	Ocean	\N	5	142065
143460	\N	\N	\N	\N	20245104	Tshiompo	\N	5	142065
143461	\N	\N	\N	\N	20245105	Vulumba	\N	5	142065
143462	\N	\N	\N	\N	20245106	Malamba_Mbendo 1	\N	5	142065
143463	\N	\N	\N	\N	20245107	Mpioka	\N	5	142065
143464	\N	\N	\N	\N	20245108	Tonde	\N	5	142065
143465	\N	\N	\N	\N	20245109	Mutshindi	\N	5	142065
143466	\N	\N	\N	\N	20245110	Mbwede	\N	5	142065
143467	\N	\N	\N	\N	20245111	Mweliambu	\N	5	142065
143468	\N	\N	\N	\N	20245112	Mutoke	\N	5	142065
143469	\N	\N	\N	\N	20245113	Kinsiaku	\N	5	142065
143470	\N	\N	\N	\N	20245114	Centre Ville	\N	5	142065
143471	\N	\N	\N	\N	20310101	Bas _Kuimba	\N	5	142066
143472	\N	\N	\N	\N	20310102	Haut _Kuimba	\N	5	142066
143473	\N	\N	\N	\N	20310103	Kayi_Nzobe	\N	5	142066
143474	\N	\N	\N	\N	20310104	Mbuku_Nzobe	\N	5	142066
143475	\N	\N	\N	\N	20310105	Nama_Tsanga	\N	5	142066
143476	\N	\N	\N	\N	20310106	Ndingi	\N	5	142066
143477	\N	\N	\N	\N	20310107	Tembe Nzobe	\N	5	142066
143478	\N	\N	\N	\N	20310108	Tsanga Nord	\N	5	142066
143479	\N	\N	\N	\N	20310109	Hors Mileu Coutumier	\N	5	142066
143480	\N	\N	\N	\N	20310201	Kasamvu	\N	5	142067
143481	\N	\N	\N	\N	20310202	Kikamba	\N	5	142067
143482	\N	\N	\N	\N	20310203	Mbemba	\N	5	142067
143483	\N	\N	\N	\N	20310204	Niali	\N	5	142067
143484	\N	\N	\N	\N	20310205	Ntene Yemo	\N	5	142067
143485	\N	\N	\N	\N	20310206	Fuku	\N	5	142067
143486	\N	\N	\N	\N	20310207	Singini	\N	5	142067
143487	\N	\N	\N	\N	20310208	Hors Milieu Coutumier	\N	5	142067
143488	\N	\N	\N	\N	20310301	Kikhokolo	\N	5	142068
143603	\N	\N	\N	\N	20330201	Baka	\N	5	142084
143489	\N	\N	\N	\N	20310302	Mbuku-Dungu	\N	5	142068
143490	\N	\N	\N	\N	20310303	Mbuku-Pholo	\N	5	142068
143491	\N	\N	\N	\N	20310304	Miyingu	\N	5	142068
143492	\N	\N	\N	\N	20310305	Nganda-Nsundi	\N	5	142068
143493	\N	\N	\N	\N	20310306	Phalanga	\N	5	142068
143494	\N	\N	\N	\N	20310307	Tsundi Nzambi	\N	5	142068
143495	\N	\N	\N	\N	20310308	Hors Milieu Coutumier	\N	5	142068
143496	\N	\N	\N	\N	20310401	Kai-Mbaku	\N	5	142069
143497	\N	\N	\N	\N	20310402	Kimbidi	\N	5	142069
143498	\N	\N	\N	\N	20310403	Kiobo-Ngoy	\N	5	142069
143499	\N	\N	\N	\N	20310404	Maduda	\N	5	142069
143500	\N	\N	\N	\N	20310405	Mbenza Masola	\N	5	142069
143501	\N	\N	\N	\N	20310406	Nlundu	\N	5	142069
143502	\N	\N	\N	\N	20310407	Tsanga-Ngoma	\N	5	142069
143503	\N	\N	\N	\N	20310408	Hors Milieu Coutumier	\N	5	142069
143504	\N	\N	\N	\N	20310501	Kifuma	\N	5	142070
143505	\N	\N	\N	\N	20310502	Kimuela	\N	5	142070
143506	\N	\N	\N	\N	20310503	Kinkonzi	\N	5	142070
143507	\N	\N	\N	\N	20310504	Lele Nsudi	\N	5	142070
143508	\N	\N	\N	\N	20310505	Lubuzi-Maleba	\N	5	142070
143509	\N	\N	\N	\N	20310506	Luvu	\N	5	142070
143510	\N	\N	\N	\N	20310507	Banga	\N	5	142070
143511	\N	\N	\N	\N	20310508	Mbenza-Nzita	\N	5	142070
143512	\N	\N	\N	\N	20310509	Ngunda-Ngunda	\N	5	142070
143513	\N	\N	\N	\N	20310510	Niolo	\N	5	142070
143514	\N	\N	\N	\N	20310511	Nkondo-Mayeka	\N	5	142070
143515	\N	\N	\N	\N	20310512	Tumba	\N	5	142070
143516	\N	\N	\N	\N	20310513	Vinda	\N	5	142070
143517	\N	\N	\N	\N	20310514	Kinanga	\N	5	142070
143518	\N	\N	\N	\N	20310515	Maba	\N	5	142070
143519	\N	\N	\N	\N	20310516	Manianga	\N	5	142070
143520	\N	\N	\N	\N	20310517	Hors Milieu Coutumier	\N	5	142070
143521	\N	\N	\N	\N	20310601	Bangula	\N	5	142071
143522	\N	\N	\N	\N	20310602	Biabu	\N	5	142071
143523	\N	\N	\N	\N	20310603	Seke	\N	5	142071
143524	\N	\N	\N	\N	20310604	Khami-Lelo	\N	5	142071
143525	\N	\N	\N	\N	20310605	Khele-Nlunzi	\N	5	142071
143526	\N	\N	\N	\N	20310606	Kimbenza	\N	5	142071
143527	\N	\N	\N	\N	20310607	Kinganda-Situ	\N	5	142071
143528	\N	\N	\N	\N	20310608	Kivutu	\N	5	142071
143529	\N	\N	\N	\N	20310609	Loango-Ndukula	\N	5	142071
143530	\N	\N	\N	\N	20310610	Loango-Nzadi	\N	5	142071
143531	\N	\N	\N	\N	20310611	Mbala-Vumu	\N	5	142071
143532	\N	\N	\N	\N	20310612	Mvoze	\N	5	142071
143533	\N	\N	\N	\N	20310613	Phuka	\N	5	142071
143534	\N	\N	\N	\N	20310614	Tuidi-Lungila	\N	5	142071
143535	\N	\N	\N	\N	20310615	Tuidi-Nzambi	\N	5	142071
143536	\N	\N	\N	\N	20310616	Tuidi-Tsundi	\N	5	142071
143537	\N	\N	\N	\N	20310617	Vaku-Nkuzi	\N	5	142071
143538	\N	\N	\N	\N	20310618	Vaku-Nzebo	\N	5	142071
143539	\N	\N	\N	\N	20310619	Hors Milieu Coutumier	\N	5	142071
143540	\N	\N	\N	\N	20310701	Bula-Naku	\N	5	142072
143541	\N	\N	\N	\N	20310702	Dizi Mbenza	\N	5	142072
143542	\N	\N	\N	\N	20310703	Kasadi	\N	5	142072
143543	\N	\N	\N	\N	20310704	Kingulu	\N	5	142072
143544	\N	\N	\N	\N	20310705	Madinga	\N	5	142072
143545	\N	\N	\N	\N	20310706	Mbinga	\N	5	142072
143546	\N	\N	\N	\N	20310707	Samba	\N	5	142072
143547	\N	\N	\N	\N	20310708	Dizi Makaba	\N	5	142072
143548	\N	\N	\N	\N	20310709	Hors Milieu Coutumier	\N	5	142072
143549	\N	\N	\N	\N	20310801	Khele	\N	5	142073
143550	\N	\N	\N	\N	20310802	Kithadi	\N	5	142073
143551	\N	\N	\N	\N	20310803	Kivunda	\N	5	142073
143552	\N	\N	\N	\N	20310804	Kizu	\N	5	142073
143553	\N	\N	\N	\N	20310805	Kimongo	\N	5	142073
143554	\N	\N	\N	\N	20310806	Ntombo-Yanga	\N	5	142073
143555	\N	\N	\N	\N	20310807	Yanga	\N	5	142073
143556	\N	\N	\N	\N	20310808	Hors Milieu Coutumier	\N	5	142073
143557	\N	\N	\N	\N	20315101	Kasa-Vubu	\N	5	142074
143558	\N	\N	\N	\N	20315102	Masiala	\N	5	142074
143559	\N	\N	\N	\N	20315103	Mobutu	\N	5	142074
143560	\N	\N	\N	\N	20320101	Kitsiengo	\N	5	142075
143561	\N	\N	\N	\N	20320102	Mongodolo	\N	5	142075
143562	\N	\N	\N	\N	20320103	Mumba-Nkazu	\N	5	142075
143563	\N	\N	\N	\N	20320104	Munu-Yalala	\N	5	142075
143564	\N	\N	\N	\N	20320105	Nlamba	\N	5	142075
143565	\N	\N	\N	\N	20320106	Seke-Banza	\N	5	142075
143566	\N	\N	\N	\N	20320201	Kavuzi	\N	5	142076
143567	\N	\N	\N	\N	20320202	Khuni	\N	5	142076
143568	\N	\N	\N	\N	20320203	Makaba	\N	5	142076
143569	\N	\N	\N	\N	20320204	Matamba	\N	5	142076
143570	\N	\N	\N	\N	20320205	Mbenza	\N	5	142076
143571	\N	\N	\N	\N	20320206	Nziuti 2	\N	5	142076
143572	\N	\N	\N	\N	20320207	Phudi	\N	5	142076
143573	\N	\N	\N	\N	20320208	Sanzulu	\N	5	142076
143574	\N	\N	\N	\N	20320209	Tsundi	\N	5	142076
143575	\N	\N	\N	\N	20320301	Lolo-Mazinga	\N	5	142077
143576	\N	\N	\N	\N	20320302	Lolo-Mbavu	\N	5	142077
143577	\N	\N	\N	\N	20320303	Lusengi-Makulu	\N	5	142077
143578	\N	\N	\N	\N	20320304	Lutala-Mbeko	\N	5	142077
143579	\N	\N	\N	\N	20320305	Sumbi-Nord	\N	5	142077
143580	\N	\N	\N	\N	20320306	Sumbi-Sud	\N	5	142077
143581	\N	\N	\N	\N	20320401	Isangila	\N	5	142078
143582	\N	\N	\N	\N	20320402	Kizulu Tabi	\N	5	142078
143583	\N	\N	\N	\N	20320403	Saka	\N	5	142078
143584	\N	\N	\N	\N	20320404	Seke-Lolo	\N	5	142078
143585	\N	\N	\N	\N	20320501	Kionzo	\N	5	142079
143586	\N	\N	\N	\N	20320502	Sanda	\N	5	142079
143587	\N	\N	\N	\N	20320503	Vivi	\N	5	142079
143588	\N	\N	\N	\N	20325101	Kokolo	\N	5	142080
143589	\N	\N	\N	\N	20325102	Mama-Yemo	\N	5	142080
143590	\N	\N	\N	\N	20325201	Camp Scirima	\N	5	142081
143591	\N	\N	\N	\N	20325202	Kinzao_Mvuete	\N	5	142081
143592	\N	\N	\N	\N	20325301	Cite_Inga	\N	5	142082
143593	\N	\N	\N	\N	20330101	Bidi	\N	5	142083
143594	\N	\N	\N	\N	20330102	Kiala - Mongo	\N	5	142083
143595	\N	\N	\N	\N	20330103	Kai-Situ	\N	5	142083
143596	\N	\N	\N	\N	20330104	Kiphata	\N	5	142083
143597	\N	\N	\N	\N	20330105	Lele-Sikila	\N	5	142083
143598	\N	\N	\N	\N	20330106	Luvu	\N	5	142083
143599	\N	\N	\N	\N	20330107	Makungu-Lengi	\N	5	142083
143600	\N	\N	\N	\N	20330108	Seke di Mazanza	\N	5	142083
143601	\N	\N	\N	\N	20330109	Mvuangu	\N	5	142083
143602	\N	\N	\N	\N	20330110	Hors Milieu Coutumier	\N	5	142083
143604	\N	\N	\N	\N	20330202	Buende	\N	5	142084
143605	\N	\N	\N	\N	20330203	Kindeze	\N	5	142084
143606	\N	\N	\N	\N	20330204	Kiphondo	\N	5	142084
143607	\N	\N	\N	\N	20330205	Kungu-Mbambi	\N	5	142084
143608	\N	\N	\N	\N	20330206	Loango-Lukula	\N	5	142084
143609	\N	\N	\N	\N	20330207	Mandu	\N	5	142084
143610	\N	\N	\N	\N	20330208	Mazinga	\N	5	142084
143611	\N	\N	\N	\N	20330209	Mbuku-Lubongo	\N	5	142084
143612	\N	\N	\N	\N	20330210	Nkuangila-Manga	\N	5	142084
143613	\N	\N	\N	\N	20330211	Nyingu	\N	5	142084
143614	\N	\N	\N	\N	20330212	Sungu	\N	5	142084
143615	\N	\N	\N	\N	20330213	Tende	\N	5	142084
143616	\N	\N	\N	\N	20330214	Kimbauka	\N	5	142084
143617	\N	\N	\N	\N	20330215	Phonze	\N	5	142084
143618	\N	\N	\N	\N	20330216	Hors Milieu Coutumier	\N	5	142084
143619	\N	\N	\N	\N	20330301	Kangu	\N	5	142085
143620	\N	\N	\N	\N	20330302	Khoze	\N	5	142085
143621	\N	\N	\N	\N	20330303	Kiniati	\N	5	142085
143622	\N	\N	\N	\N	20330304	Kuimba-Lukula	\N	5	142085
143623	\N	\N	\N	\N	20330305	Mbamba	\N	5	142085
143624	\N	\N	\N	\N	20330306	Mbavu	\N	5	142085
143625	\N	\N	\N	\N	20330307	Mboma-Tsundi	\N	5	142085
143626	\N	\N	\N	\N	20330308	Nkuangila	\N	5	142085
143627	\N	\N	\N	\N	20330309	Phelele	\N	5	142085
143628	\N	\N	\N	\N	20330310	Tsese-Ntinu	\N	5	142085
143629	\N	\N	\N	\N	20330311	Vungu	\N	5	142085
143630	\N	\N	\N	\N	20330312	Vonde	\N	5	142085
143631	\N	\N	\N	\N	20330313	Hors Milieu Coutumier	\N	5	142085
143632	\N	\N	\N	\N	20330401	Kanzi-Tandu	\N	5	142086
143633	\N	\N	\N	\N	20330402	Khungidi	\N	5	142086
143634	\N	\N	\N	\N	20330403	Khuvi	\N	5	142086
143635	\N	\N	\N	\N	20330404	Lukamba-Lengi	\N	5	142086
143636	\N	\N	\N	\N	20330405	Lusanga	\N	5	142086
143637	\N	\N	\N	\N	20330406	Mbingu	\N	5	142086
143638	\N	\N	\N	\N	20330407	Nkoko	\N	5	142086
143639	\N	\N	\N	\N	20330408	Phadi	\N	5	142086
143640	\N	\N	\N	\N	20330409	Tsanga	\N	5	142086
143641	\N	\N	\N	\N	20330410	Tsinga-khala	\N	5	142086
143642	\N	\N	\N	\N	20330411	Tsinga-Masisa	\N	5	142086
143643	\N	\N	\N	\N	20330412	Tuidi-Yila	\N	5	142086
143644	\N	\N	\N	\N	20330413	Hors Milieu Coutumier	\N	5	142086
143645	\N	\N	\N	\N	20330501	Bemba-Bunzi	\N	5	142087
143646	\N	\N	\N	\N	20330502	Kinsundi	\N	5	142087
143647	\N	\N	\N	\N	20330503	Kongo-Ndefi	\N	5	142087
143648	\N	\N	\N	\N	20330504	Lukamba-Lengi	\N	5	142087
143649	\N	\N	\N	\N	20330505	Mbenza-Mvangi	\N	5	142087
143650	\N	\N	\N	\N	20330506	Mfuiki	\N	5	142087
143651	\N	\N	\N	\N	20330507	Mono-Ngao	\N	5	142087
143652	\N	\N	\N	\N	20330508	Wambu-Munga	\N	5	142087
143653	\N	\N	\N	\N	20330509	Mbilu-Tolo	\N	5	142087
143654	\N	\N	\N	\N	20330510	Ntinu-Makaba	\N	5	142087
143655	\N	\N	\N	\N	20330511	Patu-Noki	\N	5	142087
143656	\N	\N	\N	\N	20330512	Tsandanda	\N	5	142087
143657	\N	\N	\N	\N	20330513	Tsinga-Songo	\N	5	142087
143658	\N	\N	\N	\N	20330514	Tsinga-Nkazu	\N	5	142087
143659	\N	\N	\N	\N	20330515	Hors Milieu Coutumier	\N	5	142087
143660	\N	\N	\N	\N	20335101	24 Novembre	\N	5	142088
143661	\N	\N	\N	\N	20335102	4 Janvier	\N	5	142088
143662	\N	\N	\N	\N	20335103	Kaa-Vubu	\N	5	142088
143663	\N	\N	\N	\N	20335104	Kokolo	\N	5	142088
143664	\N	\N	\N	\N	20335105	Mobutu	\N	5	142088
143665	\N	\N	\N	\N	20335201	M.P.R.	\N	5	142089
143666	\N	\N	\N	\N	20335202	Kimbala	\N	5	142089
143667	\N	\N	\N	\N	20335203	Kinlumba	\N	5	142089
143668	\N	\N	\N	\N	20410101	Bangu	\N	5	142090
143669	\N	\N	\N	\N	20410102	Gombe-Sud	\N	5	142090
143670	\N	\N	\N	\N	20410103	Kiloango	\N	5	142090
143671	\N	\N	\N	\N	20410104	Kinsende	\N	5	142090
143672	\N	\N	\N	\N	20410105	Luvaka	\N	5	142090
143673	\N	\N	\N	\N	20410106	Mbanza-Mbata	\N	5	142090
143674	\N	\N	\N	\N	20410107	Mongo	\N	5	142090
143675	\N	\N	\N	\N	20410108	Nkiende	\N	5	142090
143676	\N	\N	\N	\N	20410109	Hors Milieu Coutumier	\N	5	142090
143677	\N	\N	\N	\N	20410201	Luvituku	\N	5	142091
143678	\N	\N	\N	\N	20410202	Mawete	\N	5	142091
143679	\N	\N	\N	\N	20410203	Mbanza-Makuta	\N	5	142091
143680	\N	\N	\N	\N	20410204	Tumba-Vata	\N	5	142091
143681	\N	\N	\N	\N	20410205	Tungua	\N	5	142091
143682	\N	\N	\N	\N	20410206	Nlemvo	\N	5	142091
143683	\N	\N	\N	\N	20410207	Lufu Toto	\N	5	142091
143684	\N	\N	\N	\N	20410208	ONDS/Kwilu-Ngongo	\N	5	142091
143685	\N	\N	\N	\N	20410209	Ciza/Lukala-Tumba	\N	5	142091
143686	\N	\N	\N	\N	20410210	SNCC/Lufu-Toto	\N	5	142091
143687	\N	\N	\N	\N	20410211	D.P.N./Yabi	\N	5	142091
143688	\N	\N	\N	\N	20410212	Centre Lukala	\N	5	142091
143689	\N	\N	\N	\N	20410301	Fumvu	\N	5	142092
143690	\N	\N	\N	\N	20410302	Kilua	\N	5	142092
143691	\N	\N	\N	\N	20410303	Kimoko	\N	5	142092
143692	\N	\N	\N	\N	20410304	Kongo-Botongo	\N	5	142092
143693	\N	\N	\N	\N	20410305	Lombo-Fuese	\N	5	142092
143694	\N	\N	\N	\N	20410306	Lukunga	\N	5	142092
143695	\N	\N	\N	\N	20410307	Ndunga	\N	5	142092
143696	\N	\N	\N	\N	20410308	Nionga	\N	5	142092
143697	\N	\N	\N	\N	20410309	Nkandanda	\N	5	142092
143698	\N	\N	\N	\N	20410310	Nsanzala	\N	5	142092
143699	\N	\N	\N	\N	20410311	Ntadi	\N	5	142092
143700	\N	\N	\N	\N	20410312	Nzundu	\N	5	142092
143701	\N	\N	\N	\N	20410313	Sanga	\N	5	142092
143702	\N	\N	\N	\N	20410401	Gombe-Matadi	\N	5	142093
143703	\N	\N	\N	\N	20410402	Kiloango	\N	5	142093
143704	\N	\N	\N	\N	20410403	Kinkuzu	\N	5	142093
143705	\N	\N	\N	\N	20410404	Kinzinga	\N	5	142093
143706	\N	\N	\N	\N	20410405	Nkandu-Kiama	\N	5	142093
143707	\N	\N	\N	\N	20410501	Kindunga	\N	5	142094
143708	\N	\N	\N	\N	20410502	Nkazu	\N	5	142094
143709	\N	\N	\N	\N	20410503	Nzimba	\N	5	142094
143710	\N	\N	\N	\N	20410504	Nkusu	\N	5	142094
143711	\N	\N	\N	\N	20410601	Kiazi	\N	5	142095
143712	\N	\N	\N	\N	20410602	Kifua	\N	5	142095
143713	\N	\N	\N	\N	20410603	Kindundu	\N	5	142095
143714	\N	\N	\N	\N	20410604	Lovo	\N	5	142095
143715	\N	\N	\N	\N	20410605	Luvaka	\N	5	142095
143716	\N	\N	\N	\N	20410606	Mbanza-Nsundi	\N	5	142095
143717	\N	\N	\N	\N	20410607	Nkolo	\N	5	142095
143718	\N	\N	\N	\N	20410608	Tadila	\N	5	142095
143719	\N	\N	\N	\N	20410701	Kolo-Tava	\N	5	142096
143720	\N	\N	\N	\N	20410702	Mbanza-Nsundi	\N	5	142096
143721	\N	\N	\N	\N	20410703	Mbengua-Tadi	\N	5	142096
143722	\N	\N	\N	\N	20410704	Ndembo	\N	5	142096
143723	\N	\N	\N	\N	20415101	Disengomoka	\N	5	142097
143724	\N	\N	\N	\N	20415102	Loma	\N	5	142097
143725	\N	\N	\N	\N	20415103	Ngungu	\N	5	142097
143726	\N	\N	\N	\N	20415104	Noki	\N	5	142097
143727	\N	\N	\N	\N	20415105	RÃ©volution	\N	5	142097
143728	\N	\N	\N	\N	20420101	Kongo - dia - Lemba	\N	5	142098
143729	\N	\N	\N	\N	20420102	Palabala	\N	5	142098
143730	\N	\N	\N	\N	20420201	Mbanza-Manteke	\N	5	142099
143731	\N	\N	\N	\N	20420202	Mbanza-Nkazi	\N	5	142099
143732	\N	\N	\N	\N	20420203	Ngombe	\N	5	142099
143733	\N	\N	\N	\N	20420301	Kimpese	\N	5	142100
143734	\N	\N	\N	\N	20420302	Kongo-Songololo	\N	5	142100
143735	\N	\N	\N	\N	20420303	Ngombe-Makulukulu	\N	5	142100
143736	\N	\N	\N	\N	20420401	Kasi	\N	5	142101
143737	\N	\N	\N	\N	20420402	Mukimbungu	\N	5	142101
143738	\N	\N	\N	\N	20420403	Nienge	\N	5	142101
143739	\N	\N	\N	\N	20420501	Kimpese	\N	5	142102
143740	\N	\N	\N	\N	20420502	Mbemba	\N	5	142102
143741	\N	\N	\N	\N	20425101	Independance	\N	5	142103
143742	\N	\N	\N	\N	20425102	Mobutu	\N	5	142103
143743	\N	\N	\N	\N	20425103	Nsangu Salembe	\N	5	142103
143744	\N	\N	\N	\N	20425104	Quartier 3	\N	5	142103
143745	\N	\N	\N	\N	20425105	Revolution	\N	5	142103
143746	\N	\N	\N	\N	20425201	Quartier 1	\N	5	142104
143747	\N	\N	\N	\N	20425202	Quartier 2	\N	5	142104
143748	\N	\N	\N	\N	20425203	Quartier 3	\N	5	142104
143749	\N	\N	\N	\N	20425204	Quartier 4	\N	5	142104
143750	\N	\N	\N	\N	20430101	Kibunzi	\N	5	142105
143751	\N	\N	\N	\N	20430102	Kinkungu	\N	5	142105
143752	\N	\N	\N	\N	20430103	Mbamba	\N	5	142105
143753	\N	\N	\N	\N	20430201	Kinkenge	\N	5	142106
143754	\N	\N	\N	\N	20430202	Luala	\N	5	142106
143755	\N	\N	\N	\N	20430203	Luangu	\N	5	142106
143756	\N	\N	\N	\N	20430301	Kingoyi	\N	5	142107
143757	\N	\N	\N	\N	20430302	Munkaka	\N	5	142107
143758	\N	\N	\N	\N	20430303	Tembisa	\N	5	142107
143759	\N	\N	\N	\N	20430304	Yanga-Pompe	\N	5	142107
143760	\N	\N	\N	\N	20430401	Kimbimbi	\N	5	142108
143761	\N	\N	\N	\N	20430402	Kinsumbu	\N	5	142108
143762	\N	\N	\N	\N	20430403	Kivunda	\N	5	142108
143763	\N	\N	\N	\N	20430501	Londe-Nzadi	\N	5	142109
143764	\N	\N	\N	\N	20430502	Mimpala	\N	5	142109
143765	\N	\N	\N	\N	20430503	Ndoba	\N	5	142109
143766	\N	\N	\N	\N	20430504	Yokolo	\N	5	142109
143767	\N	\N	\N	\N	20430601	Kikiunga	\N	5	142110
143768	\N	\N	\N	\N	20430602	Kimata	\N	5	142110
143769	\N	\N	\N	\N	20430603	Kiniangi	\N	5	142110
143770	\N	\N	\N	\N	20430604	Masangi	\N	5	142110
143771	\N	\N	\N	\N	20430605	Sundi-Lutete	\N	5	142110
143772	\N	\N	\N	\N	20430606	Yanga-Nord	\N	5	142110
143773	\N	\N	\N	\N	20430701	Kimbanza	\N	5	142111
143774	\N	\N	\N	\N	20430702	Kinkenda	\N	5	142111
143775	\N	\N	\N	\N	20430703	Mbanza-Mbu	\N	5	142111
143776	\N	\N	\N	\N	20430704	Yanga	\N	5	142111
143777	\N	\N	\N	\N	20430801	Kimpaka	\N	5	142112
143778	\N	\N	\N	\N	20430802	Lemba	\N	5	142112
143779	\N	\N	\N	\N	20430803	Luangu	\N	5	142112
143780	\N	\N	\N	\N	20430804	Mbiongo	\N	5	142112
143781	\N	\N	\N	\N	20430901	Bulu	\N	5	142113
143782	\N	\N	\N	\N	20430902	Kingila	\N	5	142113
143783	\N	\N	\N	\N	20430903	Kinsemi	\N	5	142113
143784	\N	\N	\N	\N	20431001	Bidi	\N	5	142114
143785	\N	\N	\N	\N	20431002	Mfuenta	\N	5	142114
143786	\N	\N	\N	\N	20431003	Sundi-Mamba	\N	5	142114
143787	\N	\N	\N	\N	20435101	Quartier 1	\N	5	142115
143788	\N	\N	\N	\N	20435102	Quartier 2	\N	5	142115
143789	\N	\N	\N	\N	20435103	Quartier 3	\N	5	142115
143790	\N	\N	\N	\N	20435104	Quartier 4	\N	5	142115
143791	\N	\N	\N	\N	20435105	Quartier 5	\N	5	142115
143792	\N	\N	\N	\N	20510101	Kigala	\N	5	142116
143793	\N	\N	\N	\N	20510102	Kindompolo	\N	5	142116
143794	\N	\N	\N	\N	20510103	Kinkondongo	\N	5	142116
143795	\N	\N	\N	\N	20510104	Kivita	\N	5	142116
143796	\N	\N	\N	\N	20510105	Kiwembo	\N	5	142116
143797	\N	\N	\N	\N	20510106	Malele	\N	5	142116
143798	\N	\N	\N	\N	20510107	Mbata-Makela	\N	5	142116
143799	\N	\N	\N	\N	20510108	Sadi-Kinsanga	\N	5	142116
143800	\N	\N	\N	\N	20510109	Tumba-Mani	\N	5	142116
143801	\N	\N	\N	\N	20510110	Vua	\N	5	142116
143802	\N	\N	\N	\N	20510111	Yungu	\N	5	142116
143803	\N	\N	\N	\N	20510112	Zulu	\N	5	142116
143804	\N	\N	\N	\N	20510201	Kimpemba	\N	5	142117
143805	\N	\N	\N	\N	20510202	Kinsaku-Muanda	\N	5	142117
143806	\N	\N	\N	\N	20510203	Kinyengo	\N	5	142117
143807	\N	\N	\N	\N	20510301	Kisantu	\N	5	142118
143808	\N	\N	\N	\N	20510302	Kiyanika	\N	5	142118
143809	\N	\N	\N	\N	20510303	Ndembo	\N	5	142118
143810	\N	\N	\N	\N	20510304	Nselo	\N	5	142118
143811	\N	\N	\N	\N	20510305	Centre Ngeba	\N	5	142118
143812	\N	\N	\N	\N	20510401	Boko	\N	5	142119
143813	\N	\N	\N	\N	20510402	Buense	\N	5	142119
143814	\N	\N	\N	\N	20510403	Kifua	\N	5	142119
143815	\N	\N	\N	\N	20510404	Kinkoni	\N	5	142119
143816	\N	\N	\N	\N	20510405	Kipako	\N	5	142119
143817	\N	\N	\N	\N	20510406	Kitempa	\N	5	142119
143818	\N	\N	\N	\N	20510407	Kongo - Yongo	\N	5	142119
143819	\N	\N	\N	\N	20510408	Kinkoko	\N	5	142119
143820	\N	\N	\N	\N	20510409	Ndanda	\N	5	142119
143821	\N	\N	\N	\N	20510410	Ndewa	\N	5	142119
143822	\N	\N	\N	\N	20510411	Nlembo	\N	5	142119
143823	\N	\N	\N	\N	20510412	Centre Madimba	\N	5	142119
143824	\N	\N	\N	\N	20510501	Kiangala-Mansundi	\N	5	142120
143825	\N	\N	\N	\N	20510502	Kibambi	\N	5	142120
143826	\N	\N	\N	\N	20510503	Kimbata-Luidi	\N	5	142120
143827	\N	\N	\N	\N	20510504	Mbamba-Kalunga	\N	5	142120
143828	\N	\N	\N	\N	20510505	Mbamba-Kopo	\N	5	142120
143829	\N	\N	\N	\N	20510506	Mbamba-Mpangu	\N	5	142120
143830	\N	\N	\N	\N	20510507	Mbata-Wembo	\N	5	142120
143831	\N	\N	\N	\N	20510601	Kimfuti-Ngulu	\N	5	142121
143832	\N	\N	\N	\N	20510602	Kinzamba	\N	5	142121
143833	\N	\N	\N	\N	20510603	Kinzieto	\N	5	142121
143834	\N	\N	\N	\N	20515401	CarriÃ¨re	\N	5	142125
143835	\N	\N	\N	\N	20515402	Kimbondo	\N	5	142125
143836	\N	\N	\N	\N	20515403	Mfuki	\N	5	142125
143837	\N	\N	\N	\N	20515404	Wete	\N	5	142125
143838	\N	\N	\N	\N	20515405	Wombo	\N	5	142125
143839	\N	\N	\N	\N	20520101	Boko-Mbuba	\N	5	142126
143840	\N	\N	\N	\N	20520102	Kimbungu	\N	5	142126
143841	\N	\N	\N	\N	20520103	Kinzambi	\N	5	142126
143842	\N	\N	\N	\N	20520104	Kinzuana	\N	5	142126
143843	\N	\N	\N	\N	20520105	Mbansa-Mbata	\N	5	142126
143844	\N	\N	\N	\N	20520106	Ngomina	\N	5	142126
143845	\N	\N	\N	\N	20520107	Nlala-Kikuama	\N	5	142126
143846	\N	\N	\N	\N	20520108	Ntampa	\N	5	142126
143847	\N	\N	\N	\N	20520109	Toto-Lembolo	\N	5	142126
143848	\N	\N	\N	\N	20520110	Yidi	\N	5	142126
143849	\N	\N	\N	\N	20520111	Sefu	\N	5	142126
143850	\N	\N	\N	\N	20520112	Centres	\N	5	142126
143851	\N	\N	\N	\N	20520201	Kifuma	\N	5	142127
143852	\N	\N	\N	\N	20520202	Kimbongo	\N	5	142127
143853	\N	\N	\N	\N	20520203	Kingantoko	\N	5	142127
143854	\N	\N	\N	\N	20520204	Kinimi	\N	5	142127
143855	\N	\N	\N	\N	20520205	Kinsabi	\N	5	142127
143856	\N	\N	\N	\N	20520206	Minkoko	\N	5	142127
143857	\N	\N	\N	\N	20520207	Nsabuka	\N	5	142127
143858	\N	\N	\N	\N	20520301	Bibanga	\N	5	142128
143859	\N	\N	\N	\N	20520302	Bu	\N	5	142128
143860	\N	\N	\N	\N	20520303	Kimpungi	\N	5	142128
143861	\N	\N	\N	\N	20520304	Kindu	\N	5	142128
143862	\N	\N	\N	\N	20520305	Kingao	\N	5	142128
143863	\N	\N	\N	\N	20520306	Kisiama	\N	5	142128
143864	\N	\N	\N	\N	20520307	Kitempa	\N	5	142128
143865	\N	\N	\N	\N	20525101	Luzama	\N	5	142129
143866	\N	\N	\N	\N	20525102	Mampuya	\N	5	142129
143867	\N	\N	\N	\N	20525103	Mawete	\N	5	142129
143868	\N	\N	\N	\N	20530101	Kimakundi	\N	5	142130
143869	\N	\N	\N	\N	20530102	Kimbuba	\N	5	142130
143870	\N	\N	\N	\N	20530103	Kimvidi	\N	5	142130
143871	\N	\N	\N	\N	20530104	Kinsimbu-Lukeni	\N	5	142130
143872	\N	\N	\N	\N	20530201	Lula-lumene	\N	5	142131
143873	\N	\N	\N	\N	20530202	Kimpisiala	\N	5	142131
143874	\N	\N	\N	\N	20530203	Mbakini	\N	5	142131
143875	\N	\N	\N	\N	20530301	Kimabaka	\N	5	142132
143876	\N	\N	\N	\N	20530302	Pangala	\N	5	142132
143877	\N	\N	\N	\N	20530303	Tsaka	\N	5	142132
143878	\N	\N	\N	\N	30110001	Ibole	\N	5	142134
143879	\N	\N	\N	\N	30110002	Kamanyola	\N	5	142134
143880	\N	\N	\N	\N	30110003	Kwango	\N	5	142134
143881	\N	\N	\N	\N	30110004	Mama Yemo	\N	5	142134
143882	\N	\N	\N	\N	30110005	Mobutu	\N	5	142134
143883	\N	\N	\N	\N	30110006	Molende	\N	5	142134
143884	\N	\N	\N	\N	30110007	Nsele	\N	5	142134
143885	\N	\N	\N	\N	30110008	Salaminta	\N	5	142134
143886	\N	\N	\N	\N	30110009	Lwami	\N	5	142134
143887	\N	\N	\N	\N	30120001	Air-Congo	\N	5	142135
143888	\N	\N	\N	\N	30120002	Buza	\N	5	142135
143889	\N	\N	\N	\N	30120003	Camp Militaire Weli	\N	5	142135
143890	\N	\N	\N	\N	30120004	Ifuri	\N	5	142135
143891	\N	\N	\N	\N	30120005	Lumbu	\N	5	142135
143892	\N	\N	\N	\N	30120006	Salongo	\N	5	142135
143893	\N	\N	\N	\N	30130001	Bosembo	\N	5	142136
143894	\N	\N	\N	\N	30130002	Ito	\N	5	142136
143895	\N	\N	\N	\N	30130003	Kimvuka	\N	5	142136
143896	\N	\N	\N	\N	30130004	Malebo	\N	5	142136
143897	\N	\N	\N	\N	30130005	Musaba	\N	5	142136
143898	\N	\N	\N	\N	30130006	Ngamilele	\N	5	142136
143899	\N	\N	\N	\N	30210101	Bokote	\N	5	142137
143900	\N	\N	\N	\N	30210102	Mbelo	\N	5	142137
143901	\N	\N	\N	\N	30210103	Mpenge	\N	5	142137
143902	\N	\N	\N	\N	30210104	Basengele	\N	5	142137
143903	\N	\N	\N	\N	30210201	Bokwala	\N	5	142138
143904	\N	\N	\N	\N	30210202	Ibeke-Bolia	\N	5	142138
143905	\N	\N	\N	\N	30210203	Lokanga	\N	5	142138
143906	\N	\N	\N	\N	30210204	Nkilie	\N	5	142138
143907	\N	\N	\N	\N	30210301	Benga	\N	5	142139
143908	\N	\N	\N	\N	30210302	Iyembe	\N	5	142139
143909	\N	\N	\N	\N	30210303	Ilanga (Ntomba Nzale )	\N	5	142139
143910	\N	\N	\N	\N	30215101	Likwangola	\N	5	142140
143911	\N	\N	\N	\N	30215102	Mpongo-Nzoli	\N	5	142140
143912	\N	\N	\N	\N	30215103	Mubilanga	\N	5	142140
143913	\N	\N	\N	\N	30220101	Bakonda	\N	5	142141
143914	\N	\N	\N	\N	30220102	Ilanga	\N	5	142141
143915	\N	\N	\N	\N	30220103	Iyembe	\N	5	142141
143916	\N	\N	\N	\N	30220201	Bolongo-Ngali	\N	5	142142
143917	\N	\N	\N	\N	30220202	Bolongi-Weli	\N	5	142142
143918	\N	\N	\N	\N	30220203	Ibeke	\N	5	142142
143919	\N	\N	\N	\N	30220204	Weli	\N	5	142142
143920	\N	\N	\N	\N	30220301	Besongo Waya	\N	5	142143
143921	\N	\N	\N	\N	30220302	Djongo	\N	5	142143
143922	\N	\N	\N	\N	30220303	Djoko	\N	5	142143
143923	\N	\N	\N	\N	30220304	Waya	\N	5	142143
143924	\N	\N	\N	\N	30220305	Nkodi	\N	5	142143
143925	\N	\N	\N	\N	30230101	Batitu	\N	5	142145
143926	\N	\N	\N	\N	30230102	Ipanga	\N	5	142145
143927	\N	\N	\N	\N	30230201	Bidiankamba(Mbandjankamba)	\N	5	142146
143928	\N	\N	\N	\N	30230301	Bolendo	\N	5	142147
143929	\N	\N	\N	\N	30230302	Bolongo	\N	5	142147
143930	\N	\N	\N	\N	30230401	Booli	\N	5	142148
143931	\N	\N	\N	\N	30230402	Etwali	\N	5	142148
143932	\N	\N	\N	\N	30235101	Komoriko	\N	5	142149
143933	\N	\N	\N	\N	30235102	Linet	\N	5	142149
143934	\N	\N	\N	\N	30235103	Lokala	\N	5	142149
143935	\N	\N	\N	\N	30235104	Lukenie	\N	5	142149
143936	\N	\N	\N	\N	30235105	Maingolo	\N	5	142149
143937	\N	\N	\N	\N	30235106	N'selÃ©	\N	5	142149
143938	\N	\N	\N	\N	30240101	Lemvia-nord	\N	5	142150
143939	\N	\N	\N	\N	30240102	Lemvia-sud	\N	5	142150
143940	\N	\N	\N	\N	30240103	Mabie	\N	5	142150
143941	\N	\N	\N	\N	30240104	Mbamoshie	\N	5	142150
143942	\N	\N	\N	\N	30240201	Badia	\N	5	142151
143943	\N	\N	\N	\N	30240301	Mbelo	\N	5	142152
143944	\N	\N	\N	\N	30240302	Babay	\N	5	142152
143945	\N	\N	\N	\N	30240401	Batere	\N	5	142153
143946	\N	\N	\N	\N	30240501	Bantin-Nord	\N	5	142154
143947	\N	\N	\N	\N	30240502	Ndwele	\N	5	142154
143948	\N	\N	\N	\N	30240503	Bantin-Sud	\N	5	142154
143949	\N	\N	\N	\N	30245101	Basuki	\N	5	142155
143950	\N	\N	\N	\N	30245102	Boboliko	\N	5	142155
143951	\N	\N	\N	\N	30245103	Lumumba	\N	5	142155
143952	\N	\N	\N	\N	30245104	Mobutu	\N	5	142155
143953	\N	\N	\N	\N	30245201	Nzambani	\N	5	142156
143954	\N	\N	\N	\N	30245202	Mongo-Nkolo	\N	5	142156
143955	\N	\N	\N	\N	30245203	No-Kina	\N	5	142156
143956	\N	\N	\N	\N	30245301	Aliba	\N	5	142157
143957	\N	\N	\N	\N	30245302	Komanda	\N	5	142157
143958	\N	\N	\N	\N	30245303	Mpinzela	\N	5	142157
143959	\N	\N	\N	\N	30250101	Baboma	\N	5	142158
143960	\N	\N	\N	\N	30250102	Bampe	\N	5	142158
143961	\N	\N	\N	\N	30250103	Banunu	\N	5	142158
143962	\N	\N	\N	\N	30255101	Bolobo	\N	5	142159
143963	\N	\N	\N	\N	30255102	Mbali	\N	5	142159
143964	\N	\N	\N	\N	30255103	Mbee	\N	5	142159
143965	\N	\N	\N	\N	30255104	Nkamba	\N	5	142159
143966	\N	\N	\N	\N	30255105	Twa	\N	5	142159
143967	\N	\N	\N	\N	30260101	Bwema	\N	5	142160
143968	\N	\N	\N	\N	30260102	Mbee	\N	5	142160
143969	\N	\N	\N	\N	30265101	Bondongo	\N	5	142161
143970	\N	\N	\N	\N	30265102	Boyambola	\N	5	142161
143971	\N	\N	\N	\N	30265103	Mabwa	\N	5	142161
143972	\N	\N	\N	\N	30265104	Mobutu	\N	5	142161
143973	\N	\N	\N	\N	30265105	Motondi	\N	5	142161
143974	\N	\N	\N	\N	30270101	Baboma-Banku	\N	5	142162
143975	\N	\N	\N	\N	30270102	Baboma-Sud	\N	5	142162
143976	\N	\N	\N	\N	30270103	Bateke-Sud	\N	5	142162
143977	\N	\N	\N	\N	30280101	Banunu (Mongama)	\N	5	142164
143978	\N	\N	\N	\N	30280102	Batende	\N	5	142164
143979	\N	\N	\N	\N	30285101	Bolu	\N	5	142165
143980	\N	\N	\N	\N	30285102	Bonkenda	\N	5	142165
143981	\N	\N	\N	\N	30285103	Bonkongo	\N	5	142165
143982	\N	\N	\N	\N	30285104	Lokolo	\N	5	142165
143983	\N	\N	\N	\N	30285105	Moy	\N	5	142165
143984	\N	\N	\N	\N	30285106	Nsenseke	\N	5	142165
143985	\N	\N	\N	\N	30310101	Bahungana	\N	5	142166
143986	\N	\N	\N	\N	30310102	Fungulu	\N	5	142166
143987	\N	\N	\N	\N	30310103	Mangungu	\N	5	142166
143988	\N	\N	\N	\N	30310104	Mbulunzimbu	\N	5	142166
143989	\N	\N	\N	\N	30310105	Mudiata ( Madidiata )	\N	5	142166
143990	\N	\N	\N	\N	30310106	Mudikwiti	\N	5	142166
143991	\N	\N	\N	\N	30310107	Mudizinga	\N	5	142166
143992	\N	\N	\N	\N	30310108	Mudimyuku ( Mudimayuku )	\N	5	142166
143993	\N	\N	\N	\N	30310109	Mudimuzinga	\N	5	142166
143994	\N	\N	\N	\N	30310110	Mudingubu	\N	5	142166
143995	\N	\N	\N	\N	30310111	Ngulunzanza ( Ngulunzanza )	\N	5	142166
143996	\N	\N	\N	\N	30310201	Basamba-Basu	\N	5	142167
143997	\N	\N	\N	\N	30310202	Kalamba	\N	5	142167
143998	\N	\N	\N	\N	30310203	Mudikasandji	\N	5	142167
143999	\N	\N	\N	\N	30310204	Menikongo ( Mudikongo )	\N	5	142167
144000	\N	\N	\N	\N	30310205	Musambi	\N	5	142167
144001	\N	\N	\N	\N	30310206	Mutamba ( Mutaba )	\N	5	142167
144002	\N	\N	\N	\N	30310207	Takamba	\N	5	142167
144003	\N	\N	\N	\N	30310208	Tambangi	\N	5	142167
144004	\N	\N	\N	\N	30310209	Tanganga	\N	5	142167
144005	\N	\N	\N	\N	30310210	Tasimba	\N	5	142167
144006	\N	\N	\N	\N	30310301	Basuku	\N	5	142168
144007	\N	\N	\N	\N	30310302	Bionga	\N	5	142168
144008	\N	\N	\N	\N	30310303	Bambala-Bamba	\N	5	142168
144009	\N	\N	\N	\N	30310304	Kishiongo	\N	5	142168
144010	\N	\N	\N	\N	30310305	Mbanza	\N	5	142168
144011	\N	\N	\N	\N	30310306	Ngandungala	\N	5	142168
144012	\N	\N	\N	\N	30310401	Muduwamba ( Mudiwanja )	\N	5	142169
144013	\N	\N	\N	\N	30310402	Kisunga ( Kisumba )	\N	5	142169
144014	\N	\N	\N	\N	30310403	Kinkondji	\N	5	142169
144015	\N	\N	\N	\N	30310404	Kikumbi	\N	5	142169
144016	\N	\N	\N	\N	30310405	Mudikatambi	\N	5	142169
144017	\N	\N	\N	\N	30310406	Kinzambi	\N	5	142169
144018	\N	\N	\N	\N	30310407	Kipweti	\N	5	142169
144019	\N	\N	\N	\N	30310408	Kisala ( Kisala-Mudindambi )	\N	5	142169
144020	\N	\N	\N	\N	30310409	Kumbi-Mashi	\N	5	142169
144021	\N	\N	\N	\N	30310410	Kunga-Mwe	\N	5	142169
144022	\N	\N	\N	\N	30310411	Mbanza-babwini ( Mbonga-Babwin	\N	5	142169
144023	\N	\N	\N	\N	30310412	Miwandji-Tatu	\N	5	142169
144024	\N	\N	\N	\N	30310413	Mundonda ( Mundanda )	\N	5	142169
144025	\N	\N	\N	\N	30310414	Putubumba	\N	5	142169
144026	\N	\N	\N	\N	30310415	Songo-Tatu	\N	5	142169
144027	\N	\N	\N	\N	30310416	Tasamba	\N	5	142169
144028	\N	\N	\N	\N	30310501	Kilunda	\N	5	142170
144029	\N	\N	\N	\N	30310502	Kilusu	\N	5	142170
144030	\N	\N	\N	\N	30310503	Kimbie-Kingoma	\N	5	142170
144031	\N	\N	\N	\N	30310504	Lemfu	\N	5	142170
144032	\N	\N	\N	\N	30310505	Lwanda	\N	5	142170
144033	\N	\N	\N	\N	30310506	Mbonga-Nduy	\N	5	142170
144034	\N	\N	\N	\N	30310507	Mupulu	\N	5	142170
144035	\N	\N	\N	\N	30310508	Ndunga	\N	5	142170
144036	\N	\N	\N	\N	30310509	Nzomfi	\N	5	142170
144037	\N	\N	\N	\N	30310510	Songo	\N	5	142170
144038	\N	\N	\N	\N	30310601	Bilili-Ndumbu	\N	5	142171
144039	\N	\N	\N	\N	30310602	Kibala ( kabala )	\N	5	142171
144040	\N	\N	\N	\N	30310603	Kimwanza	\N	5	142171
144041	\N	\N	\N	\N	30310604	Kinganga	\N	5	142171
144042	\N	\N	\N	\N	30310605	Lubembo	\N	5	142171
144043	\N	\N	\N	\N	30310606	Luzubi	\N	5	142171
144044	\N	\N	\N	\N	30310607	Malu	\N	5	142171
144045	\N	\N	\N	\N	30310608	Mpata	\N	5	142171
144046	\N	\N	\N	\N	30310609	Mbelo-Ndumbu	\N	5	142171
144047	\N	\N	\N	\N	30310610	Nkwasa-Lembe	\N	5	142171
144048	\N	\N	\N	\N	30310701	Mbwaniangi	\N	5	142172
144049	\N	\N	\N	\N	30310702	Kibongo-M	\N	5	142172
144050	\N	\N	\N	\N	30310703	Kibongo-Bulugu	\N	5	142172
144051	\N	\N	\N	\N	30310704	Kibwadi-Yonso	\N	5	142172
144052	\N	\N	\N	\N	30310705	Kimbata	\N	5	142172
144053	\N	\N	\N	\N	30310706	Kimpanda	\N	5	142172
144054	\N	\N	\N	\N	30310707	Longo-Mubindi	\N	5	142172
144055	\N	\N	\N	\N	30310708	Lundu	\N	5	142172
144056	\N	\N	\N	\N	30310709	Madibi-Mawawa	\N	5	142172
144057	\N	\N	\N	\N	30310710	Mayoyo-Kwilu	\N	5	142172
144058	\N	\N	\N	\N	30310711	Mayoko-Lutundu	\N	5	142172
144059	\N	\N	\N	\N	30310712	Mbelo-Lumeya	\N	5	142172
144060	\N	\N	\N	\N	30310713	Mbushi- Mbiye	\N	5	142172
144061	\N	\N	\N	\N	30310714	Milundu-Kita	\N	5	142172
144062	\N	\N	\N	\N	30310715	Mukili-Makuku	\N	5	142172
144063	\N	\N	\N	\N	30310716	Mushia	\N	5	142172
144064	\N	\N	\N	\N	30310717	Muyeletango	\N	5	142172
144065	\N	\N	\N	\N	30310718	Mandundu Nganga	\N	5	142172
144295	\N	\N	\N	\N	30340608	Kinday	\N	5	142200
144066	\N	\N	\N	\N	30310719	Pukulu-Muway	\N	5	142172
144067	\N	\N	\N	\N	30310801	Ambura-Fumunzoko	\N	5	142173
144068	\N	\N	\N	\N	30310802	Dwe	\N	5	142173
144069	\N	\N	\N	\N	30310803	Kimputu	\N	5	142173
144070	\N	\N	\N	\N	30310804	Mayoko-Sakasaka	\N	5	142173
144071	\N	\N	\N	\N	30310805	Mbelo	\N	5	142173
144072	\N	\N	\N	\N	30310806	Mikingi	\N	5	142173
144073	\N	\N	\N	\N	30310807	Milundu	\N	5	142173
144074	\N	\N	\N	\N	30310808	Muyene	\N	5	142173
144075	\N	\N	\N	\N	30310809	Ngunu	\N	5	142173
144076	\N	\N	\N	\N	30310810	Nkwebe	\N	5	142173
144077	\N	\N	\N	\N	30310811	Ntunu	\N	5	142173
144078	\N	\N	\N	\N	30310812	Sala	\N	5	142173
144079	\N	\N	\N	\N	30310813	Tshampere	\N	5	142173
144080	\N	\N	\N	\N	30310901	Ekubi	\N	5	142174
144081	\N	\N	\N	\N	30310902	Kiaka-Biensi	\N	5	142174
144082	\N	\N	\N	\N	30310903	Kikandji ( Kikondji )Kikongo-M	\N	5	142174
144083	\N	\N	\N	\N	30310904	Longo-Kumakuma	\N	5	142174
144084	\N	\N	\N	\N	30310905	Matamanko	\N	5	142174
144085	\N	\N	\N	\N	30310906	Mitshakila	\N	5	142174
144086	\N	\N	\N	\N	30310907	Mpene	\N	5	142174
144087	\N	\N	\N	\N	30310908	Nduiy	\N	5	142174
144088	\N	\N	\N	\N	30310909	Niadi	\N	5	142174
144089	\N	\N	\N	\N	30310910	Ntandu	\N	5	142174
144090	\N	\N	\N	\N	30310911	Tshimbele	\N	5	142174
144091	\N	\N	\N	\N	30310912	Yambau	\N	5	142174
144092	\N	\N	\N	\N	30311001	Eban	\N	5	142175
144093	\N	\N	\N	\N	30311002	Kikwit-Mbu	\N	5	142175
144094	\N	\N	\N	\N	30311003	Kimbimbi	\N	5	142175
144095	\N	\N	\N	\N	30311004	Kisomi	\N	5	142175
144096	\N	\N	\N	\N	30311005	Mampungu	\N	5	142175
144097	\N	\N	\N	\N	30311006	Mazinga	\N	5	142175
144098	\N	\N	\N	\N	30311007	Mikata	\N	5	142175
144099	\N	\N	\N	\N	30311008	Mukwamwene	\N	5	142175
144100	\N	\N	\N	\N	30311009	Nganda	\N	5	142175
144101	\N	\N	\N	\N	30311010	Ngwene	\N	5	142175
144102	\N	\N	\N	\N	30311011	Tango	\N	5	142175
144103	\N	\N	\N	\N	30315101	Ilunga	\N	5	142176
144104	\N	\N	\N	\N	30315102	Kabangu	\N	5	142176
144105	\N	\N	\N	\N	30315103	Kabombo	\N	5	142176
144106	\N	\N	\N	\N	30315104	Kyalwe	\N	5	142176
144107	\N	\N	\N	\N	30315105	Lubundji	\N	5	142176
144108	\N	\N	\N	\N	30315106	Muyombo	\N	5	142176
144109	\N	\N	\N	\N	30315107	Nsele	\N	5	142176
144110	\N	\N	\N	\N	30315108	Tunzundu	\N	5	142176
144111	\N	\N	\N	\N	30320101	Buka-Kipangu	\N	5	142177
144112	\N	\N	\N	\N	30320102	Buka-Tsana	\N	5	142177
144113	\N	\N	\N	\N	30320103	Bwacongo	\N	5	142177
144114	\N	\N	\N	\N	30320104	Mwela-Nduwa	\N	5	142177
144115	\N	\N	\N	\N	30320105	Ngombe	\N	5	142177
144116	\N	\N	\N	\N	30320201	kabangu	\N	5	142178
144117	\N	\N	\N	\N	30320202	Mayoyo	\N	5	142178
144118	\N	\N	\N	\N	30320203	Mikunzi	\N	5	142178
144119	\N	\N	\N	\N	30320204	Mubunda	\N	5	142178
144120	\N	\N	\N	\N	30320205	Nzomba ( Nzombe )	\N	5	142178
144121	\N	\N	\N	\N	30320206	Tangungu / Tanganga	\N	5	142178
144122	\N	\N	\N	\N	30320207	Tawamba	\N	5	142178
144123	\N	\N	\N	\N	30320301	Kimbie	\N	5	142179
144124	\N	\N	\N	\N	30320302	Kimwilu-Kuba	\N	5	142179
144125	\N	\N	\N	\N	30320303	Kimwanza-Twal	\N	5	142179
144126	\N	\N	\N	\N	30320304	Kimwilu-Mabanza	\N	5	142179
144127	\N	\N	\N	\N	30320305	Kingoma-Masala ( Kingoma-Manza	\N	5	142179
144128	\N	\N	\N	\N	30320306	Kingoma-Munene	\N	5	142179
144129	\N	\N	\N	\N	30320307	Mudikwiti	\N	5	142179
144130	\N	\N	\N	\N	30320308	Mumbanda	\N	5	142179
144131	\N	\N	\N	\N	30320401	Kazamba-King	\N	5	142180
144132	\N	\N	\N	\N	30320402	Kikasa-Muene ( Kikasa-Mweni )	\N	5	142180
144133	\N	\N	\N	\N	30320403	Kimbie-Munbunga	\N	5	142180
144134	\N	\N	\N	\N	30320404	Kimbie-Mungie	\N	5	142180
144135	\N	\N	\N	\N	30320405	Kimbie-Ngiayi	\N	5	142180
144136	\N	\N	\N	\N	30320406	Kimbie-Matua	\N	5	142180
144137	\N	\N	\N	\N	30320407	Kimpila-Ngoto	\N	5	142180
144138	\N	\N	\N	\N	30320408	Kindia	\N	5	142180
144139	\N	\N	\N	\N	30320409	Kingoma-Bukiene	\N	5	142180
144140	\N	\N	\N	\N	30320501	Kanuutshi ( Kuhutshi)	\N	5	142181
144141	\N	\N	\N	\N	30320502	Kintulu / Kitulu	\N	5	142181
144142	\N	\N	\N	\N	30320503	Kongo-Muluma	\N	5	142181
144143	\N	\N	\N	\N	30320504	Kumbimashi	\N	5	142181
144144	\N	\N	\N	\N	30320505	Mbanza-Munda	\N	5	142181
144145	\N	\N	\N	\N	30320506	Mbazi ( Mbari )	\N	5	142181
144146	\N	\N	\N	\N	30320507	Mbata-Kizinga	\N	5	142181
144147	\N	\N	\N	\N	30320508	Mbata-Mwando ( Mbata Mawando )	\N	5	142181
144148	\N	\N	\N	\N	30320509	Mikunzi	\N	5	142181
144149	\N	\N	\N	\N	30320510	Mudiakama	\N	5	142181
144150	\N	\N	\N	\N	30320511	Mudikiti	\N	5	142181
144151	\N	\N	\N	\N	30320512	Mudingulu	\N	5	142181
144152	\N	\N	\N	\N	30320513	Mulutu	\N	5	142181
144153	\N	\N	\N	\N	30320514	Munkie	\N	5	142181
144154	\N	\N	\N	\N	30320515	Sakabanza ( Sakambanza )	\N	5	142181
144155	\N	\N	\N	\N	30320516	Simuna ( Shimuna )	\N	5	142181
144156	\N	\N	\N	\N	30320601	Fungulu	\N	5	142182
144157	\N	\N	\N	\N	30320602	Mbulukabala	\N	5	142182
144158	\N	\N	\N	\N	30320603	Mudikwiti	\N	5	142182
144159	\N	\N	\N	\N	30320604	Mudimuzinga	\N	5	142182
144160	\N	\N	\N	\N	30320605	Mwakama / Mwakana	\N	5	142182
144161	\N	\N	\N	\N	30320701	Mudikisongo	\N	5	142183
144162	\N	\N	\N	\N	30320702	Mudikiswa	\N	5	142183
144163	\N	\N	\N	\N	30320703	Ngulumbishi	\N	5	142183
144164	\N	\N	\N	\N	30320704	Pata-Kidinda	\N	5	142183
144165	\N	\N	\N	\N	30320710	Kingoma-Kapenda	\N	5	142183
144166	\N	\N	\N	\N	30320711	Kingoma-Mikwi	\N	5	142183
144167	\N	\N	\N	\N	30320712	Kingoma-Muluene	\N	5	142183
144168	\N	\N	\N	\N	30320713	Kumbi-Mashi	\N	5	142183
144169	\N	\N	\N	\N	30320714	Mukil Ngiene	\N	5	142183
144170	\N	\N	\N	\N	30320715	Musenge Kialu	\N	5	142183
144171	\N	\N	\N	\N	30320716	Musenge Mashanga	\N	5	142183
144172	\N	\N	\N	\N	30320717	Sakabanza	\N	5	142183
144173	\N	\N	\N	\N	30320718	Kimbumba-Milundu	\N	5	142183
144174	\N	\N	\N	\N	30320801	Menikongo	\N	5	142184
144175	\N	\N	\N	\N	30320802	Munguba	\N	5	142184
144176	\N	\N	\N	\N	30320901	Bagalala	\N	5	142185
144177	\N	\N	\N	\N	30320902	Kalunga-Mukinzi	\N	5	142185
144178	\N	\N	\N	\N	30320903	Minikwiti ( Menikwiti )	\N	5	142185
144179	\N	\N	\N	\N	30320904	Minimbimbi ( Munimbimbi )	\N	5	142185
144180	\N	\N	\N	\N	30320905	Mwilu-Mwilu	\N	5	142185
144181	\N	\N	\N	\N	30321001	Bibanga	\N	5	142186
144182	\N	\N	\N	\N	30321002	Katembo	\N	5	142186
144183	\N	\N	\N	\N	30321003	Katika	\N	5	142186
144184	\N	\N	\N	\N	30321004	Kiamfu	\N	5	142186
144185	\N	\N	\N	\N	30321005	Mafuta-mingi	\N	5	142186
144186	\N	\N	\N	\N	30321006	Fumunkento	\N	5	142186
144187	\N	\N	\N	\N	30321007	Mas-Manimba	\N	5	142186
144188	\N	\N	\N	\N	30321008	Matungulu	\N	5	142186
144189	\N	\N	\N	\N	30321009	Mikunzi	\N	5	142186
144190	\N	\N	\N	\N	30321010	Sumbu	\N	5	142186
144191	\N	\N	\N	\N	30330101	Balula	\N	5	142188
144192	\N	\N	\N	\N	30330102	Fadiaka	\N	5	142188
144193	\N	\N	\N	\N	30330103	Fambembe	\N	5	142188
144194	\N	\N	\N	\N	30330104	Fankana	\N	5	142188
144195	\N	\N	\N	\N	30330105	Fayala	\N	5	142188
144196	\N	\N	\N	\N	30330106	Kalakitini	\N	5	142188
144197	\N	\N	\N	\N	30330107	Fankamba	\N	5	142188
144198	\N	\N	\N	\N	30330108	Mubenga	\N	5	142188
144199	\N	\N	\N	\N	30330109	Kinkutu	\N	5	142188
144200	\N	\N	\N	\N	30330110	Kishia ( Kisia )	\N	5	142188
144201	\N	\N	\N	\N	30330111	Mbonga	\N	5	142188
144202	\N	\N	\N	\N	30330112	Ngonde	\N	5	142188
144203	\N	\N	\N	\N	30330113	Ngulu	\N	5	142188
144204	\N	\N	\N	\N	30330114	Simba	\N	5	142188
144205	\N	\N	\N	\N	30330115	Simuna ( Simma )	\N	5	142188
144206	\N	\N	\N	\N	30330116	zanga	\N	5	142188
144207	\N	\N	\N	\N	30330201	Bukuy	\N	5	142189
144208	\N	\N	\N	\N	30330202	Kimwana	\N	5	142189
144209	\N	\N	\N	\N	30330203	Makwa	\N	5	142189
144210	\N	\N	\N	\N	30330204	Malu	\N	5	142189
144211	\N	\N	\N	\N	30330205	Mbee	\N	5	142189
144212	\N	\N	\N	\N	30330206	Mbeno	\N	5	142189
144213	\N	\N	\N	\N	30330207	Mpono	\N	5	142189
144214	\N	\N	\N	\N	30330208	Mundale ( Mondale )	\N	5	142189
144215	\N	\N	\N	\N	30330209	Pentane	\N	5	142189
144216	\N	\N	\N	\N	30330301	Bambi-Etumba	\N	5	142190
144217	\N	\N	\N	\N	30330302	Mamvula	\N	5	142190
144218	\N	\N	\N	\N	30330303	Mbaka-Kasai	\N	5	142190
144219	\N	\N	\N	\N	30330304	Mbala-Ngudi	\N	5	142190
144220	\N	\N	\N	\N	30330305	Mbaya-Salikoko	\N	5	142190
144221	\N	\N	\N	\N	30330306	Mbene-Kasai	\N	5	142190
144222	\N	\N	\N	\N	30330307	Mbaya-Kasai	\N	5	142190
144223	\N	\N	\N	\N	30330308	Mbene-Nsampere	\N	5	142190
144224	\N	\N	\N	\N	30330309	Ndambi	\N	5	142190
144225	\N	\N	\N	\N	30330310	Soko-Pilipili	\N	5	142190
144226	\N	\N	\N	\N	30330401	Batere	\N	5	142191
144227	\N	\N	\N	\N	30330402	Kibwadi	\N	5	142191
144228	\N	\N	\N	\N	30330403	Kinkulu	\N	5	142191
144229	\N	\N	\N	\N	30330404	Kinsomo	\N	5	142191
144230	\N	\N	\N	\N	30330405	Kipata	\N	5	142191
144231	\N	\N	\N	\N	30330406	Mbelo	\N	5	142191
144232	\N	\N	\N	\N	30330407	Mbwasa	\N	5	142191
144233	\N	\N	\N	\N	30330408	Mowanzie	\N	5	142191
144234	\N	\N	\N	\N	30330409	Nkwa	\N	5	142191
144235	\N	\N	\N	\N	30330410	Ndana	\N	5	142191
144236	\N	\N	\N	\N	30330411	Ntunu	\N	5	142191
144237	\N	\N	\N	\N	30330412	Panga	\N	5	142191
144238	\N	\N	\N	\N	30330501	Djumango	\N	5	142192
144239	\N	\N	\N	\N	30330502	Fabomo	\N	5	142192
144240	\N	\N	\N	\N	30330503	Fampie	\N	5	142192
144241	\N	\N	\N	\N	30330504	Fampuni	\N	5	142192
144242	\N	\N	\N	\N	30330505	Kabuanga	\N	5	142192
144243	\N	\N	\N	\N	30330506	Kibuadi	\N	5	142192
144244	\N	\N	\N	\N	30330507	Kimbau	\N	5	142192
144245	\N	\N	\N	\N	30330508	Kimbimbi	\N	5	142192
144246	\N	\N	\N	\N	30330509	Kimbuma	\N	5	142192
144247	\N	\N	\N	\N	30330510	Kimobo	\N	5	142192
144248	\N	\N	\N	\N	30330511	Kimpini	\N	5	142192
144249	\N	\N	\N	\N	30330512	Kindondo Kibaya	\N	5	142192
144250	\N	\N	\N	\N	30330513	Kinshu	\N	5	142192
144251	\N	\N	\N	\N	30330514	Kinsongo	\N	5	142192
144252	\N	\N	\N	\N	30330515	Kisala	\N	5	142192
144253	\N	\N	\N	\N	30330516	Mbaya	\N	5	142192
144254	\N	\N	\N	\N	30330517	Mbenda	\N	5	142192
144255	\N	\N	\N	\N	30330518	Mushuni	\N	5	142192
144256	\N	\N	\N	\N	30330519	Mutombo	\N	5	142192
144257	\N	\N	\N	\N	30330520	Ndame	\N	5	142192
144258	\N	\N	\N	\N	30330521	Nguli	\N	5	142192
144259	\N	\N	\N	\N	30330522	Nguene	\N	5	142192
144260	\N	\N	\N	\N	30330523	Pimbili	\N	5	142192
144261	\N	\N	\N	\N	30330524	Nzumanzo (Ndana)	\N	5	142192
144262	\N	\N	\N	\N	30340101	Kwitinda	\N	5	142195
144263	\N	\N	\N	\N	30340102	Ngominene	\N	5	142195
144264	\N	\N	\N	\N	30340103	Tshimangungu	\N	5	142195
144265	\N	\N	\N	\N	30340201	Mbwilibale	\N	5	142196
144266	\N	\N	\N	\N	30340202	Miyoyo	\N	5	142196
144267	\N	\N	\N	\N	30340203	Mvulua-Mpi	\N	5	142196
144268	\N	\N	\N	\N	30340301	Lwem	\N	5	142197
144269	\N	\N	\N	\N	30340302	Mukupamu	\N	5	142197
144270	\N	\N	\N	\N	30340303	Ngala-Lweme	\N	5	142197
144271	\N	\N	\N	\N	30340304	Ngala-Ngoso	\N	5	142197
144272	\N	\N	\N	\N	30340305	Ngala-Panga	\N	5	142197
144273	\N	\N	\N	\N	30340306	Panelime	\N	5	142197
144274	\N	\N	\N	\N	30340401	Bangoli	\N	5	142198
144275	\N	\N	\N	\N	30340402	Bifar	\N	5	142198
144276	\N	\N	\N	\N	30340403	Lweme	\N	5	142198
144277	\N	\N	\N	\N	30340404	Ndele-Beleshi	\N	5	142198
144278	\N	\N	\N	\N	30340405	Ebiala	\N	5	142198
144279	\N	\N	\N	\N	30340406	Ngala-Kianga	\N	5	142198
144280	\N	\N	\N	\N	30340407	Makando	\N	5	142198
144281	\N	\N	\N	\N	30340408	Pili-Pili	\N	5	142198
144282	\N	\N	\N	\N	30340501	Gaminay	\N	5	142199
144283	\N	\N	\N	\N	30340502	Kibwanga	\N	5	142199
144284	\N	\N	\N	\N	30340503	Munimi	\N	5	142199
144285	\N	\N	\N	\N	30340504	Nkumi	\N	5	142199
144286	\N	\N	\N	\N	30340505	Tshitshiri	\N	5	142199
144287	\N	\N	\N	\N	30340506	Wamba Muzulu	\N	5	142199
144288	\N	\N	\N	\N	30340601	Bulanga-Mpey	\N	5	142200
144289	\N	\N	\N	\N	30340602	Bulanga-Wi	\N	5	142200
144290	\N	\N	\N	\N	30340603	Longwama	\N	5	142200
144291	\N	\N	\N	\N	30340604	Mateko	\N	5	142200
144292	\N	\N	\N	\N	30340605	Mayumbu	\N	5	142200
144293	\N	\N	\N	\N	30340606	Yaya	\N	5	142200
144294	\N	\N	\N	\N	30340607	Nkenge	\N	5	142200
144296	\N	\N	\N	\N	30340609	Mabamaba	\N	5	142200
144297	\N	\N	\N	\N	30340610	Muzo	\N	5	142200
144298	\N	\N	\N	\N	30340701	Bangoli	\N	5	142201
144299	\N	\N	\N	\N	30340702	Ibo	\N	5	142201
144300	\N	\N	\N	\N	30340703	Munken-Mbe	\N	5	142201
144301	\N	\N	\N	\N	30340704	Ntor	\N	5	142201
144302	\N	\N	\N	\N	30340801	Bukutu	\N	5	142202
144303	\N	\N	\N	\N	30340802	Gombe	\N	5	142202
144304	\N	\N	\N	\N	30340803	Ikwiti	\N	5	142202
144305	\N	\N	\N	\N	30340804	Isamanga Musenge	\N	5	142202
144306	\N	\N	\N	\N	30340805	Ishanga-Bensi	\N	5	142202
144307	\N	\N	\N	\N	30340806	Itunda-Kit	\N	5	142202
144308	\N	\N	\N	\N	30340807	Idibu-Iyumi	\N	5	142202
144309	\N	\N	\N	\N	30340808	Kipuku	\N	5	142202
144310	\N	\N	\N	\N	30340809	Ingundu	\N	5	142202
144311	\N	\N	\N	\N	30340810	Ombole	\N	5	142202
144312	\N	\N	\N	\N	30340811	Tundu-Mapepe	\N	5	142202
144313	\N	\N	\N	\N	30340901	Bakwa-Kiwenge	\N	5	142203
144314	\N	\N	\N	\N	30340902	Bakwa-Phungu	\N	5	142203
144315	\N	\N	\N	\N	30340903	Bakwa-Samba	\N	5	142203
144316	\N	\N	\N	\N	30340904	Ingundu-Bawongo	\N	5	142203
144317	\N	\N	\N	\N	30340905	Belo-Shimuna	\N	5	142203
144318	\N	\N	\N	\N	30340906	Kimbembele	\N	5	142203
144319	\N	\N	\N	\N	30340907	Kimfumu-Nene	\N	5	142203
144320	\N	\N	\N	\N	30340908	Mbimbi	\N	5	142203
144321	\N	\N	\N	\N	30340909	Ngula-Ndambi	\N	5	142203
144322	\N	\N	\N	\N	30341001	banda-Busungu	\N	5	142204
144323	\N	\N	\N	\N	30341002	Bawa-Muyunzi	\N	5	142204
144324	\N	\N	\N	\N	30341003	Kisamango	\N	5	142204
144325	\N	\N	\N	\N	30341004	Kakwata	\N	5	142204
144326	\N	\N	\N	\N	30341005	Kahumba	\N	5	142204
144327	\N	\N	\N	\N	30341006	Kibulu-Mwanga	\N	5	142204
144328	\N	\N	\N	\N	30341007	Kikoso	\N	5	142204
144329	\N	\N	\N	\N	30341008	Kinguba	\N	5	142204
144330	\N	\N	\N	\N	30341009	Kizanga	\N	5	142204
144331	\N	\N	\N	\N	30341010	Luka	\N	5	142204
144332	\N	\N	\N	\N	30341011	Kwnde-Nzango	\N	5	142204
144333	\N	\N	\N	\N	30341012	Bikwiti	\N	5	142204
144334	\N	\N	\N	\N	30341013	Mungay-Muzenge	\N	5	142204
144335	\N	\N	\N	\N	30341014	Nenga	\N	5	142204
144336	\N	\N	\N	\N	30341101	Ambun-Bishi	\N	5	142205
144337	\N	\N	\N	\N	30341102	Ambun-Ifwanzone	\N	5	142205
144338	\N	\N	\N	\N	30341103	Ambun-Insuem Bulenge	\N	5	142205
144339	\N	\N	\N	\N	30341104	Ambun-Lubwe	\N	5	142205
144340	\N	\N	\N	\N	30341105	Ingala-Makela	\N	5	142205
144341	\N	\N	\N	\N	30341201	Impanga-Mupila	\N	5	142206
144342	\N	\N	\N	\N	30341202	Kalanganda	\N	5	142206
144343	\N	\N	\N	\N	30341203	Mayanda	\N	5	142206
144344	\N	\N	\N	\N	30341204	Mpukusu-Musenge	\N	5	142206
144345	\N	\N	\N	\N	30341205	Musenge-Lumeya	\N	5	142206
144346	\N	\N	\N	\N	30341206	Mwempata	\N	5	142206
144347	\N	\N	\N	\N	30341207	Mpukulu Lakas	\N	5	142206
144348	\N	\N	\N	\N	30345101	Eba	\N	5	142207
144349	\N	\N	\N	\N	30345102	Mapela	\N	5	142207
144350	\N	\N	\N	\N	30345103	Minampala	\N	5	142207
144351	\N	\N	\N	\N	30345104	Mobutu	\N	5	142207
144352	\N	\N	\N	\N	30345105	Ngomposo	\N	5	142207
144353	\N	\N	\N	\N	30345106	N'Sele	\N	5	142207
144354	\N	\N	\N	\N	30345107	Congo(ZaÃ¯re)	\N	5	142207
144355	\N	\N	\N	\N	30345201	Cafe	\N	5	142208
144356	\N	\N	\N	\N	30345202	Owongo	\N	5	142208
144357	\N	\N	\N	\N	30345203	Isabo	\N	5	142208
144358	\N	\N	\N	\N	30345204	Midima	\N	5	142208
144359	\N	\N	\N	\N	30345205	Muke	\N	5	142208
144360	\N	\N	\N	\N	30345206	Noki-Noki	\N	5	142208
144361	\N	\N	\N	\N	30345207	N'Sele	\N	5	142208
144362	\N	\N	\N	\N	30345301	Bandundu	\N	5	142209
144363	\N	\N	\N	\N	30345302	Ipala	\N	5	142209
144364	\N	\N	\N	\N	30345303	Kapita	\N	5	142209
144365	\N	\N	\N	\N	30345304	Kwilu	\N	5	142209
144366	\N	\N	\N	\N	30345305	Port Bisengo	\N	5	142209
144367	\N	\N	\N	\N	30345401	Nkoro	\N	5	142210
144368	\N	\N	\N	\N	30345402	Makanza	\N	5	142210
144369	\N	\N	\N	\N	30345403	Mbila	\N	5	142210
144370	\N	\N	\N	\N	30345404	Mobutu	\N	5	142210
144371	\N	\N	\N	\N	30345405	Nzau	\N	5	142210
144372	\N	\N	\N	\N	30345406	M.P.R.	\N	5	142210
144373	\N	\N	\N	\N	30350101	Hako	\N	5	142211
144374	\N	\N	\N	\N	30350102	Kabula	\N	5	142211
144375	\N	\N	\N	\N	30350103	Kiama	\N	5	142211
144376	\N	\N	\N	\N	30350104	Kisongonzila	\N	5	142211
144377	\N	\N	\N	\N	30350105	Mutondonzila	\N	5	142211
144378	\N	\N	\N	\N	30350106	Nambanza	\N	5	142211
144379	\N	\N	\N	\N	30350107	Ndongela	\N	5	142211
144380	\N	\N	\N	\N	30350108	Ngalakitende	\N	5	142211
144381	\N	\N	\N	\N	30350109	Ngandu	\N	5	142211
144382	\N	\N	\N	\N	30350201	Holu	\N	5	142212
144383	\N	\N	\N	\N	30350202	Kangu	\N	5	142212
144384	\N	\N	\N	\N	30350203	Kasanza	\N	5	142212
144385	\N	\N	\N	\N	30350204	Kashitu	\N	5	142212
144386	\N	\N	\N	\N	30350205	Kinnzungu	\N	5	142212
144387	\N	\N	\N	\N	30350206	Mbalakunda	\N	5	142212
144388	\N	\N	\N	\N	30350207	Mudikwiti	\N	5	142212
144389	\N	\N	\N	\N	30350208	Mudiwamba	\N	5	142212
144390	\N	\N	\N	\N	30350209	Mulikalunga	\N	5	142212
144391	\N	\N	\N	\N	30350210	Mwandu	\N	5	142212
144392	\N	\N	\N	\N	30350211	Ngandu-Kitende	\N	5	142212
144393	\N	\N	\N	\N	30350212	Shimuna-Kanza	\N	5	142212
144394	\N	\N	\N	\N	30350301	Kibongo	\N	5	142213
144395	\N	\N	\N	\N	30350302	Kingudi	\N	5	142213
144396	\N	\N	\N	\N	30350303	Kisunzu	\N	5	142213
144397	\N	\N	\N	\N	30350304	Mbamba	\N	5	142213
144398	\N	\N	\N	\N	30350305	Mudiniati	\N	5	142213
144399	\N	\N	\N	\N	30350306	Mulikalunga	\N	5	142213
144400	\N	\N	\N	\N	30350307	Mwilu	\N	5	142213
144401	\N	\N	\N	\N	30350401	Ngwangwa	\N	5	142214
144402	\N	\N	\N	\N	30350402	Kahundji	\N	5	142214
144403	\N	\N	\N	\N	30350403	Kangu	\N	5	142214
144404	\N	\N	\N	\N	30350404	Kisunzu	\N	5	142214
144405	\N	\N	\N	\N	30350405	Kingulu	\N	5	142214
144406	\N	\N	\N	\N	30350406	Kitombe	\N	5	142214
144407	\N	\N	\N	\N	30350407	Mangolo	\N	5	142214
144408	\N	\N	\N	\N	30350408	Mukoso	\N	5	142214
144409	\N	\N	\N	\N	30350409	Mutombo	\N	5	142214
144410	\N	\N	\N	\N	30350410	Ngongo	\N	5	142214
144411	\N	\N	\N	\N	30350411	Mutundu	\N	5	142214
144412	\N	\N	\N	\N	30350412	Ngumbambulu	\N	5	142214
144413	\N	\N	\N	\N	30350413	Niekenene	\N	5	142214
144414	\N	\N	\N	\N	30350414	Pukusu	\N	5	142214
144415	\N	\N	\N	\N	30350501	Bangi	\N	5	142215
144416	\N	\N	\N	\N	30350502	Bondo	\N	5	142215
144417	\N	\N	\N	\N	30350503	Bushi	\N	5	142215
144418	\N	\N	\N	\N	30350504	Kindele	\N	5	142215
144419	\N	\N	\N	\N	30350505	Kazamba	\N	5	142215
144420	\N	\N	\N	\N	30350506	Mulasa	\N	5	142215
144421	\N	\N	\N	\N	30350507	Musoto	\N	5	142215
144422	\N	\N	\N	\N	30350508	Ndala	\N	5	142215
144423	\N	\N	\N	\N	30350509	Ulume	\N	5	142215
144424	\N	\N	\N	\N	30350510	Yongo 2	\N	5	142215
144425	\N	\N	\N	\N	30350601	Ebeal	\N	5	142216
144426	\N	\N	\N	\N	30350602	Kimbanda	\N	5	142216
144427	\N	\N	\N	\N	30350603	Kimpundu	\N	5	142216
144428	\N	\N	\N	\N	30350604	Lubushi	\N	5	142216
144429	\N	\N	\N	\N	30350605	Lukamba	\N	5	142216
144430	\N	\N	\N	\N	30350606	Mukulu	\N	5	142216
144431	\N	\N	\N	\N	30350607	Patende	\N	5	142216
144432	\N	\N	\N	\N	30350701	Kangu	\N	5	142217
144433	\N	\N	\N	\N	30350702	Kanzonzo	\N	5	142217
144434	\N	\N	\N	\N	30350703	Kikwa-Mboka	\N	5	142217
144435	\N	\N	\N	\N	30350704	Mwenenbangu	\N	5	142217
144436	\N	\N	\N	\N	30350705	Mwenengungu	\N	5	142217
144437	\N	\N	\N	\N	30350706	Kunga-Kihangu	\N	5	142217
144438	\N	\N	\N	\N	30350707	Yonso	\N	5	142217
144439	\N	\N	\N	\N	30350801	Gapemba	\N	5	142218
144440	\N	\N	\N	\N	30350802	Gasandji	\N	5	142218
144441	\N	\N	\N	\N	30350803	Gatundo	\N	5	142218
144442	\N	\N	\N	\N	30350804	kinguba	\N	5	142218
144443	\N	\N	\N	\N	30350805	Kinzamba	\N	5	142218
144444	\N	\N	\N	\N	30350806	Lozo	\N	5	142218
144445	\N	\N	\N	\N	30350807	Kungu	\N	5	142218
144446	\N	\N	\N	\N	30350808	Malondo	\N	5	142218
144447	\N	\N	\N	\N	30350809	Mulungu	\N	5	142218
144448	\N	\N	\N	\N	30350810	Musango	\N	5	142218
144449	\N	\N	\N	\N	30350811	Ngombo	\N	5	142218
144450	\N	\N	\N	\N	30350812	Ngunda	\N	5	142218
144451	\N	\N	\N	\N	30350901	Bawongo	\N	5	142219
144452	\N	\N	\N	\N	30350902	Bushi	\N	5	142219
144453	\N	\N	\N	\N	30350903	Kimbembele	\N	5	142219
144454	\N	\N	\N	\N	30350904	Kikwinzi	\N	5	142219
144455	\N	\N	\N	\N	30350905	Ngashi	\N	5	142219
144456	\N	\N	\N	\N	30350906	Ngudi	\N	5	142219
144457	\N	\N	\N	\N	30350907	Samba	\N	5	142219
144458	\N	\N	\N	\N	30351001	Banga	\N	5	142220
144459	\N	\N	\N	\N	30351002	Bashi-Bulenge	\N	5	142220
144460	\N	\N	\N	\N	30351003	Bushi-Makola	\N	5	142220
144461	\N	\N	\N	\N	30351004	Kpita	\N	5	142220
144462	\N	\N	\N	\N	30351005	Katamba	\N	5	142220
144463	\N	\N	\N	\N	30351006	Kinga	\N	5	142220
144464	\N	\N	\N	\N	30351007	Landa	\N	5	142220
144465	\N	\N	\N	\N	30351008	Madimbi	\N	5	142220
144466	\N	\N	\N	\N	30351009	Makola	\N	5	142220
144467	\N	\N	\N	\N	30351010	Mbandji	\N	5	142220
144468	\N	\N	\N	\N	30351011	Mudiwa	\N	5	142220
144469	\N	\N	\N	\N	30351012	Ndumbi	\N	5	142220
144470	\N	\N	\N	\N	30351013	Ngudi	\N	5	142220
144471	\N	\N	\N	\N	30351014	Nianga	\N	5	142220
144472	\N	\N	\N	\N	30351015	Pinda	\N	5	142220
144473	\N	\N	\N	\N	30351016	Ubole	\N	5	142220
144474	\N	\N	\N	\N	30351101	Kahungula	\N	5	142221
144475	\N	\N	\N	\N	30351102	Katengakio	\N	5	142221
144476	\N	\N	\N	\N	30351103	Katengakuba	\N	5	142221
144477	\N	\N	\N	\N	30351104	Kawaya	\N	5	142221
144478	\N	\N	\N	\N	30351105	kilumbu	\N	5	142221
144479	\N	\N	\N	\N	30351106	Kinzashibama	\N	5	142221
144480	\N	\N	\N	\N	30351107	Kizashi-Kumbi	\N	5	142221
144481	\N	\N	\N	\N	30351108	Kisamba-Kesa	\N	5	142221
144482	\N	\N	\N	\N	30351109	Kisenzula	\N	5	142221
144483	\N	\N	\N	\N	30351110	Katembo	\N	5	142221
144484	\N	\N	\N	\N	30351111	Loji Makumbi	\N	5	142221
144485	\N	\N	\N	\N	30351112	Mahange	\N	5	142221
144486	\N	\N	\N	\N	30351113	Manda Pulu	\N	5	142221
144487	\N	\N	\N	\N	30351114	Ngashi	\N	5	142221
144488	\N	\N	\N	\N	30351115	Ngandu-Kas	\N	5	142221
144489	\N	\N	\N	\N	30351116	Ngundu-Kindamba	\N	5	142221
144490	\N	\N	\N	\N	30351201	Basamba	\N	5	142222
144491	\N	\N	\N	\N	30351202	Kabambay	\N	5	142222
144492	\N	\N	\N	\N	30351203	Kibanda	\N	5	142222
144493	\N	\N	\N	\N	30351204	Kifuza	\N	5	142222
144494	\N	\N	\N	\N	30351205	Kiefu	\N	5	142222
144495	\N	\N	\N	\N	30351206	Kombana	\N	5	142222
144496	\N	\N	\N	\N	30351207	Kudi	\N	5	142222
144497	\N	\N	\N	\N	30351208	Mbondo	\N	5	142222
144498	\N	\N	\N	\N	30351209	Bakwamuya Mugwa	\N	5	142222
144499	\N	\N	\N	\N	30351210	Ngunda	\N	5	142222
144500	\N	\N	\N	\N	30351211	Nzinga	\N	5	142222
144501	\N	\N	\N	\N	30410001	30 Juin	\N	5	142224
144502	\N	\N	\N	\N	30410002	Inga	\N	5	142224
144503	\N	\N	\N	\N	30410003	Lwano	\N	5	142224
144504	\N	\N	\N	\N	30420001	Kimwanga	\N	5	142225
144505	\N	\N	\N	\N	30420002	Lumbi	\N	5	142225
144506	\N	\N	\N	\N	30420003	Ndeke Zulu	\N	5	142225
144507	\N	\N	\N	\N	30420004	Sankuru	\N	5	142225
144508	\N	\N	\N	\N	30430001	Bongiza	\N	5	142226
144509	\N	\N	\N	\N	30430002	Lunia	\N	5	142226
144510	\N	\N	\N	\N	30430003	Yonzi	\N	5	142226
144511	\N	\N	\N	\N	30430004	Mudikwiti	\N	5	142226
144512	\N	\N	\N	\N	30440001	Etac	\N	5	142227
144513	\N	\N	\N	\N	30440002	Misengi	\N	5	142227
144514	\N	\N	\N	\N	30440003	Ndangu	\N	5	142227
144515	\N	\N	\N	\N	30440004	Ngulunzamba	\N	5	142227
144516	\N	\N	\N	\N	30440005	Nzundu	\N	5	142227
144517	\N	\N	\N	\N	30440006	Wenze	\N	5	142227
144518	\N	\N	\N	\N	30510007	Mbinda-Dinga	\N	5	142228
144519	\N	\N	\N	\N	30510101	Dinga	\N	5	142228
144520	\N	\N	\N	\N	30510102	Malambo	\N	5	142228
144521	\N	\N	\N	\N	30510103	Kanimbu-Mut	\N	5	142228
144522	\N	\N	\N	\N	30510104	Kasandji	\N	5	142228
144523	\N	\N	\N	\N	30510105	Kasongo-Dinga	\N	5	142228
144524	\N	\N	\N	\N	30510106	Kasongo-Yungu	\N	5	142228
144525	\N	\N	\N	\N	30510108	Mboso-Mwa	\N	5	142228
144526	\N	\N	\N	\N	30510109	Mbumi-Tsh	\N	5	142228
144527	\N	\N	\N	\N	30510110	Mukukulu	\N	5	142228
144528	\N	\N	\N	\N	30510111	Munzengele	\N	5	142228
144529	\N	\N	\N	\N	30510201	Bukanga	\N	5	142229
144530	\N	\N	\N	\N	30510202	Kafulu	\N	5	142229
144531	\N	\N	\N	\N	30510203	Kasandji	\N	5	142229
144532	\N	\N	\N	\N	30510204	Kiamfu-K	\N	5	142229
144533	\N	\N	\N	\N	30510205	Kikwanga	\N	5	142229
144534	\N	\N	\N	\N	30510206	Kitadi-Lwasa	\N	5	142229
144535	\N	\N	\N	\N	30510207	Kitshongo	\N	5	142229
144536	\N	\N	\N	\N	30510208	Mbadinga	\N	5	142229
144537	\N	\N	\N	\N	30510209	Makengo	\N	5	142229
144538	\N	\N	\N	\N	30510210	Munene	\N	5	142229
144539	\N	\N	\N	\N	30510211	Takundi	\N	5	142229
144540	\N	\N	\N	\N	30510301	Kalende	\N	5	142230
144541	\N	\N	\N	\N	30510302	Kamungu	\N	5	142230
144542	\N	\N	\N	\N	30510303	Kasanzi	\N	5	142230
144543	\N	\N	\N	\N	30510304	Kasongo-Tsheke	\N	5	142230
144544	\N	\N	\N	\N	30510305	Kayonso	\N	5	142230
144545	\N	\N	\N	\N	30510306	Kibanda	\N	5	142230
144546	\N	\N	\N	\N	30510307	Kibwila	\N	5	142230
144547	\N	\N	\N	\N	30510308	Kidima	\N	5	142230
144548	\N	\N	\N	\N	30510309	Kikondo ( Mukondo )	\N	5	142230
144549	\N	\N	\N	\N	30510310	Kivundisa	\N	5	142230
144550	\N	\N	\N	\N	30510311	Kobo	\N	5	142230
144551	\N	\N	\N	\N	30510312	Lukunda	\N	5	142230
144552	\N	\N	\N	\N	30510313	Misele	\N	5	142230
144553	\N	\N	\N	\N	30510314	Muambu	\N	5	142230
144554	\N	\N	\N	\N	30510315	Mukata	\N	5	142230
144555	\N	\N	\N	\N	30510316	Mukumbi	\N	5	142230
144556	\N	\N	\N	\N	30510317	Munene	\N	5	142230
144557	\N	\N	\N	\N	30510318	Mwela-Ns	\N	5	142230
144558	\N	\N	\N	\N	30510319	Nzau-Musitu	\N	5	142230
144559	\N	\N	\N	\N	30510320	Sindulaswa Mbuya	\N	5	142230
144560	\N	\N	\N	\N	30510321	Swa-Bangu	\N	5	142230
144561	\N	\N	\N	\N	30510322	Swa-Kahumba	\N	5	142230
144562	\N	\N	\N	\N	30510323	Swa-Kasongo	\N	5	142230
144563	\N	\N	\N	\N	30510324	Swa-Yamfu	\N	5	142230
144564	\N	\N	\N	\N	30510401	Bokanga-Molete	\N	5	142231
144565	\N	\N	\N	\N	30510402	Bokanga-Tshike	\N	5	142231
144566	\N	\N	\N	\N	30510403	Fasamba	\N	5	142231
144567	\N	\N	\N	\N	30510404	Kamwene	\N	5	142231
144568	\N	\N	\N	\N	30510405	Kapay	\N	5	142231
144569	\N	\N	\N	\N	30510406	Kimafu	\N	5	142231
144570	\N	\N	\N	\N	30510407	Lwasa	\N	5	142231
144571	\N	\N	\N	\N	30510408	Mundonda	\N	5	142231
144572	\N	\N	\N	\N	30510409	Munzanza-Ngombo	\N	5	142231
144573	\N	\N	\N	\N	30510410	Tshakala-Nord	\N	5	142231
144574	\N	\N	\N	\N	30510601	Kalunga	\N	5	142232
144575	\N	\N	\N	\N	30510602	Kambundi	\N	5	142232
144576	\N	\N	\N	\N	30510603	Kandi	\N	5	142232
144577	\N	\N	\N	\N	30510604	Kiamfu-Kinza	\N	5	142232
144578	\N	\N	\N	\N	30510605	Lukuni-Wamba	\N	5	142232
144579	\N	\N	\N	\N	30510606	Lwakuni-Tsha	\N	5	142232
144580	\N	\N	\N	\N	30510607	Mabaka	\N	5	142232
144581	\N	\N	\N	\N	30510608	Mbau	\N	5	142232
144582	\N	\N	\N	\N	30510609	Musaka	\N	5	142232
144583	\N	\N	\N	\N	30510610	Ngoy	\N	5	142232
144584	\N	\N	\N	\N	30510611	Tanda	\N	5	142232
144585	\N	\N	\N	\N	30515101	3 Z	\N	5	142233
144586	\N	\N	\N	\N	30515102	Mavula	\N	5	142233
144587	\N	\N	\N	\N	30515103	Kapanga	\N	5	142233
144588	\N	\N	\N	\N	30515104	Kenge 2	\N	5	142233
144589	\N	\N	\N	\N	30515105	Manonga	\N	5	142233
144590	\N	\N	\N	\N	30515106	Masikita	\N	5	142233
144591	\N	\N	\N	\N	30515109	Salongo	\N	5	142233
144592	\N	\N	\N	\N	30515110	Yete	\N	5	142233
144593	\N	\N	\N	\N	30520101	Bakangumbi	\N	5	142234
144594	\N	\N	\N	\N	30520102	Buka-Sangwa	\N	5	142234
144595	\N	\N	\N	\N	30520103	Kabukulu	\N	5	142234
144596	\N	\N	\N	\N	30520104	Kakopmbi	\N	5	142234
144597	\N	\N	\N	\N	30520105	Kambundi-Nganga	\N	5	142234
144598	\N	\N	\N	\N	30520106	Kambundi-Tundi	\N	5	142234
144599	\N	\N	\N	\N	30520107	Kabongo	\N	5	142234
144600	\N	\N	\N	\N	30520108	Kitala	\N	5	142234
144601	\N	\N	\N	\N	30520109	Mubanga	\N	5	142234
144602	\N	\N	\N	\N	30520110	Mulasa-Mbaku	\N	5	142234
144603	\N	\N	\N	\N	30520111	Muluwa-MF	\N	5	142234
144604	\N	\N	\N	\N	30520112	Mwana--Basila	\N	5	142234
144605	\N	\N	\N	\N	30520113	Mwela-Tshaku	\N	5	142234
144606	\N	\N	\N	\N	30520114	Ngima	\N	5	142234
144607	\N	\N	\N	\N	30520115	Tshiaku	\N	5	142234
144608	\N	\N	\N	\N	30520116	Tsiamu-Kakabaka	\N	5	142234
144609	\N	\N	\N	\N	30520117	Tshiaku-Zume	\N	5	142234
144610	\N	\N	\N	\N	30520201	Kambundi	\N	5	142235
144611	\N	\N	\N	\N	30520202	Katambi	\N	5	142235
144612	\N	\N	\N	\N	30520203	Kikwanza	\N	5	142235
144613	\N	\N	\N	\N	30520204	Lwanga	\N	5	142235
144614	\N	\N	\N	\N	30520205	Mbumba	\N	5	142235
144615	\N	\N	\N	\N	30520206	Mulasa	\N	5	142235
144616	\N	\N	\N	\N	30520207	Muzengo	\N	5	142235
144617	\N	\N	\N	\N	30520208	Zalala	\N	5	142235
144618	\N	\N	\N	\N	30520301	Bolashi	\N	5	142236
144619	\N	\N	\N	\N	30520302	Kahungu	\N	5	142236
144620	\N	\N	\N	\N	30520303	Kafula	\N	5	142236
144621	\N	\N	\N	\N	30520304	Kikombo	\N	5	142236
144622	\N	\N	\N	\N	30520306	Kisambu	\N	5	142236
144623	\N	\N	\N	\N	30520307	Luhemba	\N	5	142236
144624	\N	\N	\N	\N	30520308	Mulikikanda	\N	5	142236
144625	\N	\N	\N	\N	30520401	Kianza	\N	5	142237
144626	\N	\N	\N	\N	30520402	Ngungi	\N	5	142237
144627	\N	\N	\N	\N	30520403	Palanga	\N	5	142237
144628	\N	\N	\N	\N	30530101	Mwadikaluga	\N	5	142239
144629	\N	\N	\N	\N	30530102	Kayita	\N	5	142239
144630	\N	\N	\N	\N	30530103	Kulindji	\N	5	142239
144631	\N	\N	\N	\N	30530104	Mayeza	\N	5	142239
144632	\N	\N	\N	\N	30530105	Mwamufiya	\N	5	142239
144633	\N	\N	\N	\N	30530106	Mwanzanza	\N	5	142239
144634	\N	\N	\N	\N	30530107	Nzofu	\N	5	142239
144635	\N	\N	\N	\N	30530108	Sakabuku	\N	5	142239
144636	\N	\N	\N	\N	30530201	Kabanga	\N	5	142240
144637	\N	\N	\N	\N	30530202	Kapela	\N	5	142240
144638	\N	\N	\N	\N	30530203	Kawanda	\N	5	142240
144639	\N	\N	\N	\N	30530204	Muloposhinda	\N	5	142240
144640	\N	\N	\N	\N	30530205	Mwendjila	\N	5	142240
144641	\N	\N	\N	\N	30530207	Mweni-Kalunga	\N	5	142240
144642	\N	\N	\N	\N	30530208	Pungu	\N	5	142240
144643	\N	\N	\N	\N	30530209	shapoko	\N	5	142240
144644	\N	\N	\N	\N	30530301	Kahungu	\N	5	142241
144645	\N	\N	\N	\N	30530302	Kamba-Nguya	\N	5	142241
144646	\N	\N	\N	\N	30530303	Mufikidi	\N	5	142241
144647	\N	\N	\N	\N	30530304	Muloshi	\N	5	142241
144648	\N	\N	\N	\N	30530305	Mwambu	\N	5	142241
144649	\N	\N	\N	\N	30530306	Tshimangata	\N	5	142241
144650	\N	\N	\N	\N	30530307	Tshikalaba	\N	5	142241
144651	\N	\N	\N	\N	30530401	Bumba	\N	5	142242
144652	\N	\N	\N	\N	30530402	Shamalenge	\N	5	142242
144653	\N	\N	\N	\N	30530403	Shamanganda	\N	5	142242
144654	\N	\N	\N	\N	30530501	Kama-Lwanzo	\N	5	142243
144655	\N	\N	\N	\N	30530502	Kama-Mwaka	\N	5	142243
144656	\N	\N	\N	\N	30530503	Mwakabinza	\N	5	142243
144657	\N	\N	\N	\N	30530504	Mwamushiko	\N	5	142243
144658	\N	\N	\N	\N	30530505	Shamibanda	\N	5	142243
144659	\N	\N	\N	\N	30530506	Shamisongo	\N	5	142243
144660	\N	\N	\N	\N	30530507	Shatisiminia	\N	5	142243
144661	\N	\N	\N	\N	30530508	Shayamanda	\N	5	142243
144662	\N	\N	\N	\N	30530601	Bindu	\N	5	142244
144663	\N	\N	\N	\N	30530602	Kabongo	\N	5	142244
144664	\N	\N	\N	\N	30530603	Kamatanda	\N	5	142244
144665	\N	\N	\N	\N	30530604	Kamba-Kanda	\N	5	142244
144666	\N	\N	\N	\N	30530605	Kamba-Nana	\N	5	142244
144667	\N	\N	\N	\N	30530606	Kasasa	\N	5	142244
144668	\N	\N	\N	\N	30530607	Mapasa	\N	5	142244
144669	\N	\N	\N	\N	30530608	Muteba Kaz	\N	5	142244
144670	\N	\N	\N	\N	30530609	Mwatshivunda	\N	5	142244
144671	\N	\N	\N	\N	30530610	Shadima	\N	5	142244
144672	\N	\N	\N	\N	30530611	Shamalenge	\N	5	142244
144673	\N	\N	\N	\N	30530612	Shatsaka	\N	5	142244
144674	\N	\N	\N	\N	30530613	Kamba-Tshafika	\N	5	142244
144675	\N	\N	\N	\N	30530614	Tshifwameso	\N	5	142244
144676	\N	\N	\N	\N	30530615	Tshivunda	\N	5	142244
144677	\N	\N	\N	\N	30535101	Conseil	\N	5	142245
144678	\N	\N	\N	\N	30535102	Kahembe	\N	5	142245
144679	\N	\N	\N	\N	30535103	Kamanbanda	\N	5	142245
144680	\N	\N	\N	\N	30535104	Mobutu	\N	5	142245
144681	\N	\N	\N	\N	30535105	Muloshi	\N	5	142245
144682	\N	\N	\N	\N	30535106	Sukisa	\N	5	142245
144683	\N	\N	\N	\N	30540101	Kambamba	\N	5	142246
144684	\N	\N	\N	\N	30540102	Kasndji	\N	5	142246
144685	\N	\N	\N	\N	30540103	Kibenga	\N	5	142246
144686	\N	\N	\N	\N	30540104	Kizamba	\N	5	142246
144687	\N	\N	\N	\N	30540105	Madimba	\N	5	142246
144688	\N	\N	\N	\N	30540106	Mangangi	\N	5	142246
144689	\N	\N	\N	\N	30540107	Mawangu	\N	5	142246
144690	\N	\N	\N	\N	30540108	Ngombe-Tumba	\N	5	142246
144691	\N	\N	\N	\N	30540109	Tembo	\N	5	142246
144692	\N	\N	\N	\N	30540201	Kisadi	\N	5	142247
144693	\N	\N	\N	\N	30540202	Mutwmbala	\N	5	142247
144694	\N	\N	\N	\N	30540203	Nzazi-Mwabi	\N	5	142247
144695	\N	\N	\N	\N	30540204	Swa-Ibanda	\N	5	142247
144696	\N	\N	\N	\N	30540205	Swa-Ibula	\N	5	142247
144697	\N	\N	\N	\N	30540206	Swa -Kalemba	\N	5	142247
144698	\N	\N	\N	\N	30540207	Swa -Tenda	\N	5	142247
144699	\N	\N	\N	\N	30540208	Yamfu -Kit	\N	5	142247
144700	\N	\N	\N	\N	30540209	Yenga-Lusandji	\N	5	142247
144701	\N	\N	\N	\N	30540210	Yuenga-Dia-Bangu	\N	5	142247
144702	\N	\N	\N	\N	30540301	Kasongo-Lunda	\N	5	142248
144703	\N	\N	\N	\N	30540302	Kingete	\N	5	142248
144704	\N	\N	\N	\N	30540303	Swa-Mbambi	\N	5	142248
144705	\N	\N	\N	\N	30540304	Mulingunda	\N	5	142248
144706	\N	\N	\N	\N	30540305	Mwanabuta	\N	5	142248
144707	\N	\N	\N	\N	30540306	Pokoso	\N	5	142248
144708	\N	\N	\N	\N	30540307	Swa-Ibanda	\N	5	142248
144709	\N	\N	\N	\N	30540308	Swa-Ikomba	\N	5	142248
144710	\N	\N	\N	\N	30540401	Mbangi	\N	5	142249
144711	\N	\N	\N	\N	30540402	Kabaka(Ipangi Buka)	\N	5	142249
144712	\N	\N	\N	\N	30540403	Mubuku	\N	5	142249
144713	\N	\N	\N	\N	30540404	Mulopo(Ndindi)	\N	5	142249
144714	\N	\N	\N	\N	30540405	Muluwa	\N	5	142249
144715	\N	\N	\N	\N	30540406	Mwaka Yala	\N	5	142249
144716	\N	\N	\N	\N	30540407	Tshiaku	\N	5	142249
144717	\N	\N	\N	\N	30540501	Bukakalau	\N	5	142250
144718	\N	\N	\N	\N	30540502	Kiama	\N	5	142250
144719	\N	\N	\N	\N	30540503	Kibunda	\N	5	142250
144720	\N	\N	\N	\N	30540504	Manzegele	\N	5	142250
144721	\N	\N	\N	\N	30540505	Mwana-Mutome	\N	5	142250
144722	\N	\N	\N	\N	30540506	Tambu-Seki	\N	5	142250
144723	\N	\N	\N	\N	30540601	kabemba	\N	5	142251
144724	\N	\N	\N	\N	30540602	Kambundi	\N	5	142251
144725	\N	\N	\N	\N	30540603	Kasandji	\N	5	142251
144726	\N	\N	\N	\N	30540604	Kazungu	\N	5	142251
144727	\N	\N	\N	\N	30540605	Kibunda	\N	5	142251
144728	\N	\N	\N	\N	30540606	Mazinga	\N	5	142251
144729	\N	\N	\N	\N	30540607	Panzi	\N	5	142251
144730	\N	\N	\N	\N	30540701	Kasa	\N	5	142252
144731	\N	\N	\N	\N	30540801	Baringa	\N	5	142253
144732	\N	\N	\N	\N	30540802	Kikoso	\N	5	142253
144733	\N	\N	\N	\N	30540803	Mukumbi	\N	5	142253
144734	\N	\N	\N	\N	30540804	Muniungulu	\N	5	142253
144735	\N	\N	\N	\N	30540805	Pelende	\N	5	142253
144736	\N	\N	\N	\N	30545101	Kababa	\N	5	142254
144737	\N	\N	\N	\N	30545102	Kasanga	\N	5	142254
144738	\N	\N	\N	\N	30545103	Mobutu	\N	5	142254
144739	\N	\N	\N	\N	30545104	Ntemo	\N	5	142254
144740	\N	\N	\N	\N	30545105	Nzaki-Mweka	\N	5	142254
144741	\N	\N	\N	\N	30545107	Mobutu	\N	5	142254
144742	\N	\N	\N	\N	30545108	Munikenge	\N	5	142254
144743	\N	\N	\N	\N	30550101	Ikomba	\N	5	142255
144744	\N	\N	\N	\N	30550102	Imwela	\N	5	142255
144745	\N	\N	\N	\N	30550103	Itenga	\N	5	142255
144746	\N	\N	\N	\N	30550104	Kabaka	\N	5	142255
144747	\N	\N	\N	\N	30550105	Kangu	\N	5	142255
144748	\N	\N	\N	\N	30550106	Kiamfu-Kinzadi	\N	5	142255
144749	\N	\N	\N	\N	30550107	Mbulu-Tshiala	\N	5	142255
144750	\N	\N	\N	\N	30550108	Monene-Tseke	\N	5	142255
144751	\N	\N	\N	\N	30550109	Munene	\N	5	142255
144752	\N	\N	\N	\N	30550110	Inzofo	\N	5	142255
144753	\N	\N	\N	\N	30550201	Popokabaka	\N	5	142256
144754	\N	\N	\N	\N	30550202	Ilwanda	\N	5	142256
144755	\N	\N	\N	\N	30550203	Kamama	\N	5	142256
144756	\N	\N	\N	\N	30550204	Katoko	\N	5	142256
144757	\N	\N	\N	\N	30550205	Kobi-Mayo	\N	5	142256
144758	\N	\N	\N	\N	30550206	Lusanga	\N	5	142256
144759	\N	\N	\N	\N	30550207	Ngowa	\N	5	142256
144760	\N	\N	\N	\N	30550301	Kabeya-Ilunga	\N	5	142257
144761	\N	\N	\N	\N	30550302	Kiala-Baka	\N	5	142257
144762	\N	\N	\N	\N	30550303	Kisindji	\N	5	142257
144763	\N	\N	\N	\N	30550304	Malambo	\N	5	142257
144764	\N	\N	\N	\N	30550305	Mbonde-Mfumu	\N	5	142257
144765	\N	\N	\N	\N	30550306	Mukukulu	\N	5	142257
144766	\N	\N	\N	\N	30550307	Ziwulu	\N	5	142257
144767	\N	\N	\N	\N	40110001	Bombwanza	\N	5	142259
144768	\N	\N	\N	\N	40110002	Boliba	\N	5	142259
144769	\N	\N	\N	\N	40110003	Bonsole	\N	5	142259
144770	\N	\N	\N	\N	40110004	Salongo	\N	5	142259
144771	\N	\N	\N	\N	40110005	Mokonzo	\N	5	142259
144772	\N	\N	\N	\N	40110006	Mompembe	\N	5	142259
144773	\N	\N	\N	\N	40110007	Masikita	\N	5	142259
144774	\N	\N	\N	\N	40110008	Ituri	\N	5	142259
144775	\N	\N	\N	\N	40110009	Longomba	\N	5	142259
144776	\N	\N	\N	\N	40110010	Ekunde	\N	5	142259
144777	\N	\N	\N	\N	40110011	Bongonzo	\N	5	142259
144778	\N	\N	\N	\N	40110012	Iyonda	\N	5	142259
144779	\N	\N	\N	\N	40110013	Wendji	\N	5	142259
144780	\N	\N	\N	\N	40110014	Ikengo	\N	5	142259
144781	\N	\N	\N	\N	40110015	Bongonde	\N	5	142259
144782	\N	\N	\N	\N	40110016	Hors Milieu Coutumier	\N	5	142259
144783	\N	\N	\N	\N	40120001	Mambenga	\N	5	142260
144784	\N	\N	\N	\N	40120002	Ruki	\N	5	142260
144785	\N	\N	\N	\N	40120003	Air-ZaÃ¯re	\N	5	142260
144786	\N	\N	\N	\N	40210101	Buya	\N	5	142261
144787	\N	\N	\N	\N	40210102	Boendo	\N	5	142261
144788	\N	\N	\N	\N	40210103	Bokenda	\N	5	142261
144789	\N	\N	\N	\N	40210104	Bolima 1	\N	5	142261
144790	\N	\N	\N	\N	40210105	Bolima 2	\N	5	142261
144791	\N	\N	\N	\N	40210106	Boeke	\N	5	142261
144792	\N	\N	\N	\N	40210107	Boyela	\N	5	142261
144793	\N	\N	\N	\N	40210108	Elinga	\N	5	142261
144794	\N	\N	\N	\N	40210109	Lifumba	\N	5	142261
144795	\N	\N	\N	\N	40210110	Lolungu	\N	5	142261
144796	\N	\N	\N	\N	40210111	Monzondjo 1	\N	5	142261
144797	\N	\N	\N	\N	40210112	Monzondjo 2	\N	5	142261
144798	\N	\N	\N	\N	40210113	Ntomba	\N	5	142261
144799	\N	\N	\N	\N	40210114	Waka	\N	5	142261
144800	\N	\N	\N	\N	40210115	Wala	\N	5	142261
144801	\N	\N	\N	\N	40210116	Ntomba	\N	5	142261
144802	\N	\N	\N	\N	40210117	Boende	\N	5	142261
144803	\N	\N	\N	\N	40210201	Bokakata	\N	5	142262
144804	\N	\N	\N	\N	40210202	Bomate	\N	5	142262
144805	\N	\N	\N	\N	40210203	Bongilima	\N	5	142262
144806	\N	\N	\N	\N	40210204	Ekombe	\N	5	142262
144807	\N	\N	\N	\N	40210205	Ekoto	\N	5	142262
144808	\N	\N	\N	\N	40210206	Lifumba 2	\N	5	142262
144809	\N	\N	\N	\N	40210207	Lilangi 1	\N	5	142262
144810	\N	\N	\N	\N	40210208	Lilangi 2	\N	5	142262
144811	\N	\N	\N	\N	40210209	Lisafa	\N	5	142262
144812	\N	\N	\N	\N	40210210	Songo	\N	5	142262
144813	\N	\N	\N	\N	40210211	Ekombe	\N	5	142262
144814	\N	\N	\N	\N	40210212	Lokokoloko	\N	5	142262
144815	\N	\N	\N	\N	40210213	Lilangi	\N	5	142262
144816	\N	\N	\N	\N	40210301	Bobambo	\N	5	142263
144817	\N	\N	\N	\N	40210302	Bobende-Mwera	\N	5	142263
144818	\N	\N	\N	\N	40210303	Boso-Djombo	\N	5	142263
144819	\N	\N	\N	\N	40210304	Boso-Djanongo 2	\N	5	142263
144820	\N	\N	\N	\N	40210305	Boso-Gba	\N	5	142263
144821	\N	\N	\N	\N	40210306	Boso-Ngumu	\N	5	142263
144822	\N	\N	\N	\N	40210307	Bosongo	\N	5	142263
144823	\N	\N	\N	\N	40210308	Boso-Ngombo	\N	5	142263
144824	\N	\N	\N	\N	40210309	Ebongo-Bulu	\N	5	142263
144825	\N	\N	\N	\N	40210310	Ebongo-Libia	\N	5	142263
144826	\N	\N	\N	\N	40210311	Kodoro	\N	5	142263
144827	\N	\N	\N	\N	40210312	Ngumu	\N	5	142263
144828	\N	\N	\N	\N	40210313	Poma	\N	5	142263
144829	\N	\N	\N	\N	40210314	Poo	\N	5	142263
144830	\N	\N	\N	\N	40215101	CitÃ© Basankusu	\N	5	142264
144831	\N	\N	\N	\N	40220101	Isay	\N	5	142265
144832	\N	\N	\N	\N	40220102	Mbemba	\N	5	142265
144833	\N	\N	\N	\N	40220103	Ngambeli 1	\N	5	142265
144834	\N	\N	\N	\N	40220104	Ngambeli 2	\N	5	142265
144835	\N	\N	\N	\N	40220105	Nguma	\N	5	142265
144836	\N	\N	\N	\N	40220201	Bolombo-Mongo	\N	5	142266
144837	\N	\N	\N	\N	40220202	Eleku	\N	5	142266
144838	\N	\N	\N	\N	40220203	Bozenga	\N	5	142266
144839	\N	\N	\N	\N	40220301	Bolombo	\N	5	142267
144840	\N	\N	\N	\N	40220302	Bomenge	\N	5	142267
144841	\N	\N	\N	\N	40220303	Kombo	\N	5	142267
144842	\N	\N	\N	\N	40220304	Mondjale Elombe	\N	5	142267
144843	\N	\N	\N	\N	40220305	Mondjale Mondjoi	\N	5	142267
144844	\N	\N	\N	\N	40220306	Mwera-Kutu	\N	5	142267
144845	\N	\N	\N	\N	40220307	Mwera-Sabando	\N	5	142267
144846	\N	\N	\N	\N	40220308	Monyanga	\N	5	142267
144847	\N	\N	\N	\N	40220309	Hors Milieu Coutumier	\N	5	142267
144848	\N	\N	\N	\N	40220401	Waola	\N	5	142268
144849	\N	\N	\N	\N	40220402	Bolenge	\N	5	142268
144850	\N	\N	\N	\N	40220403	Bongandanga	\N	5	142268
144851	\N	\N	\N	\N	40220404	Ikengo	\N	5	142268
144852	\N	\N	\N	\N	40220405	Mongo	\N	5	142268
144853	\N	\N	\N	\N	40220406	Eleku	\N	5	142268
144854	\N	\N	\N	\N	40220407	Hors Milieu Coutumier	\N	5	142268
144855	\N	\N	\N	\N	40220501	Bokala	\N	5	142269
144856	\N	\N	\N	\N	40220502	Bonyanga	\N	5	142269
144857	\N	\N	\N	\N	40220503	Lingoy	\N	5	142269
144858	\N	\N	\N	\N	40220504	Mpombo	\N	5	142269
144859	\N	\N	\N	\N	40230101	Bakaala	\N	5	142271
144860	\N	\N	\N	\N	40230102	Beloko	\N	5	142271
144861	\N	\N	\N	\N	40230103	Bombwanza	\N	5	142271
144862	\N	\N	\N	\N	40230104	Bongale	\N	5	142271
144863	\N	\N	\N	\N	40230105	Elinga Nkundo	\N	5	142271
144864	\N	\N	\N	\N	40230106	Lifumba Nkundo	\N	5	142271
144865	\N	\N	\N	\N	40230107	Lifumba Batswa	\N	5	142271
144866	\N	\N	\N	\N	40230108	Beloko Batswa	\N	5	142271
144867	\N	\N	\N	\N	40230109	Bongale Batswa	\N	5	142271
144868	\N	\N	\N	\N	40230110	Elinga Batswa	\N	5	142271
144869	\N	\N	\N	\N	40230201	Bomboma	\N	5	142272
144870	\N	\N	\N	\N	40230202	Bongili Nkundo	\N	5	142272
144871	\N	\N	\N	\N	40230203	Iyonda Nkundo	\N	5	142272
144872	\N	\N	\N	\N	40230204	Bonkoso Nkundo	\N	5	142272
144873	\N	\N	\N	\N	40230205	Wangata Nkundo	\N	5	142272
144874	\N	\N	\N	\N	40230206	Wangata Batswa	\N	5	142272
144875	\N	\N	\N	\N	40230207	Bongili Batswa	\N	5	142272
144876	\N	\N	\N	\N	40230208	Bonkoso-Batswa	\N	5	142272
144993	\N	\N	\N	\N	40310412	Mpandu	\N	5	142293
144877	\N	\N	\N	\N	40230209	Bombomba Batswa	\N	5	142272
144878	\N	\N	\N	\N	40230210	Iyonda Batswa	\N	5	142272
144879	\N	\N	\N	\N	40230301	Besombo-Nkundo	\N	5	142273
144880	\N	\N	\N	\N	40230302	Boangi-Nkundo	\N	5	142273
144881	\N	\N	\N	\N	40230303	Booya-Nkundo	\N	5	142273
144882	\N	\N	\N	\N	40230304	Indjolu-Nkundo	\N	5	142273
144883	\N	\N	\N	\N	40230305	Booya-Batswa	\N	5	142273
144884	\N	\N	\N	\N	40230306	Boangi-Batswa	\N	5	142273
144885	\N	\N	\N	\N	40230307	Indjolu Batswa	\N	5	142273
144886	\N	\N	\N	\N	40240101	Besongo 1	\N	5	142275
144887	\N	\N	\N	\N	40240102	Besongo 2	\N	5	142275
144888	\N	\N	\N	\N	40240103	Bonginda	\N	5	142275
144889	\N	\N	\N	\N	40240104	Bonsende	\N	5	142275
144890	\N	\N	\N	\N	40240105	Bosanga-Ntomba	\N	5	142275
144891	\N	\N	\N	\N	40240106	Botuali	\N	5	142275
144892	\N	\N	\N	\N	40240107	Lokongo	\N	5	142275
144893	\N	\N	\N	\N	40240108	Ntomba-Nkole	\N	5	142275
144894	\N	\N	\N	\N	40240109	Batswa	\N	5	142275
144895	\N	\N	\N	\N	40240201	Bofidji-Est	\N	5	142276
144896	\N	\N	\N	\N	40240202	Bofidji-Ouest	\N	5	142276
144897	\N	\N	\N	\N	40240203	Indjolo	\N	5	142276
144898	\N	\N	\N	\N	40240204	Hors Milieu Coutumier	\N	5	142276
144899	\N	\N	\N	\N	40240301	Bokengia Baina	\N	5	142277
144900	\N	\N	\N	\N	40240302	Bosanga	\N	5	142277
144901	\N	\N	\N	\N	40240303	Ilokwampela	\N	5	142277
144902	\N	\N	\N	\N	40240304	Loonda	\N	5	142277
144903	\N	\N	\N	\N	40240305	Baringo	\N	5	142277
144904	\N	\N	\N	\N	40240306	Yoloyeleko	\N	5	142277
144905	\N	\N	\N	\N	40240307	Businga	\N	5	142277
144906	\N	\N	\N	\N	40240308	Hors Milieu Coutumier	\N	5	142277
144907	\N	\N	\N	\N	40250101	Banunu	\N	5	142279
144908	\N	\N	\N	\N	40250201	Mpama	\N	5	142280
144909	\N	\N	\N	\N	40250202	Tafutuma	\N	5	142280
144910	\N	\N	\N	\N	40250203	Tayoka	\N	5	142280
144911	\N	\N	\N	\N	40250204	Mbongi	\N	5	142280
144912	\N	\N	\N	\N	40250205	Lusakani	\N	5	142280
144913	\N	\N	\N	\N	40250301	Lusakania	\N	5	142281
144914	\N	\N	\N	\N	40250302	Ngele	\N	5	142281
144915	\N	\N	\N	\N	40250303	Hors Milieu Coutumier	\N	5	142281
144916	\N	\N	\N	\N	40260101	Boboka	\N	5	142283
144917	\N	\N	\N	\N	40260102	Bolombo	\N	5	142283
144918	\N	\N	\N	\N	40260103	Emateloa	\N	5	142283
144919	\N	\N	\N	\N	40260104	Ndobo	\N	5	142283
144920	\N	\N	\N	\N	40260201	Bonkula	\N	5	142284
144921	\N	\N	\N	\N	40260202	Bozinga	\N	5	142284
144922	\N	\N	\N	\N	40260203	Mabembe	\N	5	142284
144923	\N	\N	\N	\N	40260204	Makanza	\N	5	142284
144924	\N	\N	\N	\N	40260301	Lusengo	\N	5	142285
144925	\N	\N	\N	\N	40260302	Malunza	\N	5	142285
144926	\N	\N	\N	\N	40260303	Mobeka	\N	5	142285
144927	\N	\N	\N	\N	40270101	Bengenga	\N	5	142287
144928	\N	\N	\N	\N	40270102	Bikunda	\N	5	142287
144929	\N	\N	\N	\N	40270103	Bubangi	\N	5	142287
144930	\N	\N	\N	\N	40270104	Bobenga	\N	5	142287
144931	\N	\N	\N	\N	40270105	Bonkembe	\N	5	142287
144932	\N	\N	\N	\N	40270106	Bomana	\N	5	142287
144933	\N	\N	\N	\N	40270107	Bonkene	\N	5	142287
144934	\N	\N	\N	\N	40270108	Bosesela	\N	5	142287
144935	\N	\N	\N	\N	40270109	Libele	\N	5	142287
144936	\N	\N	\N	\N	40270110	Libinza	\N	5	142287
144937	\N	\N	\N	\N	40270111	Limania	\N	5	142287
144938	\N	\N	\N	\N	40270112	Mampoko	\N	5	142287
144939	\N	\N	\N	\N	40270113	Mabembe	\N	5	142287
144940	\N	\N	\N	\N	40270114	Lusengo	\N	5	142287
144941	\N	\N	\N	\N	40270115	Malunza	\N	5	142287
144942	\N	\N	\N	\N	40270116	Mobeka	\N	5	142287
144943	\N	\N	\N	\N	40270117	Bozinga	\N	5	142287
144944	\N	\N	\N	\N	40270118	VII	\N	5	142287
144945	\N	\N	\N	\N	40270119	Moboka	\N	5	142287
144946	\N	\N	\N	\N	40270120	Bolondo	\N	5	142287
144947	\N	\N	\N	\N	40270121	Mobena	\N	5	142287
144948	\N	\N	\N	\N	40270201	Busira	\N	5	142288
144949	\N	\N	\N	\N	40270202	Bonsambi 2	\N	5	142288
144950	\N	\N	\N	\N	40270203	Likoka	\N	5	142288
144951	\N	\N	\N	\N	40270204	Lobala 1	\N	5	142288
144952	\N	\N	\N	\N	40270205	Lobala 2	\N	5	142288
144953	\N	\N	\N	\N	40270206	Lobala 3	\N	5	142288
144954	\N	\N	\N	\N	40270207	Makutu	\N	5	142288
144955	\N	\N	\N	\N	40270208	Mamba (Mbangisa)	\N	5	142288
144956	\N	\N	\N	\N	40270209	Sikoro	\N	5	142288
144957	\N	\N	\N	\N	40310101	Bodingia-Sembadigi	\N	5	142290
144958	\N	\N	\N	\N	40310102	Bodumbili	\N	5	142290
144959	\N	\N	\N	\N	40310103	Bogbakudu	\N	5	142290
144960	\N	\N	\N	\N	40310104	Bogoro	\N	5	142290
144961	\N	\N	\N	\N	40310105	Bomadea	\N	5	142290
144962	\N	\N	\N	\N	40310106	Bombia-Mwangbia	\N	5	142290
144963	\N	\N	\N	\N	40310107	Bombia-Wegbena	\N	5	142290
144964	\N	\N	\N	\N	40310108	Furu-Bobalia	\N	5	142290
144965	\N	\N	\N	\N	40310109	Boyele-Bogbamele	\N	5	142290
144966	\N	\N	\N	\N	40310110	Boyele-Bomani	\N	5	142290
144967	\N	\N	\N	\N	40310111	Lingo-Tebe	\N	5	142290
144968	\N	\N	\N	\N	40310112	Ngimi	\N	5	142290
144969	\N	\N	\N	\N	40310201	Bagase	\N	5	142291
144970	\N	\N	\N	\N	40310202	Bambwa	\N	5	142291
144971	\N	\N	\N	\N	40310203	Bokomwa	\N	5	142291
144972	\N	\N	\N	\N	40310204	Bosebwanga	\N	5	142291
144973	\N	\N	\N	\N	40310205	Botela	\N	5	142291
144974	\N	\N	\N	\N	40310301	Bobanga	\N	5	142292
144975	\N	\N	\N	\N	40310302	Bobasonga	\N	5	142292
144976	\N	\N	\N	\N	40310303	Bobulunggba	\N	5	142292
144977	\N	\N	\N	\N	40310304	Bodigia	\N	5	142292
144978	\N	\N	\N	\N	40310305	Bodotoa	\N	5	142292
144979	\N	\N	\N	\N	40310306	Bokode	\N	5	142292
144980	\N	\N	\N	\N	40310307	Bombakutu	\N	5	142292
144981	\N	\N	\N	\N	40310308	BongoBakengese-Bokada	\N	5	142292
144982	\N	\N	\N	\N	40310401	Bakenge	\N	5	142293
144983	\N	\N	\N	\N	40310402	Bambakabe	\N	5	142293
144984	\N	\N	\N	\N	40310403	Bobito	\N	5	142293
144985	\N	\N	\N	\N	40310404	Bukanzi	\N	5	142293
144986	\N	\N	\N	\N	40310405	Bokode	\N	5	142293
144987	\N	\N	\N	\N	40310406	Bokuda	\N	5	142293
144988	\N	\N	\N	\N	40310407	Bombawili	\N	5	142293
144989	\N	\N	\N	\N	40310408	Bominenge	\N	5	142293
144990	\N	\N	\N	\N	40310409	Boyambi	\N	5	142293
144991	\N	\N	\N	\N	40310410	Damia	\N	5	142293
144992	\N	\N	\N	\N	40310411	Kalanda	\N	5	142293
144994	\N	\N	\N	\N	40310413	Ngbanguma	\N	5	142293
144995	\N	\N	\N	\N	40310414	Ngbubulu	\N	5	142293
144996	\N	\N	\N	\N	40315101	Ngombe Sukia	\N	5	142294
144997	\N	\N	\N	\N	40315102	Ngbandi Sukia	\N	5	142294
144998	\N	\N	\N	\N	40315103	Mbanza Sekpili	\N	5	142294
144999	\N	\N	\N	\N	40315104	Okangakolo-Kunda	\N	5	142294
145000	\N	\N	\N	\N	40315105	ArabisÃ©	\N	5	142294
145001	\N	\N	\N	\N	40315106	Gemena 2	\N	5	142294
145002	\N	\N	\N	\N	40315107	Ngbaka	\N	5	142294
145003	\N	\N	\N	\N	40315108	Gens D'Eau	\N	5	142294
145004	\N	\N	\N	\N	40315109	Salongo	\N	5	142294
145005	\N	\N	\N	\N	40315110	Du ZaÃ¯re	\N	5	142294
145006	\N	\N	\N	\N	40320101	Banga	\N	5	142295
145007	\N	\N	\N	\N	40320102	Bokala	\N	5	142295
145008	\N	\N	\N	\N	40320103	Bokondo	\N	5	142295
145009	\N	\N	\N	\N	40320104	Bombati	\N	5	142295
145010	\N	\N	\N	\N	40320105	Bosanga	\N	5	142295
145011	\N	\N	\N	\N	40320106	Bosimba	\N	5	142295
145012	\N	\N	\N	\N	40320107	Boso-Melo	\N	5	142295
145013	\N	\N	\N	\N	40320108	Boso-Kupe	\N	5	142295
145014	\N	\N	\N	\N	40320109	Engbunda	\N	5	142295
145015	\N	\N	\N	\N	40320110	Likula	\N	5	142295
145016	\N	\N	\N	\N	40320111	Likaw	\N	5	142295
145017	\N	\N	\N	\N	40320112	Liponga	\N	5	142295
145018	\N	\N	\N	\N	40320113	Lisombo	\N	5	142295
145019	\N	\N	\N	\N	40320114	Monyongo	\N	5	142295
145020	\N	\N	\N	\N	40320115	Mosange	\N	5	142295
145021	\N	\N	\N	\N	40320116	Ngondo	\N	5	142295
145022	\N	\N	\N	\N	40320117	Saw	\N	5	142295
145023	\N	\N	\N	\N	40320118	Tando	\N	5	142295
145024	\N	\N	\N	\N	40320201	Balaw	\N	5	142296
145025	\N	\N	\N	\N	40320202	Banza-Est	\N	5	142296
145026	\N	\N	\N	\N	40320203	Bokalakiti	\N	5	142296
145027	\N	\N	\N	\N	40320204	Bomele	\N	5	142296
145028	\N	\N	\N	\N	40320205	B/Mongwandi	\N	5	142296
145029	\N	\N	\N	\N	40320206	Gwapara	\N	5	142296
145030	\N	\N	\N	\N	40320207	Lida	\N	5	142296
145031	\N	\N	\N	\N	40320208	Kengele	\N	5	142296
145032	\N	\N	\N	\N	40320209	Kutu	\N	5	142296
145033	\N	\N	\N	\N	40320210	Mbwa-Djiba	\N	5	142296
145034	\N	\N	\N	\N	40320211	Mozeba	\N	5	142296
145035	\N	\N	\N	\N	40320212	Mussa	\N	5	142296
145036	\N	\N	\N	\N	40320213	Ngbanda	\N	5	142296
145037	\N	\N	\N	\N	40320214	Nguluma	\N	5	142296
145038	\N	\N	\N	\N	40320215	Nzeka	\N	5	142296
145039	\N	\N	\N	\N	40320216	Taliba	\N	5	142296
145040	\N	\N	\N	\N	40320217	Taozambe	\N	5	142296
145041	\N	\N	\N	\N	40320218	Toyo	\N	5	142296
145042	\N	\N	\N	\N	40320219	Yakamba	\N	5	142296
145043	\N	\N	\N	\N	40320301	Banza	\N	5	142297
145044	\N	\N	\N	\N	40320302	Boemili	\N	5	142297
145045	\N	\N	\N	\N	40320303	Damia	\N	5	142297
145046	\N	\N	\N	\N	40320304	Gbele	\N	5	142297
145047	\N	\N	\N	\N	40320305	Gbodu	\N	5	142297
145048	\N	\N	\N	\N	40320306	Lengo	\N	5	142297
145049	\N	\N	\N	\N	40320307	Libanza	\N	5	142297
145050	\N	\N	\N	\N	40320308	Kutsu	\N	5	142297
145051	\N	\N	\N	\N	40320309	Maki	\N	5	142297
145052	\N	\N	\N	\N	40320310	Mbulu	\N	5	142297
145053	\N	\N	\N	\N	40320311	Mozo 1	\N	5	142297
145054	\N	\N	\N	\N	40320312	Mwate	\N	5	142297
145055	\N	\N	\N	\N	40320401	xx Gombe Doko	\N	5	142298
145056	\N	\N	\N	\N	40320501	Gbandaki	\N	5	142299
145057	\N	\N	\N	\N	40320502	Karagba	\N	5	142299
145058	\N	\N	\N	\N	40320503	Kuma-Gwi	\N	5	142299
145059	\N	\N	\N	\N	40320504	Makuba	\N	5	142299
145060	\N	\N	\N	\N	40320505	Mbaya	\N	5	142299
145061	\N	\N	\N	\N	40320506	Mbonga-Mbake	\N	5	142299
145062	\N	\N	\N	\N	40320507	Mbongo-Boto	\N	5	142299
145063	\N	\N	\N	\N	40320508	Motembo	\N	5	142299
145064	\N	\N	\N	\N	40320509	Ngugu	\N	5	142299
145065	\N	\N	\N	\N	40320510	Puma	\N	5	142299
145066	\N	\N	\N	\N	40320511	Tabala-Gende	\N	5	142299
145067	\N	\N	\N	\N	40320512	Yanga-Gwaka	\N	5	142299
145068	\N	\N	\N	\N	40320601	xx Likimi	\N	5	142300
145069	\N	\N	\N	\N	40330101	Lobala-Peko	\N	5	142302
145070	\N	\N	\N	\N	40330102	Lobala-Tanda	\N	5	142302
145071	\N	\N	\N	\N	40330103	Mobala-Sud	\N	5	142302
145072	\N	\N	\N	\N	40330104	Momboli	\N	5	142302
145073	\N	\N	\N	\N	40330105	Monzombo	\N	5	142302
145074	\N	\N	\N	\N	40330106	Tanda-Kombe	\N	5	142302
145075	\N	\N	\N	\N	40330201	Bobandu-Fulu	\N	5	142303
145076	\N	\N	\N	\N	40330202	Bogbabondo	\N	5	142303
145077	\N	\N	\N	\N	40330203	Bombili-Bodigia	\N	5	142303
145078	\N	\N	\N	\N	40330204	Bomenenge-Boy	\N	5	142303
145079	\N	\N	\N	\N	40330205	Bozene	\N	5	142303
145080	\N	\N	\N	\N	40330206	Mbatyi-Bolo	\N	5	142303
145081	\N	\N	\N	\N	40330207	Molia	\N	5	142303
145082	\N	\N	\N	\N	40330208	Mombongo	\N	5	142303
145083	\N	\N	\N	\N	40330209	Mondonga	\N	5	142303
145084	\N	\N	\N	\N	40330210	Ngwagodo	\N	5	142303
145085	\N	\N	\N	\N	40330301	Banza-Balakpa	\N	5	142304
145086	\N	\N	\N	\N	40330302	Banza-Wolo	\N	5	142304
145087	\N	\N	\N	\N	40330303	Sendele	\N	5	142304
145088	\N	\N	\N	\N	40330304	Bogba	\N	5	142304
145089	\N	\N	\N	\N	40330305	Bomenge	\N	5	142304
145090	\N	\N	\N	\N	40330306	Boso-Ndongo	\N	5	142304
145091	\N	\N	\N	\N	40330307	Boso-Ngoso	\N	5	142304
145092	\N	\N	\N	\N	40330308	Gbeli	\N	5	142304
145093	\N	\N	\N	\N	40330309	Gulukolo	\N	5	142304
145094	\N	\N	\N	\N	40330310	Gunga	\N	5	142304
145095	\N	\N	\N	\N	40330311	Kungu	\N	5	142304
145096	\N	\N	\N	\N	40330312	Lingo	\N	5	142304
145097	\N	\N	\N	\N	40330313	Mbati-Wene	\N	5	142304
145098	\N	\N	\N	\N	40330314	Ngbanda	\N	5	142304
145099	\N	\N	\N	\N	40330315	Gbele	\N	5	142304
145100	\N	\N	\N	\N	40330401	Bokey	\N	5	142305
145101	\N	\N	\N	\N	40330402	Bokonzi	\N	5	142305
145102	\N	\N	\N	\N	40330403	Bomboma 1	\N	5	142305
145103	\N	\N	\N	\N	40330404	Bomboma 2	\N	5	142305
145104	\N	\N	\N	\N	40330405	Boso-Lite	\N	5	142305
145105	\N	\N	\N	\N	40330406	Boso-Makkbolengo	\N	5	142305
145106	\N	\N	\N	\N	40330407	Boso-Mbulu	\N	5	142305
145107	\N	\N	\N	\N	40330408	Boso-Mombenga	\N	5	142305
145108	\N	\N	\N	\N	40330409	Boso-Mondende	\N	5	142305
145109	\N	\N	\N	\N	40330410	Dingo-Ngandi	\N	5	142305
145110	\N	\N	\N	\N	40330411	Lingonda	\N	5	142305
145111	\N	\N	\N	\N	40330412	Lokombo	\N	5	142305
145112	\N	\N	\N	\N	40330413	Makengo	\N	5	142305
145113	\N	\N	\N	\N	40330414	Motuba	\N	5	142305
145114	\N	\N	\N	\N	40330415	Mumbele	\N	5	142305
145115	\N	\N	\N	\N	40330501	Bofolo	\N	5	142306
145116	\N	\N	\N	\N	40330502	Bondela	\N	5	142306
145117	\N	\N	\N	\N	40330503	Bondongo	\N	5	142306
145118	\N	\N	\N	\N	40330504	Bozaba	\N	5	142306
145119	\N	\N	\N	\N	40330505	Bwaku	\N	5	142306
145120	\N	\N	\N	\N	40330506	Ebuku	\N	5	142306
145121	\N	\N	\N	\N	40330507	Libobi	\N	5	142306
145122	\N	\N	\N	\N	40330508	Lifunga	\N	5	142306
145123	\N	\N	\N	\N	40330509	Likata	\N	5	142306
145124	\N	\N	\N	\N	40330510	limpoko	\N	5	142306
145125	\N	\N	\N	\N	40330511	Lokayi	\N	5	142306
145126	\N	\N	\N	\N	40330512	Lokutu	\N	5	142306
145127	\N	\N	\N	\N	40330513	Maboko	\N	5	142306
145128	\N	\N	\N	\N	40330514	Moliba	\N	5	142306
145129	\N	\N	\N	\N	40330515	Mondongo	\N	5	142306
145130	\N	\N	\N	\N	40330516	Munya	\N	5	142306
145131	\N	\N	\N	\N	40330517	Sombe	\N	5	142306
145132	\N	\N	\N	\N	40330518	Mounga	\N	5	142306
145133	\N	\N	\N	\N	40340101	Bwaka-Bondolo	\N	5	142308
145134	\N	\N	\N	\N	40340102	Bwaka-Vulisi	\N	5	142308
145135	\N	\N	\N	\N	40340103	Mbanza-Bango	\N	5	142308
145136	\N	\N	\N	\N	40340104	Mbanza-Busutu	\N	5	142308
145137	\N	\N	\N	\N	40340105	Mbanza-Lengo	\N	5	142308
145138	\N	\N	\N	\N	40340106	Mbati-Piko	\N	5	142308
145139	\N	\N	\N	\N	40340107	Monzombo	\N	5	142308
145140	\N	\N	\N	\N	40340108	Ngombe-Bau	\N	5	142308
145141	\N	\N	\N	\N	40340201	Lokolio	\N	5	142309
145142	\N	\N	\N	\N	40340202	Bokonga	\N	5	142309
145143	\N	\N	\N	\N	40340203	Bowase	\N	5	142309
145144	\N	\N	\N	\N	40340204	Kwala	\N	5	142309
145145	\N	\N	\N	\N	40340205	Mono-Kati	\N	5	142309
145146	\N	\N	\N	\N	40340206	Ngbaka-Mabo	\N	5	142309
145147	\N	\N	\N	\N	40340207	Ngbundu-Nord	\N	5	142309
145148	\N	\N	\N	\N	40340208	Ngbundu-sud	\N	5	142309
145149	\N	\N	\N	\N	40340209	Ngombe-Boswa	\N	5	142309
145150	\N	\N	\N	\N	40340210	Ngombe-Monengbe	\N	5	142309
145151	\N	\N	\N	\N	40340301	Bandi	\N	5	142310
145152	\N	\N	\N	\N	40340302	Bogon	\N	5	142310
145153	\N	\N	\N	\N	40340303	Mbanza	\N	5	142310
145154	\N	\N	\N	\N	40340304	Mono-Bwaka	\N	5	142310
145155	\N	\N	\N	\N	40340305	Mono-Galaba	\N	5	142310
145156	\N	\N	\N	\N	40340306	Mono-Kaga	\N	5	142310
145157	\N	\N	\N	\N	40340307	Ndzoma	\N	5	142310
145158	\N	\N	\N	\N	40410001	Mobay	\N	5	142312
145159	\N	\N	\N	\N	40410002	Mole	\N	5	142312
145160	\N	\N	\N	\N	40420001	Samba	\N	5	142313
145161	\N	\N	\N	\N	40420002	Kpeanga	\N	5	142313
145162	\N	\N	\N	\N	40510101	Bogonda	\N	5	142314
145163	\N	\N	\N	\N	40510102	Bukaku	\N	5	142314
145164	\N	\N	\N	\N	40510103	Gbado-Gbakete	\N	5	142314
145165	\N	\N	\N	\N	40510104	Gobele	\N	5	142314
145166	\N	\N	\N	\N	40510105	Fulu	\N	5	142314
145167	\N	\N	\N	\N	40510106	Kugbo	\N	5	142314
145168	\N	\N	\N	\N	40510107	Kokpua	\N	5	142314
145169	\N	\N	\N	\N	40510108	Maniko	\N	5	142314
145170	\N	\N	\N	\N	40510109	Mbanza-Fulo	\N	5	142314
145171	\N	\N	\N	\N	40510110	Mbanza-Vulu	\N	5	142314
145172	\N	\N	\N	\N	40510111	Mugbaka	\N	5	142314
145173	\N	\N	\N	\N	40510112	Mwanzi-Kiri	\N	5	142314
145174	\N	\N	\N	\N	40510113	Ngbanyo	\N	5	142314
145175	\N	\N	\N	\N	40510114	Basagba	\N	5	142314
145176	\N	\N	\N	\N	40510201	Bakpwa	\N	5	142315
145177	\N	\N	\N	\N	40510202	Basa	\N	5	142315
145178	\N	\N	\N	\N	40510203	Bindo	\N	5	142315
145179	\N	\N	\N	\N	40510204	Bondo	\N	5	142315
145180	\N	\N	\N	\N	40510205	Gbau	\N	5	142315
145181	\N	\N	\N	\N	40510206	Gbo-Gombe	\N	5	142315
145182	\N	\N	\N	\N	40510207	Gomu	\N	5	142315
145183	\N	\N	\N	\N	40510208	Kumbu	\N	5	142315
145184	\N	\N	\N	\N	40510209	Mune	\N	5	142315
145185	\N	\N	\N	\N	40510210	Ndekese	\N	5	142315
145186	\N	\N	\N	\N	40510211	Ngbanda	\N	5	142315
145187	\N	\N	\N	\N	40510212	Ngola	\N	5	142315
145188	\N	\N	\N	\N	40510213	Nzaka	\N	5	142315
145189	\N	\N	\N	\N	40510214	Vote	\N	5	142315
145190	\N	\N	\N	\N	40510215	Yake	\N	5	142315
145191	\N	\N	\N	\N	40510216	Ziamba	\N	5	142315
145192	\N	\N	\N	\N	40520101	Bobongo	\N	5	142317
145193	\N	\N	\N	\N	40520102	Bodunga	\N	5	142317
145194	\N	\N	\N	\N	40520103	Bandalangi	\N	5	142317
145195	\N	\N	\N	\N	40520104	Bwato	\N	5	142317
145196	\N	\N	\N	\N	40520105	Likwangola	\N	5	142317
145197	\N	\N	\N	\N	40520106	Mogbada	\N	5	142317
145198	\N	\N	\N	\N	40520107	Mogbamo	\N	5	142317
145199	\N	\N	\N	\N	40520108	Mogbale	\N	5	142317
145200	\N	\N	\N	\N	40520109	Mogugu	\N	5	142317
145201	\N	\N	\N	\N	40520110	Mombati	\N	5	142317
145202	\N	\N	\N	\N	40520111	Mondanga	\N	5	142317
145203	\N	\N	\N	\N	40520112	Mongende-Nord	\N	5	142317
145204	\N	\N	\N	\N	40520113	Mongende-Sud	\N	5	142317
145205	\N	\N	\N	\N	40520114	Mongwa	\N	5	142317
145206	\N	\N	\N	\N	40520115	Monzobo	\N	5	142317
145207	\N	\N	\N	\N	40520116	Pumbi	\N	5	142317
145208	\N	\N	\N	\N	40520201	Amasa	\N	5	142318
145209	\N	\N	\N	\N	40520202	Bira	\N	5	142318
145210	\N	\N	\N	\N	40520203	Gini	\N	5	142318
145211	\N	\N	\N	\N	40520204	Kando	\N	5	142318
145212	\N	\N	\N	\N	40520205	Lau-Est	\N	5	142318
145213	\N	\N	\N	\N	40520206	Lau-Ouest	\N	5	142318
145214	\N	\N	\N	\N	40520207	Ndalo	\N	5	142318
145215	\N	\N	\N	\N	40520208	Momba	\N	5	142318
145216	\N	\N	\N	\N	40520209	Mongu	\N	5	142318
145217	\N	\N	\N	\N	40520210	Ndayo	\N	5	142318
145218	\N	\N	\N	\N	40520211	Ngazamba	\N	5	142318
145219	\N	\N	\N	\N	40520212	Nzale	\N	5	142318
145220	\N	\N	\N	\N	40520301	Baya	\N	5	142319
145221	\N	\N	\N	\N	40520302	Gombele	\N	5	142319
145222	\N	\N	\N	\N	40520303	Lite-Bala	\N	5	142319
145223	\N	\N	\N	\N	40520304	Kashiu	\N	5	142319
145224	\N	\N	\N	\N	40520305	Mbongo	\N	5	142319
145225	\N	\N	\N	\N	40520306	Nzamba	\N	5	142319
145226	\N	\N	\N	\N	40530101	Bobadi	\N	5	142321
145227	\N	\N	\N	\N	40530102	Bobilisi	\N	5	142321
145228	\N	\N	\N	\N	40530103	Bodambule	\N	5	142321
145229	\N	\N	\N	\N	40530104	Budua	\N	5	142321
145230	\N	\N	\N	\N	40530105	Bokundu-B	\N	5	142321
145231	\N	\N	\N	\N	40530106	Karawa-Sud	\N	5	142321
145232	\N	\N	\N	\N	40530107	Bomele	\N	5	142321
145233	\N	\N	\N	\N	40530108	Bonudana	\N	5	142321
145234	\N	\N	\N	\N	40530109	Bozagba Boyame.	\N	5	142321
145235	\N	\N	\N	\N	40530110	Bulundue	\N	5	142321
145236	\N	\N	\N	\N	40530111	Andu Bogon	\N	5	142321
145237	\N	\N	\N	\N	40530112	Malika Bobandi	\N	5	142321
145238	\N	\N	\N	\N	40530113	Centre de Karawa	\N	5	142321
145239	\N	\N	\N	\N	40530201	Bobengo	\N	5	142322
145240	\N	\N	\N	\N	40530202	Bodangabo	\N	5	142322
145241	\N	\N	\N	\N	40530203	Bodetoa	\N	5	142322
145242	\N	\N	\N	\N	40530204	Bogeze	\N	5	142322
145243	\N	\N	\N	\N	40530205	Bokara 2	\N	5	142322
145244	\N	\N	\N	\N	40530206	Bokarawa	\N	5	142322
145245	\N	\N	\N	\N	40530207	Bongula	\N	5	142322
145246	\N	\N	\N	\N	40530208	Boya-Gbaswe	\N	5	142322
145247	\N	\N	\N	\N	40530209	Kele	\N	5	142322
145248	\N	\N	\N	\N	40530301	Ambuma	\N	5	142323
145249	\N	\N	\N	\N	40530302	Babalo	\N	5	142323
145250	\N	\N	\N	\N	40530303	Bobale	\N	5	142323
145251	\N	\N	\N	\N	40530304	Bobiti	\N	5	142323
145252	\N	\N	\N	\N	40530305	Bobudu	\N	5	142323
145253	\N	\N	\N	\N	40530306	Boboso	\N	5	142323
145254	\N	\N	\N	\N	40530307	Bogboin	\N	5	142323
145255	\N	\N	\N	\N	40530308	Bogbolu	\N	5	142323
145256	\N	\N	\N	\N	40530309	Bogoro	\N	5	142323
145257	\N	\N	\N	\N	40530310	Bokapo	\N	5	142323
145258	\N	\N	\N	\N	40530311	Bokosa	\N	5	142323
145259	\N	\N	\N	\N	40530312	Bokudu	\N	5	142323
145260	\N	\N	\N	\N	40530313	Bomongo	\N	5	142323
145261	\N	\N	\N	\N	40530314	Bondoy	\N	5	142323
145262	\N	\N	\N	\N	40530315	Bogonda	\N	5	142323
145263	\N	\N	\N	\N	40530316	Bopili	\N	5	142323
145264	\N	\N	\N	\N	40530317	Bosima	\N	5	142323
145265	\N	\N	\N	\N	40530318	Bozamo	\N	5	142323
145266	\N	\N	\N	\N	40530319	Mombati	\N	5	142323
145267	\N	\N	\N	\N	40530320	Mongwapele	\N	5	142323
145268	\N	\N	\N	\N	40530321	Monzamboli 1	\N	5	142323
145269	\N	\N	\N	\N	40530322	Monzwambo	\N	5	142323
145270	\N	\N	\N	\N	40530323	Yangbate	\N	5	142323
145271	\N	\N	\N	\N	40530324	Zakunda	\N	5	142323
145272	\N	\N	\N	\N	40535101	Mobutu	\N	5	142324
145273	\N	\N	\N	\N	40535102	Lumumba	\N	5	142324
145274	\N	\N	\N	\N	40535103	Lingo	\N	5	142324
145275	\N	\N	\N	\N	40535104	Anciens Combatants	\N	5	142324
145276	\N	\N	\N	\N	40535105	Bobozo	\N	5	142324
145277	\N	\N	\N	\N	40535106	Du Zaire	\N	5	142324
145278	\N	\N	\N	\N	40535107	Centre Urbain	\N	5	142324
145279	\N	\N	\N	\N	40540101	Bodeme	\N	5	142325
145280	\N	\N	\N	\N	40540102	Bokada	\N	5	142325
145281	\N	\N	\N	\N	40540103	Mbwi	\N	5	142325
145282	\N	\N	\N	\N	40540104	Mongo-Banz.	\N	5	142325
145283	\N	\N	\N	\N	40540105	Mono-Bilio	\N	5	142325
145284	\N	\N	\N	\N	40540106	Mono-Bubanda	\N	5	142325
145285	\N	\N	\N	\N	40540107	Ngombe-Mbanza	\N	5	142325
145286	\N	\N	\N	\N	40540108	Ngombe-Ngb.	\N	5	142325
145287	\N	\N	\N	\N	40540201	Botume	\N	5	142326
145288	\N	\N	\N	\N	40540202	Gobu-Mandu	\N	5	142326
145289	\N	\N	\N	\N	40540203	Sabo	\N	5	142326
145290	\N	\N	\N	\N	40540204	Sawa	\N	5	142326
145291	\N	\N	\N	\N	40540205	Togbo	\N	5	142326
145292	\N	\N	\N	\N	40540301	Badza-Kelo	\N	5	142327
145293	\N	\N	\N	\N	40540302	Bombe-Yakpa	\N	5	142327
145294	\N	\N	\N	\N	40540303	Fulu	\N	5	142327
145295	\N	\N	\N	\N	40540304	Fulu-Mbanza	\N	5	142327
145296	\N	\N	\N	\N	40540305	Mono-Bili	\N	5	142327
145297	\N	\N	\N	\N	40540306	Mono Kongo	\N	5	142327
145298	\N	\N	\N	\N	40540307	Mono-Wodjo	\N	5	142327
145299	\N	\N	\N	\N	40540308	Ngbagiri	\N	5	142327
145300	\N	\N	\N	\N	40540309	Ngbandi	\N	5	142327
145301	\N	\N	\N	\N	40610101	Akula-Nord	\N	5	142329
145302	\N	\N	\N	\N	40610102	Bokutu	\N	5	142329
145303	\N	\N	\N	\N	40610103	Bongopa	\N	5	142329
145304	\N	\N	\N	\N	40610104	Boso-Gbeku	\N	5	142329
145305	\N	\N	\N	\N	40610105	Boso-Mahuli	\N	5	142329
145306	\N	\N	\N	\N	40610106	Boso-Mane	\N	5	142329
145307	\N	\N	\N	\N	40610107	Boso-Mokulu	\N	5	142329
145308	\N	\N	\N	\N	40610108	Diobo	\N	5	142329
145309	\N	\N	\N	\N	40610109	Gwemba	\N	5	142329
145310	\N	\N	\N	\N	40610110	Gwzenzale	\N	5	142329
145311	\N	\N	\N	\N	40610111	Libona	\N	5	142329
145312	\N	\N	\N	\N	40610112	Mbata	\N	5	142329
145313	\N	\N	\N	\N	40610113	Mombangi	\N	5	142329
145314	\N	\N	\N	\N	40610114	Mondunga	\N	5	142329
145315	\N	\N	\N	\N	40610115	Boso-Ngumani	\N	5	142329
145316	\N	\N	\N	\N	40610116	Ikonongo	\N	5	142329
145317	\N	\N	\N	\N	40610201	Bobala	\N	5	142330
145318	\N	\N	\N	\N	40610202	Boby	\N	5	142330
145319	\N	\N	\N	\N	40610203	Bokula (Bokutu)	\N	5	142330
145320	\N	\N	\N	\N	40610204	Bolongo	\N	5	142330
145321	\N	\N	\N	\N	40610205	Mondingili	\N	5	142330
145322	\N	\N	\N	\N	40610206	Bongombo	\N	5	142330
145323	\N	\N	\N	\N	40610207	Bongenza	\N	5	142330
145324	\N	\N	\N	\N	40610208	Bopoto	\N	5	142330
145325	\N	\N	\N	\N	40610209	Bopuo	\N	5	142330
145326	\N	\N	\N	\N	40610210	Boso-Godu	\N	5	142330
145327	\N	\N	\N	\N	40610211	Bwela	\N	5	142330
145328	\N	\N	\N	\N	40610212	Ebongo-Mika	\N	5	142330
145329	\N	\N	\N	\N	40610213	Kalagba	\N	5	142330
145330	\N	\N	\N	\N	40610214	Mondungfa	\N	5	142330
145331	\N	\N	\N	\N	40610215	Ndeke	\N	5	142330
145332	\N	\N	\N	\N	40610216	Ngbele	\N	5	142330
145333	\N	\N	\N	\N	40610217	Umangi	\N	5	142330
145334	\N	\N	\N	\N	40610301	Bokopo	\N	5	142331
145335	\N	\N	\N	\N	40610302	Boso-Manzi	\N	5	142331
145336	\N	\N	\N	\N	40610303	Boso-Modjebo	\N	5	142331
145337	\N	\N	\N	\N	40610304	Gumba-Ebongo	\N	5	142331
145338	\N	\N	\N	\N	40610305	Gwanga	\N	5	142331
145339	\N	\N	\N	\N	40610306	Kwawa	\N	5	142331
145340	\N	\N	\N	\N	40610307	Moasa	\N	5	142331
145341	\N	\N	\N	\N	40610308	Mozomboli	\N	5	142331
145342	\N	\N	\N	\N	40610309	Ngonzi	\N	5	142331
145343	\N	\N	\N	\N	40610310	Bombia	\N	5	142331
145344	\N	\N	\N	\N	40610311	Moweya	\N	5	142331
145345	\N	\N	\N	\N	40610312	Bonguba-Mongili	\N	5	142331
145346	\N	\N	\N	\N	40615101	Kaba	\N	5	142332
145347	\N	\N	\N	\N	40615102	Ebabo	\N	5	142332
145348	\N	\N	\N	\N	40615103	3 Z	\N	5	142332
145349	\N	\N	\N	\N	40615104	PÃªcheurs	\N	5	142332
145350	\N	\N	\N	\N	40620101	Bopoto	\N	5	142333
145351	\N	\N	\N	\N	40620102	Likombe	\N	5	142333
145352	\N	\N	\N	\N	40620103	Monzoi	\N	5	142333
145353	\N	\N	\N	\N	40620104	Yalokolu	\N	5	142333
145354	\N	\N	\N	\N	40620105	Yambuli	\N	5	142333
145355	\N	\N	\N	\N	40620106	Yamikeli	\N	5	142333
145356	\N	\N	\N	\N	40620107	Yamisiko	\N	5	142333
145357	\N	\N	\N	\N	40620108	Yamolanga	\N	5	142333
145358	\N	\N	\N	\N	40620109	Yamongoi	\N	5	142333
145359	\N	\N	\N	\N	40620110	Yampaka	\N	5	142333
145360	\N	\N	\N	\N	40620111	Yaongera	\N	5	142333
145361	\N	\N	\N	\N	40620201	Bolupi	\N	5	142334
145362	\N	\N	\N	\N	40620202	Ndobo	\N	5	142334
145363	\N	\N	\N	\N	40620203	Yakombo	\N	5	142334
145364	\N	\N	\N	\N	40620204	Yalombo	\N	5	142334
145365	\N	\N	\N	\N	40620205	Yambao	\N	5	142334
145366	\N	\N	\N	\N	40620206	Yambenga	\N	5	142334
145367	\N	\N	\N	\N	40620207	Yamendo	\N	5	142334
145368	\N	\N	\N	\N	40620208	Yandjela	\N	5	142334
145369	\N	\N	\N	\N	40620209	Yangola	\N	5	142334
145370	\N	\N	\N	\N	40620210	Yatsonzo	\N	5	142334
145371	\N	\N	\N	\N	40620301	Bokoyi	\N	5	142335
145372	\N	\N	\N	\N	40620302	Boli-Nord	\N	5	142335
145373	\N	\N	\N	\N	40620303	Boli-Sud	\N	5	142335
145374	\N	\N	\N	\N	40620304	Gongo	\N	5	142335
145375	\N	\N	\N	\N	40620305	Yamandjika	\N	5	142335
145376	\N	\N	\N	\N	40620306	Yambata	\N	5	142335
145377	\N	\N	\N	\N	40620401	Angongo	\N	5	142336
145378	\N	\N	\N	\N	40620402	Auma	\N	5	142336
145379	\N	\N	\N	\N	40620403	Banzale	\N	5	142336
145380	\N	\N	\N	\N	40620404	Doko	\N	5	142336
145381	\N	\N	\N	\N	40620405	Bokoy	\N	5	142336
145382	\N	\N	\N	\N	40620406	Bozongi	\N	5	142336
145383	\N	\N	\N	\N	40620407	Mombongo	\N	5	142336
145384	\N	\N	\N	\N	40620408	Ndundusana	\N	5	142336
145385	\N	\N	\N	\N	40620409	Yalisika	\N	5	142336
145386	\N	\N	\N	\N	40620410	Yambila	\N	5	142336
145387	\N	\N	\N	\N	40620411	Yambuka	\N	5	142336
145388	\N	\N	\N	\N	40620501	Bopoto	\N	5	142337
145389	\N	\N	\N	\N	40620502	Budja	\N	5	142337
145390	\N	\N	\N	\N	40620503	Bosanga	\N	5	142337
145391	\N	\N	\N	\N	40620504	Mpunga	\N	5	142337
145392	\N	\N	\N	\N	40620505	Yaisinbi	\N	5	142337
145393	\N	\N	\N	\N	40620506	Yakoy	\N	5	142337
145394	\N	\N	\N	\N	40620507	Yambili	\N	5	142337
145395	\N	\N	\N	\N	40620508	Yandanda	\N	5	142337
145396	\N	\N	\N	\N	40620509	Yamongili	\N	5	142337
145397	\N	\N	\N	\N	40620510	Yahuma	\N	5	142337
145398	\N	\N	\N	\N	40620511	Yanzeka	\N	5	142337
145399	\N	\N	\N	\N	40620512	Yalasaka	\N	5	142337
145400	\N	\N	\N	\N	40620513	Botsoli ( Malekesa )	\N	5	142337
145401	\N	\N	\N	\N	40620601	Bokombe	\N	5	142338
145402	\N	\N	\N	\N	40620602	Bopandu	\N	5	142338
145403	\N	\N	\N	\N	40620603	Bowela-Bomengo	\N	5	142338
145404	\N	\N	\N	\N	40620604	Yaliambi	\N	5	142338
145405	\N	\N	\N	\N	40620605	Yalingimba	\N	5	142338
145406	\N	\N	\N	\N	40620606	Yamiongo	\N	5	142338
145407	\N	\N	\N	\N	40620607	Yamolota	\N	5	142338
145408	\N	\N	\N	\N	40620608	Woonda	\N	5	142338
145409	\N	\N	\N	\N	40630101	Bokatolaka	\N	5	142340
145410	\N	\N	\N	\N	40630102	Bombombo	\N	5	142340
145411	\N	\N	\N	\N	40630103	Bongbonga	\N	5	142340
145412	\N	\N	\N	\N	40630104	Bongombe	\N	5	142340
145413	\N	\N	\N	\N	40630105	Boso-Dole	\N	5	142340
145414	\N	\N	\N	\N	40630106	Boso-Efuta	\N	5	142340
145415	\N	\N	\N	\N	40630107	Boso Gbo-Gbo	\N	5	142340
145416	\N	\N	\N	\N	40630108	Boso-Mane	\N	5	142340
145417	\N	\N	\N	\N	40630109	Boso-Mboke	\N	5	142340
145418	\N	\N	\N	\N	40630110	Boso-Modanda	\N	5	142340
145419	\N	\N	\N	\N	40630111	Boso-Mongbula	\N	5	142340
145420	\N	\N	\N	\N	40630112	Boso-Nzongo	\N	5	142340
145421	\N	\N	\N	\N	40630113	Mbatsi	\N	5	142340
145422	\N	\N	\N	\N	40630114	Mosweya	\N	5	142340
145423	\N	\N	\N	\N	40630115	Mwenu	\N	5	142340
145424	\N	\N	\N	\N	40630116	Ndiko	\N	5	142340
145425	\N	\N	\N	\N	40630117	Ngwenzale	\N	5	142340
145426	\N	\N	\N	\N	40630118	Po	\N	5	142340
145427	\N	\N	\N	\N	40630119	Hors Milieu Coutumier	\N	5	142340
145428	\N	\N	\N	\N	40630201	Bobende	\N	5	142341
145429	\N	\N	\N	\N	40630202	Bobende-Rive	\N	5	142341
145430	\N	\N	\N	\N	40630203	Bombasi-Ikele	\N	5	142341
145431	\N	\N	\N	\N	40630204	Bombati-Rive	\N	5	142341
145432	\N	\N	\N	\N	40630205	Bombele-Ikele	\N	5	142341
145433	\N	\N	\N	\N	40630206	Bombele-Rive	\N	5	142341
145434	\N	\N	\N	\N	40630207	Bongbonga	\N	5	142341
145435	\N	\N	\N	\N	40630208	Boso-Likolo	\N	5	142341
145436	\N	\N	\N	\N	40630209	Boso-Lopori	\N	5	142341
145437	\N	\N	\N	\N	40630210	Boso-Kema	\N	5	142341
145438	\N	\N	\N	\N	40630211	Boswa-Nord	\N	5	142341
145439	\N	\N	\N	\N	40630212	Buza	\N	5	142341
145440	\N	\N	\N	\N	40630213	Enengo	\N	5	142341
145441	\N	\N	\N	\N	40630214	Heterogene	\N	5	142341
145442	\N	\N	\N	\N	40630215	Kodoro	\N	5	142341
145443	\N	\N	\N	\N	40630216	Likende	\N	5	142341
145444	\N	\N	\N	\N	40630217	Limboye	\N	5	142341
145445	\N	\N	\N	\N	40630218	Mowaka	\N	5	142341
145446	\N	\N	\N	\N	40630219	Boswa-Linkende	\N	5	142341
145447	\N	\N	\N	\N	40630220	Hors milieu Coutumier	\N	5	142341
145448	\N	\N	\N	\N	40630301	Baenga	\N	5	142342
145449	\N	\N	\N	\N	40630302	Bobambo	\N	5	142342
145450	\N	\N	\N	\N	40630303	Bodala	\N	5	142342
145451	\N	\N	\N	\N	40630304	Boonga	\N	5	142342
145452	\N	\N	\N	\N	40630305	Boso-Kuluki	\N	5	142342
145453	\N	\N	\N	\N	40630306	Doso	\N	5	142342
145454	\N	\N	\N	\N	40630307	Heterogene	\N	5	142342
145455	\N	\N	\N	\N	40630308	Kire	\N	5	142342
145456	\N	\N	\N	\N	40630309	Lingoy	\N	5	142342
145457	\N	\N	\N	\N	40630310	Liombo	\N	5	142342
145458	\N	\N	\N	\N	40630311	Lokalema	\N	5	142342
145459	\N	\N	\N	\N	40630312	Lofongo-Bolaka	\N	5	142342
145460	\N	\N	\N	\N	40630313	Lofongo-Kore	\N	5	142342
145461	\N	\N	\N	\N	40630314	Mbangi	\N	5	142342
145462	\N	\N	\N	\N	40630315	Mombeka	\N	5	142342
145463	\N	\N	\N	\N	40630316	Nseni	\N	5	142342
145464	\N	\N	\N	\N	40630317	Yakono	\N	5	142342
145465	\N	\N	\N	\N	40630318	Yaofanga	\N	5	142342
145466	\N	\N	\N	\N	40630319	Yayolo	\N	5	142342
145467	\N	\N	\N	\N	40630401	Baolongo	\N	5	142343
145468	\N	\N	\N	\N	40630402	Dikilo	\N	5	142343
145469	\N	\N	\N	\N	40630403	Bokenda 1	\N	5	142343
145470	\N	\N	\N	\N	40630404	Bokenda 2	\N	5	142343
145471	\N	\N	\N	\N	40630405	Bongandanga	\N	5	142343
145472	\N	\N	\N	\N	40630406	Ekombe	\N	5	142343
145473	\N	\N	\N	\N	40630407	Likaa	\N	5	142343
145474	\N	\N	\N	\N	40630408	Likote	\N	5	142343
145475	\N	\N	\N	\N	40630409	Lilangi	\N	5	142343
145476	\N	\N	\N	\N	40630410	Lolengi	\N	5	142343
145477	\N	\N	\N	\N	40630411	Looka	\N	5	142343
145478	\N	\N	\N	\N	40630412	Manga - Yaliko	\N	5	142343
145479	\N	\N	\N	\N	40630413	Mpokaongo	\N	5	142343
145480	\N	\N	\N	\N	40630414	Songomboyo	\N	5	142343
145481	\N	\N	\N	\N	40630415	Yanga-Yamba	\N	5	142343
145482	\N	\N	\N	\N	40630416	Mange Wana	\N	5	142343
145483	\N	\N	\N	\N	40630417	Limba	\N	5	142343
145484	\N	\N	\N	\N	40630418	Hors Milieu Coutumier	\N	5	142343
145485	\N	\N	\N	\N	40710101	Busanga	\N	5	142345
145486	\N	\N	\N	\N	40710102	Bolingo	\N	5	142345
145487	\N	\N	\N	\N	40710103	Efale	\N	5	142345
145488	\N	\N	\N	\N	40710104	Eleku-Longa	\N	5	142345
145489	\N	\N	\N	\N	40710105	Ilenge	\N	5	142345
145490	\N	\N	\N	\N	40710106	Isaka-Busira	\N	5	142345
145491	\N	\N	\N	\N	40710107	Iyenge	\N	5	142345
145492	\N	\N	\N	\N	40710108	Linkundu	\N	5	142345
145493	\N	\N	\N	\N	40710109	Losanga	\N	5	142345
145494	\N	\N	\N	\N	40710110	Mpoko	\N	5	142345
145495	\N	\N	\N	\N	40710111	Ngele	\N	5	142345
145496	\N	\N	\N	\N	40710112	Nkengo	\N	5	142345
145497	\N	\N	\N	\N	40710113	Nkondji-Luankamba	\N	5	142345
145498	\N	\N	\N	\N	40710201	Bokongo-Lokata	\N	5	142346
145499	\N	\N	\N	\N	40710202	Bolondo	\N	5	142346
145500	\N	\N	\N	\N	40710203	Bongaekotsi	\N	5	142346
145501	\N	\N	\N	\N	40710204	Bongaukuli	\N	5	142346
145502	\N	\N	\N	\N	40710205	Botende	\N	5	142346
145503	\N	\N	\N	\N	40710206	Boonde	\N	5	142346
145504	\N	\N	\N	\N	40710207	Djoo	\N	5	142346
145505	\N	\N	\N	\N	40710208	Ilombe-Bokele	\N	5	142346
145506	\N	\N	\N	\N	40710209	Imbo	\N	5	142346
145507	\N	\N	\N	\N	40710210	Luindje	\N	5	142346
145508	\N	\N	\N	\N	40710211	Ntomba-Bongo	\N	5	142346
145509	\N	\N	\N	\N	40710212	Ebamba-Bol.	\N	5	142346
145510	\N	\N	\N	\N	40710301	Baseke-Ntulu	\N	5	142347
145511	\N	\N	\N	\N	40710302	Bolemba	\N	5	142347
145512	\N	\N	\N	\N	40710303	Bosongote	\N	5	142347
145513	\N	\N	\N	\N	40710304	Mpombi	\N	5	142347
145514	\N	\N	\N	\N	40710305	Ntomba-Boanga	\N	5	142347
145515	\N	\N	\N	\N	40710306	Ntomba-Nkole	\N	5	142347
145516	\N	\N	\N	\N	40710307	Ntomb'Ekili	\N	5	142347
145517	\N	\N	\N	\N	40710308	Nsamba	\N	5	142347
145518	\N	\N	\N	\N	40710401	Boliangama	\N	5	142348
145519	\N	\N	\N	\N	40710402	Boono-Boene	\N	5	142348
145520	\N	\N	\N	\N	40710403	Ntsike	\N	5	142348
145521	\N	\N	\N	\N	40710404	Ngomb'Amuna	\N	5	142348
145522	\N	\N	\N	\N	40710405	Nkwe	\N	5	142348
145523	\N	\N	\N	\N	40710406	Nongelema	\N	5	142348
145524	\N	\N	\N	\N	40710407	Nongokwa	\N	5	142348
145525	\N	\N	\N	\N	40710408	Nongonongo	\N	5	142348
145526	\N	\N	\N	\N	40710409	Yongo-Booli	\N	5	142348
145527	\N	\N	\N	\N	40710410	Yongo-Yala	\N	5	142348
145528	\N	\N	\N	\N	40720101	Bareinga	\N	5	142350
145529	\N	\N	\N	\N	40720102	Boilinga	\N	5	142350
145530	\N	\N	\N	\N	40720103	Bolingo	\N	5	142350
145531	\N	\N	\N	\N	40720104	Bolongo	\N	5	142350
145532	\N	\N	\N	\N	40720105	Bomandja	\N	5	142350
145533	\N	\N	\N	\N	40720106	Eos'Aliko	\N	5	142350
145534	\N	\N	\N	\N	40720107	Eos'Eanse	\N	5	142350
145535	\N	\N	\N	\N	40720108	Esanga	\N	5	142350
145536	\N	\N	\N	\N	40720109	Imende-Boyela	\N	5	142350
145537	\N	\N	\N	\N	40720110	Iwoku	\N	5	142350
145538	\N	\N	\N	\N	40720111	Lifindo	\N	5	142350
145539	\N	\N	\N	\N	40720112	Lifumba	\N	5	142350
145540	\N	\N	\N	\N	40720113	Lileko	\N	5	142350
145541	\N	\N	\N	\N	40720114	Loolo	\N	5	142350
145542	\N	\N	\N	\N	40720115	Wamba-Liinza	\N	5	142350
145543	\N	\N	\N	\N	40720201	Boyela	\N	5	142351
145544	\N	\N	\N	\N	40720202	Loma	\N	5	142351
145545	\N	\N	\N	\N	40720203	Nsongo-Mboy	\N	5	142351
145546	\N	\N	\N	\N	40720301	Bolaka	\N	5	142352
145547	\N	\N	\N	\N	40720302	Bolemba	\N	5	142352
145548	\N	\N	\N	\N	40720303	Bokumbe-Lok	\N	5	142352
145549	\N	\N	\N	\N	40720304	Bomwankoy	\N	5	142352
145550	\N	\N	\N	\N	40720305	Ekalankoy	\N	5	142352
145551	\N	\N	\N	\N	40720306	Likunduamba	\N	5	142352
145552	\N	\N	\N	\N	40720307	Likongo	\N	5	142352
145553	\N	\N	\N	\N	40720308	Lombeolo	\N	5	142352
145554	\N	\N	\N	\N	40720309	Moma	\N	5	142352
145555	\N	\N	\N	\N	40720310	Mompono	\N	5	142352
145556	\N	\N	\N	\N	40720311	Yala	\N	5	142352
145557	\N	\N	\N	\N	40730101	Lingomo	\N	5	142354
145558	\N	\N	\N	\N	40730102	Nkole	\N	5	142354
145559	\N	\N	\N	\N	40730103	Yailala	\N	5	142354
145560	\N	\N	\N	\N	40730104	Yaloola	\N	5	142354
145561	\N	\N	\N	\N	40730105	Yolota	\N	5	142354
145562	\N	\N	\N	\N	40730201	Bofonge-Boma	\N	5	142355
145563	\N	\N	\N	\N	40730202	Bofongo 2	\N	5	142355
145564	\N	\N	\N	\N	40730203	Bokakata	\N	5	142355
145565	\N	\N	\N	\N	40730204	Bongoy	\N	5	142355
145566	\N	\N	\N	\N	40730205	Boonde	\N	5	142355
145567	\N	\N	\N	\N	40730206	Eala	\N	5	142355
145568	\N	\N	\N	\N	40730301	Bimbi	\N	5	142356
145569	\N	\N	\N	\N	40730302	Boangi	\N	5	142356
145570	\N	\N	\N	\N	40730303	Kongi-Bokele	\N	5	142356
145571	\N	\N	\N	\N	40730304	Lofongo 1	\N	5	142356
145572	\N	\N	\N	\N	40730305	Lotulo	\N	5	142356
145573	\N	\N	\N	\N	40730306	Losaila	\N	5	142356
145574	\N	\N	\N	\N	40730307	Mamongo	\N	5	142356
145575	\N	\N	\N	\N	40730308	Wanga-Lingomo	\N	5	142356
145576	\N	\N	\N	\N	40730309	Yete	\N	5	142356
145577	\N	\N	\N	\N	40730401	Balanga	\N	5	142357
145578	\N	\N	\N	\N	40730402	Bokumbo	\N	5	142357
145579	\N	\N	\N	\N	40730403	Bokolombo	\N	5	142357
145580	\N	\N	\N	\N	40730404	Likonda	\N	5	142357
145581	\N	\N	\N	\N	40730405	Linza 1	\N	5	142357
145582	\N	\N	\N	\N	40730406	Linza 2	\N	5	142357
145583	\N	\N	\N	\N	40730407	Mpombi	\N	5	142357
145584	\N	\N	\N	\N	40730408	Nsona	\N	5	142357
145585	\N	\N	\N	\N	40730409	Wamba-Yokose	\N	5	142357
145586	\N	\N	\N	\N	40730410	Yondji	\N	5	142357
145587	\N	\N	\N	\N	40740101	Boanga	\N	5	142359
145588	\N	\N	\N	\N	40740102	Ekuku	\N	5	142359
145589	\N	\N	\N	\N	40740103	Mongi	\N	5	142359
145590	\N	\N	\N	\N	40740104	Yaforo	\N	5	142359
145591	\N	\N	\N	\N	40740105	Yoye	\N	5	142359
145592	\N	\N	\N	\N	40740201	Liondo-Itale	\N	5	142360
145593	\N	\N	\N	\N	40740202	Mongando	\N	5	142360
145594	\N	\N	\N	\N	40740301	Buma	\N	5	142361
145595	\N	\N	\N	\N	40740302	Bombole	\N	5	142361
145596	\N	\N	\N	\N	40740303	Bosange-Mpangu	\N	5	142361
145597	\N	\N	\N	\N	40740304	Esoke	\N	5	142361
145598	\N	\N	\N	\N	40740305	Ilongo	\N	5	142361
145599	\N	\N	\N	\N	40740401	Boeke	\N	5	142362
145600	\N	\N	\N	\N	40740402	Boso-Ndongo	\N	5	142362
145601	\N	\N	\N	\N	40740403	Botende	\N	5	142362
145602	\N	\N	\N	\N	40740404	Mankanza	\N	5	142362
145603	\N	\N	\N	\N	40740501	Biesi-Ene	\N	5	142363
145604	\N	\N	\N	\N	40740502	Boketsi	\N	5	142363
145605	\N	\N	\N	\N	40740503	Boyongo	\N	5	142363
145606	\N	\N	\N	\N	40740504	Ikolomwa	\N	5	142363
145607	\N	\N	\N	\N	40740505	Lokalo	\N	5	142363
145608	\N	\N	\N	\N	40740506	Mbandaka-Ngulo	\N	5	142363
145609	\N	\N	\N	\N	40740507	Mbondo	\N	5	142363
145610	\N	\N	\N	\N	40740508	Moma-Yosila	\N	5	142363
145611	\N	\N	\N	\N	40740509	Nkolo-Balanga	\N	5	142363
145612	\N	\N	\N	\N	40740510	Samanda	\N	5	142363
145613	\N	\N	\N	\N	40740511	Sondjo	\N	5	142363
145614	\N	\N	\N	\N	40740512	Watsi	\N	5	142363
145615	\N	\N	\N	\N	40750101	Bonkeli	\N	5	142365
145616	\N	\N	\N	\N	40750102	Ehula	\N	5	142365
145617	\N	\N	\N	\N	40750103	Mbelo	\N	5	142365
145618	\N	\N	\N	\N	40750104	Mondji-Yale	\N	5	142365
145619	\N	\N	\N	\N	40750105	Monkanda	\N	5	142365
145620	\N	\N	\N	\N	40750106	Ntoma	\N	5	142365
145621	\N	\N	\N	\N	40750201	Lolingo-Sud	\N	5	142366
145622	\N	\N	\N	\N	40750202	Lotoko-Ik.	\N	5	142366
145623	\N	\N	\N	\N	40750203	Mom'Elinga	\N	5	142366
145624	\N	\N	\N	\N	40750204	Ngelewa	\N	5	142366
145625	\N	\N	\N	\N	40750205	Ntomonkonde	\N	5	142366
145626	\N	\N	\N	\N	40750206	Ntomosama	\N	5	142366
145627	\N	\N	\N	\N	40750301	Biambe	\N	5	142367
145628	\N	\N	\N	\N	40750302	Loboma	\N	5	142367
145629	\N	\N	\N	\N	40750303	Nkombe	\N	5	142367
145630	\N	\N	\N	\N	40750401	Bolanda	\N	5	142368
145631	\N	\N	\N	\N	40750402	Bokota	\N	5	142368
145632	\N	\N	\N	\N	40750403	Bokonde	\N	5	142368
145633	\N	\N	\N	\N	40750404	Lolingo	\N	5	142368
145634	\N	\N	\N	\N	40750405	Mondj'Okuli	\N	5	142368
145635	\N	\N	\N	\N	40750406	Ngole	\N	5	142368
145636	\N	\N	\N	\N	40750501	Ilemo	\N	5	142369
145637	\N	\N	\N	\N	40750502	Momboyo-Ikengo	\N	5	142369
145638	\N	\N	\N	\N	40750503	Nkome-Boi	\N	5	142369
145639	\N	\N	\N	\N	40750504	Nongo-Lifanga	\N	5	142369
145640	\N	\N	\N	\N	40760101	Bomate-Kumu	\N	5	142371
145641	\N	\N	\N	\N	40760102	Bobwandja-Indole	\N	5	142371
145642	\N	\N	\N	\N	40760103	Nkole-Lokolo	\N	5	142371
145643	\N	\N	\N	\N	40760104	Ntomba-Nkole	\N	5	142371
145644	\N	\N	\N	\N	40760105	Wafanya	\N	5	142371
145645	\N	\N	\N	\N	40760201	Etete	\N	5	142372
145646	\N	\N	\N	\N	40760202	Iyong'Amongo	\N	5	142372
145647	\N	\N	\N	\N	40760203	Loole	\N	5	142372
145648	\N	\N	\N	\N	40760204	Mpenge	\N	5	142372
145649	\N	\N	\N	\N	40760205	Yongo-Lokalo	\N	5	142372
145650	\N	\N	\N	\N	40760301	Bolenga-Ngele	\N	5	142373
145651	\N	\N	\N	\N	40760302	Bomanga	\N	5	142373
145652	\N	\N	\N	\N	40760303	Bongelokwa	\N	5	142373
145653	\N	\N	\N	\N	40760304	Bongili	\N	5	142373
145654	\N	\N	\N	\N	40760305	Bongoyampongo	\N	5	142373
145655	\N	\N	\N	\N	40760306	Booli	\N	5	142373
145656	\N	\N	\N	\N	40760307	Boongo	\N	5	142373
145657	\N	\N	\N	\N	40760308	Bosongo	\N	5	142373
145658	\N	\N	\N	\N	40760309	Emaka	\N	5	142373
145659	\N	\N	\N	\N	40760310	Emomampako	\N	5	142373
145660	\N	\N	\N	\N	40760311	Entow	\N	5	142373
145661	\N	\N	\N	\N	40760312	Esanga	\N	5	142373
145662	\N	\N	\N	\N	40760313	Esenge-Kaboko	\N	5	142373
145663	\N	\N	\N	\N	40760314	Esolu	\N	5	142373
145664	\N	\N	\N	\N	40760315	Losekungu	\N	5	142373
145665	\N	\N	\N	\N	40760316	Ndomba	\N	5	142373
145666	\N	\N	\N	\N	40760317	Yondji	\N	5	142373
145667	\N	\N	\N	\N	42401010	Ntomba	\N	5	142275
145668	\N	\N	\N	\N	42401011	Mpenge	\N	5	142275
145669	\N	\N	\N	\N	42401012	Hors Milieu Coutumier	\N	5	142275
145670	\N	\N	\N	\N	50110001	Basoko	\N	5	142375
145671	\N	\N	\N	\N	50110002	Batiangubu-Lula	\N	5	142375
145672	\N	\N	\N	\N	50110003	Buta	\N	5	142375
145673	\N	\N	\N	\N	50110004	Camp Lukusa	\N	5	142375
145674	\N	\N	\N	\N	50110005	Kasai	\N	5	142375
145675	\N	\N	\N	\N	50110006	Kolwezi	\N	5	142375
145676	\N	\N	\N	\N	50110007	Lokele	\N	5	142375
145677	\N	\N	\N	\N	50110008	Lokwa-osio	\N	5	142375
145678	\N	\N	\N	\N	50110009	Maniema	\N	5	142375
145679	\N	\N	\N	\N	50110010	Opala	\N	5	142375
145680	\N	\N	\N	\N	50110011	Salumu	\N	5	142375
145681	\N	\N	\N	\N	50110012	Wagenia	\N	5	142375
145682	\N	\N	\N	\N	50110013	Yalisombo	\N	5	142375
145683	\N	\N	\N	\N	50120001	Camp Ilunga	\N	5	142376
145684	\N	\N	\N	\N	50120002	Camp Ketele	\N	5	142376
145685	\N	\N	\N	\N	50120003	Camp P.M	\N	5	142376
145686	\N	\N	\N	\N	50120004	Commercial	\N	5	142376
145687	\N	\N	\N	\N	50120005	Mama-Mobutu	\N	5	142376
145688	\N	\N	\N	\N	50120006	Musicien	\N	5	142376
145689	\N	\N	\N	\N	50120007	Plateau Boyoma	\N	5	142376
145690	\N	\N	\N	\N	50120008	Plateau MÃ©dical	\N	5	142376
145691	\N	\N	\N	\N	50130001	Aruwimi	\N	5	142377
145692	\N	\N	\N	\N	50130002	Elima	\N	5	142377
145693	\N	\N	\N	\N	50130003	Imbolo	\N	5	142377
145694	\N	\N	\N	\N	50130004	Itimbiri	\N	5	142377
145695	\N	\N	\N	\N	50130005	Limanga 1	\N	5	142377
145696	\N	\N	\N	\N	50130006	Lindi	\N	5	142377
145697	\N	\N	\N	\N	50130007	Minzoto	\N	5	142377
145698	\N	\N	\N	\N	50130008	Okapi	\N	5	142377
145699	\N	\N	\N	\N	50130009	Ruwenzori	\N	5	142377
145700	\N	\N	\N	\N	50130010	Segama	\N	5	142377
145701	\N	\N	\N	\N	50140001	Auwimi	\N	5	142378
145702	\N	\N	\N	\N	50140002	Du Stade	\N	5	142378
145703	\N	\N	\N	\N	50140003	Ecole	\N	5	142378
145704	\N	\N	\N	\N	50140004	Kapalata	\N	5	142378
145705	\N	\N	\N	\N	50140005	Lubumbashi	\N	5	142378
145706	\N	\N	\N	\N	50140006	MarchÃ©	\N	5	142378
145707	\N	\N	\N	\N	50140007	Mbilinga	\N	5	142378
145708	\N	\N	\N	\N	50140008	Poste	\N	5	142378
145709	\N	\N	\N	\N	50140009	Pumuzika	\N	5	142378
145710	\N	\N	\N	\N	50140010	UÃ©lÃ©	\N	5	142378
145711	\N	\N	\N	\N	50140011	Zoo	\N	5	142378
145712	\N	\N	\N	\N	50150001	Bakusu	\N	5	142379
145713	\N	\N	\N	\N	50150002	Bandundu	\N	5	142379
145714	\N	\N	\N	\N	50150003	Basakata	\N	5	142379
145715	\N	\N	\N	\N	50150004	Batama	\N	5	142379
145716	\N	\N	\N	\N	50150005	Bekeni	\N	5	142379
145717	\N	\N	\N	\N	50150006	Camp Onatra	\N	5	142379
145718	\N	\N	\N	\N	50150007	Fataki	\N	5	142379
145719	\N	\N	\N	\N	50150008	Faz	\N	5	142379
145720	\N	\N	\N	\N	50150009	Ibambi	\N	5	142379
145721	\N	\N	\N	\N	50150010	Kasai	\N	5	142379
145722	\N	\N	\N	\N	50150011	Kibali-Ituri	\N	5	142379
145723	\N	\N	\N	\N	50150012	Lokutu	\N	5	142379
145724	\N	\N	\N	\N	50150013	Maniema	\N	5	142379
145725	\N	\N	\N	\N	50150014	Masimango	\N	5	142379
145726	\N	\N	\N	\N	50150015	Monga	\N	5	142379
145727	\N	\N	\N	\N	50150016	Musibasiba	\N	5	142379
145728	\N	\N	\N	\N	50150017	N'selÃ©	\N	5	142379
145729	\N	\N	\N	\N	50150018	Place du Congo	\N	5	142379
145730	\N	\N	\N	\N	50150019	Ruwenzori	\N	5	142379
145731	\N	\N	\N	\N	50150020	Tshopo	\N	5	142379
145732	\N	\N	\N	\N	50150021	Tshuapa	\N	5	142379
145733	\N	\N	\N	\N	50160001	24 Novembre	\N	5	142380
145734	\N	\N	\N	\N	50160002	Bangoka	\N	5	142380
145735	\N	\N	\N	\N	50160003	Ikemibie	\N	5	142380
145736	\N	\N	\N	\N	50160004	Kilanga	\N	5	142380
145737	\N	\N	\N	\N	50160005	Kisangani 1	\N	5	142380
145738	\N	\N	\N	\N	50160006	Kongakonga	\N	5	142380
145739	\N	\N	\N	\N	50160007	Malexe	\N	5	142380
145740	\N	\N	\N	\N	50210101	Abata	\N	5	142381
145741	\N	\N	\N	\N	50210102	Bamanga-Bengamisa	\N	5	142381
145742	\N	\N	\N	\N	50210103	Bamanga-Bangelema	\N	5	142381
145743	\N	\N	\N	\N	50210104	Bamanga-Yambuya	\N	5	142381
145744	\N	\N	\N	\N	50210105	Boimbua	\N	5	142381
145745	\N	\N	\N	\N	50210201	Banganzolo	\N	5	142382
145746	\N	\N	\N	\N	50210202	Batchaba ( Bodjaba )	\N	5	142382
145747	\N	\N	\N	\N	50210203	Bobiti	\N	5	142382
145748	\N	\N	\N	\N	50210204	Bomaheli	\N	5	142382
145749	\N	\N	\N	\N	50210205	Bomboma	\N	5	142382
145750	\N	\N	\N	\N	50210206	Bondjala	\N	5	142382
145751	\N	\N	\N	\N	50210207	Liandumba	\N	5	142382
145752	\N	\N	\N	\N	50210301	Bambule	\N	5	142383
145753	\N	\N	\N	\N	50210302	Bobenge	\N	5	142383
145754	\N	\N	\N	\N	50210303	Bobola (Bongbola)	\N	5	142383
145755	\N	\N	\N	\N	50210304	Bokapo	\N	5	142383
145756	\N	\N	\N	\N	50210305	Botokpea	\N	5	142383
145757	\N	\N	\N	\N	50210401	Bagume ( Bapume )	\N	5	142384
145758	\N	\N	\N	\N	50210402	Bakobi	\N	5	142384
145759	\N	\N	\N	\N	50210403	Bamboli	\N	5	142384
145760	\N	\N	\N	\N	50210404	Dango ( Bangbo )	\N	5	142384
145761	\N	\N	\N	\N	50210501	Badadola	\N	5	142385
145762	\N	\N	\N	\N	50210502	Banalia	\N	5	142385
145763	\N	\N	\N	\N	50210503	Bangba	\N	5	142385
145764	\N	\N	\N	\N	50210504	Bokote	\N	5	142385
145765	\N	\N	\N	\N	50210505	Bombwa	\N	5	142385
145766	\N	\N	\N	\N	50210506	Mopee	\N	5	142385
145767	\N	\N	\N	\N	50220101	Loya	\N	5	142387
145768	\N	\N	\N	\N	50220102	Wandi	\N	5	142387
145769	\N	\N	\N	\N	50220201	Bakomoy	\N	5	142388
145770	\N	\N	\N	\N	50220202	Bobodi ( Bambodi )	\N	5	142388
145771	\N	\N	\N	\N	50220203	Molilo ( Molimo )	\N	5	142388
145772	\N	\N	\N	\N	50220204	Wanginda	\N	5	142388
145773	\N	\N	\N	\N	50220301	Bafwakpama	\N	5	142389
145774	\N	\N	\N	\N	50220302	Bafwandu	\N	5	142389
145775	\N	\N	\N	\N	50220303	Bafwatende 1	\N	5	142389
145776	\N	\N	\N	\N	50220304	Bafwatende 2	\N	5	142389
145777	\N	\N	\N	\N	50220305	Bafwazongo	\N	5	142389
145778	\N	\N	\N	\N	50220306	Barumbi-Tshopo	\N	5	142389
145779	\N	\N	\N	\N	50220307	Basokoli	\N	5	142389
145780	\N	\N	\N	\N	50220308	Bemili 2	\N	5	142389
145781	\N	\N	\N	\N	50220401	Babamba	\N	5	142390
145782	\N	\N	\N	\N	50220402	Babengo	\N	5	142390
145783	\N	\N	\N	\N	50220403	Bafwakubi ( Bafwakuleke )	\N	5	142390
145784	\N	\N	\N	\N	50220404	Bangbatale	\N	5	142390
145785	\N	\N	\N	\N	50220405	Bavagu ( Bafwabu )	\N	5	142390
145786	\N	\N	\N	\N	50220406	Betingeni	\N	5	142390
145787	\N	\N	\N	\N	50220501	Bafwandjili	\N	5	142391
145788	\N	\N	\N	\N	50220502	Bafwazea	\N	5	142391
145789	\N	\N	\N	\N	50220503	Bamadea	\N	5	142391
145790	\N	\N	\N	\N	50220504	Bembitela	\N	5	142391
145791	\N	\N	\N	\N	50220505	Bemili	\N	5	142391
145792	\N	\N	\N	\N	50220601	Araisa-Avakubi	\N	5	142392
145793	\N	\N	\N	\N	50220602	Bafwasiba	\N	5	142392
145794	\N	\N	\N	\N	50220603	Bafwasola	\N	5	142392
145795	\N	\N	\N	\N	50220604	Bakundumu 2	\N	5	142392
145796	\N	\N	\N	\N	50220605	Bakundumu-Lindi	\N	5	142392
145797	\N	\N	\N	\N	50220606	Boyulu	\N	5	142392
145798	\N	\N	\N	\N	50220607	Kenge	\N	5	142392
145799	\N	\N	\N	\N	50220608	Lindi	\N	5	142392
145800	\N	\N	\N	\N	50225101	Bafwa Zungu	\N	5	142393
145801	\N	\N	\N	\N	50225102	Bafwasiba	\N	5	142393
145802	\N	\N	\N	\N	50225103	Kenge	\N	5	142393
145803	\N	\N	\N	\N	50225104	Lindi	\N	5	142393
145804	\N	\N	\N	\N	50230101	Babuma	\N	5	142394
145805	\N	\N	\N	\N	50230102	Bagbandia	\N	5	142394
145806	\N	\N	\N	\N	50230104	Baimana	\N	5	142394
145807	\N	\N	\N	\N	50230105	Bayero	\N	5	142394
145808	\N	\N	\N	\N	50230201	Baikuba	\N	5	142395
145809	\N	\N	\N	\N	50230202	Bamoso	\N	5	142395
145810	\N	\N	\N	\N	50230203	Bamutamba	\N	5	142395
145929	\N	\N	\N	\N	50250703	Yambau	\N	5	142424
145811	\N	\N	\N	\N	50230204	Basiki ( Basiki )	\N	5	142395
145812	\N	\N	\N	\N	50230205	Basikonge	\N	5	142395
145813	\N	\N	\N	\N	50230301	Bakuta	\N	5	142396
145814	\N	\N	\N	\N	50230302	Banakebuka	\N	5	142396
145815	\N	\N	\N	\N	50230303	Banyalobeke	\N	5	142396
145816	\N	\N	\N	\N	50230304	Bimbi	\N	5	142396
145817	\N	\N	\N	\N	50230401	Babiondo	\N	5	142397
145818	\N	\N	\N	\N	50230402	Bafale	\N	5	142397
145819	\N	\N	\N	\N	50230403	Bagwase	\N	5	142397
145820	\N	\N	\N	\N	50230404	Babimi	\N	5	142397
145821	\N	\N	\N	\N	50230501	Bamanga	\N	5	142398
145822	\N	\N	\N	\N	50230502	Bamini	\N	5	142398
145823	\N	\N	\N	\N	50230503	Puku	\N	5	142398
145824	\N	\N	\N	\N	50230504	Ruwiki	\N	5	142398
145825	\N	\N	\N	\N	50230601	Babusoko	\N	5	142399
145826	\N	\N	\N	\N	50230602	Babunze	\N	5	142399
145827	\N	\N	\N	\N	50230603	Bamuyumbe	\N	5	142399
145828	\N	\N	\N	\N	50230604	Bandu	\N	5	142399
145829	\N	\N	\N	\N	50230605	Banekwa	\N	5	142399
145830	\N	\N	\N	\N	50230701	Bakumu-Kabalo	\N	5	142400
145831	\N	\N	\N	\N	50230702	Baleka-Kabalo	\N	5	142400
145832	\N	\N	\N	\N	50230703	Madula	\N	5	142400
145833	\N	\N	\N	\N	50230801	Bafwaboli	\N	5	142401
145834	\N	\N	\N	\N	50230802	Kilinga	\N	5	142401
145835	\N	\N	\N	\N	50230901	Bakumu-Azambau	\N	5	142402
145836	\N	\N	\N	\N	50230902	Bakumu-Baleka	\N	5	142402
145837	\N	\N	\N	\N	50230903	Bakumu-Maiko	\N	5	142402
145838	\N	\N	\N	\N	50230904	Bakumu-Chakala	\N	5	142402
145839	\N	\N	\N	\N	50231001	Asombi	\N	5	142403
145840	\N	\N	\N	\N	50231002	Babaudu	\N	5	142403
145841	\N	\N	\N	\N	50231003	Babimbi	\N	5	142403
145842	\N	\N	\N	\N	50231004	Baluko	\N	5	142403
145843	\N	\N	\N	\N	50231005	Bangose	\N	5	142403
145844	\N	\N	\N	\N	50231006	Saba ( Osaba )	\N	5	142403
145845	\N	\N	\N	\N	50231101	W/Kibonge	\N	5	142404
145846	\N	\N	\N	\N	50231102	W/Saidi	\N	5	142404
145847	\N	\N	\N	\N	50231103	W/Ugarawa	\N	5	142404
145848	\N	\N	\N	\N	50235101	Bakumu	\N	5	142405
145849	\N	\N	\N	\N	50235102	Lubama	\N	5	142405
145850	\N	\N	\N	\N	50235103	Mituku	\N	5	142405
145851	\N	\N	\N	\N	50235104	Walengola	\N	5	142405
145852	\N	\N	\N	\N	50240101	Loolo	\N	5	142406
145853	\N	\N	\N	\N	50240102	Yawende	\N	5	142406
145854	\N	\N	\N	\N	50240201	Boma	\N	5	142407
145855	\N	\N	\N	\N	50240202	Nongo	\N	5	142407
145856	\N	\N	\N	\N	50240203	Ngombe	\N	5	142407
145857	\N	\N	\N	\N	50240204	Yawelo	\N	5	142407
145858	\N	\N	\N	\N	50240301	Elombe	\N	5	142408
145859	\N	\N	\N	\N	50240302	Ilanga	\N	5	142408
145860	\N	\N	\N	\N	50240303	Yakuma	\N	5	142408
145861	\N	\N	\N	\N	50240304	Yawilo	\N	5	142408
145862	\N	\N	\N	\N	50240305	Yemaka	\N	5	142408
145863	\N	\N	\N	\N	50240306	Yokeli	\N	5	142408
145864	\N	\N	\N	\N	50240307	Yuma	\N	5	142408
145865	\N	\N	\N	\N	50240401	Ekele	\N	5	142409
145866	\N	\N	\N	\N	50240402	Mongo / Nonga	\N	5	142409
145867	\N	\N	\N	\N	50240403	Yaolonga	\N	5	142409
145868	\N	\N	\N	\N	50240501	Likunda	\N	5	142410
145869	\N	\N	\N	\N	50240502	Yawanga	\N	5	142410
145870	\N	\N	\N	\N	50240503	Yaweti	\N	5	142410
145871	\N	\N	\N	\N	50240601	Yakoko	\N	5	142411
145872	\N	\N	\N	\N	50240602	Yaongelo	\N	5	142411
145873	\N	\N	\N	\N	50240701	Ikenge	\N	5	142412
145874	\N	\N	\N	\N	50240702	Ilondo	\N	5	142412
145875	\N	\N	\N	\N	50240703	Yambembe-Kima	\N	5	142412
145876	\N	\N	\N	\N	50240704	Yambetsi	\N	5	142412
145877	\N	\N	\N	\N	50240705	Yandja	\N	5	142412
145878	\N	\N	\N	\N	50240706	Yanzate	\N	5	142412
145879	\N	\N	\N	\N	50240707	Yaokasa	\N	5	142412
145880	\N	\N	\N	\N	50240708	Yaokumbe	\N	5	142412
145881	\N	\N	\N	\N	50240709	Yaolongo	\N	5	142412
145882	\N	\N	\N	\N	50240710	Yasonge	\N	5	142412
145883	\N	\N	\N	\N	50240801	Bokoke	\N	5	142413
145884	\N	\N	\N	\N	50240802	Yapalake	\N	5	142413
145885	\N	\N	\N	\N	50240803	Yawina	\N	5	142413
145886	\N	\N	\N	\N	50240901	Balolo	\N	5	142414
145887	\N	\N	\N	\N	50240902	Bokuma	\N	5	142414
145888	\N	\N	\N	\N	50240903	Ilanga-Ilondo	\N	5	142414
145889	\N	\N	\N	\N	50240904	Ilanga	\N	5	142414
145890	\N	\N	\N	\N	50240905	Lokulu	\N	5	142414
145891	\N	\N	\N	\N	50240906	Yalokulu-L.	\N	5	142414
145892	\N	\N	\N	\N	50240907	Yenga	\N	5	142414
145893	\N	\N	\N	\N	50241001	Bokuma	\N	5	142415
145894	\N	\N	\N	\N	50241002	Koli	\N	5	142415
145895	\N	\N	\N	\N	50241003	Yawelo	\N	5	142415
145896	\N	\N	\N	\N	50241004	Yaisa	\N	5	142415
145897	\N	\N	\N	\N	50241005	Yangonda	\N	5	142415
145898	\N	\N	\N	\N	50241006	Yaoka	\N	5	142415
145899	\N	\N	\N	\N	50241007	Yatanda	\N	5	142415
145900	\N	\N	\N	\N	50241008	Yatulia	\N	5	142415
145901	\N	\N	\N	\N	50241101	Botunga	\N	5	142416
145902	\N	\N	\N	\N	50241102	Yamba	\N	5	142416
145903	\N	\N	\N	\N	50250101	Ilombo 1	\N	5	142418
145904	\N	\N	\N	\N	50250102	Ilombo 2 (Elambo)	\N	5	142418
145905	\N	\N	\N	\N	50250103	Mbole	\N	5	142418
145906	\N	\N	\N	\N	50250201	Liombo	\N	5	142419
145907	\N	\N	\N	\N	50250202	Wetsi / Wete	\N	5	142419
145908	\N	\N	\N	\N	50250203	Yaoleo	\N	5	142419
145909	\N	\N	\N	\N	50250301	Basusaenge	\N	5	142420
145910	\N	\N	\N	\N	50250302	Batolombo	\N	5	142420
145911	\N	\N	\N	\N	50250303	Bondi	\N	5	142420
145912	\N	\N	\N	\N	50250304	Seloye	\N	5	142420
145913	\N	\N	\N	\N	50250305	Yatsasoa	\N	5	142420
145914	\N	\N	\N	\N	50250401	Bolea	\N	5	142421
145915	\N	\N	\N	\N	50250402	Ilowa	\N	5	142421
145916	\N	\N	\N	\N	50250501	Bohuma	\N	5	142422
145917	\N	\N	\N	\N	50250502	Logoge	\N	5	142422
145918	\N	\N	\N	\N	50250503	Mangala	\N	5	142422
145919	\N	\N	\N	\N	50250504	Mwando	\N	5	142422
145920	\N	\N	\N	\N	50250601	Boanga	\N	5	142423
145921	\N	\N	\N	\N	50250602	Baswa	\N	5	142423
145922	\N	\N	\N	\N	50250603	Bolimosisa	\N	5	142423
145923	\N	\N	\N	\N	50250604	Isangi	\N	5	142423
145924	\N	\N	\N	\N	50250605	Yafunga	\N	5	142423
145925	\N	\N	\N	\N	50250606	Yalikina	\N	5	142423
145926	\N	\N	\N	\N	50250607	Yaombole	\N	5	142423
145927	\N	\N	\N	\N	50250701	Weko	\N	5	142424
145928	\N	\N	\N	\N	50250702	Yalengo / Yelongo	\N	5	142424
145930	\N	\N	\N	\N	50250704	Yawenda	\N	5	142424
145931	\N	\N	\N	\N	50250801	Likolombole	\N	5	142425
145932	\N	\N	\N	\N	50250802	Lileko	\N	5	142425
145933	\N	\N	\N	\N	50250803	Yaboni	\N	5	142425
145934	\N	\N	\N	\N	50250804	Yowani	\N	5	142425
145935	\N	\N	\N	\N	50250808	Yasangandjia	\N	5	142425
145936	\N	\N	\N	\N	50250901	Bolongo	\N	5	142426
145937	\N	\N	\N	\N	50250902	Lotokila	\N	5	142426
145938	\N	\N	\N	\N	50250903	Totuku	\N	5	142426
145939	\N	\N	\N	\N	50250904	Yase	\N	5	142426
145940	\N	\N	\N	\N	50250905	Yangambi / Yangandi	\N	5	142426
145941	\N	\N	\N	\N	50250906	Yanonge	\N	5	142426
145942	\N	\N	\N	\N	50250907	Yainyongo	\N	5	142426
145943	\N	\N	\N	\N	50251001	Yalikutu	\N	5	142427
145944	\N	\N	\N	\N	50251002	Yawenda	\N	5	142427
145945	\N	\N	\N	\N	50251101	Loholo	\N	5	142428
145946	\N	\N	\N	\N	50251102	Yaosayo / Yalikoka	\N	5	142428
145947	\N	\N	\N	\N	50251201	Ilambi	\N	5	142429
145948	\N	\N	\N	\N	50251202	Litwa	\N	5	142429
145949	\N	\N	\N	\N	50251203	Mbongi	\N	5	142429
145950	\N	\N	\N	\N	50251204	Nkeleli	\N	5	142429
145951	\N	\N	\N	\N	50251205	Timbo	\N	5	142429
145952	\N	\N	\N	\N	50251206	Yalofeli	\N	5	142429
145953	\N	\N	\N	\N	50251301	Liutua	\N	5	142430
145954	\N	\N	\N	\N	50251302	Yalibande	\N	5	142430
145955	\N	\N	\N	\N	50255101	Camp Etat	\N	5	142431
145956	\N	\N	\N	\N	50255102	Isangi	\N	5	142431
145957	\N	\N	\N	\N	50255201	Bangala	\N	5	142432
145958	\N	\N	\N	\N	50255202	Ekutsu	\N	5	142432
145959	\N	\N	\N	\N	50255203	Likango	\N	5	142432
145960	\N	\N	\N	\N	50255204	Lomboto	\N	5	142432
145961	\N	\N	\N	\N	50255205	Lumumba	\N	5	142432
145962	\N	\N	\N	\N	50255206	Lusambila	\N	5	142432
145963	\N	\N	\N	\N	50255207	Moussa	\N	5	142432
145964	\N	\N	\N	\N	50255208	Ngazi	\N	5	142432
145965	\N	\N	\N	\N	50255209	Okito	\N	5	142432
145966	\N	\N	\N	\N	50255210	Yaekema	\N	5	142432
145967	\N	\N	\N	\N	50260101	Bokoka	\N	5	142433
145968	\N	\N	\N	\N	50260102	Bosoku	\N	5	142433
145969	\N	\N	\N	\N	50260103	Bokotshu	\N	5	142433
145970	\N	\N	\N	\N	50260104	Okombokombo	\N	5	142433
145971	\N	\N	\N	\N	50260201	Bokala	\N	5	142434
145972	\N	\N	\N	\N	50260202	Bolese	\N	5	142434
145973	\N	\N	\N	\N	50260203	Bolombo 1	\N	5	142434
145974	\N	\N	\N	\N	50260204	Bolombo 2	\N	5	142434
145975	\N	\N	\N	\N	50260205	Bongemba	\N	5	142434
145976	\N	\N	\N	\N	50260206	Yahuma	\N	5	142434
145977	\N	\N	\N	\N	50260207	Yembu	\N	5	142434
145978	\N	\N	\N	\N	50260301	Bokala	\N	5	142435
145979	\N	\N	\N	\N	50260302	Bolombo	\N	5	142435
145980	\N	\N	\N	\N	50260303	Losaila	\N	5	142435
145981	\N	\N	\N	\N	50260401	Mombongo	\N	5	142436
145982	\N	\N	\N	\N	50260402	Mondimbi	\N	5	142436
145983	\N	\N	\N	\N	50260403	Yamolemba	\N	5	142436
145984	\N	\N	\N	\N	50260404	Yanduka (Yanduka)	\N	5	142436
145985	\N	\N	\N	\N	50270101	Mwingi	\N	5	142438
145986	\N	\N	\N	\N	50270102	Yanongo	\N	5	142438
145987	\N	\N	\N	\N	50270103	Lokutu	\N	5	142438
145988	\N	\N	\N	\N	50270201	Maandjo	\N	5	142439
145989	\N	\N	\N	\N	50270202	Mobenge	\N	5	142439
145990	\N	\N	\N	\N	50270203	Mokula	\N	5	142439
145991	\N	\N	\N	\N	50270204	Moliele	\N	5	142439
145992	\N	\N	\N	\N	50270205	Obakulu	\N	5	142439
145993	\N	\N	\N	\N	50270206	Opandu	\N	5	142439
145994	\N	\N	\N	\N	50270207	Wina Wina	\N	5	142439
145995	\N	\N	\N	\N	50270301	Mbole	\N	5	142440
145996	\N	\N	\N	\N	50270302	Mokaria	\N	5	142440
145997	\N	\N	\N	\N	50270303	Yamonongeri	\N	5	142440
145998	\N	\N	\N	\N	50270401	Kuma	\N	5	142441
145999	\N	\N	\N	\N	50270402	Lokesa	\N	5	142441
146000	\N	\N	\N	\N	50270403	Yamakumbaka	\N	5	142441
146001	\N	\N	\N	\N	50270501	Bahanga	\N	5	142442
146002	\N	\N	\N	\N	50270502	Bomenge	\N	5	142442
146003	\N	\N	\N	\N	50270503	Boyanga	\N	5	142442
146004	\N	\N	\N	\N	50270504	Ikoti	\N	5	142442
146005	\N	\N	\N	\N	50270505	Mobamba 2	\N	5	142442
146006	\N	\N	\N	\N	50270506	Moenge	\N	5	142442
146007	\N	\N	\N	\N	50270507	Mokongo	\N	5	142442
146008	\N	\N	\N	\N	50270508	Wakalasi	\N	5	142442
146009	\N	\N	\N	\N	50270601	Adjoboa	\N	5	142443
146010	\N	\N	\N	\N	50270602	Baonde	\N	5	142443
146011	\N	\N	\N	\N	50270603	Fimbo	\N	5	142443
146012	\N	\N	\N	\N	50270604	Ilongo	\N	5	142443
146013	\N	\N	\N	\N	50270605	Likombe	\N	5	142443
146014	\N	\N	\N	\N	50270606	Mongandjo	\N	5	142443
146015	\N	\N	\N	\N	50270607	Ngoi	\N	5	142443
146016	\N	\N	\N	\N	50270608	Mongelema	\N	5	142443
146017	\N	\N	\N	\N	50270701	Bangelema	\N	5	142444
146018	\N	\N	\N	\N	50270702	Likile	\N	5	142444
146019	\N	\N	\N	\N	50270801	Basoo	\N	5	142445
146020	\N	\N	\N	\N	50270802	Bomane	\N	5	142445
146021	\N	\N	\N	\N	50275101	Ambambe	\N	5	142446
146022	\N	\N	\N	\N	50275102	Libamba	\N	5	142446
146023	\N	\N	\N	\N	50275103	Mambandu	\N	5	142446
146024	\N	\N	\N	\N	50275104	Toyokana	\N	5	142446
146025	\N	\N	\N	\N	50275201	Irumu	\N	5	142447
146026	\N	\N	\N	\N	50275202	Lokumete	\N	5	142447
146027	\N	\N	\N	\N	50275203	Lokutu	\N	5	142447
146028	\N	\N	\N	\N	50310101	Bangbalea	\N	5	142448
146029	\N	\N	\N	\N	50310102	Basali	\N	5	142448
146030	\N	\N	\N	\N	50310103	Benge	\N	5	142448
146031	\N	\N	\N	\N	50310104	Bobate	\N	5	142448
146032	\N	\N	\N	\N	50310105	Bokapo	\N	5	142448
146033	\N	\N	\N	\N	50310106	Bomene	\N	5	142448
146034	\N	\N	\N	\N	50310107	Bosumbaga	\N	5	142448
146035	\N	\N	\N	\N	50310108	Bozama	\N	5	142448
146036	\N	\N	\N	\N	50310201	Kotely	\N	5	142449
146037	\N	\N	\N	\N	50310202	Longa	\N	5	142449
146038	\N	\N	\N	\N	50310203	Makala	\N	5	142449
146039	\N	\N	\N	\N	50310204	Maselebende	\N	5	142449
146040	\N	\N	\N	\N	50310205	Ndio 1	\N	5	142449
146041	\N	\N	\N	\N	50310206	Ndio 2	\N	5	142449
146042	\N	\N	\N	\N	50310207	Tekembo	\N	5	142449
146043	\N	\N	\N	\N	50310301	Baangba	\N	5	142450
146044	\N	\N	\N	\N	50310302	Babeaza	\N	5	142450
146045	\N	\N	\N	\N	50310303	Batuae	\N	5	142450
146046	\N	\N	\N	\N	50310304	Bobati	\N	5	142450
146047	\N	\N	\N	\N	50310305	Bobenge	\N	5	142450
146048	\N	\N	\N	\N	50310306	Boboze	\N	5	142450
146049	\N	\N	\N	\N	50310307	Bodembu	\N	5	142450
146050	\N	\N	\N	\N	50310308	Bofando	\N	5	142450
146051	\N	\N	\N	\N	50310309	Bokusi	\N	5	142450
146052	\N	\N	\N	\N	50310310	Bongeni	\N	5	142450
146053	\N	\N	\N	\N	50310311	Bosay	\N	5	142450
146054	\N	\N	\N	\N	50310312	Bozaki	\N	5	142450
146055	\N	\N	\N	\N	50310401	Badakpa 1	\N	5	142451
146056	\N	\N	\N	\N	50310402	Badakpa 2	\N	5	142451
146057	\N	\N	\N	\N	50310403	Bobambwa	\N	5	142451
146058	\N	\N	\N	\N	50310404	Bokasele	\N	5	142451
146059	\N	\N	\N	\N	50310405	Bodingima	\N	5	142451
146060	\N	\N	\N	\N	50310406	Bodongosa	\N	5	142451
146061	\N	\N	\N	\N	50310407	Bonduluma	\N	5	142451
146062	\N	\N	\N	\N	50310408	Bongbagele	\N	5	142451
146063	\N	\N	\N	\N	50310501	Bangombi	\N	5	142452
146064	\N	\N	\N	\N	50310502	Basayo	\N	5	142452
146065	\N	\N	\N	\N	50310503	Bobimba	\N	5	142452
146066	\N	\N	\N	\N	50310504	Bobita	\N	5	142452
146067	\N	\N	\N	\N	50310505	Bogbaze	\N	5	142452
146068	\N	\N	\N	\N	50310506	Bondonga	\N	5	142452
146069	\N	\N	\N	\N	50310507	Bongaluma	\N	5	142452
146070	\N	\N	\N	\N	50310508	Bongbobole	\N	5	142452
146071	\N	\N	\N	\N	50310509	Bongule	\N	5	142452
146072	\N	\N	\N	\N	50310510	Bosawa	\N	5	142452
146073	\N	\N	\N	\N	50310511	Boyenge	\N	5	142452
146074	\N	\N	\N	\N	50310512	Bozangada	\N	5	142452
146075	\N	\N	\N	\N	50310601	Baboa	\N	5	142453
146076	\N	\N	\N	\N	50310602	Batue	\N	5	142453
146077	\N	\N	\N	\N	50310603	Bayeu	\N	5	142453
146078	\N	\N	\N	\N	50310604	Bobindisi	\N	5	142453
146079	\N	\N	\N	\N	50310605	Bogata	\N	5	142453
146080	\N	\N	\N	\N	50310606	Bogogo	\N	5	142453
146081	\N	\N	\N	\N	50310607	Bondungwale	\N	5	142453
146082	\N	\N	\N	\N	50310608	Bongaluma	\N	5	142453
146083	\N	\N	\N	\N	50310609	Bongbeme	\N	5	142453
146084	\N	\N	\N	\N	50310610	Buliale-Gbea	\N	5	142453
146085	\N	\N	\N	\N	50310611	Buliamamboli	\N	5	142453
146086	\N	\N	\N	\N	50315101	Alogo	\N	5	142454
146087	\N	\N	\N	\N	50315102	Bagbe	\N	5	142454
146088	\N	\N	\N	\N	50315103	Besose	\N	5	142454
146089	\N	\N	\N	\N	50315104	Bokapo	\N	5	142454
146090	\N	\N	\N	\N	50315105	Makasi	\N	5	142454
146091	\N	\N	\N	\N	50315106	Mobalea	\N	5	142454
146092	\N	\N	\N	\N	50315107	Mongwandi	\N	5	142454
146093	\N	\N	\N	\N	50315108	Rubi 1	\N	5	142454
146094	\N	\N	\N	\N	50315109	Rubi 2	\N	5	142454
146095	\N	\N	\N	\N	50320101	Bolendo	\N	5	142455
146096	\N	\N	\N	\N	50320102	Bongbasa	\N	5	142455
146097	\N	\N	\N	\N	50320103	Bagwase	\N	5	142455
146098	\N	\N	\N	\N	50320104	Bongeta	\N	5	142455
146099	\N	\N	\N	\N	50320201	Abibi	\N	5	142456
146100	\N	\N	\N	\N	50320202	Aboso	\N	5	142456
146101	\N	\N	\N	\N	50320203	Bogbuta	\N	5	142456
146102	\N	\N	\N	\N	50320204	Bokalaka	\N	5	142456
146103	\N	\N	\N	\N	50320205	Bondongola	\N	5	142456
146104	\N	\N	\N	\N	50320206	Bonganga	\N	5	142456
146105	\N	\N	\N	\N	50320301	Babwa	\N	5	142457
146106	\N	\N	\N	\N	50320302	Bobotombo	\N	5	142457
146107	\N	\N	\N	\N	50320303	Bogbama	\N	5	142457
146108	\N	\N	\N	\N	50320304	Bogolo	\N	5	142457
146109	\N	\N	\N	\N	50320401	Balisango	\N	5	142458
146110	\N	\N	\N	\N	50320402	Dengwa	\N	5	142458
146111	\N	\N	\N	\N	50320403	Nguta	\N	5	142458
146112	\N	\N	\N	\N	50320501	Bogbasa	\N	5	142459
146113	\N	\N	\N	\N	50320502	Bogbondolo	\N	5	142459
146114	\N	\N	\N	\N	50320503	Bosombea	\N	5	142459
146115	\N	\N	\N	\N	50320504	Ngbatala	\N	5	142459
146116	\N	\N	\N	\N	50320601	Banangi	\N	5	142460
146117	\N	\N	\N	\N	50320602	Guruza	\N	5	142460
146118	\N	\N	\N	\N	50320603	Ngbali	\N	5	142460
146119	\N	\N	\N	\N	50320701	Adongo	\N	5	142461
146120	\N	\N	\N	\N	50320702	Amondo	\N	5	142461
146121	\N	\N	\N	\N	50320703	Bobenga	\N	5	142461
146122	\N	\N	\N	\N	50320704	Bodhe	\N	5	142461
146123	\N	\N	\N	\N	50320705	Bodumbe	\N	5	142461
146124	\N	\N	\N	\N	50320706	Bodunga	\N	5	142461
146125	\N	\N	\N	\N	50320707	Nadoka	\N	5	142461
146126	\N	\N	\N	\N	50320708	Noswa / Boswa	\N	5	142461
146127	\N	\N	\N	\N	50320801	Banga-Nkoy	\N	5	142462
146128	\N	\N	\N	\N	50320802	Bela	\N	5	142462
146129	\N	\N	\N	\N	50320803	Boso	\N	5	142462
146130	\N	\N	\N	\N	50320804	Genza	\N	5	142462
146131	\N	\N	\N	\N	50320805	Gongea	\N	5	142462
146132	\N	\N	\N	\N	50320806	Kiso	\N	5	142462
146133	\N	\N	\N	\N	50320807	Mboa	\N	5	142462
146134	\N	\N	\N	\N	50320808	Motsay	\N	5	142462
146135	\N	\N	\N	\N	50320809	Nzudu	\N	5	142462
146136	\N	\N	\N	\N	50325101	Azande	\N	5	142463
146137	\N	\N	\N	\N	50325102	Itimbiri	\N	5	142463
146138	\N	\N	\N	\N	50325103	Kisangani	\N	5	142463
146139	\N	\N	\N	\N	50325104	Mabinza	\N	5	142463
146140	\N	\N	\N	\N	50325105	Mobati	\N	5	142463
146141	\N	\N	\N	\N	50325106	Mongwandi	\N	5	142463
146142	\N	\N	\N	\N	50330101	Bangbe	\N	5	142464
146143	\N	\N	\N	\N	50330102	Biasu	\N	5	142464
146144	\N	\N	\N	\N	50330103	Londo	\N	5	142464
146145	\N	\N	\N	\N	50330104	Nduma	\N	5	142464
146146	\N	\N	\N	\N	50330105	Zalo	\N	5	142464
146147	\N	\N	\N	\N	50330201	Bangba	\N	5	142465
146148	\N	\N	\N	\N	50330202	Ndongba	\N	5	142465
146149	\N	\N	\N	\N	50330203	Soa ( Kpelende )	\N	5	142465
146150	\N	\N	\N	\N	50330204	Zerete	\N	5	142465
146151	\N	\N	\N	\N	50330301	Bisangu	\N	5	142466
146152	\N	\N	\N	\N	50330302	Dongobe	\N	5	142466
146153	\N	\N	\N	\N	50330303	Gbasa	\N	5	142466
146154	\N	\N	\N	\N	50330304	Mboli	\N	5	142466
146155	\N	\N	\N	\N	50330305	Nilu	\N	5	142466
146156	\N	\N	\N	\N	50330401	Balimbala	\N	5	142467
146157	\N	\N	\N	\N	50330402	Baye	\N	5	142467
146158	\N	\N	\N	\N	50330403	Gulube	\N	5	142467
146159	\N	\N	\N	\N	50330404	Manamuve	\N	5	142467
146160	\N	\N	\N	\N	50330405	Nungba	\N	5	142467
146161	\N	\N	\N	\N	50330501	Kasambi	\N	5	142468
146162	\N	\N	\N	\N	50330502	Luanya	\N	5	142468
146163	\N	\N	\N	\N	50330503	Mabenge	\N	5	142468
146164	\N	\N	\N	\N	50330504	Usumo	\N	5	142468
146165	\N	\N	\N	\N	50330505	Yekutala	\N	5	142468
146166	\N	\N	\N	\N	50330601	Banday	\N	5	142469
146167	\N	\N	\N	\N	50330602	Dezu	\N	5	142469
146168	\N	\N	\N	\N	50330603	Sanza	\N	5	142469
146169	\N	\N	\N	\N	50330604	Tilinga	\N	5	142469
146170	\N	\N	\N	\N	50330701	Bolongo	\N	5	142470
146171	\N	\N	\N	\N	50330702	Gambate	\N	5	142470
146172	\N	\N	\N	\N	50330703	Ingasu	\N	5	142470
146173	\N	\N	\N	\N	50330704	Muma	\N	5	142470
146174	\N	\N	\N	\N	50330705	Ngbazi	\N	5	142470
146175	\N	\N	\N	\N	50330706	Zambabu / Zambangbe	\N	5	142470
146176	\N	\N	\N	\N	50330707	Zamu	\N	5	142470
146177	\N	\N	\N	\N	50330801	Gbandu	\N	5	142471
146178	\N	\N	\N	\N	50330802	Mbeletu	\N	5	142471
146179	\N	\N	\N	\N	50330803	Nangba	\N	5	142471
146180	\N	\N	\N	\N	50330804	Nganya	\N	5	142471
146181	\N	\N	\N	\N	50330901	Dekere	\N	5	142472
146182	\N	\N	\N	\N	50330902	Eteli	\N	5	142472
146183	\N	\N	\N	\N	50330903	Gatanga	\N	5	142472
146184	\N	\N	\N	\N	50330904	Limbasa	\N	5	142472
146185	\N	\N	\N	\N	50330905	Mokozo	\N	5	142472
146186	\N	\N	\N	\N	50330906	Mozile	\N	5	142472
146187	\N	\N	\N	\N	50330907	Ndigbo	\N	5	142472
146188	\N	\N	\N	\N	50330908	Ulele	\N	5	142472
146189	\N	\N	\N	\N	50330909	Zakila	\N	5	142472
146190	\N	\N	\N	\N	50330910	Zakpo-Efoli	\N	5	142472
146191	\N	\N	\N	\N	50331001	Bobotea	\N	5	142473
146192	\N	\N	\N	\N	50331002	Bokusi	\N	5	142473
146193	\N	\N	\N	\N	50331003	Bomolo	\N	5	142473
146194	\N	\N	\N	\N	50331004	Bondila	\N	5	142473
146195	\N	\N	\N	\N	50331005	Bongunguma	\N	5	142473
146196	\N	\N	\N	\N	50331006	Bozambwa	\N	5	142473
146197	\N	\N	\N	\N	50335101	Mabiso	\N	5	142474
146198	\N	\N	\N	\N	50335102	Makambwa	\N	5	142474
146199	\N	\N	\N	\N	50335103	Monzili	\N	5	142474
146200	\N	\N	\N	\N	50335104	Panzaka	\N	5	142474
146201	\N	\N	\N	\N	50340101	Bamela	\N	5	142475
146202	\N	\N	\N	\N	50340102	Gbudi	\N	5	142475
146203	\N	\N	\N	\N	50340103	Lisala	\N	5	142475
146204	\N	\N	\N	\N	50340104	Mbabi	\N	5	142475
146205	\N	\N	\N	\N	50340105	Mbibi	\N	5	142475
146206	\N	\N	\N	\N	50340106	Mbibile	\N	5	142475
146207	\N	\N	\N	\N	50340107	Mbote	\N	5	142475
146208	\N	\N	\N	\N	50340108	Mulundu	\N	5	142475
146209	\N	\N	\N	\N	50340201	Abangili 1	\N	5	142476
146210	\N	\N	\N	\N	50340202	Abangili 2	\N	5	142476
146211	\N	\N	\N	\N	50340203	Agbanga	\N	5	142476
146212	\N	\N	\N	\N	50340204	Anginda	\N	5	142476
146213	\N	\N	\N	\N	50340205	Angondo	\N	5	142476
146214	\N	\N	\N	\N	50340206	Aula	\N	5	142476
146215	\N	\N	\N	\N	50340207	Azingbo	\N	5	142476
146216	\N	\N	\N	\N	50340208	Nipilo	\N	5	142476
146217	\N	\N	\N	\N	50340301	Baneipa	\N	5	142477
146218	\N	\N	\N	\N	50340302	Batuya	\N	5	142477
146219	\N	\N	\N	\N	50340303	Boeli	\N	5	142477
146220	\N	\N	\N	\N	50340304	Bokoto	\N	5	142477
146221	\N	\N	\N	\N	50340401	Balibasangu 1	\N	5	142478
146222	\N	\N	\N	\N	50340402	Balibasangu 2	\N	5	142478
146223	\N	\N	\N	\N	50340403	Ndolomo	\N	5	142478
146224	\N	\N	\N	\N	50340404	Ngima 1	\N	5	142478
146225	\N	\N	\N	\N	50340405	Ngima 2	\N	5	142478
146226	\N	\N	\N	\N	50340406	Zengbe	\N	5	142478
146227	\N	\N	\N	\N	50340407	Zeru	\N	5	142478
146228	\N	\N	\N	\N	50345101	Mboyi	\N	5	142479
146229	\N	\N	\N	\N	50345102	Congo	\N	5	142479
146230	\N	\N	\N	\N	50350101	Bakitu	\N	5	142480
146231	\N	\N	\N	\N	50350102	Bakpoli	\N	5	142480
146232	\N	\N	\N	\N	50350103	Bandese	\N	5	142480
146233	\N	\N	\N	\N	50350104	Bima	\N	5	142480
146234	\N	\N	\N	\N	50350105	Kanamoke	\N	5	142480
146235	\N	\N	\N	\N	50350106	Mangele 1	\N	5	142480
146236	\N	\N	\N	\N	50350107	Mangele 2	\N	5	142480
146237	\N	\N	\N	\N	50350201	Baduka	\N	5	142481
146238	\N	\N	\N	\N	50350202	Balamaya	\N	5	142481
146239	\N	\N	\N	\N	50350203	Balassa	\N	5	142481
146240	\N	\N	\N	\N	50350204	Bangbala	\N	5	142481
146241	\N	\N	\N	\N	50350205	Bayebu	\N	5	142481
146242	\N	\N	\N	\N	50350206	Bokoi	\N	5	142481
146243	\N	\N	\N	\N	50350207	Kanamoke	\N	5	142481
146244	\N	\N	\N	\N	50350301	Bongenge	\N	5	142482
146245	\N	\N	\N	\N	50350302	Botani	\N	5	142482
146246	\N	\N	\N	\N	50350303	Bulegogoe 1	\N	5	142482
146247	\N	\N	\N	\N	50350304	Bulegogoe 2	\N	5	142482
146248	\N	\N	\N	\N	50350305	Bulemakpalu	\N	5	142482
146249	\N	\N	\N	\N	50350401	Amokuma 1	\N	5	142483
146250	\N	\N	\N	\N	50350402	Amokuma 2	\N	5	142483
146251	\N	\N	\N	\N	50350403	Amokuma 3	\N	5	142483
146252	\N	\N	\N	\N	50350404	Amokuma 4	\N	5	142483
146253	\N	\N	\N	\N	50350405	Amokuma 5	\N	5	142483
146254	\N	\N	\N	\N	50350406	Awolo	\N	5	142483
146255	\N	\N	\N	\N	50350407	Bakango 1	\N	5	142483
146256	\N	\N	\N	\N	50350408	Bakango 2	\N	5	142483
146257	\N	\N	\N	\N	50350501	Baboyo	\N	5	142484
146258	\N	\N	\N	\N	50350502	Bogwenge	\N	5	142484
146259	\N	\N	\N	\N	50350503	Bokango	\N	5	142484
146260	\N	\N	\N	\N	50350504	Bokea	\N	5	142484
146261	\N	\N	\N	\N	50350505	Boliakanda	\N	5	142484
146262	\N	\N	\N	\N	50350506	Bomanzi	\N	5	142484
146263	\N	\N	\N	\N	50350507	Buduasala (Badwesele)	\N	5	142484
146264	\N	\N	\N	\N	50350601	Badode	\N	5	142485
146265	\N	\N	\N	\N	50350602	Bakango	\N	5	142485
146266	\N	\N	\N	\N	50350603	Bambule	\N	5	142485
146267	\N	\N	\N	\N	50350604	Bogbolo	\N	5	142485
146268	\N	\N	\N	\N	50350605	Bulendenge	\N	5	142485
146269	\N	\N	\N	\N	50350606	Magbaya	\N	5	142485
146270	\N	\N	\N	\N	50350701	Badenga	\N	5	142486
146271	\N	\N	\N	\N	50350702	Bakango	\N	5	142486
146272	\N	\N	\N	\N	50350703	Bambule	\N	5	142486
146273	\N	\N	\N	\N	50350704	Bobagala	\N	5	142486
146274	\N	\N	\N	\N	50350705	Bodomazango	\N	5	142486
146275	\N	\N	\N	\N	50350706	Bokpendu	\N	5	142486
146276	\N	\N	\N	\N	50350707	Bulegasane	\N	5	142486
146277	\N	\N	\N	\N	50350708	Bulevunda	\N	5	142486
146278	\N	\N	\N	\N	50350801	Baboyi	\N	5	142487
146279	\N	\N	\N	\N	50350802	Babuenge	\N	5	142487
146280	\N	\N	\N	\N	50350803	Baguenge	\N	5	142487
146281	\N	\N	\N	\N	50350804	Bambuele	\N	5	142487
146282	\N	\N	\N	\N	50350805	Basui	\N	5	142487
146283	\N	\N	\N	\N	50350901	Bangombo	\N	5	142488
146284	\N	\N	\N	\N	50350902	Babongono 1	\N	5	142488
146285	\N	\N	\N	\N	50350903	Babongono 2	\N	5	142488
146286	\N	\N	\N	\N	50350904	Bogbamboli	\N	5	142488
146287	\N	\N	\N	\N	50350905	Bokalasa	\N	5	142488
146288	\N	\N	\N	\N	50350906	Bokangonda	\N	5	142488
146289	\N	\N	\N	\N	50355101	Buta 1	\N	5	142489
146290	\N	\N	\N	\N	50355102	Buta 2	\N	5	142489
146291	\N	\N	\N	\N	50355103	Lumumba	\N	5	142489
146292	\N	\N	\N	\N	50355104	Ngbulua	\N	5	142489
146293	\N	\N	\N	\N	50355105	President	\N	5	142489
146294	\N	\N	\N	\N	50355106	Congo ( Zaire )	\N	5	142489
146295	\N	\N	\N	\N	50360101	Babogi	\N	5	142490
146296	\N	\N	\N	\N	50360102	Badzandala	\N	5	142490
146297	\N	\N	\N	\N	50360103	Bakpolo	\N	5	142490
146298	\N	\N	\N	\N	50360104	Banyendu	\N	5	142490
146299	\N	\N	\N	\N	50360105	Baube-Babuyi	\N	5	142490
146300	\N	\N	\N	\N	50360106	Boboko-Zobo	\N	5	142490
146301	\N	\N	\N	\N	50360107	Mangboko	\N	5	142490
146302	\N	\N	\N	\N	50360108	Mongi	\N	5	142490
146303	\N	\N	\N	\N	50360201	Angongi	\N	5	142491
146304	\N	\N	\N	\N	50360202	Bamba	\N	5	142491
146305	\N	\N	\N	\N	50360203	Essi	\N	5	142491
146306	\N	\N	\N	\N	50360204	Mawa-Geitu	\N	5	142491
146307	\N	\N	\N	\N	50360205	Molangi	\N	5	142491
146308	\N	\N	\N	\N	50360206	Nebune	\N	5	142491
146309	\N	\N	\N	\N	50360207	Nengwe	\N	5	142491
146310	\N	\N	\N	\N	50360208	Swanga	\N	5	142491
146311	\N	\N	\N	\N	50360301	Angongoy	\N	5	142492
146312	\N	\N	\N	\N	50360302	Babena	\N	5	142492
146313	\N	\N	\N	\N	50360303	Bangale	\N	5	142492
146314	\N	\N	\N	\N	50360304	Bavungara	\N	5	142492
146315	\N	\N	\N	\N	50360305	Bomune	\N	5	142492
146316	\N	\N	\N	\N	50360306	Mangale	\N	5	142492
146317	\N	\N	\N	\N	50360307	Mengbagu	\N	5	142492
146318	\N	\N	\N	\N	50360308	Menza	\N	5	142492
146319	\N	\N	\N	\N	50360401	Bambela	\N	5	142493
146320	\N	\N	\N	\N	50360402	Bautse	\N	5	142493
146321	\N	\N	\N	\N	50360403	Bipala	\N	5	142493
146322	\N	\N	\N	\N	50360404	Bodo	\N	5	142493
146323	\N	\N	\N	\N	50360405	Bope	\N	5	142493
146324	\N	\N	\N	\N	50360406	Efu	\N	5	142493
146325	\N	\N	\N	\N	50360407	Logo	\N	5	142493
146326	\N	\N	\N	\N	50360501	Boso	\N	5	142494
146327	\N	\N	\N	\N	50360502	Tehu	\N	5	142494
146328	\N	\N	\N	\N	50360601	Azali	\N	5	142495
146329	\N	\N	\N	\N	50360602	Banya	\N	5	142495
146330	\N	\N	\N	\N	50360603	Maya	\N	5	142495
146331	\N	\N	\N	\N	50360604	Miwele	\N	5	142495
146332	\N	\N	\N	\N	50360701	Angbango	\N	5	142496
146333	\N	\N	\N	\N	50360702	Ndumba	\N	5	142496
146334	\N	\N	\N	\N	50360703	Teli	\N	5	142496
146335	\N	\N	\N	\N	50360801	Angiala	\N	5	142497
146336	\N	\N	\N	\N	50360802	Bangule	\N	5	142497
146337	\N	\N	\N	\N	50360803	Kpuluda	\N	5	142497
146338	\N	\N	\N	\N	50360804	Mapita	\N	5	142497
146339	\N	\N	\N	\N	50360805	Nakili	\N	5	142497
146340	\N	\N	\N	\N	50360806	Nengwende	\N	5	142497
146341	\N	\N	\N	\N	50360901	Mazulu	\N	5	142498
146342	\N	\N	\N	\N	50360902	Nangubali	\N	5	142498
146343	\N	\N	\N	\N	50360903	Nendumba	\N	5	142498
146344	\N	\N	\N	\N	50360904	Nevulu	\N	5	142498
146345	\N	\N	\N	\N	50361001	Bumba	\N	5	142499
146346	\N	\N	\N	\N	50361002	Dimama	\N	5	142499
146347	\N	\N	\N	\N	50361003	Dimbiya	\N	5	142499
146348	\N	\N	\N	\N	50361004	Maliangele	\N	5	142499
146349	\N	\N	\N	\N	50361005	Mawa	\N	5	142499
146350	\N	\N	\N	\N	50361006	Mazulu	\N	5	142499
146351	\N	\N	\N	\N	50361007	Mbana	\N	5	142499
146352	\N	\N	\N	\N	50361008	Napusi	\N	5	142499
146353	\N	\N	\N	\N	50361009	Tangani	\N	5	142499
146354	\N	\N	\N	\N	50361010	Vungba	\N	5	142499
146355	\N	\N	\N	\N	50361011	Wapudo-Napuda	\N	5	142499
146356	\N	\N	\N	\N	50361101	Kobokobo	\N	5	142500
146357	\N	\N	\N	\N	50361102	Makokoloko	\N	5	142500
146358	\N	\N	\N	\N	50361103	Nangiwa	\N	5	142500
146359	\N	\N	\N	\N	50361104	Neru	\N	5	142500
146360	\N	\N	\N	\N	50361105	Saboma	\N	5	142500
146361	\N	\N	\N	\N	50361106	Sambala	\N	5	142500
146362	\N	\N	\N	\N	50361107	Votondo	\N	5	142500
146363	\N	\N	\N	\N	50361201	Bakumba	\N	5	142501
146364	\N	\N	\N	\N	50361202	Gboma	\N	5	142501
146365	\N	\N	\N	\N	50361203	Kuge	\N	5	142501
146366	\N	\N	\N	\N	50361204	Loko	\N	5	142501
146367	\N	\N	\N	\N	50361205	Mbe	\N	5	142501
146368	\N	\N	\N	\N	50361301	Kumbala	\N	5	142502
146369	\N	\N	\N	\N	50361302	Ngubeli	\N	5	142502
146370	\N	\N	\N	\N	50361303	Wala	\N	5	142502
146371	\N	\N	\N	\N	50365101	Essi	\N	5	142503
146372	\N	\N	\N	\N	50365102	Kama	\N	5	142503
146373	\N	\N	\N	\N	50365103	Vungali	\N	5	142503
146374	\N	\N	\N	\N	50401706	Makumboli	\N	5	142510
146375	\N	\N	\N	\N	50410101	Mambia	\N	5	142504
146376	\N	\N	\N	\N	50410102	Mapana I	\N	5	142504
146377	\N	\N	\N	\N	50410103	Mapana II	\N	5	142504
146378	\N	\N	\N	\N	50410104	Palambay	\N	5	142504
146379	\N	\N	\N	\N	50410201	Balika	\N	5	142505
146380	\N	\N	\N	\N	50410202	Mabuli	\N	5	142505
146381	\N	\N	\N	\N	50410203	Madoka	\N	5	142505
146382	\N	\N	\N	\N	50410204	Mambunga_Mandjo	\N	5	142505
146383	\N	\N	\N	\N	50410205	Mandola	\N	5	142505
146384	\N	\N	\N	\N	50410206	Mangbetu	\N	5	142505
146385	\N	\N	\N	\N	50410207	Mangbo	\N	5	142505
146386	\N	\N	\N	\N	50410208	Mbika-Ogboy	\N	5	142505
146387	\N	\N	\N	\N	50410209	M/Makere	\N	5	142505
146388	\N	\N	\N	\N	50410210	M/Mandea	\N	5	142505
146389	\N	\N	\N	\N	50410211	M/Mandjandala	\N	5	142505
146390	\N	\N	\N	\N	50410301	Amboma	\N	5	142506
146391	\N	\N	\N	\N	50410302	Mapume 1	\N	5	142506
146392	\N	\N	\N	\N	50410303	Mapume 2	\N	5	142506
146393	\N	\N	\N	\N	50410304	Mbangi	\N	5	142506
146394	\N	\N	\N	\N	50410401	Kpokpa	\N	5	142507
146395	\N	\N	\N	\N	50410402	Madima	\N	5	142507
146396	\N	\N	\N	\N	50410403	Madjabe	\N	5	142507
146397	\N	\N	\N	\N	50410404	Madjogo	\N	5	142507
146398	\N	\N	\N	\N	50410405	Magola	\N	5	142507
146399	\N	\N	\N	\N	50410406	Makpa 1	\N	5	142507
146400	\N	\N	\N	\N	50410407	Makpa 2	\N	5	142507
146401	\N	\N	\N	\N	50410408	Mangbele	\N	5	142507
146402	\N	\N	\N	\N	50410409	Mangbetu	\N	5	142507
146403	\N	\N	\N	\N	50410410	Nambia	\N	5	142507
146404	\N	\N	\N	\N	50410411	Navomo	\N	5	142507
146405	\N	\N	\N	\N	50410412	Nyapu	\N	5	142507
146406	\N	\N	\N	\N	50410501	Mabili	\N	5	142508
146407	\N	\N	\N	\N	50410502	Madjo - Mbito	\N	5	142508
146408	\N	\N	\N	\N	50410503	Mangbetu 2	\N	5	142508
146409	\N	\N	\N	\N	50410504	Mangbetu - Matado	\N	5	142508
146410	\N	\N	\N	\N	50410601	Magalonga	\N	5	142509
146411	\N	\N	\N	\N	50410602	Masomana	\N	5	142509
146412	\N	\N	\N	\N	50410603	Matagbuse	\N	5	142509
146413	\N	\N	\N	\N	50410604	Mazima	\N	5	142509
146414	\N	\N	\N	\N	50410701	Mabolo	\N	5	142510
146415	\N	\N	\N	\N	50410702	Mabudesi	\N	5	142510
146416	\N	\N	\N	\N	50410703	Makolodi	\N	5	142510
146417	\N	\N	\N	\N	50410704	Makondama	\N	5	142510
146418	\N	\N	\N	\N	50410705	Makpono	\N	5	142510
146419	\N	\N	\N	\N	50410707	Makundo	\N	5	142510
146420	\N	\N	\N	\N	50410708	Mawana	\N	5	142510
146421	\N	\N	\N	\N	50410709	Mazebu	\N	5	142510
146422	\N	\N	\N	\N	50410710	Mazuluwa	\N	5	142510
146423	\N	\N	\N	\N	50415101	Akpoma	\N	5	142511
146424	\N	\N	\N	\N	50415102	Bazanga	\N	5	142511
146425	\N	\N	\N	\N	50415103	Dingida	\N	5	142511
146426	\N	\N	\N	\N	50415104	Edindali	\N	5	142511
146427	\N	\N	\N	\N	50415105	Kongoli	\N	5	142511
146428	\N	\N	\N	\N	50415106	Madjo	\N	5	142511
146429	\N	\N	\N	\N	50415107	Nambaya	\N	5	142511
146430	\N	\N	\N	\N	50415108	N'sele	\N	5	142511
146431	\N	\N	\N	\N	50415109	Tely	\N	5	142511
146432	\N	\N	\N	\N	50415110	Zebwandra	\N	5	142511
146433	\N	\N	\N	\N	50415111	Zossano	\N	5	142511
146434	\N	\N	\N	\N	50420101	Bakindosungu	\N	5	142512
146435	\N	\N	\N	\N	50420102	Bandafolu	\N	5	142512
146436	\N	\N	\N	\N	50420103	Gongbo	\N	5	142512
146437	\N	\N	\N	\N	50420104	Sadi	\N	5	142512
146438	\N	\N	\N	\N	50420201	Mabuodo	\N	5	142513
146439	\N	\N	\N	\N	50420202	Makoda	\N	5	142513
146440	\N	\N	\N	\N	50420203	Naka	\N	5	142513
146441	\N	\N	\N	\N	50420301	Berigba	\N	5	142514
146442	\N	\N	\N	\N	50420302	Kiliwa	\N	5	142514
146443	\N	\N	\N	\N	50420303	Magogbo	\N	5	142514
146444	\N	\N	\N	\N	50420304	Makombo	\N	5	142514
146445	\N	\N	\N	\N	50420305	Mangalu	\N	5	142514
146446	\N	\N	\N	\N	50420306	Tuku	\N	5	142514
146447	\N	\N	\N	\N	50420401	Guseyo	\N	5	142515
146448	\N	\N	\N	\N	50420402	Kipo	\N	5	142515
146449	\N	\N	\N	\N	50420403	Nabakpa	\N	5	142515
146450	\N	\N	\N	\N	50420404	Nagombo	\N	5	142515
146451	\N	\N	\N	\N	50420405	Nambia	\N	5	142515
146452	\N	\N	\N	\N	50420406	Naworo	\N	5	142515
146453	\N	\N	\N	\N	50420407	Sendebe	\N	5	142515
146454	\N	\N	\N	\N	50420501	Ekibondo	\N	5	142516
146455	\N	\N	\N	\N	50420502	Eti	\N	5	142516
146456	\N	\N	\N	\N	50420503	Gbaga	\N	5	142516
146457	\N	\N	\N	\N	50420504	Kilima	\N	5	142516
146458	\N	\N	\N	\N	50420505	Makombo	\N	5	142516
146459	\N	\N	\N	\N	50420506	Mambetu	\N	5	142516
146460	\N	\N	\N	\N	50420507	Medi-Medi	\N	5	142516
146461	\N	\N	\N	\N	50420601	Arambi	\N	5	142517
146462	\N	\N	\N	\N	50420602	Edro	\N	5	142517
146463	\N	\N	\N	\N	50420603	Mademba	\N	5	142517
146464	\N	\N	\N	\N	50420604	Mambe	\N	5	142517
146465	\N	\N	\N	\N	50420605	Obita	\N	5	142517
146466	\N	\N	\N	\N	50420606	Tulungu	\N	5	142517
146467	\N	\N	\N	\N	50420701	Bobo	\N	5	142518
146468	\N	\N	\N	\N	50420702	Dete	\N	5	142518
146469	\N	\N	\N	\N	50420703	Djaga	\N	5	142518
146470	\N	\N	\N	\N	50420704	Kakoro	\N	5	142518
146471	\N	\N	\N	\N	50420705	Kpambele	\N	5	142518
146472	\N	\N	\N	\N	50420706	Lipombo	\N	5	142518
146473	\N	\N	\N	\N	50420707	Magbanga	\N	5	142518
146474	\N	\N	\N	\N	50420708	Mbelekeu	\N	5	142518
146475	\N	\N	\N	\N	50420709	Mbita	\N	5	142518
146476	\N	\N	\N	\N	50420710	Meka	\N	5	142518
146477	\N	\N	\N	\N	50420711	Ngiribi	\N	5	142518
146478	\N	\N	\N	\N	50420712	Nokondoda	\N	5	142518
146479	\N	\N	\N	\N	50425101	Lingunza	\N	5	142519
146480	\N	\N	\N	\N	50425102	Nangeta	\N	5	142519
146481	\N	\N	\N	\N	50425103	Zande	\N	5	142519
146482	\N	\N	\N	\N	50430101	Afu	\N	5	142520
146483	\N	\N	\N	\N	50430102	Andwala	\N	5	142520
146484	\N	\N	\N	\N	50430103	Bagbale	\N	5	142520
146485	\N	\N	\N	\N	50430104	Bangi	\N	5	142520
146486	\N	\N	\N	\N	50430105	Biodi	\N	5	142520
146487	\N	\N	\N	\N	50430106	Bitima	\N	5	142520
146488	\N	\N	\N	\N	50430107	Dungu	\N	5	142520
146489	\N	\N	\N	\N	50430108	Gbazi	\N	5	142520
146490	\N	\N	\N	\N	50430109	Kana	\N	5	142520
146491	\N	\N	\N	\N	50430110	Kpepe	\N	5	142520
146492	\N	\N	\N	\N	50430111	Kpezu	\N	5	142520
146493	\N	\N	\N	\N	50430112	Li-Ika	\N	5	142520
146494	\N	\N	\N	\N	50430113	Makusa	\N	5	142520
146495	\N	\N	\N	\N	50430114	Mangondi	\N	5	142520
146496	\N	\N	\N	\N	50430115	Masala	\N	5	142520
146497	\N	\N	\N	\N	50430116	Maya	\N	5	142520
146498	\N	\N	\N	\N	50430117	Mfikapa	\N	5	142520
146499	\N	\N	\N	\N	50430118	Nakpudu	\N	5	142520
146500	\N	\N	\N	\N	50430119	Nambia	\N	5	142520
146501	\N	\N	\N	\N	50430120	Nambiliki	\N	5	142520
146502	\N	\N	\N	\N	50430121	Nandika	\N	5	142520
146503	\N	\N	\N	\N	50430122	Ndedu	\N	5	142520
146504	\N	\N	\N	\N	50430123	Ngbandi	\N	5	142520
146505	\N	\N	\N	\N	50430124	Ngilima	\N	5	142520
146506	\N	\N	\N	\N	50430125	Ngwawela	\N	5	142520
146507	\N	\N	\N	\N	50430126	Sepio	\N	5	142520
146508	\N	\N	\N	\N	50430127	Tongotongo	\N	5	142520
146509	\N	\N	\N	\N	50430128	Ungwa	\N	5	142520
146510	\N	\N	\N	\N	50430201	Biesio	\N	5	142521
146511	\N	\N	\N	\N	50430202	Kikpindi	\N	5	142521
146512	\N	\N	\N	\N	50430203	Lindambia	\N	5	142521
146513	\N	\N	\N	\N	50430204	Makurda	\N	5	142521
146514	\N	\N	\N	\N	50430205	Nambia	\N	5	142521
146515	\N	\N	\N	\N	50430206	Nango	\N	5	142521
146516	\N	\N	\N	\N	50430207	Zigbi	\N	5	142521
146517	\N	\N	\N	\N	50430301	Gangala	\N	5	142522
146518	\N	\N	\N	\N	50430302	Kpindangbala	\N	5	142522
146519	\N	\N	\N	\N	50430303	Magoloko	\N	5	142522
146520	\N	\N	\N	\N	50430304	Mapata	\N	5	142522
146521	\N	\N	\N	\N	50430305	Mbomu	\N	5	142522
146522	\N	\N	\N	\N	50430306	Naisa	\N	5	142522
146523	\N	\N	\N	\N	50430307	Nyavungo	\N	5	142522
146524	\N	\N	\N	\N	50430908	Bague 1	\N	5	142552
146525	\N	\N	\N	\N	50435101	Bamokandi	\N	5	142523
146526	\N	\N	\N	\N	50435102	Ngilima	\N	5	142523
146527	\N	\N	\N	\N	50435103	Uye 1	\N	5	142523
146528	\N	\N	\N	\N	50435104	Uye 2	\N	5	142523
146529	\N	\N	\N	\N	50440101	Budu	\N	5	142524
146530	\N	\N	\N	\N	50440102	Djabir	\N	5	142524
146531	\N	\N	\N	\N	50440103	Ombandroa	\N	5	142524
146532	\N	\N	\N	\N	50440104	Tadu	\N	5	142524
146533	\N	\N	\N	\N	50440105	Tondra-Alimasi	\N	5	142524
146534	\N	\N	\N	\N	50440201	Buru	\N	5	142525
146535	\N	\N	\N	\N	50440202	Missa	\N	5	142525
146536	\N	\N	\N	\N	50440203	Tikadje	\N	5	142525
146537	\N	\N	\N	\N	50440301	Aba-Zungbi	\N	5	142526
146538	\N	\N	\N	\N	50440302	Kirikwa	\N	5	142526
146539	\N	\N	\N	\N	50440303	Lamanda	\N	5	142526
146540	\N	\N	\N	\N	50440304	Sambiri	\N	5	142526
146541	\N	\N	\N	\N	50440401	Dramba	\N	5	142527
146542	\N	\N	\N	\N	50440402	Lagabe	\N	5	142527
146543	\N	\N	\N	\N	50440403	Sagu	\N	5	142527
146544	\N	\N	\N	\N	50440501	Ali	\N	5	142528
146545	\N	\N	\N	\N	50440502	Asigi	\N	5	142528
146546	\N	\N	\N	\N	50440503	Dema	\N	5	142528
146547	\N	\N	\N	\N	50440504	Makakro	\N	5	142528
146548	\N	\N	\N	\N	50440505	Mandango	\N	5	142528
146549	\N	\N	\N	\N	50440506	Manigo	\N	5	142528
146550	\N	\N	\N	\N	50440507	Mude	\N	5	142528
146551	\N	\N	\N	\N	50440601	Alomo	\N	5	142529
146552	\N	\N	\N	\N	50440602	Azay	\N	5	142529
146553	\N	\N	\N	\N	50440603	Maulo	\N	5	142529
146554	\N	\N	\N	\N	50440701	Ambarao	\N	5	142530
146555	\N	\N	\N	\N	50440702	Keraka	\N	5	142530
146556	\N	\N	\N	\N	50440703	Kiri	\N	5	142530
146557	\N	\N	\N	\N	50440704	Makoro	\N	5	142530
146558	\N	\N	\N	\N	50440705	Nakasango	\N	5	142530
146559	\N	\N	\N	\N	50440706	Ndoloma	\N	5	142530
146560	\N	\N	\N	\N	50440801	Dema	\N	5	142531
146561	\N	\N	\N	\N	50440802	Mude	\N	5	142531
146562	\N	\N	\N	\N	50440803	Sima	\N	5	142531
146563	\N	\N	\N	\N	50445103	Njura	\N	5	142532
146564	\N	\N	\N	\N	50445201	Kirikwa	\N	5	142533
146565	\N	\N	\N	\N	50445202	Sambili	\N	5	142533
146566	\N	\N	\N	\N	50445203	Zungbi	\N	5	142533
146567	\N	\N	\N	\N	50450101	Andamonoso	\N	5	142534
146568	\N	\N	\N	\N	50450102	Baitebi	\N	5	142534
146569	\N	\N	\N	\N	50450103	Ebi	\N	5	142534
146570	\N	\N	\N	\N	50450104	Kalukisu	\N	5	142534
146571	\N	\N	\N	\N	50450105	Ngoya	\N	5	142534
146572	\N	\N	\N	\N	50450106	Sofotude	\N	5	142534
146573	\N	\N	\N	\N	50450201	Ambanani	\N	5	142535
146574	\N	\N	\N	\N	50450202	Apodo	\N	5	142535
146575	\N	\N	\N	\N	50450203	Ligoya	\N	5	142535
146576	\N	\N	\N	\N	50450301	Batitia	\N	5	142536
146577	\N	\N	\N	\N	50450302	Difolo	\N	5	142536
146578	\N	\N	\N	\N	50450303	Dondi	\N	5	142536
146579	\N	\N	\N	\N	50450304	Gialou	\N	5	142536
146580	\N	\N	\N	\N	50450305	Kpau	\N	5	142536
146581	\N	\N	\N	\N	50450401	Andikolo	\N	5	142537
146582	\N	\N	\N	\N	50450402	Doratazi	\N	5	142537
146583	\N	\N	\N	\N	50450403	Konzokondu	\N	5	142537
146584	\N	\N	\N	\N	50450404	Mengo	\N	5	142537
146585	\N	\N	\N	\N	50450405	Modigu	\N	5	142537
146586	\N	\N	\N	\N	50450406	Ndey	\N	5	142537
146587	\N	\N	\N	\N	50450407	Tosiga	\N	5	142537
146588	\N	\N	\N	\N	50450501	Bari-Karo	\N	5	142538
146589	\N	\N	\N	\N	50450502	Bari-Moka	\N	5	142538
146590	\N	\N	\N	\N	50450503	Mangbele	\N	5	142538
146591	\N	\N	\N	\N	50450504	Mayanga	\N	5	142538
146592	\N	\N	\N	\N	50450601	Anguley	\N	5	142539
146593	\N	\N	\N	\N	50450602	Bugutali	\N	5	142539
146594	\N	\N	\N	\N	50450603	Efelomi	\N	5	142539
146595	\N	\N	\N	\N	50450604	Gbandi	\N	5	142539
146596	\N	\N	\N	\N	50450605	Kanyaba	\N	5	142539
146597	\N	\N	\N	\N	50450606	Kenebe	\N	5	142539
146598	\N	\N	\N	\N	50450607	Kpegukobo	\N	5	142539
146599	\N	\N	\N	\N	50450608	Mangoto	\N	5	142539
146600	\N	\N	\N	\N	50450609	Obelendi	\N	5	142539
146601	\N	\N	\N	\N	50450610	Teka	\N	5	142539
146602	\N	\N	\N	\N	50450611	Tulundrue	\N	5	142539
146603	\N	\N	\N	\N	50450612	Tumu	\N	5	142539
146604	\N	\N	\N	\N	50450701	Angoley	\N	5	142540
146605	\N	\N	\N	\N	50450702	Kengelo	\N	5	142540
146606	\N	\N	\N	\N	50450703	Tora	\N	5	142540
146607	\N	\N	\N	\N	50450704	Mandra-Mandra	\N	5	142540
146608	\N	\N	\N	\N	50450801	Alulembani	\N	5	142541
146609	\N	\N	\N	\N	50450802	Arebi	\N	5	142541
146610	\N	\N	\N	\N	50450803	Ariokota	\N	5	142541
146611	\N	\N	\N	\N	50450804	Awilaba	\N	5	142541
146612	\N	\N	\N	\N	50450805	Dubele	\N	5	142541
146613	\N	\N	\N	\N	50450806	Genedi	\N	5	142541
146614	\N	\N	\N	\N	50450807	Gima	\N	5	142541
146615	\N	\N	\N	\N	50450808	Kongbo	\N	5	142541
146616	\N	\N	\N	\N	50450809	Kotaza	\N	5	142541
146617	\N	\N	\N	\N	50450810	Lindikoda	\N	5	142541
146618	\N	\N	\N	\N	50450811	Magoruza	\N	5	142541
146619	\N	\N	\N	\N	50450812	Makala	\N	5	142541
146620	\N	\N	\N	\N	50450813	Makowe	\N	5	142541
146621	\N	\N	\N	\N	50450814	Mangozo	\N	5	142541
146622	\N	\N	\N	\N	50450815	Ombando	\N	5	142541
146623	\N	\N	\N	\N	50450816	Ozulukpi	\N	5	142541
146624	\N	\N	\N	\N	50450901	Andazo	\N	5	142542
146625	\N	\N	\N	\N	50450902	Andikamata	\N	5	142542
146626	\N	\N	\N	\N	50450903	Andosa	\N	5	142542
146627	\N	\N	\N	\N	50450904	Embio	\N	5	142542
146628	\N	\N	\N	\N	50450905	Emole	\N	5	142542
146629	\N	\N	\N	\N	50450906	Kubi	\N	5	142542
146630	\N	\N	\N	\N	50450907	Mambakadi	\N	5	142542
146631	\N	\N	\N	\N	50450908	Ngevea	\N	5	142542
146632	\N	\N	\N	\N	50450909	Ondemulau	\N	5	142542
146633	\N	\N	\N	\N	50450910	Telekudu-Nosi	\N	5	142542
146634	\N	\N	\N	\N	50455101	Ganoza	\N	5	142543
146635	\N	\N	\N	\N	50455102	Kibali	\N	5	142543
146636	\N	\N	\N	\N	50455103	Kilo-Moto	\N	5	142543
146637	\N	\N	\N	\N	50455104	Mangombo	\N	5	142543
146638	\N	\N	\N	\N	50455105	Mangoro	\N	5	142543
146639	\N	\N	\N	\N	50455106	Mines	\N	5	142543
146640	\N	\N	\N	\N	50455107	Tomo	\N	5	142543
146641	\N	\N	\N	\N	50460101	Babondakane	\N	5	142544
146642	\N	\N	\N	\N	50460102	Babonde	\N	5	142544
146643	\N	\N	\N	\N	50460103	Bafwasamowa	\N	5	142544
146644	\N	\N	\N	\N	50460104	Baromise	\N	5	142544
146645	\N	\N	\N	\N	50460105	Bavaingbe	\N	5	142544
146646	\N	\N	\N	\N	50460106	Bavakini	\N	5	142544
146647	\N	\N	\N	\N	50460107	Bavatuko	\N	5	142544
146648	\N	\N	\N	\N	50460108	Kokoo	\N	5	142544
146649	\N	\N	\N	\N	50460109	Legbo	\N	5	142544
146650	\N	\N	\N	\N	50460110	Mandele	\N	5	142544
146651	\N	\N	\N	\N	50460111	Manungbe	\N	5	142544
146652	\N	\N	\N	\N	50460112	Mbangana	\N	5	142544
146653	\N	\N	\N	\N	50460113	Toku	\N	5	142544
146654	\N	\N	\N	\N	50460201	Babia	\N	5	142545
146655	\N	\N	\N	\N	50460202	Babonde	\N	5	142545
146656	\N	\N	\N	\N	50460203	Badedeka	\N	5	142545
146657	\N	\N	\N	\N	50460204	Bakpele	\N	5	142545
146658	\N	\N	\N	\N	50460205	Bamuka	\N	5	142545
146659	\N	\N	\N	\N	50460206	Bangombo	\N	5	142545
146660	\N	\N	\N	\N	50460207	Bape	\N	5	142545
146661	\N	\N	\N	\N	50460208	Bavabazoa	\N	5	142545
146662	\N	\N	\N	\N	50460209	Bavanasia	\N	5	142545
146663	\N	\N	\N	\N	50460210	Bavandangba	\N	5	142545
146664	\N	\N	\N	\N	50460211	Bavangbaka	\N	5	142545
146665	\N	\N	\N	\N	50460212	Bavasamba	\N	5	142545
146666	\N	\N	\N	\N	50460213	Baveguku	\N	5	142545
146667	\N	\N	\N	\N	50460214	Bavendeni	\N	5	142545
146668	\N	\N	\N	\N	50460215	Bavengieni	\N	5	142545
146669	\N	\N	\N	\N	50460216	Bavendename	\N	5	142545
146670	\N	\N	\N	\N	50460217	Bovobondoni	\N	5	142545
146671	\N	\N	\N	\N	50460218	Bovombili	\N	5	142545
146672	\N	\N	\N	\N	50460219	Bovotukusangwa	\N	5	142545
146673	\N	\N	\N	\N	50460301	Babesiane	\N	5	142546
146674	\N	\N	\N	\N	50460302	Badabu	\N	5	142546
146675	\N	\N	\N	\N	50460303	Bamako	\N	5	142546
146676	\N	\N	\N	\N	50460304	Bamapuno	\N	5	142546
146677	\N	\N	\N	\N	50460305	Bamudo	\N	5	142546
146678	\N	\N	\N	\N	50460306	Bangama	\N	5	142546
146679	\N	\N	\N	\N	50460307	Bangoma	\N	5	142546
146680	\N	\N	\N	\N	50460308	Batite	\N	5	142546
146681	\N	\N	\N	\N	50460309	Batugba 1	\N	5	142546
146682	\N	\N	\N	\N	50460310	Batugba 2	\N	5	142546
146683	\N	\N	\N	\N	50460311	Batugba Guy	\N	5	142546
146684	\N	\N	\N	\N	50460401	Bafadowa	\N	5	142547
146685	\N	\N	\N	\N	50460402	Bagboyala/A	\N	5	142547
146686	\N	\N	\N	\N	50460403	Bagboyala/B	\N	5	142547
146687	\N	\N	\N	\N	50460404	Bagomba	\N	5	142547
146688	\N	\N	\N	\N	50460405	Bakenge	\N	5	142547
146689	\N	\N	\N	\N	50460406	Bakpolo	\N	5	142547
146690	\N	\N	\N	\N	50460407	Bangambasi	\N	5	142547
146691	\N	\N	\N	\N	50460408	Bangese	\N	5	142547
146692	\N	\N	\N	\N	50460409	Enganzo	\N	5	142547
146693	\N	\N	\N	\N	50460410	Nambose	\N	5	142547
146694	\N	\N	\N	\N	50460501	Babepoyo	\N	5	142548
146695	\N	\N	\N	\N	50460502	Bachanzasili	\N	5	142548
146696	\N	\N	\N	\N	50460503	Bamatese	\N	5	142548
146697	\N	\N	\N	\N	50460504	Bananga	\N	5	142548
146698	\N	\N	\N	\N	50460505	Banechane	\N	5	142548
146699	\N	\N	\N	\N	50460506	Basobuo	\N	5	142548
146700	\N	\N	\N	\N	50460507	Basaongboa	\N	5	142548
146701	\N	\N	\N	\N	50460508	Batukondey	\N	5	142548
146702	\N	\N	\N	\N	50460509	Batukusaluka	\N	5	142548
146703	\N	\N	\N	\N	50460510	Bengwe	\N	5	142548
146704	\N	\N	\N	\N	50460511	Digi	\N	5	142548
146705	\N	\N	\N	\N	50460512	Dududu	\N	5	142548
146706	\N	\N	\N	\N	50460513	Enzato	\N	5	142548
146707	\N	\N	\N	\N	50460514	Etakamu Kongo	\N	5	142548
146708	\N	\N	\N	\N	50460515	Mayanga	\N	5	142548
146709	\N	\N	\N	\N	50460516	Ndey	\N	5	142548
146710	\N	\N	\N	\N	50460601	Baboa/Boma	\N	5	142549
146711	\N	\N	\N	\N	50460602	Babosi	\N	5	142549
146712	\N	\N	\N	\N	50460603	Babuma	\N	5	142549
146713	\N	\N	\N	\N	50460604	Bachini	\N	5	142549
146714	\N	\N	\N	\N	50460605	Badebongo	\N	5	142549
146715	\N	\N	\N	\N	50460606	Bafwakwambo	\N	5	142549
146716	\N	\N	\N	\N	50460607	Bagbay	\N	5	142549
146717	\N	\N	\N	\N	50460608	Bakana	\N	5	142549
146718	\N	\N	\N	\N	50460609	Bakpele	\N	5	142549
146719	\N	\N	\N	\N	50460610	Bakese	\N	5	142549
146720	\N	\N	\N	\N	50460611	Bakondabee	\N	5	142549
146721	\N	\N	\N	\N	50460612	Bakpangbaa	\N	5	142549
146722	\N	\N	\N	\N	50460613	Bakunga	\N	5	142549
146723	\N	\N	\N	\N	50460614	Bamonyake 1	\N	5	142549
146724	\N	\N	\N	\N	50460615	Bamonyake 2	\N	5	142549
146725	\N	\N	\N	\N	50460616	Bangbo	\N	5	142549
146726	\N	\N	\N	\N	50460617	Bapalay	\N	5	142549
146727	\N	\N	\N	\N	50460618	Bawoya	\N	5	142549
146728	\N	\N	\N	\N	50460619	Gbagayi	\N	5	142549
146729	\N	\N	\N	\N	50460620	Malamba	\N	5	142549
146730	\N	\N	\N	\N	50460621	Naboo	\N	5	142549
146731	\N	\N	\N	\N	50460701	Mababaka	\N	5	142550
146732	\N	\N	\N	\N	50460702	Magbituku	\N	5	142550
146733	\N	\N	\N	\N	50460703	Makilimade	\N	5	142550
146734	\N	\N	\N	\N	50460704	Makpoguse	\N	5	142550
146735	\N	\N	\N	\N	50460705	Mavaobea	\N	5	142550
146736	\N	\N	\N	\N	50460706	Mavamasage	\N	5	142550
146737	\N	\N	\N	\N	50460707	Mavamukpo	\N	5	142550
146738	\N	\N	\N	\N	50460708	Mavangaluma	\N	5	142550
146739	\N	\N	\N	\N	50460801	Bakpekpee	\N	5	142551
146740	\N	\N	\N	\N	50460802	Bavabola	\N	5	142551
146741	\N	\N	\N	\N	50460803	Bavagbasi 1	\N	5	142551
146742	\N	\N	\N	\N	50460804	Bavagbasi 2	\N	5	142551
146743	\N	\N	\N	\N	50460805	Bavalo 1	\N	5	142551
146744	\N	\N	\N	\N	50460806	Bavalo 2	\N	5	142551
146745	\N	\N	\N	\N	50460807	Bavalo 3	\N	5	142551
146746	\N	\N	\N	\N	50460808	Bavaluu	\N	5	142551
146747	\N	\N	\N	\N	50460809	Bavamba	\N	5	142551
146748	\N	\N	\N	\N	50460810	Bavani	\N	5	142551
146749	\N	\N	\N	\N	50460811	Bavasueme	\N	5	142551
146750	\N	\N	\N	\N	50460812	Bavatasi	\N	5	142551
146751	\N	\N	\N	\N	50460813	Baveda 1	\N	5	142551
146752	\N	\N	\N	\N	50460814	Baveda 2	\N	5	142551
146753	\N	\N	\N	\N	50460815	Bavedea	\N	5	142551
146754	\N	\N	\N	\N	50460901	Atataka	\N	5	142552
146755	\N	\N	\N	\N	50460902	Andjakani 2	\N	5	142552
146756	\N	\N	\N	\N	50460903	Angbanga 1	\N	5	142552
146757	\N	\N	\N	\N	50460904	Angbanga 2	\N	5	142552
146758	\N	\N	\N	\N	50460905	Anzaga	\N	5	142552
146759	\N	\N	\N	\N	50460906	Babesu	\N	5	142552
146760	\N	\N	\N	\N	50460907	Bagoya	\N	5	142552
146761	\N	\N	\N	\N	50460909	Bague 2	\N	5	142552
146762	\N	\N	\N	\N	50460910	Basokono	\N	5	142552
146763	\N	\N	\N	\N	50460911	Batatoa	\N	5	142552
146764	\N	\N	\N	\N	50460912	Bedegao	\N	5	142552
146765	\N	\N	\N	\N	50460913	Bindani	\N	5	142552
146766	\N	\N	\N	\N	50460914	Bobombi	\N	5	142552
146767	\N	\N	\N	\N	50460915	Bogoga	\N	5	142552
146768	\N	\N	\N	\N	50460916	Degana	\N	5	142552
146769	\N	\N	\N	\N	50460917	Ekanga	\N	5	142552
146770	\N	\N	\N	\N	50460918	Ibiatuku	\N	5	142552
146771	\N	\N	\N	\N	50460919	Kati	\N	5	142552
146772	\N	\N	\N	\N	50460920	Likupe	\N	5	142552
146773	\N	\N	\N	\N	50461001	Babogi	\N	5	142553
146774	\N	\N	\N	\N	50461002	Basokobebe	\N	5	142553
146775	\N	\N	\N	\N	50461003	Bavabao	\N	5	142553
146776	\N	\N	\N	\N	50461004	Bavambi	\N	5	142553
146777	\N	\N	\N	\N	50461005	Bavandomi	\N	5	142553
146778	\N	\N	\N	\N	50461006	Bavanombembe	\N	5	142553
146779	\N	\N	\N	\N	50461007	Bavasengi	\N	5	142553
146780	\N	\N	\N	\N	50461008	Bavatueni	\N	5	142553
146781	\N	\N	\N	\N	50461101	Bamatetaka	\N	5	142554
146782	\N	\N	\N	\N	50461102	Bedegao	\N	5	142554
146783	\N	\N	\N	\N	50461103	Embanzame	\N	5	142554
146784	\N	\N	\N	\N	50461104	Engbeya	\N	5	142554
146785	\N	\N	\N	\N	50461105	Kalatende	\N	5	142554
146786	\N	\N	\N	\N	50461106	Koloya	\N	5	142554
146787	\N	\N	\N	\N	50461107	Likupe	\N	5	142554
146788	\N	\N	\N	\N	50461108	Manzabi	\N	5	142554
146789	\N	\N	\N	\N	50461109	Mashinga	\N	5	142554
146790	\N	\N	\N	\N	50461110	Sagbo	\N	5	142554
146791	\N	\N	\N	\N	50465101	Gbandi	\N	5	142555
146792	\N	\N	\N	\N	50465102	Kuleo	\N	5	142555
146793	\N	\N	\N	\N	50465103	Mangbukele	\N	5	142555
146794	\N	\N	\N	\N	50465104	Ndokanjulu	\N	5	142555
146795	\N	\N	\N	\N	50465105	Victimes des Rebelles	\N	5	142555
146796	\N	\N	\N	\N	50510101	Akawanza/B	\N	5	142556
146797	\N	\N	\N	\N	50510102	Bandavisemba	\N	5	142556
146798	\N	\N	\N	\N	50510103	Bandingili	\N	5	142556
146799	\N	\N	\N	\N	50510104	Bokucho-Mont Hoyo	\N	5	142556
146800	\N	\N	\N	\N	50510201	Bandiemusu	\N	5	142557
146801	\N	\N	\N	\N	50510202	Basumu	\N	5	142557
146802	\N	\N	\N	\N	50510203	Makabo	\N	5	142557
146803	\N	\N	\N	\N	50510301	Sopa-Badia	\N	5	142558
146804	\N	\N	\N	\N	50510302	Tsere	\N	5	142558
146805	\N	\N	\N	\N	50510401	Kunda	\N	5	142559
146806	\N	\N	\N	\N	50510402	Mazangima	\N	5	142559
146807	\N	\N	\N	\N	50510403	Ngombenyama	\N	5	142559
146808	\N	\N	\N	\N	50510404	Ngongo	\N	5	142559
146809	\N	\N	\N	\N	50510501	Babulaba	\N	5	142560
146810	\N	\N	\N	\N	50510502	Babulogu/B	\N	5	142560
146811	\N	\N	\N	\N	50510503	Babutsuka/B	\N	5	142560
146812	\N	\N	\N	\N	50510504	Badjaguru-Nzere	\N	5	142560
146813	\N	\N	\N	\N	50510505	Batali-Nyala	\N	5	142560
146814	\N	\N	\N	\N	50510506	Bavandi-Chengabo	\N	5	142560
146815	\N	\N	\N	\N	50510601	Babiase Bogoro	\N	5	142561
146816	\N	\N	\N	\N	50510602	Bandikatso-Nyaa	\N	5	142561
146817	\N	\N	\N	\N	50510603	Bandiwango/K	\N	5	142561
146818	\N	\N	\N	\N	50510604	Bangungu-Ndrigi	\N	5	142561
146819	\N	\N	\N	\N	50510605	Beizima-Ka	\N	5	142561
146820	\N	\N	\N	\N	50510606	Bundikasa-Bunia	\N	5	142561
146821	\N	\N	\N	\N	50510701	Bamuko	\N	5	142562
146822	\N	\N	\N	\N	50510702	Baviba	\N	5	142562
146823	\N	\N	\N	\N	50510703	Boloma	\N	5	142562
146824	\N	\N	\N	\N	50510704	Bukiringi	\N	5	142562
146825	\N	\N	\N	\N	50510705	Zadu-Zutono	\N	5	142562
146826	\N	\N	\N	\N	50510801	Bitima	\N	5	142563
146827	\N	\N	\N	\N	50510802	Mitego	\N	5	142563
146828	\N	\N	\N	\N	50510901	Buley	\N	5	142564
146829	\N	\N	\N	\N	50510902	Rubingo	\N	5	142564
146830	\N	\N	\N	\N	50511001	Bakwadi	\N	5	142565
146831	\N	\N	\N	\N	50511002	Tondoli	\N	5	142565
146832	\N	\N	\N	\N	50511101	Chiniya kilima	\N	5	142566
146833	\N	\N	\N	\N	50511102	Loy-Bangaga	\N	5	142566
146834	\N	\N	\N	\N	50511103	Sibabo	\N	5	142566
146835	\N	\N	\N	\N	50511201	Balwahana	\N	5	142567
146836	\N	\N	\N	\N	50511202	Marabo-Mos	\N	5	142567
146837	\N	\N	\N	\N	50511203	Mayaribo	\N	5	142567
146838	\N	\N	\N	\N	50515201	Bankoko	\N	5	142569
146839	\N	\N	\N	\N	50515202	Kindia	\N	5	142569
146840	\N	\N	\N	\N	50515203	Lembabo	\N	5	142569
146841	\N	\N	\N	\N	50515204	Lumumba	\N	5	142569
146842	\N	\N	\N	\N	50515205	Mudzi Pela	\N	5	142569
146843	\N	\N	\N	\N	50515206	Ngezi	\N	5	142569
146844	\N	\N	\N	\N	50515207	Nyakasanza	\N	5	142569
146845	\N	\N	\N	\N	50515208	Ruambuzi	\N	5	142569
146846	\N	\N	\N	\N	50515209	Saio	\N	5	142569
146847	\N	\N	\N	\N	50515210	Salongo	\N	5	142569
146848	\N	\N	\N	\N	50515211	Simbiliambo	\N	5	142569
146849	\N	\N	\N	\N	50515212	Sukisa	\N	5	142569
146850	\N	\N	\N	\N	50520101	Basiri	\N	5	142570
146851	\N	\N	\N	\N	50520201	Babunda	\N	5	142571
146852	\N	\N	\N	\N	50520202	Bafwakoa	\N	5	142571
146853	\N	\N	\N	\N	50520203	Epulu	\N	5	142571
146854	\N	\N	\N	\N	50520204	Ngayu	\N	5	142571
146855	\N	\N	\N	\N	50520205	Nia-Nia	\N	5	142571
146856	\N	\N	\N	\N	50520301	Andape	\N	5	142572
146857	\N	\N	\N	\N	50520302	Andisongi	\N	5	142572
146858	\N	\N	\N	\N	50520303	Angali	\N	5	142572
146859	\N	\N	\N	\N	50520401	Andifere	\N	5	142573
146860	\N	\N	\N	\N	50520402	Andikau	\N	5	142573
146861	\N	\N	\N	\N	50520403	Andubuta	\N	5	142573
146862	\N	\N	\N	\N	50520404	Maro	\N	5	142573
146863	\N	\N	\N	\N	50520405	Muli-Karo	\N	5	142573
146864	\N	\N	\N	\N	50520501	Bakwanza	\N	5	142574
146865	\N	\N	\N	\N	50520502	Bapuele	\N	5	142574
146866	\N	\N	\N	\N	50520503	Bayau	\N	5	142574
146867	\N	\N	\N	\N	50520601	Babombi	\N	5	142575
146868	\N	\N	\N	\N	50520602	Bakaeku	\N	5	142575
146869	\N	\N	\N	\N	50520603	Bakongoni	\N	5	142575
146870	\N	\N	\N	\N	50520604	Bangole	\N	5	142575
146871	\N	\N	\N	\N	50520605	Bashi	\N	5	142575
146872	\N	\N	\N	\N	50520606	Baswagha	\N	5	142575
146873	\N	\N	\N	\N	50520607	Batangi	\N	5	142575
146874	\N	\N	\N	\N	50520701	Bimase	\N	5	142576
146875	\N	\N	\N	\N	50520702	Mputu	\N	5	142576
146876	\N	\N	\N	\N	50520703	Nyangwe	\N	5	142576
146877	\N	\N	\N	\N	50530101	Sala	\N	5	142578
146878	\N	\N	\N	\N	50530102	Tambaki	\N	5	142578
146879	\N	\N	\N	\N	50530103	Tchomia	\N	5	142578
146880	\N	\N	\N	\N	50530201	Kabakaba	\N	5	142579
146881	\N	\N	\N	\N	50530202	Kama	\N	5	142579
146882	\N	\N	\N	\N	50530203	Karani	\N	5	142579
146883	\N	\N	\N	\N	50530204	Mabilindey	\N	5	142579
146884	\N	\N	\N	\N	50530205	Tchibitchibi	\N	5	142579
146885	\N	\N	\N	\N	50530206	Wadjabo	\N	5	142579
146886	\N	\N	\N	\N	50530207	Kirongozi	\N	5	142579
146887	\N	\N	\N	\N	50530208	Mondey	\N	5	142579
146888	\N	\N	\N	\N	50530209	Katchetche	\N	5	142579
146889	\N	\N	\N	\N	50530210	Agonema	\N	5	142579
146890	\N	\N	\N	\N	50530211	Benzamagozo	\N	5	142579
146891	\N	\N	\N	\N	50530301	Okere	\N	5	142580
146892	\N	\N	\N	\N	50530302	Zamamba	\N	5	142580
146893	\N	\N	\N	\N	50530303	Kama	\N	5	142580
146894	\N	\N	\N	\N	50530304	Akando	\N	5	142580
146895	\N	\N	\N	\N	50530305	Bongo-Bongo	\N	5	142580
146896	\N	\N	\N	\N	50530306	Suantabi	\N	5	142580
146897	\N	\N	\N	\N	50530307	Buna	\N	5	142580
146898	\N	\N	\N	\N	50530401	Buba	\N	5	142581
146899	\N	\N	\N	\N	50530402	Dhendo	\N	5	142581
146900	\N	\N	\N	\N	50530403	Djina	\N	5	142581
146901	\N	\N	\N	\N	50530404	Kwadruma	\N	5	142581
146902	\N	\N	\N	\N	50530405	Audjo	\N	5	142581
146903	\N	\N	\N	\N	50530406	Mbrebu	\N	5	142581
146904	\N	\N	\N	\N	50530501	Buku-Jokpa	\N	5	142582
146905	\N	\N	\N	\N	50530502	Utche	\N	5	142582
146906	\N	\N	\N	\N	50530503	Dirokpa	\N	5	142582
146907	\N	\N	\N	\N	50530504	Losa-Ndrena	\N	5	142582
146908	\N	\N	\N	\N	50530505	Dhendro	\N	5	142582
146909	\N	\N	\N	\N	50530506	Luvangira	\N	5	142582
146910	\N	\N	\N	\N	50530507	Malabo	\N	5	142582
146911	\N	\N	\N	\N	50530508	Risasi	\N	5	142582
146912	\N	\N	\N	\N	50530509	Sombuso	\N	5	142582
146913	\N	\N	\N	\N	50530510	Ingo (Singo)	\N	5	142582
146914	\N	\N	\N	\N	50530601	Betu-Ezekere	\N	5	142583
146915	\N	\N	\N	\N	50530602	Gobi	\N	5	142583
146916	\N	\N	\N	\N	50530603	Loga	\N	5	142583
146917	\N	\N	\N	\N	50530604	Peny	\N	5	142583
146918	\N	\N	\N	\N	50530605	Saliboko	\N	5	142583
146919	\N	\N	\N	\N	50530606	Piloo	\N	5	142583
146920	\N	\N	\N	\N	50530607	Tsoti (Tsati)	\N	5	142583
146921	\N	\N	\N	\N	50530608	Bodo	\N	5	142583
146922	\N	\N	\N	\N	50530701	Kepa	\N	5	142584
146923	\N	\N	\N	\N	50530702	Kpandima	\N	5	142584
146924	\N	\N	\N	\N	50530703	Lodha	\N	5	142584
146925	\N	\N	\N	\N	50530704	Londroma	\N	5	142584
146926	\N	\N	\N	\N	50530705	Ndikpa	\N	5	142584
146927	\N	\N	\N	\N	50530706	Taratibo	\N	5	142584
146928	\N	\N	\N	\N	50530707	Mandje	\N	5	142584
146929	\N	\N	\N	\N	50530708	Mayalibo	\N	5	142584
146930	\N	\N	\N	\N	50530709	Tchodjo	\N	5	142584
146931	\N	\N	\N	\N	50530710	Abini	\N	5	142584
146932	\N	\N	\N	\N	50530711	Pengo	\N	5	142584
146933	\N	\N	\N	\N	50530801	Akpa	\N	5	142585
146934	\N	\N	\N	\N	50530802	Ndjubu	\N	5	142585
146935	\N	\N	\N	\N	50530803	Ngakpa	\N	5	142585
146936	\N	\N	\N	\N	50530804	Uketa	\N	5	142585
146937	\N	\N	\N	\N	50530805	Wiri	\N	5	142585
146938	\N	\N	\N	\N	50530901	Djina	\N	5	142586
146939	\N	\N	\N	\N	50530902	Djugu	\N	5	142586
146940	\N	\N	\N	\N	50530903	Fataki	\N	5	142586
146941	\N	\N	\N	\N	50530904	Sesele	\N	5	142586
146942	\N	\N	\N	\N	50530905	Tchundja	\N	5	142586
146943	\N	\N	\N	\N	50530906	Ugu	\N	5	142586
146944	\N	\N	\N	\N	50531001	Dhedja	\N	5	142587
146945	\N	\N	\N	\N	50531002	Dhego	\N	5	142587
146946	\N	\N	\N	\N	50531003	Djaba	\N	5	142587
146947	\N	\N	\N	\N	50531004	Lona	\N	5	142587
146948	\N	\N	\N	\N	50531005	Dhendro	\N	5	142587
146949	\N	\N	\N	\N	50531006	Ngile	\N	5	142587
146950	\N	\N	\N	\N	50535101	Kpadju	\N	5	142588
146951	\N	\N	\N	\N	50535102	Loranu	\N	5	142588
146952	\N	\N	\N	\N	50535201	Dcg	\N	5	142589
146953	\N	\N	\N	\N	50535202	Depot	\N	5	142589
146954	\N	\N	\N	\N	50535203	Kilo-Moto	\N	5	142589
146955	\N	\N	\N	\N	50535204	Shuni	\N	5	142589
146956	\N	\N	\N	\N	50535205	Zubula	\N	5	142589
146957	\N	\N	\N	\N	50540101	Adraa	\N	5	142590
146958	\N	\N	\N	\N	50540102	Nzaba	\N	5	142590
146959	\N	\N	\N	\N	50540103	Shari	\N	5	142590
146960	\N	\N	\N	\N	50540201	Aupa	\N	5	142591
146961	\N	\N	\N	\N	50540202	Djupakanya	\N	5	142591
146962	\N	\N	\N	\N	50540203	Koch-Lala	\N	5	142591
146963	\N	\N	\N	\N	50540204	Kusu	\N	5	142591
146964	\N	\N	\N	\N	50540301	Djupamamba	\N	5	142592
146965	\N	\N	\N	\N	50540302	Gosi	\N	5	142592
146966	\N	\N	\N	\N	50540303	Padeya	\N	5	142592
146967	\N	\N	\N	\N	50540304	Palara	\N	5	142592
146968	\N	\N	\N	\N	50540305	Pikuonga	\N	5	142592
146969	\N	\N	\N	\N	50540401	Adra-Abira	\N	5	142593
146970	\N	\N	\N	\N	50540402	Agbwa	\N	5	142593
146971	\N	\N	\N	\N	50540403	Akezu	\N	5	142593
146972	\N	\N	\N	\N	50540404	Alur	\N	5	142593
146973	\N	\N	\N	\N	50540405	Awoo	\N	5	142593
146974	\N	\N	\N	\N	50540406	Djupagasa	\N	5	142593
146975	\N	\N	\N	\N	50540407	Djupio	\N	5	142593
146976	\N	\N	\N	\N	50540408	Paranhor	\N	5	142593
146977	\N	\N	\N	\N	50540409	Sabu	\N	5	142593
146978	\N	\N	\N	\N	50540410	Urii	\N	5	142593
146979	\N	\N	\N	\N	50540411	Nzinzi	\N	5	142593
146980	\N	\N	\N	\N	50540501	Angusa	\N	5	142594
146981	\N	\N	\N	\N	50540502	Djupasongi	\N	5	142594
146982	\N	\N	\N	\N	50540601	Apala	\N	5	142595
146983	\N	\N	\N	\N	50540602	Aree	\N	5	142595
146984	\N	\N	\N	\N	50540603	Dawasi	\N	5	142595
146985	\N	\N	\N	\N	50540604	Labo	\N	5	142595
146986	\N	\N	\N	\N	50540605	Musongwa	\N	5	142595
146987	\N	\N	\N	\N	50540606	Ruvinga	\N	5	142595
146988	\N	\N	\N	\N	50540701	Berungi	\N	5	142596
146989	\N	\N	\N	\N	50540702	Djupa-Nualengi	\N	5	142596
146990	\N	\N	\N	\N	50540703	Djupawalu-Luu	\N	5	142596
146991	\N	\N	\N	\N	50540704	Djupujom	\N	5	142596
146992	\N	\N	\N	\N	50540705	Pamitu-Amese	\N	5	142596
146993	\N	\N	\N	\N	50540706	Parker	\N	5	142596
146994	\N	\N	\N	\N	50540801	Akapa	\N	5	142597
146995	\N	\N	\N	\N	50540802	Ngote	\N	5	142597
146996	\N	\N	\N	\N	50540803	Rona	\N	5	142597
146997	\N	\N	\N	\N	50545101	Djumba	\N	5	142598
146998	\N	\N	\N	\N	50545102	Drii	\N	5	142598
146999	\N	\N	\N	\N	50550101	Biringi	\N	5	142599
147000	\N	\N	\N	\N	50550102	Kandoy	\N	5	142599
147001	\N	\N	\N	\N	50550103	Obitabu	\N	5	142599
147002	\N	\N	\N	\N	50550104	Rungu	\N	5	142599
147003	\N	\N	\N	\N	50550201	Doya	\N	5	142600
147004	\N	\N	\N	\N	50550202	Katsa-Mado	\N	5	142600
147005	\N	\N	\N	\N	50550203	Oli	\N	5	142600
147006	\N	\N	\N	\N	50550204	Popo	\N	5	142600
147007	\N	\N	\N	\N	50550205	Wala	\N	5	142600
147008	\N	\N	\N	\N	50550301	Adumi	\N	5	142601
147009	\N	\N	\N	\N	50550302	Driso	\N	5	142601
147010	\N	\N	\N	\N	50550303	Inzi	\N	5	142601
147011	\N	\N	\N	\N	50550304	Kumuru	\N	5	142601
147012	\N	\N	\N	\N	50550305	Rumu	\N	5	142601
147013	\N	\N	\N	\N	50550401	Abedju	\N	5	142602
147014	\N	\N	\N	\N	50550402	Adja	\N	5	142602
147015	\N	\N	\N	\N	50550403	Adobea	\N	5	142602
147016	\N	\N	\N	\N	50550404	Angila	\N	5	142602
147017	\N	\N	\N	\N	50550405	Angura	\N	5	142602
147018	\N	\N	\N	\N	50550406	Apaa	\N	5	142602
147019	\N	\N	\N	\N	50550407	Atsinia	\N	5	142602
147020	\N	\N	\N	\N	50550408	Lolo	\N	5	142602
147021	\N	\N	\N	\N	50550409	Ndey	\N	5	142602
147022	\N	\N	\N	\N	50550410	Ovisoma	\N	5	142602
147023	\N	\N	\N	\N	50550411	Rogale	\N	5	142602
147024	\N	\N	\N	\N	50550501	Araba	\N	5	142603
147025	\N	\N	\N	\N	50550502	Ofika	\N	5	142603
147026	\N	\N	\N	\N	50550503	Zurupani	\N	5	142603
147027	\N	\N	\N	\N	50550601	Atekule	\N	5	142604
147028	\N	\N	\N	\N	50550602	Eru	\N	5	142604
147029	\N	\N	\N	\N	50550701	Alivu-Vumba	\N	5	142605
147030	\N	\N	\N	\N	50550702	Gombiri	\N	5	142605
147031	\N	\N	\N	\N	50550703	Nyata-Odru	\N	5	142605
147032	\N	\N	\N	\N	50550704	Ofaka	\N	5	142605
147033	\N	\N	\N	\N	50550705	Ongoa	\N	5	142605
147034	\N	\N	\N	\N	50550801	Apinaka	\N	5	142606
147035	\N	\N	\N	\N	50550802	Asumba	\N	5	142606
147036	\N	\N	\N	\N	50550803	Djamba	\N	5	142606
147037	\N	\N	\N	\N	50550804	Edionga	\N	5	142606
147038	\N	\N	\N	\N	50555101	Esepe	\N	5	142607
147039	\N	\N	\N	\N	50555102	Katanga	\N	5	142607
147040	\N	\N	\N	\N	50555103	Kumu-Toongu	\N	5	142607
147041	\N	\N	\N	\N	50555104	Route Aba	\N	5	142607
147042	\N	\N	\N	\N	51200009	Tshatshi	\N	5	142376
147043	\N	\N	\N	\N	61110001	Katindo	\N	5	142609
147044	\N	\N	\N	\N	61110002	Keshero	\N	5	142609
147045	\N	\N	\N	\N	61110003	Lac Vert	\N	5	142609
147046	\N	\N	\N	\N	61110004	Mikeno	\N	5	142609
147047	\N	\N	\N	\N	61110005	Volcans	\N	5	142609
147048	\N	\N	\N	\N	61110006	Himbi	\N	5	142609
147049	\N	\N	\N	\N	61110007	Mapendo	\N	5	142609
147050	\N	\N	\N	\N	61120001	Kahembe	\N	5	142610
147051	\N	\N	\N	\N	61120002	Katoyi	\N	5	142610
147052	\N	\N	\N	\N	61120003	Mabanga Nord	\N	5	142610
147053	\N	\N	\N	\N	61120004	Majengo	\N	5	142610
147054	\N	\N	\N	\N	61120005	Mugunga	\N	5	142610
147055	\N	\N	\N	\N	61120006	Murara	\N	5	142610
147056	\N	\N	\N	\N	61120007	Ndosho	\N	5	142610
147057	\N	\N	\N	\N	61120008	Virunga	\N	5	142610
147058	\N	\N	\N	\N	61120009	Mabanga Sud	\N	5	142610
147059	\N	\N	\N	\N	61120010	Bujovu	\N	5	142610
147060	\N	\N	\N	\N	61120011	Kasika	\N	5	142610
147061	\N	\N	\N	\N	61220101	Bakano	\N	5	142611
147062	\N	\N	\N	\N	61220102	Bakonjo	\N	5	142611
147063	\N	\N	\N	\N	61220103	Bafuna Bakano	\N	5	142611
147064	\N	\N	\N	\N	61220104	Bananingi	\N	5	142611
147065	\N	\N	\N	\N	61220105	Banisamasi	\N	5	142611
147066	\N	\N	\N	\N	61220201	Bafuna	\N	5	142612
147067	\N	\N	\N	\N	61220202	Bakusu	\N	5	142612
147068	\N	\N	\N	\N	61220203	Banabangi	\N	5	142612
147069	\N	\N	\N	\N	61220204	Ihana	\N	5	142612
147070	\N	\N	\N	\N	61220205	Ikobo	\N	5	142612
147071	\N	\N	\N	\N	61220206	Kisimba	\N	5	142612
147072	\N	\N	\N	\N	61220207	Danda	\N	5	142612
147073	\N	\N	\N	\N	61220208	Luberike	\N	5	142612
147074	\N	\N	\N	\N	61220209	Waloa Uroba	\N	5	142612
147075	\N	\N	\N	\N	61220210	Usala	\N	5	142612
147076	\N	\N	\N	\N	61220211	Utunda	\N	5	142612
147077	\N	\N	\N	\N	61220212	Wassa	\N	5	142612
147078	\N	\N	\N	\N	61220213	Waloa Yungu	\N	5	142612
147079	\N	\N	\N	\N	61220214	Waloa Loanda	\N	5	142612
147080	\N	\N	\N	\N	61225101	Camp TP	\N	5	142613
147081	\N	\N	\N	\N	61225102	Cite Belge 1	\N	5	142613
147082	\N	\N	\N	\N	61225103	Cite Belge 2	\N	5	142613
147083	\N	\N	\N	\N	61225104	Kisima	\N	5	142613
147084	\N	\N	\N	\N	61225105	Nyabangi	\N	5	142613
147085	\N	\N	\N	\N	61225106	Nyalusukula	\N	5	142613
147086	\N	\N	\N	\N	61230101	Babika	\N	5	142614
147087	\N	\N	\N	\N	61230102	Babokara	\N	5	142614
147088	\N	\N	\N	\N	61230103	Bapaitumba	\N	5	142614
147089	\N	\N	\N	\N	61230104	Bapakombe	\N	5	142614
147090	\N	\N	\N	\N	61230105	Baredje	\N	5	142614
147091	\N	\N	\N	\N	61230106	Batike	\N	5	142614
147092	\N	\N	\N	\N	61230201	Bukenye	\N	5	142615
147093	\N	\N	\N	\N	61230202	Bulengya	\N	5	142615
147094	\N	\N	\N	\N	61230203	Buyora	\N	5	142615
147095	\N	\N	\N	\N	61230204	Luongo	\N	5	142615
147096	\N	\N	\N	\N	61230205	Manzya	\N	5	142615
147097	\N	\N	\N	\N	61230206	Muhola	\N	5	142615
147098	\N	\N	\N	\N	61230207	Mwenye	\N	5	142615
147099	\N	\N	\N	\N	61230208	Ngulu	\N	5	142615
147100	\N	\N	\N	\N	61230301	Itala	\N	5	142616
147101	\N	\N	\N	\N	61230302	Mbulie	\N	5	142616
147102	\N	\N	\N	\N	61230303	Musindi	\N	5	142616
147103	\N	\N	\N	\N	61230304	Mutundu	\N	5	142616
147104	\N	\N	\N	\N	61230305	Mutwe	\N	5	142616
147105	\N	\N	\N	\N	61230306	Ba-Musindi	\N	5	142616
147106	\N	\N	\N	\N	61230401	Buhimba	\N	5	142617
147107	\N	\N	\N	\N	61230402	Luenge	\N	5	142617
147108	\N	\N	\N	\N	61230403	Tama	\N	5	142617
147109	\N	\N	\N	\N	61230404	Utwe	\N	5	142617
147110	\N	\N	\N	\N	61230405	Monzoa	\N	5	142617
147111	\N	\N	\N	\N	61235101	Du 30 Juin	\N	5	142618
147112	\N	\N	\N	\N	61235102	Lubero	\N	5	142618
147113	\N	\N	\N	\N	61235103	Vukano	\N	5	142618
147114	\N	\N	\N	\N	61235104	Mulo	\N	5	142618
147115	\N	\N	\N	\N	61235401	Biondi	\N	5	142620
147116	\N	\N	\N	\N	61235402	CitÃ©	\N	5	142620
147117	\N	\N	\N	\N	61235403	Kabasha	\N	5	142620
147118	\N	\N	\N	\N	61235404	Kanyashi	\N	5	142620
147119	\N	\N	\N	\N	61235405	Kimina	\N	5	142620
147120	\N	\N	\N	\N	61235406	Kirumba	\N	5	142620
147121	\N	\N	\N	\N	61235407	Kyatimba	\N	5	142620
147122	\N	\N	\N	\N	61235408	Luenge	\N	5	142620
147123	\N	\N	\N	\N	61235409	Singamwambe	\N	5	142620
147124	\N	\N	\N	\N	61235501	Iramba	\N	5	142621
147125	\N	\N	\N	\N	61235502	Kaleko	\N	5	142621
147126	\N	\N	\N	\N	61235503	Lumumba	\N	5	142621
147127	\N	\N	\N	\N	61235504	Makasi	\N	5	142621
147128	\N	\N	\N	\N	61235505	Mikundi	\N	5	142621
147129	\N	\N	\N	\N	61235506	Nyamiindo	\N	5	142621
147130	\N	\N	\N	\N	61235507	Shabanlu	\N	5	142621
147131	\N	\N	\N	\N	61235508	Ururu	\N	5	142621
147132	\N	\N	\N	\N	61235601	Kasungano	\N	5	142622
147133	\N	\N	\N	\N	61235602	Kikimba	\N	5	142622
147134	\N	\N	\N	\N	61235603	Kinawa	\N	5	142622
147135	\N	\N	\N	\N	61235604	Kyalungero	\N	5	142622
147136	\N	\N	\N	\N	61235605	Makasi	\N	5	142622
147137	\N	\N	\N	\N	61235606	Mbogho	\N	5	142622
147138	\N	\N	\N	\N	61235607	Birere	\N	5	142622
147139	\N	\N	\N	\N	61240101	Bunyuka	\N	5	142623
147140	\N	\N	\N	\N	61240102	Isale Bulambo	\N	5	142623
147141	\N	\N	\N	\N	61240103	Isale Kasongwere	\N	5	142623
147142	\N	\N	\N	\N	61240104	Isale Vuhovi	\N	5	142623
147143	\N	\N	\N	\N	61240105	Malio	\N	5	142623
147144	\N	\N	\N	\N	61240106	Masiki Kalonge	\N	5	142623
147145	\N	\N	\N	\N	61240107	Masiki Vayana	\N	5	142623
147146	\N	\N	\N	\N	61240201	Bambumbaki/Ki	\N	5	142624
147147	\N	\N	\N	\N	61240202	Banande/Kayo	\N	5	142624
147148	\N	\N	\N	\N	61240203	Baswagha/M	\N	5	142624
147149	\N	\N	\N	\N	61240204	Madiwe	\N	5	142624
147150	\N	\N	\N	\N	61240205	Batangi	\N	5	142624
147151	\N	\N	\N	\N	61240301	Bahumu	\N	5	142625
147152	\N	\N	\N	\N	61240302	Bawisa	\N	5	142625
147153	\N	\N	\N	\N	61240303	Watalinga	\N	5	142625
147154	\N	\N	\N	\N	61240401	Baniangara	\N	5	142626
147155	\N	\N	\N	\N	61240402	Basongera	\N	5	142626
147156	\N	\N	\N	\N	61240403	Bolema	\N	5	142626
147157	\N	\N	\N	\N	61240404	Buliki	\N	5	142626
147158	\N	\N	\N	\N	61240405	Malambo	\N	5	142626
147159	\N	\N	\N	\N	61245201	Home	\N	5	142627
147160	\N	\N	\N	\N	61245202	Mangina	\N	5	142627
147161	\N	\N	\N	\N	61245203	Masimbembe	\N	5	142627
147162	\N	\N	\N	\N	61245204	Mangodomu	\N	5	142627
147163	\N	\N	\N	\N	61245301	Bakaiku	\N	5	142628
147164	\N	\N	\N	\N	61245303	Mbimbi	\N	5	142628
147165	\N	\N	\N	\N	61245304	Mabasele	\N	5	142628
147166	\N	\N	\N	\N	61245305	Oicha 1	\N	5	142628
147167	\N	\N	\N	\N	61245306	Nzanza	\N	5	142628
147168	\N	\N	\N	\N	61245307	Bakanza	\N	5	142628
147169	\N	\N	\N	\N	61245308	Masosi	\N	5	142628
147170	\N	\N	\N	\N	61245401	Kambalango	\N	5	142629
147171	\N	\N	\N	\N	61245402	Kitotoli	\N	5	142629
147172	\N	\N	\N	\N	61245403	Kihome	\N	5	142629
147173	\N	\N	\N	\N	61245501	Kavanga	\N	5	142630
147174	\N	\N	\N	\N	61245502	Kaviranga	\N	5	142630
147175	\N	\N	\N	\N	61245503	Kyomole	\N	5	142630
147176	\N	\N	\N	\N	61245504	Mulakirwa	\N	5	142630
147177	\N	\N	\N	\N	61245505	Ibwe	\N	5	142630
147178	\N	\N	\N	\N	61245506	Sivirwa	\N	5	142630
147179	\N	\N	\N	\N	61245601	Kivisire	\N	5	142631
147180	\N	\N	\N	\N	61245602	Lume	\N	5	142631
147181	\N	\N	\N	\N	61245603	Rwenzori	\N	5	142631
147182	\N	\N	\N	\N	61250101	Bambo	\N	5	142632
147183	\N	\N	\N	\N	61250102	Bishusha	\N	5	142632
147184	\N	\N	\N	\N	61250103	Bukombo	\N	5	142632
147185	\N	\N	\N	\N	61250104	Kanyabayonga	\N	5	142632
147186	\N	\N	\N	\N	61250105	Kihondo	\N	5	142632
147187	\N	\N	\N	\N	61250106	Mutanda	\N	5	142632
147188	\N	\N	\N	\N	61250107	Tongo	\N	5	142632
147189	\N	\N	\N	\N	61250201	Binza	\N	5	142633
147190	\N	\N	\N	\N	61250202	Bukoma	\N	5	142633
147191	\N	\N	\N	\N	61250203	Busanza	\N	5	142633
147192	\N	\N	\N	\N	61250204	Bweza	\N	5	142633
147193	\N	\N	\N	\N	61250205	Jomba	\N	5	142633
147194	\N	\N	\N	\N	61250206	Kisigari	\N	5	142633
147195	\N	\N	\N	\N	61250207	Rugari	\N	5	142633
147196	\N	\N	\N	\N	61255101	Buturande	\N	5	142634
147197	\N	\N	\N	\N	61255102	Buzito	\N	5	142634
147198	\N	\N	\N	\N	61255103	Mabungo	\N	5	142634
147199	\N	\N	\N	\N	61260101	Kamuronza	\N	5	142635
147200	\N	\N	\N	\N	61260102	Mupfuni Kibabi	\N	5	142635
147201	\N	\N	\N	\N	61260103	Mupfuni Matanda	\N	5	142635
147202	\N	\N	\N	\N	61260104	Mupfuni Karuba	\N	5	142635
147203	\N	\N	\N	\N	61260105	Mupfuni Shanga	\N	5	142635
147204	\N	\N	\N	\N	61260106	Ufamandu 1	\N	5	142635
147205	\N	\N	\N	\N	61260201	Kambule	\N	5	142636
147206	\N	\N	\N	\N	61260202	Kibabi 2	\N	5	142636
147207	\N	\N	\N	\N	61260203	Lwindi	\N	5	142636
147208	\N	\N	\N	\N	61260204	Nyalipe	\N	5	142636
147209	\N	\N	\N	\N	61260205	Nyamaboko 2	\N	5	142636
147210	\N	\N	\N	\N	61260206	Ufamandu 2	\N	5	142636
147211	\N	\N	\N	\N	61260301	Banyungu	\N	5	142637
147212	\N	\N	\N	\N	61260302	Bapfuna	\N	5	142637
147213	\N	\N	\N	\N	61260303	Biiri	\N	5	142637
147214	\N	\N	\N	\N	61260304	Buabo	\N	5	142637
147215	\N	\N	\N	\N	61260305	Nyamaboko 1	\N	5	142637
147216	\N	\N	\N	\N	61260401	Bashali Kaembe	\N	5	142638
147217	\N	\N	\N	\N	61260402	Bashali Mukoto	\N	5	142638
147218	\N	\N	\N	\N	61265101	Birere	\N	5	142639
147219	\N	\N	\N	\N	61265102	Mont Ngaliema	\N	5	142639
147220	\N	\N	\N	\N	61265103	Camp Saio	\N	5	142639
147221	\N	\N	\N	\N	61265104	Kakoka	\N	5	142639
147222	\N	\N	\N	\N	61270101	Buhumba	\N	5	142640
147223	\N	\N	\N	\N	61270102	Buvira	\N	5	142640
147224	\N	\N	\N	\N	61270103	Byahi	\N	5	142640
147225	\N	\N	\N	\N	61270104	Kibati	\N	5	142640
147226	\N	\N	\N	\N	61270105	Kibumba	\N	5	142640
147227	\N	\N	\N	\N	61270106	Mudja	\N	5	142640
147228	\N	\N	\N	\N	61270107	Munigi	\N	5	142640
147229	\N	\N	\N	\N	61270108	Rusayo	\N	5	142640
147230	\N	\N	\N	\N	61310001	Benegule	\N	5	142641
147231	\N	\N	\N	\N	61310002	Biautu	\N	5	142641
147232	\N	\N	\N	\N	61310003	Butanuka	\N	5	142641
147233	\N	\N	\N	\N	61310004	Lubahemba	\N	5	142641
147234	\N	\N	\N	\N	61310005	Liakobo	\N	5	142641
147235	\N	\N	\N	\N	61310006	Malepe	\N	5	142641
147236	\N	\N	\N	\N	61310007	Rwangoma	\N	5	142641
147237	\N	\N	\N	\N	61320001	Cite Belge	\N	5	142642
147238	\N	\N	\N	\N	61320002	Kanzulinzuli	\N	5	142642
147239	\N	\N	\N	\N	61320003	Mabolyo	\N	5	142642
147240	\N	\N	\N	\N	61320004	Mabako	\N	5	142642
147241	\N	\N	\N	\N	61320005	Mukulya	\N	5	142642
147242	\N	\N	\N	\N	61320006	Pasisi	\N	5	142642
147243	\N	\N	\N	\N	61320007	Residentiel	\N	5	142642
147244	\N	\N	\N	\N	61330001	Boikene	\N	5	142643
147245	\N	\N	\N	\N	61330002	Djuma	\N	5	142643
147246	\N	\N	\N	\N	61330003	Kasabinyole	\N	5	142643
147247	\N	\N	\N	\N	61330004	Mabakanga	\N	5	142643
147248	\N	\N	\N	\N	61330005	Ngadi	\N	5	142643
147249	\N	\N	\N	\N	61330006	Paida	\N	5	142643
147250	\N	\N	\N	\N	61340001	Tamende	\N	5	142644
147251	\N	\N	\N	\N	61340002	Matonge	\N	5	142644
147252	\N	\N	\N	\N	61340003	Kalinda	\N	5	142644
147253	\N	\N	\N	\N	61340004	Butsili	\N	5	142644
147254	\N	\N	\N	\N	61340005	Ngongolyo	\N	5	142644
147255	\N	\N	\N	\N	61340006	Sayo	\N	5	142644
147256	\N	\N	\N	\N	61340007	Masiani	\N	5	142644
147257	\N	\N	\N	\N	61340008	Matembo	\N	5	142644
147258	\N	\N	\N	\N	61340009	Kasangatua	\N	5	142644
147259	\N	\N	\N	\N	61340010	Bundji	\N	5	142644
147260	\N	\N	\N	\N	61410001	Lumuba	\N	5	142645
147261	\N	\N	\N	\N	61410002	Vutsundo	\N	5	142645
147262	\N	\N	\N	\N	61410003	Ngere	\N	5	142645
147263	\N	\N	\N	\N	61410004	Vutetse	\N	5	142645
147264	\N	\N	\N	\N	61410005	Biondi	\N	5	142645
147265	\N	\N	\N	\N	61410006	Centre commercial	\N	5	142645
147266	\N	\N	\N	\N	61410007	Bwinyole	\N	5	142645
147267	\N	\N	\N	\N	61410008	Malende	\N	5	142645
147268	\N	\N	\N	\N	61420001	Kalemire	\N	5	142646
147269	\N	\N	\N	\N	61420002	Kamesi Mbonzo	\N	5	142646
147270	\N	\N	\N	\N	61420003	Rugenda	\N	5	142646
147271	\N	\N	\N	\N	61420004	Kimbulu	\N	5	142646
147272	\N	\N	\N	\N	61420005	Mutiri	\N	5	142646
147273	\N	\N	\N	\N	61420006	Mukuna	\N	5	142646
147274	\N	\N	\N	\N	61420007	Kyaghala	\N	5	142646
147275	\N	\N	\N	\N	61420008	Wayene	\N	5	142646
147276	\N	\N	\N	\N	61430001	Ngingi	\N	5	142647
147277	\N	\N	\N	\N	61430002	Bwinongo	\N	5	142647
147278	\N	\N	\N	\N	61430003	Vighole	\N	5	142647
147279	\N	\N	\N	\N	61430004	Kitulu	\N	5	142647
147280	\N	\N	\N	\N	61430005	Matanda	\N	5	142647
147281	\N	\N	\N	\N	61430006	Katwa	\N	5	142647
147282	\N	\N	\N	\N	61430007	Vungi	\N	5	142647
147283	\N	\N	\N	\N	61440001	Kambali	\N	5	142648
147284	\N	\N	\N	\N	61440002	Congo ya sika	\N	5	142648
147285	\N	\N	\N	\N	61440003	Matembe	\N	5	142648
147286	\N	\N	\N	\N	61440004	Mukalangirwa	\N	5	142648
147287	\N	\N	\N	\N	62210101	Kodi	\N	5	142649
147288	\N	\N	\N	\N	62210102	Mukoko	\N	5	142649
147289	\N	\N	\N	\N	62210103	Sienge	\N	5	142649
147290	\N	\N	\N	\N	62210104	Tshambi	\N	5	142649
147291	\N	\N	\N	\N	62210105	Tshadi	\N	5	142649
147292	\N	\N	\N	\N	62210201	Bakuti	\N	5	142650
147293	\N	\N	\N	\N	62210202	Balanga	\N	5	142650
147294	\N	\N	\N	\N	62210203	Bambuti	\N	5	142650
147295	\N	\N	\N	\N	62210205	Basikamba	\N	5	142650
147296	\N	\N	\N	\N	62210206	Basiluamba	\N	5	142650
147297	\N	\N	\N	\N	62210207	Kimbi	\N	5	142650
147298	\N	\N	\N	\N	62210208	Ngombe	\N	5	142650
147299	\N	\N	\N	\N	62210301	Bahombo	\N	5	142651
147300	\N	\N	\N	\N	62210302	Banganya	\N	5	142651
147301	\N	\N	\N	\N	62210303	Basoko	\N	5	142651
147302	\N	\N	\N	\N	62210304	Bidjungu	\N	5	142651
147303	\N	\N	\N	\N	62210305	Binapeo	\N	5	142651
147304	\N	\N	\N	\N	62210306	Binasele	\N	5	142651
147305	\N	\N	\N	\N	62210307	Bisambulu	\N	5	142651
147306	\N	\N	\N	\N	62210308	Mikina	\N	5	142651
147307	\N	\N	\N	\N	62210309	Muene-Nord	\N	5	142651
147308	\N	\N	\N	\N	62210310	Muene-Sud	\N	5	142651
147309	\N	\N	\N	\N	62210401	Baika	\N	5	142652
147310	\N	\N	\N	\N	62210402	Kama 2	\N	5	142652
147311	\N	\N	\N	\N	62210404	Kasenga	\N	5	142652
147312	\N	\N	\N	\N	62210405	Keka	\N	5	142652
147313	\N	\N	\N	\N	62210406	Kulu	\N	5	142652
147314	\N	\N	\N	\N	62210407	Kyamba	\N	5	142652
147315	\N	\N	\N	\N	62210408	Langwa	\N	5	142652
147316	\N	\N	\N	\N	62210409	Lukandu	\N	5	142652
147317	\N	\N	\N	\N	62210410	Lukungu	\N	5	142652
147318	\N	\N	\N	\N	62220101	Bambu	\N	5	142653
147319	\N	\N	\N	\N	62220102	Batamba	\N	5	142653
147320	\N	\N	\N	\N	62220103	Ewangi	\N	5	142653
147321	\N	\N	\N	\N	62220104	Luhata	\N	5	142653
147322	\N	\N	\N	\N	62220105	Mbu	\N	5	142653
147323	\N	\N	\N	\N	62220106	Tole-lule	\N	5	142653
147324	\N	\N	\N	\N	62220201	Denge /Code)	\N	5	142654
147325	\N	\N	\N	\N	62220202	Dikungu	\N	5	142654
147326	\N	\N	\N	\N	62220203	Dimanga	\N	5	142654
147327	\N	\N	\N	\N	62220204	Ewangu	\N	5	142654
147328	\N	\N	\N	\N	62220205	Lokenye	\N	5	142654
147329	\N	\N	\N	\N	62220206	Oye	\N	5	142654
147330	\N	\N	\N	\N	62220207	Wenga	\N	5	142654
147331	\N	\N	\N	\N	62220208	Lule	\N	5	142654
147332	\N	\N	\N	\N	62220301	Kangi	\N	5	142655
147333	\N	\N	\N	\N	62220302	Kembe	\N	5	142655
147334	\N	\N	\N	\N	62220303	Lukangu	\N	5	142655
147335	\N	\N	\N	\N	62220304	Uhambe	\N	5	142655
147336	\N	\N	\N	\N	62220305	Uvundu	\N	5	142655
147337	\N	\N	\N	\N	62220306	Viamba	\N	5	142655
147338	\N	\N	\N	\N	62220307	Watambulu	\N	5	142655
147339	\N	\N	\N	\N	62220401	Difuma	\N	5	142656
147340	\N	\N	\N	\N	62220402	Eselo	\N	5	142656
147341	\N	\N	\N	\N	62220403	Manga	\N	5	142656
147342	\N	\N	\N	\N	62220404	Ukuna	\N	5	142656
147343	\N	\N	\N	\N	62220405	Utshu	\N	5	142656
147344	\N	\N	\N	\N	62220406	Wundu	\N	5	142656
147345	\N	\N	\N	\N	62220407	Yenge	\N	5	142656
147346	\N	\N	\N	\N	62220501	Kesanga	\N	5	142657
147347	\N	\N	\N	\N	62220502	Kikunda	\N	5	142657
147348	\N	\N	\N	\N	62220503	Lukonge	\N	5	142657
147349	\N	\N	\N	\N	62220504	Mabila	\N	5	142657
147350	\N	\N	\N	\N	62220505	Makunda	\N	5	142657
147351	\N	\N	\N	\N	62220506	Ngombe	\N	5	142657
147352	\N	\N	\N	\N	62220507	Tumbila	\N	5	142657
147353	\N	\N	\N	\N	62230101	Banabolelia	\N	5	142659
147354	\N	\N	\N	\N	62230102	Basupala	\N	5	142659
147355	\N	\N	\N	\N	62230103	Batiakandja	\N	5	142659
147356	\N	\N	\N	\N	62230104	Batikabusali	\N	5	142659
147357	\N	\N	\N	\N	62230105	Batikaliba	\N	5	142659
147358	\N	\N	\N	\N	62230106	Binamukundji	\N	5	142659
147359	\N	\N	\N	\N	62230107	Binawalu	\N	5	142659
147360	\N	\N	\N	\N	62230108	Kasera	\N	5	142659
147361	\N	\N	\N	\N	62230109	Mbulambulu	\N	5	142659
147362	\N	\N	\N	\N	62230110	Mitakulu	\N	5	142659
147363	\N	\N	\N	\N	62230111	Tubila	\N	5	142659
147364	\N	\N	\N	\N	62230112	Ulindi	\N	5	142659
147365	\N	\N	\N	\N	62230113	Uvasino	\N	5	142659
147366	\N	\N	\N	\N	62230201	Babaume	\N	5	142660
147367	\N	\N	\N	\N	62230202	Babimbi	\N	5	142660
147368	\N	\N	\N	\N	62230203	Bangandula	\N	5	142660
147369	\N	\N	\N	\N	62230204	Banyamulembe	\N	5	142660
147370	\N	\N	\N	\N	62230205	Batikabangu	\N	5	142660
147371	\N	\N	\N	\N	62230301	Babongena	\N	5	142661
147372	\N	\N	\N	\N	62230302	Babongombe	\N	5	142661
147373	\N	\N	\N	\N	62230303	Banamea	\N	5	142661
147374	\N	\N	\N	\N	62230304	Banyamulembe	\N	5	142661
147375	\N	\N	\N	\N	62230305	Banyamuku-Lumanya	\N	5	142661
147376	\N	\N	\N	\N	62230306	Batiagele	\N	5	142661
147377	\N	\N	\N	\N	62235101	Basenge	\N	5	142662
147378	\N	\N	\N	\N	62235102	Mangobo	\N	5	142662
147379	\N	\N	\N	\N	62235103	Miripia	\N	5	142662
147380	\N	\N	\N	\N	62235104	Mpiala	\N	5	142662
147381	\N	\N	\N	\N	62235105	Nyanga	\N	5	142662
147382	\N	\N	\N	\N	62235106	Punia	\N	5	142662
147383	\N	\N	\N	\N	62240101	Babokote	\N	5	142663
147384	\N	\N	\N	\N	62240102	Babondjele	\N	5	142663
147385	\N	\N	\N	\N	62240103	Babongombe 1	\N	5	142663
147386	\N	\N	\N	\N	62240104	Babongombe 2	\N	5	142663
147387	\N	\N	\N	\N	62240105	Babundji	\N	5	142663
147388	\N	\N	\N	\N	62240106	Babusoko	\N	5	142663
147389	\N	\N	\N	\N	62240107	Bamandea	\N	5	142663
147390	\N	\N	\N	\N	62240108	Banali	\N	5	142663
147391	\N	\N	\N	\N	62240109	Bandu-Banenu	\N	5	142663
147392	\N	\N	\N	\N	62240110	Banenu	\N	5	142663
147393	\N	\N	\N	\N	62240111	Kalombe - Nyama	\N	5	142663
147394	\N	\N	\N	\N	62240112	Kayumba - Moyo	\N	5	142663
147395	\N	\N	\N	\N	62240201	Babongena	\N	5	142664
147396	\N	\N	\N	\N	62240202	Babute	\N	5	142664
147397	\N	\N	\N	\N	62240203	Babutungani	\N	5	142664
147398	\N	\N	\N	\N	62240204	Bamugui	\N	5	142664
147399	\N	\N	\N	\N	62240205	Banango	\N	5	142664
147400	\N	\N	\N	\N	62240206	Batike	\N	5	142664
147401	\N	\N	\N	\N	62240207	Batikamwanga	\N	5	142664
147402	\N	\N	\N	\N	62240208	Lubilanga	\N	5	142664
147403	\N	\N	\N	\N	62240209	Madimba	\N	5	142664
147404	\N	\N	\N	\N	62240210	Okaku	\N	5	142664
147405	\N	\N	\N	\N	62240211	Osele	\N	5	142664
147406	\N	\N	\N	\N	62240212	Twabinga	\N	5	142664
147407	\N	\N	\N	\N	62245101	Lubutu	\N	5	142665
147408	\N	\N	\N	\N	62250101	Babongola	\N	5	142666
147409	\N	\N	\N	\N	62250102	Baliba	\N	5	142666
147410	\N	\N	\N	\N	62250103	Ikinga	\N	5	142666
147411	\N	\N	\N	\N	62250104	Kinkobo	\N	5	142666
147412	\N	\N	\N	\N	62250105	Nsanguli	\N	5	142666
147413	\N	\N	\N	\N	62250201	Juwa	\N	5	142667
147414	\N	\N	\N	\N	62250202	Keingo	\N	5	142667
147415	\N	\N	\N	\N	62250203	Meya	\N	5	142667
147416	\N	\N	\N	\N	62250204	Misisi	\N	5	142667
147417	\N	\N	\N	\N	62250205	Nangi	\N	5	142667
147418	\N	\N	\N	\N	62250206	Nkuku	\N	5	142667
147419	\N	\N	\N	\N	62250207	Nzinzi	\N	5	142667
147420	\N	\N	\N	\N	62250208	Nsange	\N	5	142667
147421	\N	\N	\N	\N	62250209	Salo	\N	5	142667
147422	\N	\N	\N	\N	62250210	Ulimba	\N	5	142667
147423	\N	\N	\N	\N	62250301	Babongola	\N	5	142668
147424	\N	\N	\N	\N	62250302	Bause 1	\N	5	142668
147425	\N	\N	\N	\N	62250303	Bause 2	\N	5	142668
147426	\N	\N	\N	\N	62250304	Kashele	\N	5	142668
147427	\N	\N	\N	\N	62250305	Kyunia	\N	5	142668
147428	\N	\N	\N	\N	62250306	Mombo	\N	5	142668
147429	\N	\N	\N	\N	62250307	Mubake	\N	5	142668
147430	\N	\N	\N	\N	62250401	Batoba	\N	5	142669
147431	\N	\N	\N	\N	62250402	Isanga	\N	5	142669
147432	\N	\N	\N	\N	62250403	Kabesa	\N	5	142669
147433	\N	\N	\N	\N	62250404	Kagela	\N	5	142669
147434	\N	\N	\N	\N	62250405	Mbiliki	\N	5	142669
147435	\N	\N	\N	\N	62250406	Munua	\N	5	142669
147436	\N	\N	\N	\N	62250407	Nzelu	\N	5	142669
147437	\N	\N	\N	\N	62260101	Benya Ngongo	\N	5	142672
147438	\N	\N	\N	\N	62260102	Benya Nsompo	\N	5	142672
147439	\N	\N	\N	\N	62260103	Bunsongwe	\N	5	142672
147440	\N	\N	\N	\N	62260104	Bushiba	\N	5	142672
147441	\N	\N	\N	\N	62260105	Loengo 1	\N	5	142672
147442	\N	\N	\N	\N	62260106	Loengo 2	\N	5	142672
147443	\N	\N	\N	\N	62260107	Lulenge	\N	5	142672
147444	\N	\N	\N	\N	62260108	Lusangay	\N	5	142672
147445	\N	\N	\N	\N	62260109	Malela	\N	5	142672
147446	\N	\N	\N	\N	62260110	Mowe	\N	5	142672
147447	\N	\N	\N	\N	62260111	Muhasa	\N	5	142672
147448	\N	\N	\N	\N	62260112	Mulamba	\N	5	142672
147449	\N	\N	\N	\N	62260201	Biadi	\N	5	142673
147450	\N	\N	\N	\N	62260202	Changa-Changa	\N	5	142673
147451	\N	\N	\N	\N	62260203	Dongo	\N	5	142673
147452	\N	\N	\N	\N	62260204	Kansadi	\N	5	142673
147453	\N	\N	\N	\N	62260205	Kapunda	\N	5	142673
147454	\N	\N	\N	\N	62260206	Kasadi	\N	5	142673
147455	\N	\N	\N	\N	62260207	Kavungu	\N	5	142673
147456	\N	\N	\N	\N	62260208	Kimbi	\N	5	142673
147457	\N	\N	\N	\N	62260209	Lufumbe	\N	5	142673
147458	\N	\N	\N	\N	62260210	Manga	\N	5	142673
147459	\N	\N	\N	\N	62260211	Matende	\N	5	142673
147460	\N	\N	\N	\N	62260212	Milombo	\N	5	142673
147461	\N	\N	\N	\N	62260213	Mwanga	\N	5	142673
147462	\N	\N	\N	\N	62260214	Tusanye	\N	5	142673
147463	\N	\N	\N	\N	62260301	Kabongo	\N	5	142674
147464	\N	\N	\N	\N	62260302	Kabundi	\N	5	142674
147465	\N	\N	\N	\N	62260303	Kasanki	\N	5	142674
147466	\N	\N	\N	\N	62260304	Kiessi	\N	5	142674
147467	\N	\N	\N	\N	62260305	Manda	\N	5	142674
147468	\N	\N	\N	\N	62260401	Benya Mbake	\N	5	142675
147469	\N	\N	\N	\N	62260402	Benye Kunga	\N	5	142675
147470	\N	\N	\N	\N	62260403	Benye Ngungwa	\N	5	142675
147471	\N	\N	\N	\N	62260404	Kabanga 1	\N	5	142675
147472	\N	\N	\N	\N	62260405	Kabanga 2	\N	5	142675
147473	\N	\N	\N	\N	62260406	Kabondo	\N	5	142675
147474	\N	\N	\N	\N	62260407	Kankuba	\N	5	142675
147475	\N	\N	\N	\N	62260408	Kifuluka	\N	5	142675
147476	\N	\N	\N	\N	62260409	Kimbulu	\N	5	142675
147477	\N	\N	\N	\N	62260410	Kyanday	\N	5	142675
147478	\N	\N	\N	\N	62260411	Lubumba	\N	5	142675
147479	\N	\N	\N	\N	62260412	Lusaki	\N	5	142675
147480	\N	\N	\N	\N	62260413	Mukungu	\N	5	142675
147481	\N	\N	\N	\N	62260414	Musambi	\N	5	142675
147482	\N	\N	\N	\N	62260415	Tambwe Mbale	\N	5	142675
147483	\N	\N	\N	\N	62260416	Tambwe Mwimba	\N	5	142675
147484	\N	\N	\N	\N	62260417	Yamba Yamba	\N	5	142675
147485	\N	\N	\N	\N	62260418	Yengo	\N	5	142675
147486	\N	\N	\N	\N	62260501	Hamba	\N	5	142676
147487	\N	\N	\N	\N	62260502	Ichima	\N	5	142676
147488	\N	\N	\N	\N	62260503	Kaila	\N	5	142676
147489	\N	\N	\N	\N	62260504	Kasubi	\N	5	142676
147490	\N	\N	\N	\N	62260505	Katcha	\N	5	142676
147491	\N	\N	\N	\N	62260506	Katembo	\N	5	142676
147492	\N	\N	\N	\N	62260507	Kisadji	\N	5	142676
147493	\N	\N	\N	\N	62260508	Langilwa	\N	5	142676
147494	\N	\N	\N	\N	62260509	Luchi	\N	5	142676
147495	\N	\N	\N	\N	62260510	Mwanga	\N	5	142676
147496	\N	\N	\N	\N	62260511	Mwinga	\N	5	142676
147497	\N	\N	\N	\N	62260512	Ngenda	\N	5	142676
147498	\N	\N	\N	\N	62260513	Sungu	\N	5	142676
147499	\N	\N	\N	\N	62260514	Tubuku	\N	5	142676
147500	\N	\N	\N	\N	62260601	Ambo	\N	5	142677
147501	\N	\N	\N	\N	62260602	Baya 1	\N	5	142677
147502	\N	\N	\N	\N	62260603	Baya 2	\N	5	142677
147503	\N	\N	\N	\N	62260604	Kasele	\N	5	142677
147504	\N	\N	\N	\N	62260605	Kibango	\N	5	142677
147505	\N	\N	\N	\N	62260606	Kila	\N	5	142677
147506	\N	\N	\N	\N	62260607	Kimwachi	\N	5	142677
147507	\N	\N	\N	\N	62260608	Kirundu	\N	5	142677
147508	\N	\N	\N	\N	62260609	Kusu	\N	5	142677
147509	\N	\N	\N	\N	62260610	Kwanga	\N	5	142677
147510	\N	\N	\N	\N	62260611	Mbaa	\N	5	142677
147511	\N	\N	\N	\N	62260612	Mbichi	\N	5	142677
147512	\N	\N	\N	\N	62260613	Mbutu	\N	5	142677
147513	\N	\N	\N	\N	62260614	Mumba	\N	5	142677
147514	\N	\N	\N	\N	62260615	Ngungwa	\N	5	142677
147515	\N	\N	\N	\N	62260616	Sangwa	\N	5	142677
147516	\N	\N	\N	\N	62260617	Saumbi	\N	5	142677
147517	\N	\N	\N	\N	62260618	Sungu	\N	5	142677
147518	\N	\N	\N	\N	62260619	Tchele	\N	5	142677
147519	\N	\N	\N	\N	62260620	Tchura	\N	5	142677
147520	\N	\N	\N	\N	62260621	Unga	\N	5	142677
147521	\N	\N	\N	\N	62260701	Benye Mbayo	\N	5	142678
147522	\N	\N	\N	\N	62260702	Benye Miale	\N	5	142678
147523	\N	\N	\N	\N	62260703	Benye Miyele	\N	5	142678
147524	\N	\N	\N	\N	62260704	Benye Mulue	\N	5	142678
147525	\N	\N	\N	\N	62260705	Bulumbilo	\N	5	142678
147526	\N	\N	\N	\N	62260706	Kanyembwa	\N	5	142678
147527	\N	\N	\N	\N	62260707	Kayoo	\N	5	142678
147528	\N	\N	\N	\N	62260708	Kika	\N	5	142678
147529	\N	\N	\N	\N	62260709	Kilimba	\N	5	142678
147530	\N	\N	\N	\N	62260710	Kinabwe	\N	5	142678
147531	\N	\N	\N	\N	62260711	Lubambo	\N	5	142678
147532	\N	\N	\N	\N	62260712	Mibangala	\N	5	142678
147533	\N	\N	\N	\N	62260713	Mitanda	\N	5	142678
147534	\N	\N	\N	\N	62260714	Ngundu	\N	5	142678
147535	\N	\N	\N	\N	62260715	Numbi	\N	5	142678
147536	\N	\N	\N	\N	62260716	Sangwa	\N	5	142678
147537	\N	\N	\N	\N	62260717	Walunba	\N	5	142678
147538	\N	\N	\N	\N	62260718	Zilange	\N	5	142678
147539	\N	\N	\N	\N	62260801	Amba 1	\N	5	142679
147540	\N	\N	\N	\N	62260802	Amba 2	\N	5	142679
147541	\N	\N	\N	\N	62260803	Arabise	\N	5	142679
147542	\N	\N	\N	\N	62260804	Bazilanguvu 1	\N	5	142679
147543	\N	\N	\N	\N	62260805	Bazilanguvu 2	\N	5	142679
147544	\N	\N	\N	\N	62260806	Bazilanyoka	\N	5	142679
147545	\N	\N	\N	\N	62260807	Benye Kunda	\N	5	142679
147546	\N	\N	\N	\N	62260808	Benye Londo	\N	5	142679
147547	\N	\N	\N	\N	62260809	Benye Mahanga	\N	5	142679
147548	\N	\N	\N	\N	62260810	Benye Mbeya	\N	5	142679
147549	\N	\N	\N	\N	62260811	Benye Mbuyu	\N	5	142679
147550	\N	\N	\N	\N	62260812	Benye Muho	\N	5	142679
147551	\N	\N	\N	\N	62260813	Benye Mukande	\N	5	142679
147552	\N	\N	\N	\N	62260814	Benye Mukundi	\N	5	142679
147553	\N	\N	\N	\N	62260815	Benye Musowa	\N	5	142679
147554	\N	\N	\N	\N	62260816	Kihongo	\N	5	142679
147555	\N	\N	\N	\N	62260817	Kitenge	\N	5	142679
147556	\N	\N	\N	\N	62260818	Lukenge	\N	5	142679
147557	\N	\N	\N	\N	62260819	Mabambo	\N	5	142679
147558	\N	\N	\N	\N	62260820	Miruhu	\N	5	142679
147559	\N	\N	\N	\N	62260821	Mufara	\N	5	142679
147560	\N	\N	\N	\N	62260822	Mukuba	\N	5	142679
147561	\N	\N	\N	\N	62260823	Musowa	\N	5	142679
147562	\N	\N	\N	\N	62260824	Mwambo 1	\N	5	142679
147563	\N	\N	\N	\N	62260825	Mwambo 2	\N	5	142679
147564	\N	\N	\N	\N	62260826	Ngwadi	\N	5	142679
147565	\N	\N	\N	\N	62260827	Yandwe	\N	5	142679
147566	\N	\N	\N	\N	62260901	Kasanda	\N	5	142680
147567	\N	\N	\N	\N	62260902	Kimba	\N	5	142680
147568	\N	\N	\N	\N	62260903	Lugulu	\N	5	142680
147569	\N	\N	\N	\N	62260904	Mako	\N	5	142680
147570	\N	\N	\N	\N	62260905	Musengya	\N	5	142680
147571	\N	\N	\N	\N	62260906	Twite	\N	5	142680
147572	\N	\N	\N	\N	62261001	Kala 1	\N	5	142681
147573	\N	\N	\N	\N	62261002	Kala 2	\N	5	142681
147574	\N	\N	\N	\N	62261003	Kambi	\N	5	142681
147575	\N	\N	\N	\N	62261004	Kantondo	\N	5	142681
147576	\N	\N	\N	\N	62261005	Kanyoe	\N	5	142681
147577	\N	\N	\N	\N	62261006	Longa	\N	5	142681
147578	\N	\N	\N	\N	62261007	Milemba	\N	5	142681
147579	\N	\N	\N	\N	62261008	Muntinta	\N	5	142681
147580	\N	\N	\N	\N	62261009	Mwimbi	\N	5	142681
147581	\N	\N	\N	\N	62261010	Sambwe	\N	5	142681
147582	\N	\N	\N	\N	62261011	Yombwe	\N	5	142681
147583	\N	\N	\N	\N	62265101	Dix Huit	\N	5	142682
147584	\N	\N	\N	\N	62265102	Kauta	\N	5	142682
147585	\N	\N	\N	\N	62265103	Limanga	\N	5	142682
147586	\N	\N	\N	\N	62265104	Tchatchatcha	\N	5	142682
147587	\N	\N	\N	\N	62270101	Kagulu	\N	5	142683
147588	\N	\N	\N	\N	62270102	Katego	\N	5	142683
147589	\N	\N	\N	\N	62270103	Magaza	\N	5	142683
147590	\N	\N	\N	\N	62270201	Bahiri	\N	5	142684
147591	\N	\N	\N	\N	62270202	Kagulu	\N	5	142684
147592	\N	\N	\N	\N	62270203	Lugambo	\N	5	142684
147593	\N	\N	\N	\N	62270204	Mugona	\N	5	142684
147594	\N	\N	\N	\N	62270205	Nonda	\N	5	142684
147595	\N	\N	\N	\N	62270301	Kaniengele	\N	5	142685
147596	\N	\N	\N	\N	62270302	Kibumba	\N	5	142685
147597	\N	\N	\N	\N	62270303	Mwambao	\N	5	142685
147598	\N	\N	\N	\N	62270401	Kitababea	\N	5	142686
147599	\N	\N	\N	\N	62270402	Muhiya 1	\N	5	142686
147600	\N	\N	\N	\N	62270403	Muhiya 2	\N	5	142686
147601	\N	\N	\N	\N	62270501	Babemba	\N	5	142687
147602	\N	\N	\N	\N	62270502	Bahutchwe	\N	5	142687
147603	\N	\N	\N	\N	62270503	Basonga	\N	5	142687
147604	\N	\N	\N	\N	62270504	Basumba	\N	5	142687
147605	\N	\N	\N	\N	62270505	Bayaha	\N	5	142687
147606	\N	\N	\N	\N	62270601	Bahombo	\N	5	142688
147607	\N	\N	\N	\N	62270602	Bazogoni	\N	5	142688
147608	\N	\N	\N	\N	62270603	Be-Kabambare	\N	5	142688
147609	\N	\N	\N	\N	62270604	Be-Kilunguyi	\N	5	142688
147610	\N	\N	\N	\N	62270605	Be-Ngongo	\N	5	142688
147611	\N	\N	\N	\N	63110001	Kasha	\N	5	142690
147612	\N	\N	\N	\N	63110002	Lumumba	\N	5	142690
147613	\N	\N	\N	\N	63110003	Nyakavogo	\N	5	142690
147614	\N	\N	\N	\N	63120001	Chimpunda	\N	5	142691
147615	\N	\N	\N	\N	63120002	Kalere	\N	5	142691
147616	\N	\N	\N	\N	63120003	Kasali	\N	5	142691
147617	\N	\N	\N	\N	63120004	Mosala	\N	5	142691
147618	\N	\N	\N	\N	63120005	Nyamugo	\N	5	142691
147619	\N	\N	\N	\N	63130001	Ndendere	\N	5	142692
147620	\N	\N	\N	\N	63130002	Nyalukemba	\N	5	142692
147621	\N	\N	\N	\N	63130003	Panzi	\N	5	142692
147622	\N	\N	\N	\N	63210101	Burhale	\N	5	142693
147623	\N	\N	\N	\N	63210102	Ikoma	\N	5	142693
147624	\N	\N	\N	\N	63210103	Irongo	\N	5	142693
147625	\N	\N	\N	\N	63210104	Izege	\N	5	142693
147626	\N	\N	\N	\N	63210105	Kamanyola	\N	5	142693
147627	\N	\N	\N	\N	63210106	Kamisimbi	\N	5	142693
147628	\N	\N	\N	\N	63210107	Kaniola	\N	5	142693
147629	\N	\N	\N	\N	63210108	Karhongo	\N	5	142693
147630	\N	\N	\N	\N	63210109	Lubona	\N	5	142693
147631	\N	\N	\N	\N	63210110	Luchiga	\N	5	142693
147632	\N	\N	\N	\N	63210111	Lurhala	\N	5	142693
147633	\N	\N	\N	\N	63210112	Mulamba	\N	5	142693
147634	\N	\N	\N	\N	63210113	Mushinga	\N	5	142693
147635	\N	\N	\N	\N	63210114	Nduba	\N	5	142693
147636	\N	\N	\N	\N	63210115	Rubimbi	\N	5	142693
147637	\N	\N	\N	\N	63210116	Walungu	\N	5	142693
147638	\N	\N	\N	\N	63210201	Bulumbwa	\N	5	142694
147639	\N	\N	\N	\N	63210202	Butuzi	\N	5	142694
147640	\N	\N	\N	\N	63210203	Chibanda	\N	5	142694
147641	\N	\N	\N	\N	63210204	Chinumba	\N	5	142694
147642	\N	\N	\N	\N	63210205	Chirimiro	\N	5	142694
147643	\N	\N	\N	\N	63210206	Kabembe	\N	5	142694
147644	\N	\N	\N	\N	63210207	Kabungwe	\N	5	142694
147645	\N	\N	\N	\N	63210208	Kasanga	\N	5	142694
147646	\N	\N	\N	\N	63210209	Kashozi	\N	5	142694
147647	\N	\N	\N	\N	63210210	Kibuti	\N	5	142694
147648	\N	\N	\N	\N	63210211	Lukube	\N	5	142694
147649	\N	\N	\N	\N	63210212	Muhumba	\N	5	142694
147650	\N	\N	\N	\N	63210213	Mulambi	\N	5	142694
147651	\N	\N	\N	\N	63210214	Mushingwa	\N	5	142694
147652	\N	\N	\N	\N	63210215	Ngando	\N	5	142694
147653	\N	\N	\N	\N	63220101	Bijombo	\N	5	142696
147654	\N	\N	\N	\N	63220102	Kabindula	\N	5	142696
147655	\N	\N	\N	\N	63220103	Kalungwe	\N	5	142696
147656	\N	\N	\N	\N	63220104	Katala	\N	5	142696
147657	\N	\N	\N	\N	63220105	Kidjaga	\N	5	142696
147658	\N	\N	\N	\N	63220106	Kitundu	\N	5	142696
147659	\N	\N	\N	\N	63220107	Makobola	\N	5	142696
147660	\N	\N	\N	\N	63220201	Kigoma	\N	5	142697
147661	\N	\N	\N	\N	63220202	Lemera	\N	5	142697
147662	\N	\N	\N	\N	63220203	Luvungi-Itara	\N	5	142697
147663	\N	\N	\N	\N	63220204	Muhungu	\N	5	142697
147664	\N	\N	\N	\N	63220205	Runingo	\N	5	142697
147665	\N	\N	\N	\N	63220301	Kabunambo	\N	5	142698
147666	\N	\N	\N	\N	63220302	Kagando	\N	5	142698
147667	\N	\N	\N	\N	63220303	Kakamba	\N	5	142698
147668	\N	\N	\N	\N	63220304	Luberizi	\N	5	142698
147669	\N	\N	\N	\N	63220305	Kiliba ?	\N	5	142698
147670	\N	\N	\N	\N	63225101	Kabindula	\N	5	142699
147671	\N	\N	\N	\N	63225102	X Kabundu X	\N	5	142699
147672	\N	\N	\N	\N	63225103	Kakombe	\N	5	142699
147673	\N	\N	\N	\N	63225104	Kasenga	\N	5	142699
147674	\N	\N	\N	\N	63225105	Kavimvira	\N	5	142699
147675	\N	\N	\N	\N	63225106	Kimanga	\N	5	142699
147676	\N	\N	\N	\N	63225107	X Kirhimbula X	\N	5	142699
147677	\N	\N	\N	\N	63225108	Mulongwe	\N	5	142699
147678	\N	\N	\N	\N	63225109	X Nyarangwa X	\N	5	142699
147679	\N	\N	\N	\N	63225110	Rombe 1	\N	5	142699
147680	\N	\N	\N	\N	63225111	X Bombe 2 X	\N	5	142699
147681	\N	\N	\N	\N	63225112	Songo	\N	5	142699
147682	\N	\N	\N	\N	63225113	Kibondwe	\N	5	142699
147683	\N	\N	\N	\N	63225114	Kilibula	\N	5	142699
147684	\N	\N	\N	\N	63225601	Kagenge Kahungwe	\N	5	142704
147685	\N	\N	\N	\N	63225602	Kibogoye	\N	5	142704
147686	\N	\N	\N	\N	63225603	Kigurwe	\N	5	142704
147687	\N	\N	\N	\N	63225604	Kyanyunda	\N	5	142704
147688	\N	\N	\N	\N	63225605	Musenyi	\N	5	142704
147689	\N	\N	\N	\N	63225606	Nyakabere 1	\N	5	142704
147690	\N	\N	\N	\N	63225607	Nyakabere 2	\N	5	142704
147691	\N	\N	\N	\N	63225608	Rutanga	\N	5	142704
147692	\N	\N	\N	\N	63230101	Babungwe Sud	\N	5	142705
147693	\N	\N	\N	\N	63230102	Basikalangwa	\N	5	142705
147694	\N	\N	\N	\N	63230103	Basikasilu	\N	5	142705
147695	\N	\N	\N	\N	63230104	Batombwe	\N	5	142705
147696	\N	\N	\N	\N	63230105	Misufi	\N	5	142705
147697	\N	\N	\N	\N	63230201	X Asombo	\N	5	142706
147698	\N	\N	\N	\N	63230202	Basikasingo	\N	5	142706
147699	\N	\N	\N	\N	63230203	Basimimbi	\N	5	142706
147700	\N	\N	\N	\N	63230204	Basimunyaka-Sud	\N	5	142706
147701	\N	\N	\N	\N	63230205	Obekulu	\N	5	142706
147702	\N	\N	\N	\N	63230206	Basombo	\N	5	142706
147703	\N	\N	\N	\N	63230301	Babungwe-Nord	\N	5	142707
147704	\N	\N	\N	\N	63230302	Balala-Nord	\N	5	142707
147705	\N	\N	\N	\N	63230303	Basilocha	\N	5	142707
147706	\N	\N	\N	\N	63230304	Basimuniaka Nord	\N	5	142707
147707	\N	\N	\N	\N	63230305	Basimukuma Nord	\N	5	142707
147708	\N	\N	\N	\N	63230401	Ubwari	\N	5	142708
147709	\N	\N	\N	\N	63230402	Balala-Sud	\N	5	142708
147710	\N	\N	\N	\N	63230403	Basimukindje	\N	5	142708
147711	\N	\N	\N	\N	63230404	Basimukuma Sud	\N	5	142708
147712	\N	\N	\N	\N	63230405	Batombwe	\N	5	142708
147713	\N	\N	\N	\N	63240101	Babongolo	\N	5	142710
147714	\N	\N	\N	\N	63240102	Babunga	\N	5	142710
147715	\N	\N	\N	\N	63240103	Bagezi	\N	5	142710
147716	\N	\N	\N	\N	63240104	Bakute	\N	5	142710
147717	\N	\N	\N	\N	63240105	Baligi	\N	5	142710
147718	\N	\N	\N	\N	63240106	Balinzi	\N	5	142710
147719	\N	\N	\N	\N	63240107	Bamulinda	\N	5	142710
147720	\N	\N	\N	\N	63240108	Banakyungu	\N	5	142710
147721	\N	\N	\N	\N	63240109	Banampute	\N	5	142710
147722	\N	\N	\N	\N	63240110	Banamukia	\N	5	142710
147723	\N	\N	\N	\N	63240111	Basibugembe	\N	5	142710
147724	\N	\N	\N	\N	63240112	Basikamugulu	\N	5	142710
147725	\N	\N	\N	\N	63240113	Basikasa	\N	5	142710
147726	\N	\N	\N	\N	63240114	Basikumbilwa	\N	5	142710
147727	\N	\N	\N	\N	63240115	Basimbi	\N	5	142710
147728	\N	\N	\N	\N	63240116	Basimwenda	\N	5	142710
147729	\N	\N	\N	\N	63240117	Basitabyale	\N	5	142710
147730	\N	\N	\N	\N	63240118	Bause	\N	5	142710
147731	\N	\N	\N	\N	63240119	Bawandeme	\N	5	142710
147732	\N	\N	\N	\N	63240120	Bingili	\N	5	142710
147733	\N	\N	\N	\N	63240201	Babulinzi	\N	5	142711
147734	\N	\N	\N	\N	63240202	Babwanda	\N	5	142711
147735	\N	\N	\N	\N	63240203	Balobola	\N	5	142711
147736	\N	\N	\N	\N	63240204	Bamulinda	\N	5	142711
147737	\N	\N	\N	\N	63240205	Basilubanda	\N	5	142711
147738	\N	\N	\N	\N	63240206	Basilugulu	\N	5	142711
147739	\N	\N	\N	\N	63240207	Basimwenda 1	\N	5	142711
147740	\N	\N	\N	\N	63240208	Basimwenda 2	\N	5	142711
147741	\N	\N	\N	\N	63240209	Basitonga	\N	5	142711
147742	\N	\N	\N	\N	63240210	Batumba	\N	5	142711
147743	\N	\N	\N	\N	63240301	Ihanga	\N	5	142712
147744	\N	\N	\N	\N	63240302	Ilowe	\N	5	142712
147745	\N	\N	\N	\N	63240303	Kalambi	\N	5	142712
147746	\N	\N	\N	\N	63240304	Kataraka	\N	5	142712
147747	\N	\N	\N	\N	63240305	Kigogo	\N	5	142712
147748	\N	\N	\N	\N	63240306	Kihonvu	\N	5	142712
147749	\N	\N	\N	\N	63240307	Kilimbwe	\N	5	142712
147750	\N	\N	\N	\N	63240308	Mukangala	\N	5	142712
147751	\N	\N	\N	\N	63240401	Birhala	\N	5	142713
147752	\N	\N	\N	\N	63240402	Budaha	\N	5	142713
147753	\N	\N	\N	\N	63240403	Bugobe	\N	5	142713
147754	\N	\N	\N	\N	63240404	Buhogo	\N	5	142713
147755	\N	\N	\N	\N	63240405	Cheshero	\N	5	142713
147756	\N	\N	\N	\N	63240406	Chibwindie	\N	5	142713
147757	\N	\N	\N	\N	63240407	Chirere	\N	5	142713
147758	\N	\N	\N	\N	63240408	Chiriri	\N	5	142713
147759	\N	\N	\N	\N	63240409	Chizuka	\N	5	142713
147760	\N	\N	\N	\N	63240410	Idudwe	\N	5	142713
147761	\N	\N	\N	\N	63240411	Kalambo	\N	5	142713
147762	\N	\N	\N	\N	63240412	Karhendezi	\N	5	142713
147763	\N	\N	\N	\N	63240413	Kitwabaluzi	\N	5	142713
147764	\N	\N	\N	\N	63240414	Luhuru	\N	5	142713
147765	\N	\N	\N	\N	63240415	Mulambi	\N	5	142713
147766	\N	\N	\N	\N	63240416	Mulanga	\N	5	142713
147767	\N	\N	\N	\N	63240417	Ntondo	\N	5	142713
147768	\N	\N	\N	\N	63240418	Nyirndja	\N	5	142713
147769	\N	\N	\N	\N	63240501	Bujiri	\N	5	142714
147770	\N	\N	\N	\N	63240502	Burhembo	\N	5	142714
147771	\N	\N	\N	\N	63240503	Chibanda 2	\N	5	142714
147772	\N	\N	\N	\N	63240504	Idubwe	\N	5	142714
147773	\N	\N	\N	\N	63240505	Kabalole	\N	5	142714
147774	\N	\N	\N	\N	63240506	Karhundu	\N	5	142714
147775	\N	\N	\N	\N	63240507	Lughiga	\N	5	142714
147776	\N	\N	\N	\N	63240508	Lutuha Chonga	\N	5	142714
147777	\N	\N	\N	\N	63240509	Mulamba	\N	5	142714
147778	\N	\N	\N	\N	63240601	Basikamakulu	\N	5	142715
147779	\N	\N	\N	\N	63240602	Basimukindje 1	\N	5	142715
147780	\N	\N	\N	\N	63240603	Basimukindje 2	\N	5	142715
147781	\N	\N	\N	\N	63240604	Basimukuma	\N	5	142715
147782	\N	\N	\N	\N	63240605	Basimunyaka	\N	5	142715
147783	\N	\N	\N	\N	63240606	Basimwenda	\N	5	142715
147784	\N	\N	\N	\N	63250101	Basitabyale	\N	5	142718
147785	\N	\N	\N	\N	63250102	Batali	\N	5	142718
147786	\N	\N	\N	\N	63250103	Ikama-Kasanza	\N	5	142718
147787	\N	\N	\N	\N	63250104	Nkulu	\N	5	142718
147788	\N	\N	\N	\N	63250201	Bagalo	\N	5	142719
147789	\N	\N	\N	\N	63250202	Bakiunga	\N	5	142719
147790	\N	\N	\N	\N	63250203	Baliga	\N	5	142719
147791	\N	\N	\N	\N	63250204	Bamuguba-Nord	\N	5	142719
147792	\N	\N	\N	\N	63250205	Bamuguba-Sud	\N	5	142719
147793	\N	\N	\N	\N	63250206	Bangoma	\N	5	142719
147794	\N	\N	\N	\N	63250207	Baygala	\N	5	142719
147795	\N	\N	\N	\N	63260101	Buzi	\N	5	142721
147796	\N	\N	\N	\N	63260102	Kalima /Kauma	\N	5	142721
147797	\N	\N	\N	\N	63260103	Kalonge	\N	5	142721
147798	\N	\N	\N	\N	63260104	Mbinga-Nord	\N	5	142721
147799	\N	\N	\N	\N	63260105	Mbinga-Sud	\N	5	142721
147800	\N	\N	\N	\N	63260106	Mubuku	\N	5	142721
147801	\N	\N	\N	\N	63260107	Ziralo	\N	5	142721
147802	\N	\N	\N	\N	63260201	Bagana	\N	5	142722
147803	\N	\N	\N	\N	63260202	Bitale	\N	5	142722
147804	\N	\N	\N	\N	63260203	Kabali	\N	5	142722
147805	\N	\N	\N	\N	63260204	Lubengera	\N	5	142722
147806	\N	\N	\N	\N	63260205	Mulonge	\N	5	142722
147807	\N	\N	\N	\N	63260206	Mushenyi	\N	5	142722
147808	\N	\N	\N	\N	63260207	Ndando	\N	5	142722
147809	\N	\N	\N	\N	63270101	Mpene	\N	5	142724
147810	\N	\N	\N	\N	63270102	Mugote	\N	5	142724
147811	\N	\N	\N	\N	63270103	Nyakalengwa	\N	5	142724
147812	\N	\N	\N	\N	63270201	Bugarura	\N	5	142725
147813	\N	\N	\N	\N	63270202	Bunyakiri	\N	5	142725
147814	\N	\N	\N	\N	63270203	Kihumba	\N	5	142725
147815	\N	\N	\N	\N	63280101	Ihembe	\N	5	142726
147816	\N	\N	\N	\N	63280102	Irhengabarhonyi	\N	5	142726
147817	\N	\N	\N	\N	63280103	Lubago	\N	5	142726
147818	\N	\N	\N	\N	63280201	Bugobe	\N	5	142727
147819	\N	\N	\N	\N	63280202	Bughorhe	\N	5	142727
147820	\N	\N	\N	\N	63280203	Bushunda	\N	5	142727
147821	\N	\N	\N	\N	63280204	Bushwira	\N	5	142727
147822	\N	\N	\N	\N	63280205	Chirunga	\N	5	142727
147823	\N	\N	\N	\N	63280206	Irhambi-Katana	\N	5	142727
147824	\N	\N	\N	\N	63280207	Ishungu	\N	5	142727
147825	\N	\N	\N	\N	63280208	Kagabi	\N	5	142727
147826	\N	\N	\N	\N	63280209	Lugendo	\N	5	142727
147827	\N	\N	\N	\N	63280210	Luhihi	\N	5	142727
147828	\N	\N	\N	\N	63280211	Miti	\N	5	142727
147829	\N	\N	\N	\N	63280212	Mudaka	\N	5	142727
147830	\N	\N	\N	\N	63280213	Mudusa	\N	5	142727
147831	\N	\N	\N	\N	63280214	Momosho	\N	5	142727
147832	\N	\N	\N	\N	70110001	Bukama	\N	5	142729
147833	\N	\N	\N	\N	70110002	Kimilolo	\N	5	142729
147834	\N	\N	\N	\N	70110003	Kinyma	\N	5	142729
147835	\N	\N	\N	\N	70110004	Kisale	\N	5	142729
147836	\N	\N	\N	\N	70110005	Lufira	\N	5	142729
147837	\N	\N	\N	\N	70110006	Musumba	\N	5	142729
147838	\N	\N	\N	\N	70110007	Mwana Shaba	\N	5	142729
147839	\N	\N	\N	\N	70110008	N'sele	\N	5	142729
147840	\N	\N	\N	\N	70110009	Upemba	\N	5	142729
147841	\N	\N	\N	\N	70120001	Gambela	\N	5	142730
147842	\N	\N	\N	\N	70120002	Kalubwe	\N	5	142730
147843	\N	\N	\N	\N	70120003	Kiwele	\N	5	142730
147844	\N	\N	\N	\N	70120004	Lido-Golf	\N	5	142730
147845	\N	\N	\N	\N	70120005	Lumumba	\N	5	142730
147846	\N	\N	\N	\N	70120006	Makutano	\N	5	142730
147847	\N	\N	\N	\N	70120007	Mampala	\N	5	142730
147848	\N	\N	\N	\N	70130000	Kafubu	\N	5	142731
147849	\N	\N	\N	\N	70130001	Bel-Air 1	\N	5	142731
147850	\N	\N	\N	\N	70130002	Bel-Air 2	\N	5	142731
147851	\N	\N	\N	\N	70130003	Bongonga	\N	5	142731
147852	\N	\N	\N	\N	70130004	Industriel	\N	5	142731
147853	\N	\N	\N	\N	70130006	Kampemba	\N	5	142731
147854	\N	\N	\N	\N	70130007	Kigoma	\N	5	142731
147855	\N	\N	\N	\N	70140001	Bendefa	\N	5	142732
147856	\N	\N	\N	\N	70140002	Kalukuluku	\N	5	142732
147857	\N	\N	\N	\N	70140003	Matoleo	\N	5	142732
147858	\N	\N	\N	\N	70140004	Shindaika	\N	5	142732
147859	\N	\N	\N	\N	70150001	Lualaba	\N	5	142733
147860	\N	\N	\N	\N	70150002	Luapula	\N	5	142733
147861	\N	\N	\N	\N	70150003	Luvua	\N	5	142733
147862	\N	\N	\N	\N	70160001	Kitumaini	\N	5	142734
147863	\N	\N	\N	\N	70160002	Njanja	\N	5	142734
147864	\N	\N	\N	\N	70170001	Kalebuka	\N	5	142735
147865	\N	\N	\N	\N	70170002	Kasanga	\N	5	142735
147866	\N	\N	\N	\N	70170003	Kasapa	\N	5	142735
147867	\N	\N	\N	\N	70170004	Kasungami	\N	5	142735
147868	\N	\N	\N	\N	70170005	Kimbembe	\N	5	142735
147869	\N	\N	\N	\N	70170006	Luwowoshi	\N	5	142735
147870	\N	\N	\N	\N	70170007	Munda	\N	5	142735
147871	\N	\N	\N	\N	70170008	Navyundu	\N	5	142735
147872	\N	\N	\N	\N	70210001	Kakontwe	\N	5	142736
147873	\N	\N	\N	\N	70210002	Kamilopa	\N	5	142736
147874	\N	\N	\N	\N	70210003	Kiwele	\N	5	142736
147875	\N	\N	\N	\N	70210004	Muchanga	\N	5	142736
147876	\N	\N	\N	\N	70220001	Kalipopo	\N	5	142737
147877	\N	\N	\N	\N	70220002	Kampemba	\N	5	142737
147878	\N	\N	\N	\N	70220003	Kanona	\N	5	142737
147879	\N	\N	\N	\N	70220004	Kaponona	\N	5	142737
147880	\N	\N	\N	\N	70220005	Kibadi	\N	5	142737
147881	\N	\N	\N	\N	70220006	Kisunka	\N	5	142737
147882	\N	\N	\N	\N	70220007	Kyubo	\N	5	142737
147883	\N	\N	\N	\N	70220008	Musumba	\N	5	142737
147884	\N	\N	\N	\N	70220009	Nkolomoni	\N	5	142737
147885	\N	\N	\N	\N	70220010	Okito	\N	5	142737
147886	\N	\N	\N	\N	70230001	Kampumpi	\N	5	142738
147887	\N	\N	\N	\N	70230002	Kitabataba	\N	5	142738
147888	\N	\N	\N	\N	70230003	Mama Yemo	\N	5	142738
147889	\N	\N	\N	\N	70230004	O.C.S.	\N	5	142738
147890	\N	\N	\N	\N	70240001	Buluo	\N	5	142739
147891	\N	\N	\N	\N	70240002	Kilima	\N	5	142739
147892	\N	\N	\N	\N	70240003	Kimulanda	\N	5	142739
147893	\N	\N	\N	\N	70240004	Nguya	\N	5	142739
147894	\N	\N	\N	\N	70310001	Bishara	\N	5	142740
147895	\N	\N	\N	\N	70310002	GCM/Kapata	\N	5	142740
147896	\N	\N	\N	\N	70310003	GCM/Kolwezi	\N	5	142740
147897	\N	\N	\N	\N	70310004	GCM/Luilu	\N	5	142740
147898	\N	\N	\N	\N	70310005	GCM/Musonoi	\N	5	142740
147899	\N	\N	\N	\N	70310006	Kamina	\N	5	142740
147900	\N	\N	\N	\N	70320001	Dilungu	\N	5	142741
147901	\N	\N	\N	\N	70320002	Industriel	\N	5	142741
147902	\N	\N	\N	\N	70320003	Kakipuluwe	\N	5	142741
147903	\N	\N	\N	\N	70320004	Kasombo	\N	5	142741
147904	\N	\N	\N	\N	70320005	Kasulu	\N	5	142741
147905	\N	\N	\N	\N	70320006	Kayeke	\N	5	142741
147906	\N	\N	\N	\N	70320007	Mununka	\N	5	142741
147907	\N	\N	\N	\N	70320008	Mutoshi	\N	5	142741
147908	\N	\N	\N	\N	70330101	Mushima	\N	5	142742
147909	\N	\N	\N	\N	70330102	Musikatantanda	\N	5	142742
147910	\N	\N	\N	\N	70330201	Kawewe	\N	5	142743
147911	\N	\N	\N	\N	70330202	Lumanga	\N	5	142743
147912	\N	\N	\N	\N	70330203	Mufunga	\N	5	142743
147913	\N	\N	\N	\N	70330301	Kazembe	\N	5	142744
147914	\N	\N	\N	\N	70330302	Mwamfwe	\N	5	142744
147915	\N	\N	\N	\N	70330303	Mwilu	\N	5	142744
147916	\N	\N	\N	\N	70330304	Pweme	\N	5	142744
147917	\N	\N	\N	\N	70340101	Munanga	\N	5	142746
147918	\N	\N	\N	\N	70340102	Wakipindji	\N	5	142746
147919	\N	\N	\N	\N	70340201	Kayombo	\N	5	142747
147920	\N	\N	\N	\N	70340202	Kibwe	\N	5	142747
147921	\N	\N	\N	\N	70340301	Katampa	\N	5	142748
147922	\N	\N	\N	\N	70340302	Mukwemba (Mulumbu)	\N	5	142748
147923	\N	\N	\N	\N	70340401	Bunkeya	\N	5	142749
147924	\N	\N	\N	\N	70340402	Kalonga	\N	5	142749
147925	\N	\N	\N	\N	70340403	Mbame	\N	5	142749
147926	\N	\N	\N	\N	70340404	Mukabe-Kazari	\N	5	142749
147927	\N	\N	\N	\N	70340405	Mutombo	\N	5	142749
147928	\N	\N	\N	\N	70340406	Mwenda-Mukose (Wakpindji)	\N	5	142749
147929	\N	\N	\N	\N	70410101	Kalenda	\N	5	142753
147930	\N	\N	\N	\N	70410102	Kanyovu	\N	5	142753
147931	\N	\N	\N	\N	70410103	Sakabwile	\N	5	142753
147932	\N	\N	\N	\N	70410104	Sangaji	\N	5	142753
147933	\N	\N	\N	\N	70410105	Tshisangama	\N	5	142753
147934	\N	\N	\N	\N	70410201	Kakena	\N	5	142754
147935	\N	\N	\N	\N	70410202	Kapita (Kayita)	\N	5	142754
147936	\N	\N	\N	\N	70410203	Katshitao	\N	5	142754
147937	\N	\N	\N	\N	70410204	Tshifina	\N	5	142754
147938	\N	\N	\N	\N	70410301	Kandaji	\N	5	142755
147939	\N	\N	\N	\N	70410302	Sakabundji	\N	5	142755
147940	\N	\N	\N	\N	70410303	Satshta	\N	5	142755
147941	\N	\N	\N	\N	70410401	Kabangu	\N	5	142756
147942	\N	\N	\N	\N	70410402	Mafunda-Kasai	\N	5	142756
147943	\N	\N	\N	\N	70410403	Mafunda-Ndembo	\N	5	142756
147944	\N	\N	\N	\N	70410404	Naomba	\N	5	142756
147945	\N	\N	\N	\N	70410405	Sakapenda	\N	5	142756
147946	\N	\N	\N	\N	70410406	Tambwe-Kalenda	\N	5	142756
147947	\N	\N	\N	\N	70410407	Tshiswakwa-Lushingi	\N	5	142756
147948	\N	\N	\N	\N	70410408	Twite	\N	5	142756
147949	\N	\N	\N	\N	70410501	Kaloko	\N	5	142757
147950	\N	\N	\N	\N	70410502	Kambi	\N	5	142757
147951	\N	\N	\N	\N	70410503	Kasengula	\N	5	142757
147952	\N	\N	\N	\N	70410504	Kasongo   (Kasanga)	\N	5	142757
147953	\N	\N	\N	\N	70410505	Lubisi / Lumbidi	\N	5	142757
147954	\N	\N	\N	\N	70410506	Ndanda	\N	5	142757
147955	\N	\N	\N	\N	70410507	Tambwe	\N	5	142757
147956	\N	\N	\N	\N	70410508	Tshala	\N	5	142757
147957	\N	\N	\N	\N	70410601	Kazembe	\N	5	142758
147958	\N	\N	\N	\N	70410602	Mukonkoto	\N	5	142758
147959	\N	\N	\N	\N	70410701	Kasongo-Mukendenge	\N	5	142759
147960	\N	\N	\N	\N	70410702	Katende-Kasongo	\N	5	142759
147961	\N	\N	\N	\N	70410703	Katende-Tshipoy	\N	5	142759
147962	\N	\N	\N	\N	70410704	Tshilemo	\N	5	142759
147963	\N	\N	\N	\N	70410801	Kaita	\N	5	142760
147964	\N	\N	\N	\N	70410802	Khukihu	\N	5	142760
147965	\N	\N	\N	\N	70410803	Mundundula	\N	5	142760
147966	\N	\N	\N	\N	70410804	Nasamba	\N	5	142760
147967	\N	\N	\N	\N	70410805	Tshimbumbulu	\N	5	142760
147968	\N	\N	\N	\N	70410806	Tshipulu	\N	5	142760
147969	\N	\N	\N	\N	70410901	Samujina	\N	5	142761
147970	\N	\N	\N	\N	70410902	Sakayongo	\N	5	142761
147971	\N	\N	\N	\N	70410903	Tambwe	\N	5	142761
147972	\N	\N	\N	\N	70410904	Tshinika	\N	5	142761
147973	\N	\N	\N	\N	70411001	Centre Kasaji	\N	5	142762
147974	\N	\N	\N	\N	70411101	Divuma-Centre	\N	5	142763
147975	\N	\N	\N	\N	70415101	Dilolo	\N	5	142764
147976	\N	\N	\N	\N	70420101	Fumu-Jinga	\N	5	142765
147977	\N	\N	\N	\N	70420102	Fumu-Kapope	\N	5	142765
147978	\N	\N	\N	\N	70420103	Fumu-Tshiambundu	\N	5	142765
147979	\N	\N	\N	\N	70420104	Kalova	\N	5	142765
147980	\N	\N	\N	\N	70420105	Kamande	\N	5	142765
147981	\N	\N	\N	\N	70420106	Kapepela	\N	5	142765
147982	\N	\N	\N	\N	70420107	Kashinda	\N	5	142765
147983	\N	\N	\N	\N	70420108	Kataola	\N	5	142765
147984	\N	\N	\N	\N	70420109	Kavumbi	\N	5	142765
147985	\N	\N	\N	\N	70420110	Kazovu	\N	5	142765
147986	\N	\N	\N	\N	70420111	Mfumu-Banda	\N	5	142765
147987	\N	\N	\N	\N	70420112	Mupatshi	\N	5	142765
147988	\N	\N	\N	\N	70420113	Mwin-Djamba	\N	5	142765
147989	\N	\N	\N	\N	70420114	Mwin-Jimbi	\N	5	142765
147990	\N	\N	\N	\N	70420115	Mwin-Katoka	\N	5	142765
147991	\N	\N	\N	\N	70420116	Mwin-Mena	\N	5	142765
147992	\N	\N	\N	\N	70420117	Mwin-Mpemba	\N	5	142765
147993	\N	\N	\N	\N	70420118	Mwin-Tshamba	\N	5	142765
147994	\N	\N	\N	\N	70420119	Talola	\N	5	142765
147995	\N	\N	\N	\N	70420201	Kabwebwe	\N	5	142766
147996	\N	\N	\N	\N	70420202	Longesa	\N	5	142766
147997	\N	\N	\N	\N	70420203	Mulimba	\N	5	142766
147998	\N	\N	\N	\N	70420204	Njamba	\N	5	142766
147999	\N	\N	\N	\N	70420205	Sandami	\N	5	142766
148000	\N	\N	\N	\N	70420206	Sapindji	\N	5	142766
148001	\N	\N	\N	\N	70420207	Say-Bwanda	\N	5	142766
148002	\N	\N	\N	\N	70420208	Tshibindu	\N	5	142766
148003	\N	\N	\N	\N	70420209	Tshikweji	\N	5	142766
148004	\N	\N	\N	\N	70420301	Mboko	\N	5	142767
148005	\N	\N	\N	\N	70420302	Mfumu Kazaji	\N	5	142767
148006	\N	\N	\N	\N	70420303	Mfumu Mujinga	\N	5	142767
148007	\N	\N	\N	\N	70420304	Mwin-Tshibwika	\N	5	142767
148008	\N	\N	\N	\N	70420305	Mwin -Kateng	\N	5	142767
148009	\N	\N	\N	\N	70420306	Nsengeu	\N	5	142767
148010	\N	\N	\N	\N	70420401	Kampon	\N	5	142768
148011	\N	\N	\N	\N	70420402	Kasongo-Jana	\N	5	142768
148012	\N	\N	\N	\N	70420403	Lupwapwa	\N	5	142768
148013	\N	\N	\N	\N	70420404	Mfumu - Uzu	\N	5	142768
148014	\N	\N	\N	\N	70420405	Mutshiy - Aman	\N	5	142768
148015	\N	\N	\N	\N	70420406	Mwin - Kabil	\N	5	142768
148016	\N	\N	\N	\N	70420407	Mwin - Kading	\N	5	142768
148017	\N	\N	\N	\N	70420408	Mwin --Kwelu	\N	5	142768
148018	\N	\N	\N	\N	70420409	Njik Kalenga	\N	5	142768
148019	\N	\N	\N	\N	70420410	Samusambu	\N	5	142768
148020	\N	\N	\N	\N	70420411	Swan - Duwa	\N	5	142768
148021	\N	\N	\N	\N	70420412	Tshibungil	\N	5	142768
148022	\N	\N	\N	\N	70420413	Tshingwele	\N	5	142768
148023	\N	\N	\N	\N	70420501	Dilombe	\N	5	142769
148024	\N	\N	\N	\N	70420502	Jimbola	\N	5	142769
148025	\N	\N	\N	\N	70420503	Kamulembe	\N	5	142769
148026	\N	\N	\N	\N	70420504	Kamwila	\N	5	142769
148027	\N	\N	\N	\N	70420505	Lukongolo	\N	5	142769
148028	\N	\N	\N	\N	70420506	Luputa	\N	5	142769
148029	\N	\N	\N	\N	70420507	Matanga	\N	5	142769
148030	\N	\N	\N	\N	70420508	Mfumu-Lav	\N	5	142769
148031	\N	\N	\N	\N	70420509	Mwan-A-Tshund	\N	5	142769
148032	\N	\N	\N	\N	70420510	Mwin Kapend	\N	5	142769
148033	\N	\N	\N	\N	70420511	Mwin-Mena	\N	5	142769
148034	\N	\N	\N	\N	70420512	Mwin-Ndjungu	\N	5	142769
148035	\N	\N	\N	\N	70420513	Ndolo	\N	5	142769
148036	\N	\N	\N	\N	70420514	Nganga-Mukota	\N	5	142769
148037	\N	\N	\N	\N	70420601	Dizungwe	\N	5	142770
148038	\N	\N	\N	\N	70420602	Kalomboji	\N	5	142770
148039	\N	\N	\N	\N	70420603	Kavula-Masamba	\N	5	142770
148040	\N	\N	\N	\N	70420604	Mpiana-Tenge	\N	5	142770
148041	\N	\N	\N	\N	70420605	Mwad-Kapuku	\N	5	142770
148042	\N	\N	\N	\N	70420606	Mwin-Mbij-Kap	\N	5	142770
148043	\N	\N	\N	\N	70420607	Mwin-Mbij-Sangand	\N	5	142770
148044	\N	\N	\N	\N	70420608	Swana-Kamburu	\N	5	142770
148045	\N	\N	\N	\N	70420609	Ulamba-Fuana	\N	5	142770
148046	\N	\N	\N	\N	70420610	Ulamba-Uweji	\N	5	142770
148047	\N	\N	\N	\N	70420701	Katala	\N	5	142771
148048	\N	\N	\N	\N	70420702	Lumbimbo	\N	5	142771
148049	\N	\N	\N	\N	70420703	Sakandundu	\N	5	142771
148050	\N	\N	\N	\N	70420704	Tshitabika	\N	5	142771
148051	\N	\N	\N	\N	70420705	Say-Bwanda	\N	5	142771
148052	\N	\N	\N	\N	70420706	Tshibindu	\N	5	142771
148053	\N	\N	\N	\N	70420707	Tshikweji	\N	5	142771
148054	\N	\N	\N	\N	70420801	Mupelete	\N	5	142772
148055	\N	\N	\N	\N	70420802	Mwin-Lwo	\N	5	142772
148056	\N	\N	\N	\N	70420803	Mwin Yambo	\N	5	142772
148057	\N	\N	\N	\N	70420804	Tshala Ambo	\N	5	142772
148058	\N	\N	\N	\N	70430101	Dininga	\N	5	142774
148059	\N	\N	\N	\N	70430102	Esuvan Mulop / Nswa - a - Mula	\N	5	142774
148060	\N	\N	\N	\N	70430103	Kambamba	\N	5	142774
148061	\N	\N	\N	\N	70430104	Kambundu	\N	5	142774
148062	\N	\N	\N	\N	70430105	Kapanga	\N	5	142774
148063	\N	\N	\N	\N	70430106	Kamwanga	\N	5	142774
148064	\N	\N	\N	\N	70430107	Kanamp	\N	5	142774
148065	\N	\N	\N	\N	70430108	Kandala	\N	5	142774
148066	\N	\N	\N	\N	70430109	Kashiy-Mukaz	\N	5	142774
148067	\N	\N	\N	\N	70430110	Mokambo	\N	5	142774
148068	\N	\N	\N	\N	70430111	Mukabu	\N	5	142774
148069	\N	\N	\N	\N	70430112	Mutiy	\N	5	142774
148070	\N	\N	\N	\N	70430113	Ntende	\N	5	142774
148071	\N	\N	\N	\N	70430114	Pand-Kalenda / Mpa Akaleng	\N	5	142774
148072	\N	\N	\N	\N	70430115	Tembo	\N	5	142774
148073	\N	\N	\N	\N	70430116	Tshibaba	\N	5	142774
148074	\N	\N	\N	\N	70430117	Tshikam	\N	5	142774
148075	\N	\N	\N	\N	70430118	Tshitazu	\N	5	142774
148076	\N	\N	\N	\N	70430119	Tshiyamb	\N	5	142774
148077	\N	\N	\N	\N	70430120	Tubungu	\N	5	142774
148078	\N	\N	\N	\N	70435101	CitÃ© Kapanga	\N	5	142775
148079	\N	\N	\N	\N	70503050	Nzwiba	\N	5	142861
148080	\N	\N	\N	\N	70510101	Bas-Lubudi	\N	5	142776
148081	\N	\N	\N	\N	70510102	Haut-Lubilash	\N	5	142776
148082	\N	\N	\N	\N	70510103	Kalangu	\N	5	142776
148083	\N	\N	\N	\N	70510104	Kapambu	\N	5	142776
148084	\N	\N	\N	\N	70510105	Lubinge  / Lubende	\N	5	142776
148085	\N	\N	\N	\N	70510106	Lupelu	\N	5	142776
148086	\N	\N	\N	\N	70510107	Samba Lwina	\N	5	142776
148087	\N	\N	\N	\N	70510201	Bulemba	\N	5	142777
148088	\N	\N	\N	\N	70510202	Kafungo	\N	5	142777
148089	\N	\N	\N	\N	70510203	Kalui	\N	5	142777
148090	\N	\N	\N	\N	70510204	Kileka	\N	5	142777
148091	\N	\N	\N	\N	70510205	Kingo	\N	5	142777
148092	\N	\N	\N	\N	70510206	Kiseke	\N	5	142777
148093	\N	\N	\N	\N	70510207	Lubinda	\N	5	142777
148094	\N	\N	\N	\N	70510208	Lukavue	\N	5	142777
148095	\N	\N	\N	\N	70510209	Lukungu	\N	5	142777
148096	\N	\N	\N	\N	70510210	Lupamba	\N	5	142777
148097	\N	\N	\N	\N	70510211	Lusanga	\N	5	142777
148098	\N	\N	\N	\N	70510212	Minonga	\N	5	142777
148099	\N	\N	\N	\N	70510213	Mulengi	\N	5	142777
148100	\N	\N	\N	\N	70510214	Mwilambwe	\N	5	142777
148101	\N	\N	\N	\N	70510215	Ngoy Mwana	\N	5	142777
148102	\N	\N	\N	\N	70510216	Nzoa	\N	5	142777
148103	\N	\N	\N	\N	70510217	Samba	\N	5	142777
148104	\N	\N	\N	\N	70510218	Samitanda	\N	5	142777
148105	\N	\N	\N	\N	70510219	Sungu	\N	5	142777
148106	\N	\N	\N	\N	70515101	Centre Urbain	\N	5	142778
148107	\N	\N	\N	\N	70515102	Cinquante Deux	\N	5	142778
148108	\N	\N	\N	\N	70515103	Cinquante Trois	\N	5	142778
148109	\N	\N	\N	\N	70515104	Kaloba Bloc 2	\N	5	142778
148110	\N	\N	\N	\N	70515105	Katuba 1	\N	5	142778
148111	\N	\N	\N	\N	70515106	Katuba 2	\N	5	142778
148112	\N	\N	\N	\N	70515107	Mayilamene	\N	5	142778
148113	\N	\N	\N	\N	70515108	Quatorze	\N	5	142778
148114	\N	\N	\N	\N	70515109	Soixante Quatre	\N	5	142778
148115	\N	\N	\N	\N	70515110	Congo ( ZaÃ¯re )	\N	5	142778
148116	\N	\N	\N	\N	70520101	Ilunga Mbiya	\N	5	142779
148117	\N	\N	\N	\N	70520102	Kalulua	\N	5	142779
148118	\N	\N	\N	\N	70520103	Kalundwe	\N	5	142779
148119	\N	\N	\N	\N	70520104	Kamwanga	\N	5	142779
148120	\N	\N	\N	\N	70520105	Kansenji	\N	5	142779
148121	\N	\N	\N	\N	70520106	Kayeye	\N	5	142779
148122	\N	\N	\N	\N	70520107	Kimpanga	\N	5	142779
148123	\N	\N	\N	\N	70520108	Lupata	\N	5	142779
148124	\N	\N	\N	\N	70520109	Ngombe	\N	5	142779
148125	\N	\N	\N	\N	70520110	Sakadi Kisengi	\N	5	142779
148126	\N	\N	\N	\N	70520111	Sunga	\N	5	142779
148127	\N	\N	\N	\N	70520112	Tamba / Yamba	\N	5	142779
148128	\N	\N	\N	\N	70520113	Tshibanda / Tshibamba	\N	5	142779
148129	\N	\N	\N	\N	70520114	Tshioma	\N	5	142779
148130	\N	\N	\N	\N	70520115	Tshivi	\N	5	142779
148131	\N	\N	\N	\N	70525101	Cite Kaniama	\N	5	142780
148132	\N	\N	\N	\N	70525102	Lubilash	\N	5	142780
148133	\N	\N	\N	\N	70525103	Mobutu	\N	5	142780
148134	\N	\N	\N	\N	70525104	Mutombo Mukulu	\N	5	142780
148135	\N	\N	\N	\N	70525105	Tshijandayi	\N	5	142780
148136	\N	\N	\N	\N	70530101	Mudindwa	\N	5	142781
148137	\N	\N	\N	\N	70530102	Mukaya	\N	5	142781
148138	\N	\N	\N	\N	70530103	Mwala	\N	5	142781
148139	\N	\N	\N	\N	70530201	Bwila	\N	5	142782
148140	\N	\N	\N	\N	70530202	Ilunga Kabale	\N	5	142782
148141	\N	\N	\N	\N	70530203	Ilunga Sungu	\N	5	142782
148142	\N	\N	\N	\N	70530204	Kadilo	\N	5	142782
148143	\N	\N	\N	\N	70530205	Katundwe	\N	5	142782
148144	\N	\N	\N	\N	70530206	Kavula M.	\N	5	142782
148145	\N	\N	\N	\N	70530207	Kibanza	\N	5	142782
148146	\N	\N	\N	\N	70530208	Kumwimba	\N	5	142782
148147	\N	\N	\N	\N	70530209	Madiya	\N	5	142782
148148	\N	\N	\N	\N	70530210	Muleya	\N	5	142782
148149	\N	\N	\N	\N	70530211	Munza	\N	5	142782
148150	\N	\N	\N	\N	70530212	Musengay	\N	5	142782
148151	\N	\N	\N	\N	70530213	Mwadi	\N	5	142782
148152	\N	\N	\N	\N	70530214	Mwambay	\N	5	142782
148153	\N	\N	\N	\N	70530215	Mwine Ngoie	\N	5	142782
148154	\N	\N	\N	\N	70530216	Ndingile	\N	5	142782
148155	\N	\N	\N	\N	70530217	Ngangole	\N	5	142782
148156	\N	\N	\N	\N	70530218	Nkombe	\N	5	142782
148157	\N	\N	\N	\N	70530219	Nyembo	\N	5	142782
148158	\N	\N	\N	\N	70530220	Umpeta	\N	5	142782
148159	\N	\N	\N	\N	70530301	Bidi-Kibwe	\N	5	142783
148160	\N	\N	\N	\N	70530302	Dipeta	\N	5	142783
148161	\N	\N	\N	\N	70530303	Kipete	\N	5	142783
148162	\N	\N	\N	\N	70530304	Lumba	\N	5	142783
148163	\N	\N	\N	\N	70530305	Musule	\N	5	142783
148164	\N	\N	\N	\N	70530306	Ngende	\N	5	142783
148165	\N	\N	\N	\N	70530307	Tambale	\N	5	142783
148166	\N	\N	\N	\N	70540101	Bangue	\N	5	142785
148167	\N	\N	\N	\N	70540102	Kikunka	\N	5	142785
148168	\N	\N	\N	\N	70540103	Kina	\N	5	142785
148169	\N	\N	\N	\N	70540104	Nondue	\N	5	142785
148170	\N	\N	\N	\N	70540201	Butombe	\N	5	142786
148171	\N	\N	\N	\N	70540202	Kabala	\N	5	142786
148172	\N	\N	\N	\N	70540203	Kabozya	\N	5	142786
148173	\N	\N	\N	\N	70540204	Kalume	\N	5	142786
148174	\N	\N	\N	\N	70540205	Lupitshi	\N	5	142786
148175	\N	\N	\N	\N	70540206	Tshimbu	\N	5	142786
148176	\N	\N	\N	\N	70540207	Tuba	\N	5	142786
148177	\N	\N	\N	\N	70540301	Bunda	\N	5	142787
148178	\N	\N	\N	\N	70540302	Kilumba	\N	5	142787
148179	\N	\N	\N	\N	70540303	Lubembey	\N	5	142787
148180	\N	\N	\N	\N	70540304	Mwanza	\N	5	142787
148181	\N	\N	\N	\N	70540305	Ndala	\N	5	142787
148182	\N	\N	\N	\N	70540401	Ilunga Mwila	\N	5	142788
148183	\N	\N	\N	\N	70540402	Kisula	\N	5	142788
148184	\N	\N	\N	\N	70540403	Ngoy-Mani	\N	5	142788
148185	\N	\N	\N	\N	70540501	Kabue	\N	5	142789
148186	\N	\N	\N	\N	70540502	Kabumbulu	\N	5	142789
148187	\N	\N	\N	\N	70540503	Kakombo	\N	5	142789
148188	\N	\N	\N	\N	70540504	Kapia	\N	5	142789
148189	\N	\N	\N	\N	70540505	Kyabo	\N	5	142789
148190	\N	\N	\N	\N	70540506	Mulongo	\N	5	142789
148191	\N	\N	\N	\N	70540601	Kangombe	\N	5	142790
148192	\N	\N	\N	\N	70540602	Kapoya	\N	5	142790
148193	\N	\N	\N	\N	70540603	Kasanza	\N	5	142790
148194	\N	\N	\N	\N	70540604	Kiwala	\N	5	142790
148195	\N	\N	\N	\N	70540605	Kongona-Bilenge/ Nkongolo	\N	5	142790
148196	\N	\N	\N	\N	70540606	Lumbule	\N	5	142790
148197	\N	\N	\N	\N	70550101	Fungwe	\N	5	142793
148198	\N	\N	\N	\N	70550102	Lualaba	\N	5	142793
148199	\N	\N	\N	\N	70550103	Mukala Nkulu	\N	5	142793
148200	\N	\N	\N	\N	70550104	Mwidia	\N	5	142793
148201	\N	\N	\N	\N	70550201	Bukama	\N	5	142794
148202	\N	\N	\N	\N	70550202	Ilunga-Lualaba	\N	5	142794
148203	\N	\N	\N	\N	70550203	Katobwe	\N	5	142794
148204	\N	\N	\N	\N	70550204	Katoto	\N	5	142794
148205	\N	\N	\N	\N	70550301	Kabuya	\N	5	142795
148206	\N	\N	\N	\N	70550302	Makonga Umba	\N	5	142795
148207	\N	\N	\N	\N	70550303	Mwine Dianda	\N	5	142795
148208	\N	\N	\N	\N	70550401	Kapamay	\N	5	142796
148209	\N	\N	\N	\N	70550402	Umpungu	\N	5	142796
148210	\N	\N	\N	\N	70550501	Kabanza 1	\N	5	142797
148211	\N	\N	\N	\N	70550502	Kabanza 2	\N	5	142797
148212	\N	\N	\N	\N	70550503	Kabelewe	\N	5	142797
148213	\N	\N	\N	\N	70550504	Kisonde	\N	5	142797
148214	\N	\N	\N	\N	70550505	Lukila	\N	5	142797
148215	\N	\N	\N	\N	70550506	Mangi	\N	5	142797
148216	\N	\N	\N	\N	70550507	Mpungwe	\N	5	142797
148217	\N	\N	\N	\N	70550508	Muyumbwe	\N	5	142797
148218	\N	\N	\N	\N	70550509	Numbi-a-Kibinga	\N	5	142797
148219	\N	\N	\N	\N	70550510	Twadi	\N	5	142797
148220	\N	\N	\N	\N	70550511	Yolo	\N	5	142797
148221	\N	\N	\N	\N	70550601	Butumba	\N	5	142798
148222	\N	\N	\N	\N	70550602	Katala	\N	5	142798
148223	\N	\N	\N	\N	70550603	Musanza	\N	5	142798
148224	\N	\N	\N	\N	70550604	Upemba	\N	5	142798
148225	\N	\N	\N	\N	70555101	Kabamona	\N	5	142799
148226	\N	\N	\N	\N	70555102	Kantentemine	\N	5	142799
148227	\N	\N	\N	\N	70555103	Lualaba	\N	5	142799
148228	\N	\N	\N	\N	70555104	Motomoto	\N	5	142799
148229	\N	\N	\N	\N	70610101	Bena Kunda	\N	5	142803
148230	\N	\N	\N	\N	70610102	Bondo	\N	5	142803
148231	\N	\N	\N	\N	70610103	Kakada	\N	5	142803
148232	\N	\N	\N	\N	70610104	Kalumbi	\N	5	142803
148233	\N	\N	\N	\N	70610105	Kasanga Mutea	\N	5	142803
148234	\N	\N	\N	\N	70610106	Kinsukulu	\N	5	142803
148235	\N	\N	\N	\N	70610107	Lambo Katenga	\N	5	142803
148236	\N	\N	\N	\N	70610108	Lambo Kilala	\N	5	142803
148237	\N	\N	\N	\N	70610109	Mahila	\N	5	142803
148238	\N	\N	\N	\N	70610110	Miketo	\N	5	142803
148239	\N	\N	\N	\N	70610111	Mulowa	\N	5	142803
148240	\N	\N	\N	\N	70610112	Tumbwe Fief	\N	5	142803
148241	\N	\N	\N	\N	70610201	Benze	\N	5	142804
148242	\N	\N	\N	\N	70610202	Kioko Nyumb	\N	5	142804
148243	\N	\N	\N	\N	70610301	Rutuku	\N	5	142805
148244	\N	\N	\N	\N	70615101	Bwana Kucha	\N	5	142806
148245	\N	\N	\N	\N	70615102	Kapulwa	\N	5	142806
148246	\N	\N	\N	\N	70615103	Kataki	\N	5	142806
148247	\N	\N	\N	\N	70615104	Katamba	\N	5	142806
148248	\N	\N	\N	\N	70615105	Kayinza	\N	5	142806
148249	\N	\N	\N	\N	70615106	Kifungo	\N	5	142806
148250	\N	\N	\N	\N	70615107	Kiginga	\N	5	142806
148251	\N	\N	\N	\N	70615108	Lubunduye	\N	5	142806
148252	\N	\N	\N	\N	70615109	Mutuka	\N	5	142806
148253	\N	\N	\N	\N	70615110	Regeza-Mwendo	\N	5	142806
148254	\N	\N	\N	\N	70620101	Kabele	\N	5	142808
148255	\N	\N	\N	\N	70620102	Kamena	\N	5	142808
148256	\N	\N	\N	\N	70620103	Kasenga	\N	5	142808
148257	\N	\N	\N	\N	70620104	Kabwela	\N	5	142808
148258	\N	\N	\N	\N	70620105	Mpenge	\N	5	142808
148259	\N	\N	\N	\N	70620106	Mupanga	\N	5	142808
148260	\N	\N	\N	\N	70620107	Mwanza	\N	5	142808
148261	\N	\N	\N	\N	70620201	Kansabala	\N	5	142809
148262	\N	\N	\N	\N	70620202	Kasokota	\N	5	142809
148263	\N	\N	\N	\N	70620203	Lambo	\N	5	142809
148264	\N	\N	\N	\N	70620204	Lungu-Lungu	\N	5	142809
148265	\N	\N	\N	\N	70620205	Malibu	\N	5	142809
148266	\N	\N	\N	\N	70620206	Masonde	\N	5	142809
148267	\N	\N	\N	\N	70620207	Mpala	\N	5	142809
148268	\N	\N	\N	\N	70620208	Mwindi (Mwidiala)	\N	5	142809
148269	\N	\N	\N	\N	70620301	Kikongo	\N	5	142810
148270	\N	\N	\N	\N	70620302	Kitendwe	\N	5	142810
148271	\N	\N	\N	\N	70620303	Kilunga	\N	5	142810
148272	\N	\N	\N	\N	70620304	Muliro	\N	5	142810
148273	\N	\N	\N	\N	70620305	Mulonde	\N	5	142810
148274	\N	\N	\N	\N	70620307	Mwange	\N	5	142810
148275	\N	\N	\N	\N	70620308	Selembe	\N	5	142810
148276	\N	\N	\N	\N	70620309	Kapampa	\N	5	142810
148277	\N	\N	\N	\N	70620401	Kabunda	\N	5	142811
148278	\N	\N	\N	\N	70620402	Kampela	\N	5	142811
148279	\N	\N	\N	\N	70620403	Kavukwa	\N	5	142811
148280	\N	\N	\N	\N	70620404	Kibiziwa	\N	5	142811
148281	\N	\N	\N	\N	70620405	Mutonwa	\N	5	142811
148282	\N	\N	\N	\N	70620501	Katele	\N	5	142812
148283	\N	\N	\N	\N	70620502	Muzombwe	\N	5	142812
148284	\N	\N	\N	\N	70620503	Mukuli	\N	5	142812
148285	\N	\N	\N	\N	70620504	Sakala	\N	5	142812
148286	\N	\N	\N	\N	70620601	Kalinde	\N	5	142813
148287	\N	\N	\N	\N	70620602	Mutambala	\N	5	142813
148288	\N	\N	\N	\N	70625101	Katele	\N	5	142814
148289	\N	\N	\N	\N	70625102	Kirungu	\N	5	142814
148290	\N	\N	\N	\N	70625103	Kinkalata	\N	5	142814
148291	\N	\N	\N	\N	70625104	Regeza	\N	5	142814
148292	\N	\N	\N	\N	70625105	Congo (Zaire)	\N	5	142814
148293	\N	\N	\N	\N	70630101	Kadilo-Kalombo	\N	5	142815
148294	\N	\N	\N	\N	70630102	Kiluwe	\N	5	142815
148295	\N	\N	\N	\N	70630103	Mpiana-Mbayo	\N	5	142815
148296	\N	\N	\N	\N	70630201	Bavumbu	\N	5	142816
148297	\N	\N	\N	\N	70630202	Kambi	\N	5	142816
148298	\N	\N	\N	\N	70630203	Kifwa	\N	5	142816
148299	\N	\N	\N	\N	70630204	Ngoya-Nseza / Ngoya Sanza	\N	5	142816
148300	\N	\N	\N	\N	70630205	Nkala	\N	5	142816
148301	\N	\N	\N	\N	70630301	Kiyombo	\N	5	142817
148302	\N	\N	\N	\N	70630302	Nsenga-Tshimbu	\N	5	142817
148303	\N	\N	\N	\N	70630401	Batembo	\N	5	142818
148304	\N	\N	\N	\N	70630402	Bena-Mbao	\N	5	142818
148305	\N	\N	\N	\N	70630403	Kabamba    (Kabanga  ?)	\N	5	142818
148306	\N	\N	\N	\N	70630404	Kalamata	\N	5	142818
148307	\N	\N	\N	\N	70630405	Kamongo	\N	5	142818
148308	\N	\N	\N	\N	70630406	Kayumba	\N	5	142818
148309	\N	\N	\N	\N	70630407	Kitentu	\N	5	142818
148310	\N	\N	\N	\N	70630408	Mwika	\N	5	142818
148311	\N	\N	\N	\N	70630501	Kanteba	\N	5	142819
148312	\N	\N	\N	\N	70630502	Katolo	\N	5	142819
148313	\N	\N	\N	\N	70630503	Luba	\N	5	142819
148314	\N	\N	\N	\N	70630601	Kamina-Lenge	\N	5	142820
148315	\N	\N	\N	\N	70630602	Kilunga	\N	5	142820
148316	\N	\N	\N	\N	70630603	Panda-Kaboko	\N	5	142820
148317	\N	\N	\N	\N	70640101	Milimi	\N	5	142823
148318	\N	\N	\N	\N	70640102	Mpaye	\N	5	142823
148319	\N	\N	\N	\N	70640103	Munga	\N	5	142823
148320	\N	\N	\N	\N	70640104	Mwishi	\N	5	142823
148321	\N	\N	\N	\N	70640201	Baleo	\N	5	142824
148322	\N	\N	\N	\N	70640202	Kasinge	\N	5	142824
148323	\N	\N	\N	\N	70640203	Maloba	\N	5	142824
148324	\N	\N	\N	\N	70640204	Mbao	\N	5	142824
148325	\N	\N	\N	\N	70640205	Mbuli	\N	5	142824
148326	\N	\N	\N	\N	70645101	Chanaga-Changa	\N	5	142825
148327	\N	\N	\N	\N	70645102	Kaile	\N	5	142825
148328	\N	\N	\N	\N	70645103	Kasu 1	\N	5	142825
148329	\N	\N	\N	\N	70645104	Kasu 2	\N	5	142825
148330	\N	\N	\N	\N	70645105	Lukundula	\N	5	142825
148331	\N	\N	\N	\N	70645106	Lumbu-Lumbu	\N	5	142825
148332	\N	\N	\N	\N	70645107	Mpongo	\N	5	142825
148333	\N	\N	\N	\N	70650101	Bahela	\N	5	142826
148334	\N	\N	\N	\N	70650102	Bakaya	\N	5	142826
148335	\N	\N	\N	\N	70650103	Bakwazimu	\N	5	142826
148336	\N	\N	\N	\N	70650104	Bakwa-Nyami	\N	5	142826
148337	\N	\N	\N	\N	70650201	Bayashi	\N	5	142827
148338	\N	\N	\N	\N	70650301	Kalonga	\N	5	142828
148339	\N	\N	\N	\N	70650302	Kayeye	\N	5	142828
148340	\N	\N	\N	\N	70650303	Kilushi	\N	5	142828
148341	\N	\N	\N	\N	70650304	Kumbi	\N	5	142828
148342	\N	\N	\N	\N	70650305	Wangongwe	\N	5	142828
148343	\N	\N	\N	\N	70650401	Bango-Bango	\N	5	142829
148344	\N	\N	\N	\N	70650402	Muhona ya Seya	\N	5	142829
148345	\N	\N	\N	\N	70650403	Wagenia	\N	5	142829
148346	\N	\N	\N	\N	70650501	Bena- Nkuvu	\N	5	142830
148347	\N	\N	\N	\N	70650601	Bamweba	\N	5	142831
148348	\N	\N	\N	\N	70650602	Yambula	\N	5	142831
148349	\N	\N	\N	\N	70650701	Bena Muhona	\N	5	142832
148350	\N	\N	\N	\N	70650801	Mbulula	\N	5	142833
148351	\N	\N	\N	\N	70650901	Bena Mambwe	\N	5	142834
148352	\N	\N	\N	\N	70655102	Localites pers.	\N	5	142835
148353	\N	\N	\N	\N	70660101	Babinga	\N	5	142836
148354	\N	\N	\N	\N	70660102	Balumbu	\N	5	142836
148355	\N	\N	\N	\N	70660103	Bayoro	\N	5	142836
148356	\N	\N	\N	\N	70660104	Kamania	\N	5	142836
148357	\N	\N	\N	\N	70660201	Bakalanga	\N	5	142837
148358	\N	\N	\N	\N	70660202	Bango-Bango	\N	5	142837
148359	\N	\N	\N	\N	70660203	Baseba	\N	5	142837
148360	\N	\N	\N	\N	70660204	Bena Kahela	\N	5	142837
148361	\N	\N	\N	\N	70660205	Kanungu	\N	5	142837
148362	\N	\N	\N	\N	70660206	Mbeya	\N	5	142837
148363	\N	\N	\N	\N	70665101	Changa - Changa	\N	5	142838
148364	\N	\N	\N	\N	70665102	Kamakonde	\N	5	142838
148365	\N	\N	\N	\N	70665103	Kapulo Kampe	\N	5	142838
148366	\N	\N	\N	\N	70665104	Mangala	\N	5	142838
148367	\N	\N	\N	\N	70665105	Nyembo	\N	5	142838
148368	\N	\N	\N	\N	70710101	Dilanda	\N	5	142839
148369	\N	\N	\N	\N	70710102	Inakiluba	\N	5	142839
148370	\N	\N	\N	\N	70710103	Kaponda	\N	5	142839
148371	\N	\N	\N	\N	70710201	Kasongo	\N	5	142840
148372	\N	\N	\N	\N	70710202	Shindaika	\N	5	142840
148373	\N	\N	\N	\N	70710301	Kinyama	\N	5	142841
148374	\N	\N	\N	\N	70710302	Kiwele	\N	5	142841
148375	\N	\N	\N	\N	70710303	Yombwe	\N	5	142841
148376	\N	\N	\N	\N	70715101	Kalubamba	\N	5	142842
148377	\N	\N	\N	\N	70715102	Kamarenge	\N	5	142842
148378	\N	\N	\N	\N	70715103	Kashoma	\N	5	142842
148379	\N	\N	\N	\N	70715104	ulumba	\N	5	142842
148380	\N	\N	\N	\N	70715105	Mungoti	\N	5	142842
148381	\N	\N	\N	\N	70715106	Uhuru	\N	5	142842
148382	\N	\N	\N	\N	70715201	Bandundu	\N	5	142843
148383	\N	\N	\N	\N	70715202	Kambasa	\N	5	142843
148384	\N	\N	\N	\N	70715203	Musumali	\N	5	142843
148385	\N	\N	\N	\N	70715204	Sodimiza	\N	5	142843
148386	\N	\N	\N	\N	70720101	Mopama	\N	5	142844
148387	\N	\N	\N	\N	70720102	Mufumbi	\N	5	142844
148388	\N	\N	\N	\N	70720103	Ngosa-Kapenda	\N	5	142844
148389	\N	\N	\N	\N	70720104	Shinkaola	\N	5	142844
148390	\N	\N	\N	\N	70720201	Fundamina	\N	5	142845
148391	\N	\N	\N	\N	70720202	Kambo	\N	5	142845
148392	\N	\N	\N	\N	70720203	Katala	\N	5	142845
148393	\N	\N	\N	\N	70720204	Kepilingu	\N	5	142845
148394	\N	\N	\N	\N	70720205	Nkumbwa	\N	5	142845
148395	\N	\N	\N	\N	70720206	Selenge	\N	5	142845
148396	\N	\N	\N	\N	70720301	Kimesa-Kalonga	\N	5	142846
148397	\N	\N	\N	\N	70720302	Kaimbi	\N	5	142846
148398	\N	\N	\N	\N	70720303	Mwenda	\N	5	142846
148399	\N	\N	\N	\N	70725101	Lubende	\N	5	142847
148400	\N	\N	\N	\N	70725102	Lukangaba	\N	5	142847
148743	\N	\N	\N	\N	80320311	Ntono	\N	5	142913
148401	\N	\N	\N	\N	70725103	Quartier Commercial	\N	5	142847
148402	\N	\N	\N	\N	70725104	Selenge	\N	5	142847
148403	\N	\N	\N	\N	70725201	Kansompa	\N	5	142848
148404	\N	\N	\N	\N	70725202	Kikula Mutima	\N	5	142848
148405	\N	\N	\N	\N	70725204	Quartier Kamwanga	\N	5	142848
148406	\N	\N	\N	\N	70730101	Katete	\N	5	142850
148407	\N	\N	\N	\N	70730102	Mukebo	\N	5	142850
148408	\N	\N	\N	\N	70730103	Mwacha	\N	5	142850
148409	\N	\N	\N	\N	70730104	Mwemena	\N	5	142850
148410	\N	\N	\N	\N	70730105	Mwenga (Mwenga ?)	\N	5	142850
148411	\N	\N	\N	\N	70730106	Ntondo	\N	5	142850
148412	\N	\N	\N	\N	70730201	Kapwasa	\N	5	142851
148413	\N	\N	\N	\N	70730202	Mukobe	\N	5	142851
148414	\N	\N	\N	\N	70730203	Mulengele	\N	5	142851
148415	\N	\N	\N	\N	70730204	Mwaba	\N	5	142851
148416	\N	\N	\N	\N	70730301	Kabimbi	\N	5	142852
148417	\N	\N	\N	\N	70730302	Kashobwe	\N	5	142852
148418	\N	\N	\N	\N	70730303	Nkambo	\N	5	142852
148419	\N	\N	\N	\N	70730304	Nkuba-Kawama	\N	5	142852
148420	\N	\N	\N	\N	70730305	Mpoyo	\N	5	142852
148421	\N	\N	\N	\N	70730401	Kamolebwe	\N	5	142853
148422	\N	\N	\N	\N	70730402	Kikungu	\N	5	142853
148423	\N	\N	\N	\N	70730403	Sapwe	\N	5	142853
148424	\N	\N	\N	\N	70735101	Kaboka	\N	5	142854
148425	\N	\N	\N	\N	70735102	Kinyata	\N	5	142854
148426	\N	\N	\N	\N	70735103	Kiwala	\N	5	142854
148427	\N	\N	\N	\N	70735104	Lumbwe	\N	5	142854
148428	\N	\N	\N	\N	70735105	Mukuku	\N	5	142854
148429	\N	\N	\N	\N	70735106	Mwalimu	\N	5	142854
148430	\N	\N	\N	\N	70735107	Mwana-Lyele	\N	5	142854
148431	\N	\N	\N	\N	70735108	Shikishi	\N	5	142854
148432	\N	\N	\N	\N	70735203	Quartier Commercial	\N	5	142848
148433	\N	\N	\N	\N	70740101	Kafwa	\N	5	142855
148434	\N	\N	\N	\N	70740102	Kaleba	\N	5	142855
148435	\N	\N	\N	\N	70740103	Kitobo	\N	5	142855
148436	\N	\N	\N	\N	70740104	Sambwe	\N	5	142855
148437	\N	\N	\N	\N	70740105	Tomombo	\N	5	142855
148438	\N	\N	\N	\N	70740201	Kalonga	\N	5	142856
148439	\N	\N	\N	\N	70740202	Mufunga	\N	5	142856
148440	\N	\N	\N	\N	70740203	Mukana	\N	5	142856
148441	\N	\N	\N	\N	70740204	Muombe	\N	5	142856
148442	\N	\N	\N	\N	70740205	Musabila	\N	5	142856
148443	\N	\N	\N	\N	70740301	Kabanda	\N	5	142857
148444	\N	\N	\N	\N	70740302	Katolo	\N	5	142857
148445	\N	\N	\N	\N	70740303	Kitya	\N	5	142857
148446	\N	\N	\N	\N	70740304	Mwema	\N	5	142857
148447	\N	\N	\N	\N	70745101	Kilala	\N	5	142858
148448	\N	\N	\N	\N	70745102	Muluobwe	\N	5	142858
148449	\N	\N	\N	\N	70750101	Kiluba / Kilomba	\N	5	142859
148450	\N	\N	\N	\N	70750102	Kyaka	\N	5	142859
148451	\N	\N	\N	\N	70750103	Mukupa	\N	5	142859
148452	\N	\N	\N	\N	70750104	Mulimba	\N	5	142859
148453	\N	\N	\N	\N	70750105	Nkuba-Bukonogolo	\N	5	142859
148454	\N	\N	\N	\N	70750106	Songa	\N	5	142859
148455	\N	\N	\N	\N	70750201	Kasongo-B.	\N	5	142860
148456	\N	\N	\N	\N	70750202	Kiona	\N	5	142860
148457	\N	\N	\N	\N	70750301	Kapulo	\N	5	142861
148458	\N	\N	\N	\N	70750302	Kasama	\N	5	142861
148459	\N	\N	\N	\N	70750303	Kizabi	\N	5	142861
148460	\N	\N	\N	\N	70750304	Mipweto	\N	5	142861
148461	\N	\N	\N	\N	70750401	Kasongo	\N	5	142862
148462	\N	\N	\N	\N	70750402	Mwenge	\N	5	142862
148463	\N	\N	\N	\N	70755101	Chamfwambu	\N	5	142863
148464	\N	\N	\N	\N	70755102	Lukinda	\N	5	142863
148465	\N	\N	\N	\N	70755103	Luvwa	\N	5	142863
148466	\N	\N	\N	\N	70760101	Kikoyo/ Kipuyo	\N	5	142864
148467	\N	\N	\N	\N	70760102	Mubambe	\N	5	142864
148468	\N	\N	\N	\N	70760103	Shamalenge	\N	5	142864
148469	\N	\N	\N	\N	70760201	Mpande	\N	5	142865
148470	\N	\N	\N	\N	70760202	Mukumbi 1	\N	5	142865
148471	\N	\N	\N	\N	70760301	Katanga	\N	5	142866
148472	\N	\N	\N	\N	70760302	Kinsuka	\N	5	142866
148473	\N	\N	\N	\N	70760303	Kyembe	\N	5	142866
148474	\N	\N	\N	\N	70760304	Lukoshi	\N	5	142866
148475	\N	\N	\N	\N	70760306	Mulandi	\N	5	142866
148476	\N	\N	\N	\N	70760307	Mwabesa	\N	5	142866
148477	\N	\N	\N	\N	70760308	Ngalu	\N	5	142866
148478	\N	\N	\N	\N	70760309	Tenke	\N	5	142866
148479	\N	\N	\N	\N	70765101	Kiwewe	\N	5	142867
148480	\N	\N	\N	\N	70765103	Mitumba	\N	5	142867
148481	\N	\N	\N	\N	70765104	Mukuba	\N	5	142867
148482	\N	\N	\N	\N	80110001	Kasai	\N	5	142869
148483	\N	\N	\N	\N	80110002	Makasi	\N	5	142869
148484	\N	\N	\N	\N	80110003	Mudiba	\N	5	142869
148485	\N	\N	\N	\N	80110004	Nsele	\N	5	142869
148486	\N	\N	\N	\N	80110005	Tshikisha	\N	5	142869
148487	\N	\N	\N	\N	80120001	kabuatshia	\N	5	142870
148488	\N	\N	\N	\N	80120002	Kalundu	\N	5	142870
148489	\N	\N	\N	\N	80120003	Kankelenge	\N	5	142870
148490	\N	\N	\N	\N	80120004	Lubuebue	\N	5	142870
148491	\N	\N	\N	\N	80120005	Makala	\N	5	142870
148492	\N	\N	\N	\N	80120006	Mission	\N	5	142870
148493	\N	\N	\N	\N	80120007	Mukelayi	\N	5	142870
148494	\N	\N	\N	\N	80130001	Bumbanji	\N	5	142871
148495	\N	\N	\N	\N	80130002	Dipa	\N	5	142871
148496	\N	\N	\N	\N	80130003	Lusenga	\N	5	142871
148497	\N	\N	\N	\N	80130004	Masanga	\N	5	142871
148498	\N	\N	\N	\N	80130005	Nkuluse	\N	5	142871
148499	\N	\N	\N	\N	80140001	Kajiba	\N	5	142872
148500	\N	\N	\N	\N	80140002	Kansele	\N	5	142872
148501	\N	\N	\N	\N	80140003	Mulumba -Musulu	\N	5	142872
148502	\N	\N	\N	\N	80140004	Ngomba Ngole	\N	5	142872
148503	\N	\N	\N	\N	80140005	Nkonga	\N	5	142872
148504	\N	\N	\N	\N	80140006	Tshibuabua	\N	5	142872
148505	\N	\N	\N	\N	80140007	Tshiminyi	\N	5	142872
148506	\N	\N	\N	\N	80150001	Bonzola	\N	5	142873
148507	\N	\N	\N	\N	80150002	Dipumba	\N	5	142873
148508	\N	\N	\N	\N	80150003	Kabongo	\N	5	142873
148509	\N	\N	\N	\N	80150004	Kasa-Vubu	\N	5	142873
148510	\N	\N	\N	\N	80150005	Mikele	\N	5	142873
148511	\N	\N	\N	\N	80150006	Minkoka	\N	5	142873
148512	\N	\N	\N	\N	80150007	Monzo	\N	5	142873
148513	\N	\N	\N	\N	80150008	Tshiya	\N	5	142873
148514	\N	\N	\N	\N	80210101	bakwa Mbadi	\N	5	142874
148515	\N	\N	\N	\N	80210102	Bakwa Mbuyi	\N	5	142874
148516	\N	\N	\N	\N	80210103	Bakwa Ndumbi	\N	5	142874
148517	\N	\N	\N	\N	80210104	Bakwa Tshimuna	\N	5	142874
148518	\N	\N	\N	\N	80210105	Bayombo	\N	5	142874
148519	\N	\N	\N	\N	80210106	Bena Kalondji	\N	5	142874
148520	\N	\N	\N	\N	80210107	Bena Kazadi	\N	5	142874
148521	\N	\N	\N	\N	80210108	Bena Lubashi	\N	5	142874
148522	\N	\N	\N	\N	80210109	Bena Mbayi Miketa	\N	5	142874
148523	\N	\N	\N	\N	80210110	Bena Nyandu	\N	5	142874
148524	\N	\N	\N	\N	80210111	Bena Tshimungu	\N	5	142874
148525	\N	\N	\N	\N	80210201	Bakwa Sumba	\N	5	142875
148526	\N	\N	\N	\N	80210202	Bashingala	\N	5	142875
148527	\N	\N	\N	\N	80210301	Bakwa Bumba 1	\N	5	142876
148528	\N	\N	\N	\N	80210302	Bakwa Bumba 2	\N	5	142876
148529	\N	\N	\N	\N	80210303	Bakwa Mbiye	\N	5	142876
148530	\N	\N	\N	\N	80210304	Bakwa Mpunga	\N	5	142876
148531	\N	\N	\N	\N	80210305	Bakwa Tembwe Kabeya	\N	5	142876
148532	\N	\N	\N	\N	80210306	Bakwa Tembwe Tshidia	\N	5	142876
148533	\N	\N	\N	\N	80210307	Bena Bitende	\N	5	142876
148534	\N	\N	\N	\N	80210308	Bena Nganza	\N	5	142876
148535	\N	\N	\N	\N	80210309	Bena Tshiloba 1	\N	5	142876
148536	\N	\N	\N	\N	80210310	Bena Tshiloba 2	\N	5	142876
148537	\N	\N	\N	\N	80210401	Bakwa Kanda	\N	5	142877
148538	\N	\N	\N	\N	80210402	Bakwa Kasanga	\N	5	142877
148539	\N	\N	\N	\N	80210403	Bakwa Lukamba	\N	5	142877
148540	\N	\N	\N	\N	80210404	Bakwa Mpemba	\N	5	142877
148541	\N	\N	\N	\N	80210405	Bakwa Tshiala	\N	5	142877
148542	\N	\N	\N	\N	80210406	Bakwa Tshiya	\N	5	142877
148543	\N	\N	\N	\N	80210407	Kabela Nkusu	\N	5	142877
148544	\N	\N	\N	\N	80215101	Central 1	\N	5	142878
148545	\N	\N	\N	\N	80215102	Central 2	\N	5	142878
148546	\N	\N	\N	\N	80215103	Kantundu	\N	5	142878
148547	\N	\N	\N	\N	80215104	Kazaba	\N	5	142878
148548	\N	\N	\N	\N	80215105	Lukunza	\N	5	142878
148549	\N	\N	\N	\N	80215106	Nyikinyiki	\N	5	142878
148550	\N	\N	\N	\N	80215107	Tshintota	\N	5	142878
148551	\N	\N	\N	\N	80215108	Tshitolo 1	\N	5	142878
148552	\N	\N	\N	\N	80215109	Tshitolo 2	\N	5	142878
148553	\N	\N	\N	\N	80220101	Bakwa Lonji 2	\N	5	142879
148554	\N	\N	\N	\N	80220102	Bakwa Lonji 3	\N	5	142879
148555	\N	\N	\N	\N	80220103	Diyoka	\N	5	142879
148556	\N	\N	\N	\N	80220105	Kazadi a Mwamba	\N	5	142879
148557	\N	\N	\N	\N	80220106	Mukendi	\N	5	142879
148558	\N	\N	\N	\N	80220107	Tshimbi	\N	5	142879
148559	\N	\N	\N	\N	80220108	Tsimowa	\N	5	142879
148560	\N	\N	\N	\N	80220201	Dileja	\N	5	142880
148561	\N	\N	\N	\N	80220202	Kajiba	\N	5	142880
148562	\N	\N	\N	\N	80220204	Kabamba 2	\N	5	142880
148563	\N	\N	\N	\N	80220301	Bakwa Mulumba	\N	5	142881
148564	\N	\N	\N	\N	80220302	Bakwa Nsulu	\N	5	142881
148565	\N	\N	\N	\N	80220303	Bakwa Tshimiyi 1	\N	5	142881
148566	\N	\N	\N	\N	80220304	Bakwa tshiumiyi 2	\N	5	142881
148567	\N	\N	\N	\N	80220305	Bakwa Tshimiyi 3	\N	5	142881
148568	\N	\N	\N	\N	80220306	Bena Majiba	\N	5	142881
148569	\N	\N	\N	\N	80220307	Bena Ngeleka	\N	5	142881
148570	\N	\N	\N	\N	80220401	Bakwa Bilonda 1	\N	5	142882
148571	\N	\N	\N	\N	80220402	Bakwa Bilonda 2	\N	5	142882
148572	\N	\N	\N	\N	80220403	Bakwa Kashila 1	\N	5	142882
148573	\N	\N	\N	\N	80220404	Bakwa Kashila 2	\N	5	142882
148574	\N	\N	\N	\N	80220405	Bakwa Lonji 1	\N	5	142882
148575	\N	\N	\N	\N	80220406	Bakwa Ntombolo 1	\N	5	142882
148576	\N	\N	\N	\N	80220407	Bakwa Ntombolo 2	\N	5	142882
148577	\N	\N	\N	\N	80220408	Bena Kasai 1	\N	5	142882
148578	\N	\N	\N	\N	80220409	Bena Kasai 2	\N	5	142882
148579	\N	\N	\N	\N	80220410	Bena Kazadi 1	\N	5	142882
148580	\N	\N	\N	\N	80220411	Bena Kazadi 2	\N	5	142882
148581	\N	\N	\N	\N	80220412	Bena Kabuanseya	\N	5	142882
148582	\N	\N	\N	\N	80220413	Bena Mulombo 1	\N	5	142882
148583	\N	\N	\N	\N	80220414	Bena Mulombo 2	\N	5	142882
148584	\N	\N	\N	\N	80220415	Bena Muya 1	\N	5	142882
148585	\N	\N	\N	\N	80220416	Bena Muya 2	\N	5	142882
148586	\N	\N	\N	\N	80220417	Bena Nzemba	\N	5	142882
148587	\N	\N	\N	\N	80220418	Bena Tshikulu	\N	5	142882
148588	\N	\N	\N	\N	80220419	Bena Tshilanda	\N	5	142882
148589	\N	\N	\N	\N	80220501	Bakwa Kanjinga	\N	5	142883
148590	\N	\N	\N	\N	80220502	Bena Kabamba	\N	5	142883
148591	\N	\N	\N	\N	80220503	Bena Mpeta	\N	5	142883
148592	\N	\N	\N	\N	80225101	Bubanji	\N	5	142884
148593	\N	\N	\N	\N	80225102	Dinanga	\N	5	142884
148594	\N	\N	\N	\N	80225103	Ditalala	\N	5	142884
148595	\N	\N	\N	\N	80225104	Ditekemena	\N	5	142884
148596	\N	\N	\N	\N	80225105	Luse	\N	5	142884
148597	\N	\N	\N	\N	80230101	Bakwanga	\N	5	142885
148598	\N	\N	\N	\N	80230201	Bakwa Hoyi	\N	5	142886
148599	\N	\N	\N	\N	80230202	Bakwa Tshisamba	\N	5	142886
148600	\N	\N	\N	\N	80230203	Basangana	\N	5	142886
148601	\N	\N	\N	\N	80230301	Bakwa Lukoka	\N	5	142887
148602	\N	\N	\N	\N	80230302	Bakwa Nsumpi	\N	5	142887
148603	\N	\N	\N	\N	80230303	Bakwa Nyanga	\N	5	142887
148604	\N	\N	\N	\N	80230304	Bena Tshilunda	\N	5	142887
148605	\N	\N	\N	\N	80230401	Bajila Kasanga	\N	5	142888
148606	\N	\N	\N	\N	80230402	Bakwa Kalondji Lusang	\N	5	142888
148607	\N	\N	\N	\N	80230403	Bakwa Lonji Tshibamb.	\N	5	142888
148608	\N	\N	\N	\N	80230404	Bakwa Mpunga	\N	5	142888
148609	\N	\N	\N	\N	80230405	Bakwa Nyanga 1	\N	5	142888
148610	\N	\N	\N	\N	80230406	Bakwa Mbuyi	\N	5	142888
148611	\N	\N	\N	\N	80230407	Bena Tshilunda	\N	5	142888
148612	\N	\N	\N	\N	80240101	Bakwa Bowa	\N	5	142890
148613	\N	\N	\N	\N	80240102	Bakwa Kabindi	\N	5	142890
148614	\N	\N	\N	\N	80240103	Bakwa Ndoba	\N	5	142890
148615	\N	\N	\N	\N	80240201	Bena Kapuya	\N	5	142891
148616	\N	\N	\N	\N	80240202	Bena Mulenda	\N	5	142891
148617	\N	\N	\N	\N	80240203	Bena Shimba	\N	5	142891
148618	\N	\N	\N	\N	80240301	Bakwa Kanda	\N	5	142892
148619	\N	\N	\N	\N	80240302	Bakwa Lonji	\N	5	142892
148620	\N	\N	\N	\N	80240303	Bakwa Tshinene	\N	5	142892
148621	\N	\N	\N	\N	80240401	Bena Tshitolo	\N	5	142893
148622	\N	\N	\N	\N	80250101	Bakwa Kolela	\N	5	142896
148623	\N	\N	\N	\N	80250102	Bakwa Malaba	\N	5	142896
148624	\N	\N	\N	\N	80250103	Bakwa Mbikayi	\N	5	142896
148625	\N	\N	\N	\N	80250104	Bakwa Tshimanga	\N	5	142896
148626	\N	\N	\N	\N	80250105	Bakwa Kabundi	\N	5	142896
148627	\N	\N	\N	\N	80250106	Bena Kakona	\N	5	142896
148744	\N	\N	\N	\N	80320401	Akavu	\N	5	142914
148628	\N	\N	\N	\N	80250107	BenaKanangila	\N	5	142896
148629	\N	\N	\N	\N	80250108	Bena Kanyanga	\N	5	142896
148630	\N	\N	\N	\N	80250109	Bena Mukendi	\N	5	142896
148631	\N	\N	\N	\N	80250110	Bena Tshimonyi	\N	5	142896
148632	\N	\N	\N	\N	80250111	Bena Tshiswaka	\N	5	142896
148633	\N	\N	\N	\N	80250112	Bena Tshitala	\N	5	142896
148634	\N	\N	\N	\N	80250201	Bajilanga	\N	5	142897
148635	\N	\N	\N	\N	80250202	Bakwa Lukusa	\N	5	142897
148636	\N	\N	\N	\N	80250203	Bena Kalala	\N	5	142897
148637	\N	\N	\N	\N	80250204	Bena Kayembe	\N	5	142897
148638	\N	\N	\N	\N	80250205	Bena Tshimanga	\N	5	142897
148639	\N	\N	\N	\N	80250301	Bakwa kalenda	\N	5	142898
148640	\N	\N	\N	\N	80250302	Bakwa Kashila	\N	5	142898
148641	\N	\N	\N	\N	80250303	Bakwa Malaba	\N	5	142898
148642	\N	\N	\N	\N	80250304	Bakwa Odile	\N	5	142898
148643	\N	\N	\N	\N	80250305	Bakwa Tshimanga	\N	5	142898
148644	\N	\N	\N	\N	80250401	Bena Kalenda 1	\N	5	142899
148645	\N	\N	\N	\N	80250402	Bena Luabeya	\N	5	142899
148646	\N	\N	\N	\N	80250403	Bena Tshilobo	\N	5	142899
148647	\N	\N	\N	\N	80250404	Bena Tsimpuma	\N	5	142899
148648	\N	\N	\N	\N	80250501	Bena Kadima	\N	5	142900
148649	\N	\N	\N	\N	80250502	bena Kalubi	\N	5	142900
148650	\N	\N	\N	\N	80255101	20 Mai	\N	5	142901
148651	\N	\N	\N	\N	80255102	24 Novembre	\N	5	142901
148652	\N	\N	\N	\N	80255103	30 Juin	\N	5	142901
148653	\N	\N	\N	\N	80255104	Inga	\N	5	142901
148654	\N	\N	\N	\N	80255105	N'sele	\N	5	142901
148655	\N	\N	\N	\N	80255106	Salongo	\N	5	142901
148656	\N	\N	\N	\N	80310101	Bena Malembe	\N	5	142902
148657	\N	\N	\N	\N	80310102	Bakwa Kabola	\N	5	142902
148658	\N	\N	\N	\N	80310103	Bakwa Mbumba	\N	5	142902
148659	\N	\N	\N	\N	80310201	Bena Bankundu	\N	5	142903
148660	\N	\N	\N	\N	80310202	Bena Tshilumbu	\N	5	142903
148661	\N	\N	\N	\N	80310203	Baisambo	\N	5	142903
148662	\N	\N	\N	\N	80310204	Bakpele	\N	5	142903
148663	\N	\N	\N	\N	80310205	Balupula	\N	5	142903
148664	\N	\N	\N	\N	80310206	Ngongo kileta	\N	5	142903
148665	\N	\N	\N	\N	80310301	Bakaya-Babindi	\N	5	142904
148666	\N	\N	\N	\N	80310302	Bashi Ingongo	\N	5	142904
148667	\N	\N	\N	\N	80310303	Bakwa Mputu	\N	5	142904
148668	\N	\N	\N	\N	80310304	Bakwa Mukedi	\N	5	142904
148669	\N	\N	\N	\N	80310305	Bakwa Ngoyi	\N	5	142904
148670	\N	\N	\N	\N	80310306	Mbumba	\N	5	142904
148671	\N	\N	\N	\N	80310401	Akaya	\N	5	142905
148672	\N	\N	\N	\N	80310402	Bashikomba	\N	5	142905
148673	\N	\N	\N	\N	80310403	Bena Kayi	\N	5	142905
148674	\N	\N	\N	\N	80310404	Bena Shilu	\N	5	142905
148675	\N	\N	\N	\N	80310405	Djondo	\N	5	142905
148676	\N	\N	\N	\N	80310406	Kambulanga	\N	5	142905
148677	\N	\N	\N	\N	80310407	Kapalu	\N	5	142905
148678	\N	\N	\N	\N	80310408	Lonkala	\N	5	142905
148679	\N	\N	\N	\N	80310409	Lumbadi Mukau	\N	5	142905
148680	\N	\N	\N	\N	80310410	Malela	\N	5	142905
148681	\N	\N	\N	\N	80310411	Mama Lokala	\N	5	142905
148682	\N	\N	\N	\N	80310412	Mulosa	\N	5	142905
148683	\N	\N	\N	\N	80310413	Sungumadi	\N	5	142905
148684	\N	\N	\N	\N	80310414	Tubunyi	\N	5	142905
148685	\N	\N	\N	\N	80310415	Yankuba Bel.	\N	5	142905
148686	\N	\N	\N	\N	80310501	Ba Elembe	\N	5	142906
148687	\N	\N	\N	\N	80310502	Badingale	\N	5	142906
148688	\N	\N	\N	\N	80310503	Bakikwasa	\N	5	142906
148689	\N	\N	\N	\N	80310504	Bakitenge	\N	5	142906
148690	\N	\N	\N	\N	80310505	Kimbalanga	\N	5	142906
148691	\N	\N	\N	\N	80310506	Kingomba	\N	5	142906
148692	\N	\N	\N	\N	80310507	Kusama	\N	5	142906
148693	\N	\N	\N	\N	80310508	Kusama	\N	5	142906
148694	\N	\N	\N	\N	80310509	Mpwanya	\N	5	142906
148695	\N	\N	\N	\N	80310510	Mukendi -Tshipaka	\N	5	142906
148696	\N	\N	\N	\N	80310601	Ba Mbala	\N	5	142907
148697	\N	\N	\N	\N	80310602	Ba Mpungu	\N	5	142907
148698	\N	\N	\N	\N	80310603	Bakonji	\N	5	142907
148699	\N	\N	\N	\N	80310604	Baluba	\N	5	142907
148700	\N	\N	\N	\N	80310605	Bapabwe	\N	5	142907
148701	\N	\N	\N	\N	80310606	Bashi Ngongo	\N	5	142907
148702	\N	\N	\N	\N	80310607	Yanduyi	\N	5	142907
148703	\N	\N	\N	\N	80310701	Babembele	\N	5	142908
148704	\N	\N	\N	\N	80310702	Basanga	\N	5	142908
148705	\N	\N	\N	\N	80310703	Batetela	\N	5	142908
148706	\N	\N	\N	\N	80310704	Bakwa Nkoto	\N	5	142908
148707	\N	\N	\N	\N	80310801	Baluba	\N	5	142909
148708	\N	\N	\N	\N	80310802	Longo	\N	5	142909
148709	\N	\N	\N	\N	80310803	Nonotshi 1	\N	5	142909
148710	\N	\N	\N	\N	80310804	Nonotshi 2	\N	5	142909
148711	\N	\N	\N	\N	80310805	Tembwe 1	\N	5	142909
148712	\N	\N	\N	\N	80310806	Tembwe 2	\N	5	142909
148713	\N	\N	\N	\N	80315101	Bajira	\N	5	142910
148714	\N	\N	\N	\N	80315102	Kabongo	\N	5	142910
148715	\N	\N	\N	\N	80315103	Salongo	\N	5	142910
148716	\N	\N	\N	\N	80315104	Shaba	\N	5	142910
148717	\N	\N	\N	\N	80320101	Apami	\N	5	142911
148718	\N	\N	\N	\N	80320102	Indenga	\N	5	142911
148719	\N	\N	\N	\N	80320103	Kamba	\N	5	142911
148720	\N	\N	\N	\N	80320104	Kisango	\N	5	142911
148721	\N	\N	\N	\N	80320105	Osenge	\N	5	142911
148722	\N	\N	\N	\N	80320106	Owende	\N	5	142911
148723	\N	\N	\N	\N	80320201	Inkota	\N	5	142912
148724	\N	\N	\N	\N	80320202	Intola	\N	5	142912
148725	\N	\N	\N	\N	80320203	Itedi	\N	5	142912
148726	\N	\N	\N	\N	80320204	Mbesue	\N	5	142912
148727	\N	\N	\N	\N	80320205	Mpata	\N	5	142912
148728	\N	\N	\N	\N	80320206	Njoka	\N	5	142912
148729	\N	\N	\N	\N	80320207	Nsaka	\N	5	142912
148730	\N	\N	\N	\N	80320208	Ohindo	\N	5	142912
148731	\N	\N	\N	\N	80320209	Okhondji	\N	5	142912
148732	\N	\N	\N	\N	80320210	Tshaka	\N	5	142912
148733	\N	\N	\N	\N	80320301	Awango	\N	5	142913
148734	\N	\N	\N	\N	80320302	Ekoto	\N	5	142913
148735	\N	\N	\N	\N	80320303	Ikoto	\N	5	142913
148736	\N	\N	\N	\N	80320304	Impete	\N	5	142913
148737	\N	\N	\N	\N	80320305	Ishenga	\N	5	142913
148738	\N	\N	\N	\N	80320306	Lolow-Bolongo	\N	5	142913
148739	\N	\N	\N	\N	80320307	Lolow-Booke	\N	5	142913
148740	\N	\N	\N	\N	80320308	Makwala	\N	5	142913
148741	\N	\N	\N	\N	80320309	Mbondje	\N	5	142913
148742	\N	\N	\N	\N	80320310	Mpenga Kaboko	\N	5	142913
148745	\N	\N	\N	\N	80320402	Banda	\N	5	142914
148746	\N	\N	\N	\N	80320403	Epombo	\N	5	142914
148747	\N	\N	\N	\N	80320404	Idole	\N	5	142914
148748	\N	\N	\N	\N	80320405	Ikedi	\N	5	142914
148749	\N	\N	\N	\N	80320406	Ipale	\N	5	142914
148750	\N	\N	\N	\N	80320407	Iwala	\N	5	142914
148751	\N	\N	\N	\N	80320408	Kahumbu	\N	5	142914
148752	\N	\N	\N	\N	80320409	Kfumu	\N	5	142914
148753	\N	\N	\N	\N	80320410	Lofwa	\N	5	142914
148754	\N	\N	\N	\N	80320411	Mbala	\N	5	142914
148755	\N	\N	\N	\N	80320412	Mbotokonda	\N	5	142914
148756	\N	\N	\N	\N	80320413	Ngombe	\N	5	142914
148757	\N	\N	\N	\N	80320414	Nkemba	\N	5	142914
148758	\N	\N	\N	\N	80320415	Okoto	\N	5	142914
148759	\N	\N	\N	\N	80320416	Osanga	\N	5	142914
148760	\N	\N	\N	\N	80320417	Owanga	\N	5	142914
148761	\N	\N	\N	\N	80320418	Panga	\N	5	142914
148762	\N	\N	\N	\N	80320419	Wampese	\N	5	142914
148763	\N	\N	\N	\N	80320420	Wopo	\N	5	142914
148764	\N	\N	\N	\N	80320502	Ekumu	\N	5	142915
148765	\N	\N	\N	\N	80320503	Ntumba Lutshi	\N	5	142915
148766	\N	\N	\N	\N	80320504	Omalonkuna	\N	5	142915
148767	\N	\N	\N	\N	80320601	Bakele	\N	5	142916
148768	\N	\N	\N	\N	80320602	Kabondo	\N	5	142916
148769	\N	\N	\N	\N	80320603	Kalonda	\N	5	142916
148770	\N	\N	\N	\N	80320604	Kombe-kombe	\N	5	142916
148771	\N	\N	\N	\N	80320605	Kondu	\N	5	142916
148772	\N	\N	\N	\N	80320606	Lobilo	\N	5	142916
148773	\N	\N	\N	\N	80320607	Lukfungu	\N	5	142916
148774	\N	\N	\N	\N	80320608	Malela	\N	5	142916
148775	\N	\N	\N	\N	80320609	Olemba	\N	5	142916
148776	\N	\N	\N	\N	80320610	Ongondu	\N	5	142916
148777	\N	\N	\N	\N	80330101	Ohambe	\N	5	142918
148778	\N	\N	\N	\N	80330102	Okal Djombo	\N	5	142918
148779	\N	\N	\N	\N	80330103	Wedinga	\N	5	142918
148780	\N	\N	\N	\N	80330201	Akandja	\N	5	142919
148781	\N	\N	\N	\N	80330202	Bakwala	\N	5	142919
148782	\N	\N	\N	\N	80330203	Bokiri	\N	5	142919
148783	\N	\N	\N	\N	80330204	Dipinga	\N	5	142919
148784	\N	\N	\N	\N	80330205	Djete-Pombo	\N	5	142919
148785	\N	\N	\N	\N	80330206	Eleku	\N	5	142919
148786	\N	\N	\N	\N	80330207	Efondoko	\N	5	142919
148787	\N	\N	\N	\N	80330208	Fukwakema	\N	5	142919
148788	\N	\N	\N	\N	80330209	Intaku	\N	5	142919
148789	\N	\N	\N	\N	80330210	Losamba	\N	5	142919
148790	\N	\N	\N	\N	80330211	Ngombe	\N	5	142919
148791	\N	\N	\N	\N	80330212	Okale	\N	5	142919
148792	\N	\N	\N	\N	80330213	Okannya-Lokongo	\N	5	142919
148793	\N	\N	\N	\N	80330214	Okundji	\N	5	142919
148794	\N	\N	\N	\N	80330215	Omandja-Imba	\N	5	142919
148795	\N	\N	\N	\N	80330216	Omandja-Emongo	\N	5	142919
148796	\N	\N	\N	\N	80330217	Ongai	\N	5	142919
148797	\N	\N	\N	\N	80330218	Oshombe	\N	5	142919
148798	\N	\N	\N	\N	80330219	Oso-Wende	\N	5	142919
148799	\N	\N	\N	\N	80330220	Pelenge	\N	5	142919
148800	\N	\N	\N	\N	80330221	Pombo	\N	5	142919
148801	\N	\N	\N	\N	80330222	Purote	\N	5	142919
148802	\N	\N	\N	\N	80330301	Alanga	\N	5	142920
148803	\N	\N	\N	\N	80330302	Dimombe	\N	5	142920
148804	\N	\N	\N	\N	80330303	Djambe	\N	5	142920
148805	\N	\N	\N	\N	80330304	Enganga	\N	5	142920
148806	\N	\N	\N	\N	80330305	Imamba	\N	5	142920
148807	\N	\N	\N	\N	80330306	Indji	\N	5	142920
148808	\N	\N	\N	\N	80330307	Lokendajovu	\N	5	142920
148809	\N	\N	\N	\N	80330308	Lolenga	\N	5	142920
148810	\N	\N	\N	\N	80330309	Omandjovu	\N	5	142920
148811	\N	\N	\N	\N	80330310	Shikondo	\N	5	142920
148812	\N	\N	\N	\N	80330401	Ambala Ompula	\N	5	142921
148813	\N	\N	\N	\N	80330402	Bahina Mukumari	\N	5	142921
148814	\N	\N	\N	\N	80330403	Diese Longanio	\N	5	142921
148815	\N	\N	\N	\N	80330404	Dikoma-Diese	\N	5	142921
148816	\N	\N	\N	\N	80330405	F.D Etshumana	\N	5	142921
148817	\N	\N	\N	\N	80330406	F.D.T. Kalonga	\N	5	142921
148818	\N	\N	\N	\N	80330407	Kingombe Diesa	\N	5	142921
148819	\N	\N	\N	\N	80330408	Kombe Olwa	\N	5	142921
148820	\N	\N	\N	\N	80330409	Kundu Musadi	\N	5	142921
148821	\N	\N	\N	\N	80330410	Lowo	\N	5	142921
148822	\N	\N	\N	\N	80330411	Malela	\N	5	142921
148823	\N	\N	\N	\N	80330412	Mamlela Ngongo	\N	5	142921
148824	\N	\N	\N	\N	80330413	Olenga	\N	5	142921
148825	\N	\N	\N	\N	80330414	Sopo Mabuki	\N	5	142921
148826	\N	\N	\N	\N	80330415	Tshula-Otenga	\N	5	142921
148827	\N	\N	\N	\N	80330416	Yangunda	\N	5	142921
148828	\N	\N	\N	\N	80330501	Bahamba-Est	\N	5	142922
148829	\N	\N	\N	\N	80330502	Bokungu	\N	5	142922
148830	\N	\N	\N	\N	80330503	Djembu	\N	5	142922
148831	\N	\N	\N	\N	80330504	Okale	\N	5	142922
148832	\N	\N	\N	\N	80330505	Yandjo	\N	5	142922
148833	\N	\N	\N	\N	80330601	Malo	\N	5	142923
148834	\N	\N	\N	\N	80330602	Nkoko	\N	5	142923
148835	\N	\N	\N	\N	80330603	Oveni Itana	\N	5	142923
148836	\N	\N	\N	\N	80340101	Djanga-Otepa	\N	5	142925
148837	\N	\N	\N	\N	80340102	Dongongo-Lombe	\N	5	142925
148838	\N	\N	\N	\N	80340103	Koyapongo-Okita	\N	5	142925
148839	\N	\N	\N	\N	80340104	Lowela-Okita	\N	5	142925
148840	\N	\N	\N	\N	80340105	Nombe-Ovungu	\N	5	142925
148841	\N	\N	\N	\N	80340106	Nyma-Otsudi	\N	5	142925
148842	\N	\N	\N	\N	80340107	Odjangi-Longonya	\N	5	142925
148843	\N	\N	\N	\N	80340201	Bahina	\N	5	142926
148844	\N	\N	\N	\N	80340202	Basonge	\N	5	142926
148845	\N	\N	\N	\N	80340203	Diefu	\N	5	142926
148846	\N	\N	\N	\N	80340204	Djalo	\N	5	142926
148847	\N	\N	\N	\N	80340205	Dombe	\N	5	142926
148848	\N	\N	\N	\N	80340206	Engo	\N	5	142926
148849	\N	\N	\N	\N	80340207	Fin terme Civil Kung.	\N	5	142926
148850	\N	\N	\N	\N	80340208	Fin Terme Militaire LumumB.	\N	5	142926
148851	\N	\N	\N	\N	80340209	Kikonda Male.	\N	5	142926
148852	\N	\N	\N	\N	80340210	Kombe 1	\N	5	142926
148853	\N	\N	\N	\N	80340211	Kombe 2	\N	5	142926
148854	\N	\N	\N	\N	80340212	Lolenge	\N	5	142926
148855	\N	\N	\N	\N	80340301	Bahenyi	\N	5	142927
148856	\N	\N	\N	\N	80340302	Boy Lokenye	\N	5	142927
148857	\N	\N	\N	\N	80340303	Djima	\N	5	142927
148858	\N	\N	\N	\N	80340304	Ekenyi	\N	5	142927
148859	\N	\N	\N	\N	80340305	Fariala	\N	5	142927
148860	\N	\N	\N	\N	80340306	Kasende	\N	5	142927
148861	\N	\N	\N	\N	80340307	Kulafai	\N	5	142927
148862	\N	\N	\N	\N	80340308	Malela 1	\N	5	142927
148863	\N	\N	\N	\N	80340309	Malela 2	\N	5	142927
148864	\N	\N	\N	\N	80340310	Tambue	\N	5	142927
148865	\N	\N	\N	\N	80340401	Dingele 1	\N	5	142928
148866	\N	\N	\N	\N	80340402	Dingele 2	\N	5	142928
148867	\N	\N	\N	\N	80340403	Dingungu	\N	5	142928
148868	\N	\N	\N	\N	80340404	Donga	\N	5	142928
148869	\N	\N	\N	\N	80340405	Kai-Mongo	\N	5	142928
148870	\N	\N	\N	\N	80340406	Lohanga	\N	5	142928
148871	\N	\N	\N	\N	80340407	Longandjo	\N	5	142928
148872	\N	\N	\N	\N	80340408	Ngombe	\N	5	142928
148873	\N	\N	\N	\N	80340409	Otanga Ndjadi	\N	5	142928
148874	\N	\N	\N	\N	80340410	Otanga Sala	\N	5	142928
148875	\N	\N	\N	\N	80340411	Womamboka	\N	5	142928
148876	\N	\N	\N	\N	80340412	Yungi 1	\N	5	142928
148877	\N	\N	\N	\N	80340413	Yungi 2	\N	5	142928
148878	\N	\N	\N	\N	80340501	Djinga	\N	5	142929
148879	\N	\N	\N	\N	80340502	Djumbusanga	\N	5	142929
148880	\N	\N	\N	\N	80340503	Numbeleki	\N	5	142929
148881	\N	\N	\N	\N	80340504	Ohambe	\N	5	142929
148882	\N	\N	\N	\N	80340505	Okale	\N	5	142929
148883	\N	\N	\N	\N	80340506	Pungu Odima	\N	5	142929
148884	\N	\N	\N	\N	80340507	Sheki	\N	5	142929
148885	\N	\N	\N	\N	80340601	Balanga	\N	5	142930
148886	\N	\N	\N	\N	80340602	Bambole	\N	5	142930
148887	\N	\N	\N	\N	80340603	Ludiya	\N	5	142930
148888	\N	\N	\N	\N	80340604	Ndjadi	\N	5	142930
148889	\N	\N	\N	\N	80340605	Nkoy-Lomami	\N	5	142930
148890	\N	\N	\N	\N	80340606	Osango	\N	5	142930
148891	\N	\N	\N	\N	80340701	Katopa	\N	5	142931
148892	\N	\N	\N	\N	80340702	Loha	\N	5	142931
148893	\N	\N	\N	\N	80340703	Mioto	\N	5	142931
148894	\N	\N	\N	\N	80340704	Ndjilapanda	\N	5	142931
148895	\N	\N	\N	\N	80340801	Kasongo	\N	5	142932
148896	\N	\N	\N	\N	80340802	Katako-Olombi	\N	5	142932
148897	\N	\N	\N	\N	80340803	Kingombe	\N	5	142932
148898	\N	\N	\N	\N	80340804	Lupaka	\N	5	142932
148899	\N	\N	\N	\N	80340805	Lupanu	\N	5	142932
148900	\N	\N	\N	\N	80340806	Lutundula	\N	5	142932
148901	\N	\N	\N	\N	80340807	Mabuka	\N	5	142932
148902	\N	\N	\N	\N	80340808	Mudimbi	\N	5	142932
148903	\N	\N	\N	\N	80340809	Mundala	\N	5	142932
148904	\N	\N	\N	\N	80340810	Mutambwe	\N	5	142932
148905	\N	\N	\N	\N	80340811	Omeonga	\N	5	142932
148906	\N	\N	\N	\N	80340812	Opelele	\N	5	142932
148907	\N	\N	\N	\N	80340813	Tete Ngomba	\N	5	142932
148908	\N	\N	\N	\N	80340901	Ahamba Dikuku	\N	5	142933
148909	\N	\N	\N	\N	80340902	Banda	\N	5	142933
148910	\N	\N	\N	\N	80340903	Djulu	\N	5	142933
148911	\N	\N	\N	\N	80340904	Dimandja	\N	5	142933
148912	\N	\N	\N	\N	80340905	Etanga Shenga	\N	5	142933
148913	\N	\N	\N	\N	80340906	Ewango	\N	5	142933
148914	\N	\N	\N	\N	80340907	Kuapanga	\N	5	142933
148915	\N	\N	\N	\N	80340908	Lonema-Opumbo	\N	5	142933
148916	\N	\N	\N	\N	80340909	Mibangu	\N	5	142933
148917	\N	\N	\N	\N	80340910	Munge	\N	5	142933
148918	\N	\N	\N	\N	80340911	Ndjadi	\N	5	142933
148919	\N	\N	\N	\N	80340912	Ngombe	\N	5	142933
148920	\N	\N	\N	\N	80340913	Nyanga-Lomembe	\N	5	142933
148921	\N	\N	\N	\N	80340914	Ohambe-Taambwe	\N	5	142933
148922	\N	\N	\N	\N	80340915	Okaku-Letshu	\N	5	142933
148923	\N	\N	\N	\N	80340916	Sheki	\N	5	142933
148924	\N	\N	\N	\N	80340917	Shenga-Losamanya	\N	5	142933
148925	\N	\N	\N	\N	80340918	Shilu	\N	5	142933
148926	\N	\N	\N	\N	80340919	Shukende	\N	5	142933
148927	\N	\N	\N	\N	80340920	Tsheko	\N	5	142933
148928	\N	\N	\N	\N	80340921	Tshekokenge	\N	5	142933
148929	\N	\N	\N	\N	80340922	Uduku	\N	5	142933
148930	\N	\N	\N	\N	80340923	Vele	\N	5	142933
148931	\N	\N	\N	\N	80340924	Wundu	\N	5	142933
148932	\N	\N	\N	\N	80350101	Babalaba Kitenge	\N	5	142935
148933	\N	\N	\N	\N	80350102	Babongo	\N	5	142935
148934	\N	\N	\N	\N	80350103	Badingwe	\N	5	142935
148935	\N	\N	\N	\N	80350104	Bakimungu	\N	5	142935
148936	\N	\N	\N	\N	80350105	Bakombe	\N	5	142935
148937	\N	\N	\N	\N	80350106	Bakwa Nioeshi	\N	5	142935
148938	\N	\N	\N	\N	80350107	Balembue	\N	5	142935
148939	\N	\N	\N	\N	80350108	Bamiengie	\N	5	142935
148940	\N	\N	\N	\N	80350109	Banatshilupe	\N	5	142935
148941	\N	\N	\N	\N	80350110	Bangolela	\N	5	142935
148942	\N	\N	\N	\N	80350111	Batobo	\N	5	142935
148943	\N	\N	\N	\N	80350112	Baumba	\N	5	142935
148944	\N	\N	\N	\N	80350113	Bende Bende	\N	5	142935
148945	\N	\N	\N	\N	80350114	Kabuya Batundu	\N	5	142935
148946	\N	\N	\N	\N	80350115	Kalanga	\N	5	142935
148947	\N	\N	\N	\N	80350116	Makadi	\N	5	142935
148948	\N	\N	\N	\N	80350117	Malubule	\N	5	142935
148949	\N	\N	\N	\N	80350118	Mateka	\N	5	142935
148950	\N	\N	\N	\N	80350119	Mutsima Munda	\N	5	142935
148951	\N	\N	\N	\N	80350201	Bena koy	\N	5	142936
148952	\N	\N	\N	\N	80350202	Ehunga	\N	5	142936
148953	\N	\N	\N	\N	80350203	Koyilodi	\N	5	142936
148954	\N	\N	\N	\N	80350204	Longonya	\N	5	142936
148955	\N	\N	\N	\N	80350205	Nyakubu	\N	5	142936
148956	\N	\N	\N	\N	80350206	Sumbu	\N	5	142936
148957	\N	\N	\N	\N	80350301	Djungu Sama	\N	5	142937
148958	\N	\N	\N	\N	80350302	Lole	\N	5	142937
148959	\N	\N	\N	\N	80350303	Lumbu	\N	5	142937
148960	\N	\N	\N	\N	80350304	Mpenge	\N	5	142937
148961	\N	\N	\N	\N	80350305	Okandjo	\N	5	142937
148962	\N	\N	\N	\N	80350306	Okoho	\N	5	142937
148963	\N	\N	\N	\N	80350307	Saka	\N	5	142937
148964	\N	\N	\N	\N	80350308	Tsheko	\N	5	142937
148965	\N	\N	\N	\N	80350309	Watambulu	\N	5	142937
148966	\N	\N	\N	\N	80350310	Yanga	\N	5	142937
148967	\N	\N	\N	\N	80350401	Adungu	\N	5	142938
148968	\N	\N	\N	\N	80350402	Biari	\N	5	142938
148969	\N	\N	\N	\N	80350403	Budja	\N	5	142938
148970	\N	\N	\N	\N	80350404	Dala	\N	5	142938
148971	\N	\N	\N	\N	80350405	Djalo Sala	\N	5	142938
148972	\N	\N	\N	\N	80350406	Djovu	\N	5	142938
148973	\N	\N	\N	\N	80350407	Djunga Olota	\N	5	142938
148974	\N	\N	\N	\N	80350408	Edje	\N	5	142938
148975	\N	\N	\N	\N	80350409	Eminga	\N	5	142938
148976	\N	\N	\N	\N	80350410	Eno Adiangu	\N	5	142938
148977	\N	\N	\N	\N	80350411	Lokombe	\N	5	142938
148978	\N	\N	\N	\N	80350412	Lombela	\N	5	142938
148979	\N	\N	\N	\N	80350413	Mpembe	\N	5	142938
148980	\N	\N	\N	\N	80350414	Okudi	\N	5	142938
148981	\N	\N	\N	\N	80350415	Ole	\N	5	142938
148982	\N	\N	\N	\N	80350416	Owandji	\N	5	142938
148983	\N	\N	\N	\N	80350417	Senga	\N	5	142938
148984	\N	\N	\N	\N	80350418	Wunda	\N	5	142938
148985	\N	\N	\N	\N	80350419	Yula	\N	5	142938
148986	\N	\N	\N	\N	80350501	Alongomo	\N	5	142915
148987	\N	\N	\N	\N	80360101	Djele	\N	5	142940
148988	\N	\N	\N	\N	80360102	Dolo	\N	5	142940
148989	\N	\N	\N	\N	80360103	Omanga	\N	5	142940
148990	\N	\N	\N	\N	80360104	Peko	\N	5	142940
148991	\N	\N	\N	\N	80360105	Tshoyo	\N	5	142940
148992	\N	\N	\N	\N	80360201	Adjoi	\N	5	142941
148993	\N	\N	\N	\N	80360202	Koditshale	\N	5	142941
148994	\N	\N	\N	\N	80360203	Konde	\N	5	142941
148995	\N	\N	\N	\N	80360204	Kowo	\N	5	142941
148996	\N	\N	\N	\N	80360205	Olongapo	\N	5	142941
148997	\N	\N	\N	\N	80360206	Piete	\N	5	142941
148998	\N	\N	\N	\N	80360207	Shilu	\N	5	142941
148999	\N	\N	\N	\N	80360208	Tshake	\N	5	142941
149000	\N	\N	\N	\N	80360301	Endjundju	\N	5	142942
149001	\N	\N	\N	\N	80360302	Koko	\N	5	142942
149002	\N	\N	\N	\N	80360303	Luketo	\N	5	142942
149003	\N	\N	\N	\N	80360304	Lungiya	\N	5	142942
149004	\N	\N	\N	\N	80360305	Okoko	\N	5	142942
149005	\N	\N	\N	\N	80360306	Owila	\N	5	142942
149006	\N	\N	\N	\N	80360307	Shenga	\N	5	142942
149007	\N	\N	\N	\N	80360308	Stamila	\N	5	142942
149008	\N	\N	\N	\N	80360309	Tsheko	\N	5	142942
149009	\N	\N	\N	\N	80360310	Wema	\N	5	142942
149010	\N	\N	\N	\N	80360311	Yimbo	\N	5	142942
149011	\N	\N	\N	\N	80360401	Djepale	\N	5	142943
149012	\N	\N	\N	\N	80360402	Ofundekoie	\N	5	142943
149013	\N	\N	\N	\N	80360403	Kombe	\N	5	142943
149014	\N	\N	\N	\N	80360404	Kuku	\N	5	142943
149015	\N	\N	\N	\N	80360405	Mumba	\N	5	142943
149016	\N	\N	\N	\N	80360406	Ngandu	\N	5	142943
149017	\N	\N	\N	\N	80360407	Ngenga	\N	5	142943
149018	\N	\N	\N	\N	80360408	Otshike	\N	5	142943
149019	\N	\N	\N	\N	80360409	Owende	\N	5	142943
149020	\N	\N	\N	\N	80360410	Pua	\N	5	142943
149021	\N	\N	\N	\N	80360501	Anono	\N	5	142944
149022	\N	\N	\N	\N	80360502	Bakutshu	\N	5	142944
149023	\N	\N	\N	\N	80360503	Kono-Hambe	\N	5	142944
149024	\N	\N	\N	\N	80360504	Manda	\N	5	142944
149025	\N	\N	\N	\N	80360505	Mango	\N	5	142944
149026	\N	\N	\N	\N	80360506	Mbotokonda	\N	5	142944
149027	\N	\N	\N	\N	80360507	Ngoyidjambe	\N	5	142944
149028	\N	\N	\N	\N	80360508	Numbe Yuwa	\N	5	142944
149029	\N	\N	\N	\N	80360509	Nyambaka	\N	5	142944
149030	\N	\N	\N	\N	80360510	Okale	\N	5	142944
149031	\N	\N	\N	\N	80360511	Ondombe	\N	5	142944
149032	\N	\N	\N	\N	80360512	Osui	\N	5	142944
149033	\N	\N	\N	\N	80360513	Toko	\N	5	142944
149034	\N	\N	\N	\N	80360514	Tumba omuna	\N	5	142944
149035	\N	\N	\N	\N	80360515	Tumbalusa	\N	5	142944
149036	\N	\N	\N	\N	80360516	Waho	\N	5	142944
149037	\N	\N	\N	\N	80360517	Yenge	\N	5	142944
149038	\N	\N	\N	\N	80360601	Djumbe	\N	5	142945
149039	\N	\N	\N	\N	80360602	Lolema	\N	5	142945
149040	\N	\N	\N	\N	80360603	Lomami	\N	5	142945
149041	\N	\N	\N	\N	80360604	Luhembe	\N	5	142945
149042	\N	\N	\N	\N	80360605	Lukumbu	\N	5	142945
149043	\N	\N	\N	\N	80360606	Nganya	\N	5	142945
149044	\N	\N	\N	\N	80360607	Odimba	\N	5	142945
149045	\N	\N	\N	\N	80360608	Yandju	\N	5	142945
149046	\N	\N	\N	\N	80360701	Anate	\N	5	142946
149047	\N	\N	\N	\N	80360702	Otaunda	\N	5	142946
149048	\N	\N	\N	\N	80360703	Kiandja	\N	5	142946
149049	\N	\N	\N	\N	80360704	Luausi	\N	5	142946
149050	\N	\N	\N	\N	80360705	Lufu	\N	5	142946
149051	\N	\N	\N	\N	80360706	Okolo	\N	5	142946
149052	\N	\N	\N	\N	80360707	Okuandji	\N	5	142946
149053	\N	\N	\N	\N	80360708	Shakanda	\N	5	142946
149054	\N	\N	\N	\N	80360709	Tshuine	\N	5	142946
149055	\N	\N	\N	\N	80360710	Ungualu	\N	5	142946
149056	\N	\N	\N	\N	80360711	Yendo	\N	5	142946
149057	\N	\N	\N	\N	80360801	Kfumu	\N	5	142947
149058	\N	\N	\N	\N	80360802	Nganga	\N	5	142947
149059	\N	\N	\N	\N	80360803	Pangu	\N	5	142947
149060	\N	\N	\N	\N	80360804	Punda	\N	5	142947
149061	\N	\N	\N	\N	80360805	Putu-Hangata	\N	5	142947
149062	\N	\N	\N	\N	80360806	Ututu	\N	5	142947
149063	\N	\N	\N	\N	80360807	Yunge	\N	5	142947
149064	\N	\N	\N	\N	80360901	Edingo	\N	5	142948
149065	\N	\N	\N	\N	80360902	Esenge 1	\N	5	142948
149066	\N	\N	\N	\N	80360903	Esenge 2	\N	5	142948
149067	\N	\N	\N	\N	80360904	Diengenga	\N	5	142948
149068	\N	\N	\N	\N	80360905	Fin Terme Civil	\N	5	142948
149069	\N	\N	\N	\N	80360906	Fiin Terme Militaire	\N	5	142948
149070	\N	\N	\N	\N	80360907	Fundji	\N	5	142948
149071	\N	\N	\N	\N	80360908	CitÃ© Lodja	\N	5	142948
149072	\N	\N	\N	\N	80360909	Londa	\N	5	142948
149073	\N	\N	\N	\N	80360910	Otetela	\N	5	142948
149074	\N	\N	\N	\N	80360911	Sango -Moke	\N	5	142948
149075	\N	\N	\N	\N	80360912	Shapembe	\N	5	142948
149076	\N	\N	\N	\N	80410101	Akamalemba	\N	5	142950
149077	\N	\N	\N	\N	80410102	Akanseji	\N	5	142950
149078	\N	\N	\N	\N	80410103	Kanutshina	\N	5	142950
149079	\N	\N	\N	\N	80410104	Mukila Kamuanga	\N	5	142950
149080	\N	\N	\N	\N	80410105	Wiyawu	\N	5	142950
149081	\N	\N	\N	\N	80410106	Yambeji	\N	5	142950
149082	\N	\N	\N	\N	80410201	Bena Ngoy	\N	5	142951
149083	\N	\N	\N	\N	80410202	Itondo Gauche	\N	5	142951
149084	\N	\N	\N	\N	80410203	Katambayi	\N	5	142951
149085	\N	\N	\N	\N	80410204	Mulundu	\N	5	142951
149086	\N	\N	\N	\N	80410205	Muenge Gauche	\N	5	142951
149087	\N	\N	\N	\N	80410206	Mwene-Ditu	\N	5	142951
149088	\N	\N	\N	\N	80410207	Tshilundu-Sabe	\N	5	142951
149089	\N	\N	\N	\N	80410208	Tshimba-Tshibwidi	\N	5	142951
149090	\N	\N	\N	\N	80410301	Bena Mbala	\N	5	142952
149091	\N	\N	\N	\N	80410302	Kanyiki Kapangu	\N	5	142952
149092	\N	\N	\N	\N	80410303	Kanyiki Mutembwe	\N	5	142952
149093	\N	\N	\N	\N	80410304	Kayembe Ngombe	\N	5	142952
149094	\N	\N	\N	\N	80410305	Luaba	\N	5	142952
149095	\N	\N	\N	\N	80410306	Matamba	\N	5	142952
149096	\N	\N	\N	\N	80410307	Mulaja Kanumbi	\N	5	142952
149097	\N	\N	\N	\N	80410308	Tshitole	\N	5	142952
149098	\N	\N	\N	\N	80410401	Hamba	\N	5	142953
149099	\N	\N	\N	\N	80410402	Itondo	\N	5	142953
149100	\N	\N	\N	\N	80410403	Kalamba	\N	5	142953
149101	\N	\N	\N	\N	80410404	Katshisungu	\N	5	142953
149102	\N	\N	\N	\N	80410405	Lusuku	\N	5	142953
149103	\N	\N	\N	\N	80410406	Musenga	\N	5	142953
149104	\N	\N	\N	\N	80410407	Tshilonda	\N	5	142953
149105	\N	\N	\N	\N	80410408	Tshobobo	\N	5	142953
149106	\N	\N	\N	\N	80410501	Bukasa	\N	5	142954
149107	\N	\N	\N	\N	80410502	Ditu Ilunga	\N	5	142954
149108	\N	\N	\N	\N	80410503	Kalondji	\N	5	142954
149109	\N	\N	\N	\N	80410504	Kamisangi	\N	5	142954
149110	\N	\N	\N	\N	80410505	Kasanza	\N	5	142954
149111	\N	\N	\N	\N	80410506	Makota	\N	5	142954
149112	\N	\N	\N	\N	80410507	Munsampi	\N	5	142954
149113	\N	\N	\N	\N	80410508	Nkunaya Tubala	\N	5	142954
149114	\N	\N	\N	\N	80410509	Tshiamala	\N	5	142954
149115	\N	\N	\N	\N	80410510	Tshibangu Mpata 1	\N	5	142954
149116	\N	\N	\N	\N	80410511	Tshinbangu Mpata 2	\N	5	142954
149117	\N	\N	\N	\N	80410512	Tshitonkonyi	\N	5	142954
149118	\N	\N	\N	\N	80415101	Bukasa	\N	5	142955
149119	\N	\N	\N	\N	80415102	Ditu Ilunga	\N	5	142955
149120	\N	\N	\N	\N	80415104	Kamisangi	\N	5	142955
149121	\N	\N	\N	\N	80415105	Kasanza	\N	5	142955
149122	\N	\N	\N	\N	80415106	Makota	\N	5	142955
149123	\N	\N	\N	\N	80415107	Munsampi	\N	5	142955
149124	\N	\N	\N	\N	80415201	Bajika	\N	5	142956
149125	\N	\N	\N	\N	80415202	Dinanga	\N	5	142956
149126	\N	\N	\N	\N	80415203	Gare 1	\N	5	142956
149127	\N	\N	\N	\N	80415204	Gare 2	\N	5	142956
149128	\N	\N	\N	\N	80415205	Kabusanga	\N	5	142956
149129	\N	\N	\N	\N	80415206	Kamukungu 1	\N	5	142956
149130	\N	\N	\N	\N	80415207	Kamukungu 2	\N	5	142956
149131	\N	\N	\N	\N	80415208	Katembwe	\N	5	142956
149132	\N	\N	\N	\N	80415209	Katubi	\N	5	142956
149133	\N	\N	\N	\N	80415210	MarchÃ©	\N	5	142956
149134	\N	\N	\N	\N	80415211	Mbuyi	\N	5	142956
149135	\N	\N	\N	\N	80415212	Mumvuyi	\N	5	142956
149136	\N	\N	\N	\N	80415213	Nkulu	\N	5	142956
149137	\N	\N	\N	\N	80415214	S.N.C.C.	\N	5	142956
149138	\N	\N	\N	\N	80415215	Triangle	\N	5	142956
149139	\N	\N	\N	\N	80415216	Tshibiayi	\N	5	142956
149140	\N	\N	\N	\N	80415217	Congo (Zaire)	\N	5	142956
149141	\N	\N	\N	\N	80420101	Bungu	\N	5	142957
149142	\N	\N	\N	\N	80420102	Nsuku	\N	5	142957
149143	\N	\N	\N	\N	80420201	Katshia	\N	5	142958
149144	\N	\N	\N	\N	80430101	Bakwa Kalonji	\N	5	142959
149145	\N	\N	\N	\N	80430102	Mpemba Nzeo	\N	5	142959
149146	\N	\N	\N	\N	80430103	Gandajika	\N	5	142959
149147	\N	\N	\N	\N	80430104	Kadiayi	\N	5	142959
149148	\N	\N	\N	\N	80430105	Kajikakayi	\N	5	142959
149149	\N	\N	\N	\N	80430106	Kamanshi	\N	5	142959
149150	\N	\N	\N	\N	80430107	Kanyika	\N	5	142959
149151	\N	\N	\N	\N	80430108	Kanyiki Mbamba	\N	5	142959
149152	\N	\N	\N	\N	80430109	Katupuila	\N	5	142959
149153	\N	\N	\N	\N	80430110	Kihanga	\N	5	142959
149154	\N	\N	\N	\N	80430111	Lobo	\N	5	142959
149155	\N	\N	\N	\N	80430112	Mpandamushilu	\N	5	142959
149156	\N	\N	\N	\N	80430113	Mpasu	\N	5	142959
149157	\N	\N	\N	\N	80430114	Mpata	\N	5	142959
149158	\N	\N	\N	\N	80430115	Mpoyi	\N	5	142959
149159	\N	\N	\N	\N	80430116	Mpunga	\N	5	142959
149160	\N	\N	\N	\N	80430117	Muana Mbuyi	\N	5	142959
149161	\N	\N	\N	\N	80430118	Muanzangudia	\N	5	142959
149162	\N	\N	\N	\N	80430119	Mulamba 1	\N	5	142959
149163	\N	\N	\N	\N	80430120	Mulamba 2	\N	5	142959
149164	\N	\N	\N	\N	80430121	Musakatshi	\N	5	142959
149165	\N	\N	\N	\N	80430122	Musuya	\N	5	142959
149166	\N	\N	\N	\N	80430123	Shalukoji	\N	5	142959
149167	\N	\N	\N	\N	80430124	Tshibumbuambu	\N	5	142959
149168	\N	\N	\N	\N	80430125	Tshimomo	\N	5	142959
149169	\N	\N	\N	\N	80430201	Kafumbu	\N	5	142960
149170	\N	\N	\N	\N	80430202	Kanyana	\N	5	142960
149171	\N	\N	\N	\N	80430203	Kaseki	\N	5	142960
149172	\N	\N	\N	\N	80430204	Luanga	\N	5	142960
149173	\N	\N	\N	\N	80430205	Manda Mbaya	\N	5	142960
149174	\N	\N	\N	\N	80430206	Manda Musenga	\N	5	142960
149175	\N	\N	\N	\N	80430207	Mpiana	\N	5	142960
149176	\N	\N	\N	\N	80430208	Mpiana Mukala	\N	5	142960
149177	\N	\N	\N	\N	80430209	Nsana	\N	5	142960
149178	\N	\N	\N	\N	80430301	Kakoma	\N	5	142961
149179	\N	\N	\N	\N	80430302	Kalula	\N	5	142961
149180	\N	\N	\N	\N	80430303	Ndalambombo	\N	5	142961
149181	\N	\N	\N	\N	80430304	Ndiadia	\N	5	142961
149182	\N	\N	\N	\N	80430305	Ngambua	\N	5	142961
149183	\N	\N	\N	\N	80430306	Ntite	\N	5	142961
149184	\N	\N	\N	\N	80430307	Nyenyempie	\N	5	142961
149185	\N	\N	\N	\N	80430308	Shabanza	\N	5	142961
149186	\N	\N	\N	\N	80430309	Tshileo	\N	5	142961
149187	\N	\N	\N	\N	80430310	Tshipanzula	\N	5	142961
149188	\N	\N	\N	\N	80430401	Bajila Membele	\N	5	142962
149189	\N	\N	\N	\N	80430402	Bashiya Kabuya	\N	5	142962
149190	\N	\N	\N	\N	80430403	Bena Kabala 1	\N	5	142962
149191	\N	\N	\N	\N	80430404	Bena Kabala 2	\N	5	142962
149192	\N	\N	\N	\N	80430405	Kabongo Ntshile	\N	5	142962
149193	\N	\N	\N	\N	80430406	Kalambayi Mbaya	\N	5	142962
149194	\N	\N	\N	\N	80430407	Kalula	\N	5	142962
149195	\N	\N	\N	\N	80430408	Kalunda Basa	\N	5	142962
149196	\N	\N	\N	\N	80430409	Kalunde musoko	\N	5	142962
149197	\N	\N	\N	\N	80430410	Kanampumbi	\N	5	142962
149198	\N	\N	\N	\N	80430411	Kanyukwa	\N	5	142962
149199	\N	\N	\N	\N	80430412	Kaponda	\N	5	142962
149200	\N	\N	\N	\N	80430413	Kayembe-Mukulu	\N	5	142962
149201	\N	\N	\N	\N	80430414	Lulenga	\N	5	142962
149202	\N	\N	\N	\N	80430415	Mbaya	\N	5	142962
149203	\N	\N	\N	\N	80430416	Mbuyi	\N	5	142962
149204	\N	\N	\N	\N	80430417	Miembia	\N	5	142962
149205	\N	\N	\N	\N	80430418	Mpoyi	\N	5	142962
149206	\N	\N	\N	\N	80430419	Muabila	\N	5	142962
149207	\N	\N	\N	\N	80430420	Mukisi	\N	5	142962
149208	\N	\N	\N	\N	80430421	Mulandala	\N	5	142962
149209	\N	\N	\N	\N	80430422	Muyumba	\N	5	142962
149210	\N	\N	\N	\N	80430423	Ngonga	\N	5	142962
149211	\N	\N	\N	\N	80430424	Ngulungu	\N	5	142962
149212	\N	\N	\N	\N	80430425	Nkezenge	\N	5	142962
149213	\N	\N	\N	\N	80430426	Ntite Kalambayi	\N	5	142962
149214	\N	\N	\N	\N	80430427	Ntombe	\N	5	142962
149215	\N	\N	\N	\N	80430428	Tshimasala	\N	5	142962
149216	\N	\N	\N	\N	80430429	Tshiminyi	\N	5	142962
149217	\N	\N	\N	\N	80430430	Tshipanzula	\N	5	142962
149218	\N	\N	\N	\N	80430431	Tshitungulu	\N	5	142962
149219	\N	\N	\N	\N	80430501	Banza	\N	5	142963
149220	\N	\N	\N	\N	80430502	Kabanga	\N	5	142963
149221	\N	\N	\N	\N	80430503	Kalume	\N	5	142963
149222	\N	\N	\N	\N	80430504	Kande	\N	5	142963
149223	\N	\N	\N	\N	80430505	Kapuku	\N	5	142963
149224	\N	\N	\N	\N	80430506	Kashala	\N	5	142963
149225	\N	\N	\N	\N	80430507	Katshi	\N	5	142963
149226	\N	\N	\N	\N	80430508	Koni	\N	5	142963
149227	\N	\N	\N	\N	80430509	Matobo	\N	5	142963
149228	\N	\N	\N	\N	80430510	Mbao Lubimbi	\N	5	142963
149229	\N	\N	\N	\N	80430511	Mbao Lulaji	\N	5	142963
149230	\N	\N	\N	\N	80430512	Mbudi	\N	5	142963
149231	\N	\N	\N	\N	80430513	Mpungwe	\N	5	142963
149232	\N	\N	\N	\N	80430514	Mulamba	\N	5	142963
149233	\N	\N	\N	\N	80430515	Musawo	\N	5	142963
149234	\N	\N	\N	\N	80430516	Nzaji	\N	5	142963
149235	\N	\N	\N	\N	80430517	Shimbi	\N	5	142963
149236	\N	\N	\N	\N	80430518	Tshileo	\N	5	142963
149237	\N	\N	\N	\N	80430519	Tshisalo	\N	5	142963
149238	\N	\N	\N	\N	80435101	Inera	\N	5	142964
149239	\N	\N	\N	\N	80435102	Kabanda	\N	5	142964
149240	\N	\N	\N	\N	80435103	Kalubanda	\N	5	142964
149241	\N	\N	\N	\N	80435104	Kasonji	\N	5	142964
149242	\N	\N	\N	\N	80435105	Lunga	\N	5	142964
149243	\N	\N	\N	\N	80435106	Mpumbua	\N	5	142964
149244	\N	\N	\N	\N	80435107	RÃ©volution	\N	5	142964
149245	\N	\N	\N	\N	80440101	Babindji	\N	5	142966
149246	\N	\N	\N	\N	80440102	Bakoji	\N	5	142966
149247	\N	\N	\N	\N	80440103	Bakwa Muanza	\N	5	142966
149248	\N	\N	\N	\N	80440104	Bakwa Nsumpi	\N	5	142966
149249	\N	\N	\N	\N	80440105	Bakwa Tshinene	\N	5	142966
149250	\N	\N	\N	\N	80440106	Belende Ngoma	\N	5	142966
149251	\N	\N	\N	\N	80440107	Majiba	\N	5	142966
149252	\N	\N	\N	\N	80440108	Nomba	\N	5	142966
149253	\N	\N	\N	\N	80440201	Basanga	\N	5	142967
149254	\N	\N	\N	\N	80440202	Evungu	\N	5	142967
149255	\N	\N	\N	\N	80440203	Kankala	\N	5	142967
149256	\N	\N	\N	\N	80440204	Misumba	\N	5	142967
149257	\N	\N	\N	\N	80440205	Mpanza	\N	5	142967
149258	\N	\N	\N	\N	80440206	Mudilu	\N	5	142967
149259	\N	\N	\N	\N	80440207	Totue	\N	5	142967
149260	\N	\N	\N	\N	80440301	Belande-Sud	\N	5	142968
149261	\N	\N	\N	\N	80440302	Kiofue	\N	5	142968
149262	\N	\N	\N	\N	80440303	Milembue-Mukungila	\N	5	142968
149263	\N	\N	\N	\N	80440304	Mulembue-Mpanda	\N	5	142968
149264	\N	\N	\N	\N	80440401	Ejiba	\N	5	142969
149265	\N	\N	\N	\N	80440402	Kaseke	\N	5	142969
149266	\N	\N	\N	\N	80440403	Keba	\N	5	142969
149267	\N	\N	\N	\N	80440404	Kitshindje	\N	5	142969
149268	\N	\N	\N	\N	80440405	Lubinda	\N	5	142969
149269	\N	\N	\N	\N	80440406	Mutengu	\N	5	142969
149270	\N	\N	\N	\N	80440501	Budia	\N	5	142970
149271	\N	\N	\N	\N	80440502	Lukate	\N	5	142970
149272	\N	\N	\N	\N	80440503	Mabe	\N	5	142970
149273	\N	\N	\N	\N	80440504	Mbale	\N	5	142970
149274	\N	\N	\N	\N	80440505	Tshibeshi	\N	5	142970
149275	\N	\N	\N	\N	80440506	Tshimonga	\N	5	142970
149276	\N	\N	\N	\N	80440507	Tshipakula	\N	5	142970
149277	\N	\N	\N	\N	80440601	Lubatshi	\N	5	142971
149278	\N	\N	\N	\N	80440602	Lumpungu	\N	5	142971
149279	\N	\N	\N	\N	80440603	Milenda	\N	5	142971
149280	\N	\N	\N	\N	80440604	Suedi	\N	5	142971
149281	\N	\N	\N	\N	80440605	Zewe	\N	5	142971
149282	\N	\N	\N	\N	80445101	Bandaka	\N	5	142972
149283	\N	\N	\N	\N	80445102	Basala	\N	5	142972
149284	\N	\N	\N	\N	80445103	Bena-Mbua	\N	5	142972
149285	\N	\N	\N	\N	80445104	Bunduki	\N	5	142972
149286	\N	\N	\N	\N	80445105	Kabondo	\N	5	142972
149287	\N	\N	\N	\N	80445106	Kamukungu	\N	5	142972
149288	\N	\N	\N	\N	80445107	Lunya	\N	5	142972
149289	\N	\N	\N	\N	80445108	Shadilayi	\N	5	142972
149290	\N	\N	\N	\N	80445109	Shindika	\N	5	142972
149291	\N	\N	\N	\N	80445110	Yakasongo	\N	5	142972
149292	\N	\N	\N	\N	80445111	Congo(ZaÃ®re)	\N	5	142972
149293	\N	\N	\N	\N	80450101	Bekalebwe-Yangongo	\N	5	142973
149294	\N	\N	\N	\N	80450102	Bekalebwe-Yantambue	\N	5	142973
149295	\N	\N	\N	\N	80450103	Bena-Mandue	\N	5	142973
149296	\N	\N	\N	\N	80450104	Bena-Mpuku	\N	5	142973
149297	\N	\N	\N	\N	80450201	Babila	\N	5	142974
149298	\N	\N	\N	\N	80450202	Bahemba	\N	5	142974
149299	\N	\N	\N	\N	80450203	Balaa	\N	5	142974
149300	\N	\N	\N	\N	80450204	Bapina	\N	5	142974
149301	\N	\N	\N	\N	80450205	Bashilangie	\N	5	142974
149302	\N	\N	\N	\N	80450206	Bobote	\N	5	142974
149303	\N	\N	\N	\N	80450207	Inga	\N	5	142974
149304	\N	\N	\N	\N	80450208	Kiofue-Yangongo	\N	5	142974
149305	\N	\N	\N	\N	80450209	Lunia	\N	5	142974
149306	\N	\N	\N	\N	80450210	Lutobo	\N	5	142974
149307	\N	\N	\N	\N	80450211	Ngungi	\N	5	142974
149308	\N	\N	\N	\N	80450301	Bena Nzala	\N	5	142975
149309	\N	\N	\N	\N	80450302	Ebula	\N	5	142975
149310	\N	\N	\N	\N	80450303	Eshadika	\N	5	142975
149311	\N	\N	\N	\N	80450304	Imbiadi	\N	5	142975
149312	\N	\N	\N	\N	80450305	Kapuwa	\N	5	142975
149313	\N	\N	\N	\N	80450306	Kasanga	\N	5	142975
149314	\N	\N	\N	\N	80450307	Kibumbu	\N	5	142975
149315	\N	\N	\N	\N	80450308	Kilembue	\N	5	142975
149316	\N	\N	\N	\N	80450309	Mukungu	\N	5	142975
149317	\N	\N	\N	\N	80450310	Ngube	\N	5	142975
149318	\N	\N	\N	\N	80450311	Sangua	\N	5	142975
149319	\N	\N	\N	\N	80450401	Buabe	\N	5	142976
149320	\N	\N	\N	\N	80450402	Ebombo	\N	5	142976
149321	\N	\N	\N	\N	80450403	Kafuma	\N	5	142976
149322	\N	\N	\N	\N	80450404	Kisengwa	\N	5	142976
149323	\N	\N	\N	\N	80450405	Mue	\N	5	142976
149324	\N	\N	\N	\N	80450406	Mumbe	\N	5	142976
149325	\N	\N	\N	\N	80455101	Kongoyi	\N	5	142977
149326	\N	\N	\N	\N	80455102	Lumumba	\N	5	142977
149327	\N	\N	\N	\N	80455103	Kalonji	\N	5	142977
149328	\N	\N	\N	\N	90110001	Lubi-a-Mpata	\N	5	142978
149329	\N	\N	\N	\N	90110002	Nganza Nord	\N	5	142978
149330	\N	\N	\N	\N	90110003	Bganza Sud	\N	5	142978
149331	\N	\N	\N	\N	90110004	Nsele	\N	5	142978
149332	\N	\N	\N	\N	90110005	Salongo	\N	5	142978
149333	\N	\N	\N	\N	90110006	Sukisa	\N	5	142978
149334	\N	\N	\N	\N	90120001	Dikongayi	\N	5	142979
149335	\N	\N	\N	\N	90120002	Itabayi	\N	5	142979
149336	\N	\N	\N	\N	90120003	Lumumba	\N	5	142979
149337	\N	\N	\N	\N	90120004	Mabondo	\N	5	142979
149338	\N	\N	\N	\N	90120005	Mulundu	\N	5	142979
149339	\N	\N	\N	\N	90120006	Tshibashi	\N	5	142979
149340	\N	\N	\N	\N	90130001	Kamilabi	\N	5	142980
149341	\N	\N	\N	\N	90130002	Kamupongo	\N	5	142980
149342	\N	\N	\N	\N	90130003	Lubuna	\N	5	142980
149343	\N	\N	\N	\N	90130004	Ndesha	\N	5	142980
149344	\N	\N	\N	\N	90130005	Tshibanda	\N	5	142980
149345	\N	\N	\N	\N	90210101	Bena Kabiye	\N	5	142982
149346	\N	\N	\N	\N	90210102	Bena Ngonji	\N	5	142982
149347	\N	\N	\N	\N	90210103	Bena Nkole	\N	5	142982
149348	\N	\N	\N	\N	90210104	Bkwa Tshipanga	\N	5	142982
149349	\N	\N	\N	\N	90210201	Bakwa Kabunda	\N	5	142983
149350	\N	\N	\N	\N	90210202	Bakwa Mpia	\N	5	142983
149351	\N	\N	\N	\N	90210203	Bakwa Tshiama	\N	5	142983
149352	\N	\N	\N	\N	90210204	Mamba	\N	5	142983
149353	\N	\N	\N	\N	90210301	Bashila Kasanga	\N	5	142984
149354	\N	\N	\N	\N	90210302	Bena Lala	\N	5	142984
149355	\N	\N	\N	\N	90210303	Bena Musua	\N	5	142984
149356	\N	\N	\N	\N	90210304	Bena Nklende	\N	5	142984
149357	\N	\N	\N	\N	90210305	Bua Lule	\N	5	142984
149358	\N	\N	\N	\N	90210306	Bakwa Kubula	\N	5	142984
149359	\N	\N	\N	\N	90210307	Bakwa Pele	\N	5	142984
149360	\N	\N	\N	\N	90210308	Bakwa Tshikonga	\N	5	142984
149361	\N	\N	\N	\N	90210309	Bakwa Tshilumba	\N	5	142984
149362	\N	\N	\N	\N	90210401	Bena Bitende	\N	5	142985
149363	\N	\N	\N	\N	90210402	Bena Nganza	\N	5	142985
149364	\N	\N	\N	\N	90210403	Bena Tshimbulu	\N	5	142985
149365	\N	\N	\N	\N	90210404	Bakwa Nkata	\N	5	142985
149366	\N	\N	\N	\N	90210405	Bakwa Tshilundu	\N	5	142985
149367	\N	\N	\N	\N	90210501	Bena Katamba	\N	5	142986
149368	\N	\N	\N	\N	90210502	Bakwa Mbiya	\N	5	142986
149369	\N	\N	\N	\N	90215101	Lukula	\N	5	142987
149370	\N	\N	\N	\N	90215201	Lubala	\N	5	142988
149371	\N	\N	\N	\N	90215202	Mitengu	\N	5	142988
149372	\N	\N	\N	\N	90215203	Nsele	\N	5	142988
149373	\N	\N	\N	\N	90215204	Tshibala	\N	5	142988
149374	\N	\N	\N	\N	90215205	Tshidima	\N	5	142988
149375	\N	\N	\N	\N	90215206	Tshimayi	\N	5	142988
149376	\N	\N	\N	\N	90220101	Aka Kasenda	\N	5	142989
149377	\N	\N	\N	\N	90220102	Aka Muangala	\N	5	142989
149378	\N	\N	\N	\N	90220103	Aka Ndambu	\N	5	142989
149379	\N	\N	\N	\N	90220104	Akuma Mpunda	\N	5	142989
149380	\N	\N	\N	\N	90220105	Ana Kabanza	\N	5	142989
149381	\N	\N	\N	\N	90220106	Ana Kalala	\N	5	142989
149382	\N	\N	\N	\N	90220107	Ana Kalomo	\N	5	142989
149383	\N	\N	\N	\N	90220108	Ana Kanza	\N	5	142989
149384	\N	\N	\N	\N	90220109	Ana Kemvuma	\N	5	142989
149385	\N	\N	\N	\N	90220110	Ana Labaya	\N	5	142989
149386	\N	\N	\N	\N	90220111	Ana Mala	\N	5	142989
149387	\N	\N	\N	\N	90220112	Ana Muvukuna	\N	5	142989
149388	\N	\N	\N	\N	90220113	Ana Tshibua	\N	5	142989
149389	\N	\N	\N	\N	90220114	Ana Tshiyala	\N	5	142989
149390	\N	\N	\N	\N	90220115	Baka Mukishi	\N	5	142989
149391	\N	\N	\N	\N	90220116	Batuka	\N	5	142989
149392	\N	\N	\N	\N	90220117	Baka Tshilandji	\N	5	142989
149393	\N	\N	\N	\N	90220201	Baka Luyambi	\N	5	142990
149394	\N	\N	\N	\N	90220202	Baka Mushinji	\N	5	142990
149395	\N	\N	\N	\N	90220203	Baka Shilandji	\N	5	142990
149396	\N	\N	\N	\N	90220204	Bana Shibundi	\N	5	142990
149397	\N	\N	\N	\N	90220205	Bashi Kanyama	\N	5	142990
149398	\N	\N	\N	\N	90220206	Bashi Makoka	\N	5	142990
149399	\N	\N	\N	\N	90220207	Bishi Kabila	\N	5	142990
149400	\N	\N	\N	\N	90220208	Bishi Kajiya	\N	5	142990
149401	\N	\N	\N	\N	90220209	Bishi Luambo	\N	5	142990
149402	\N	\N	\N	\N	90220210	Bishi Mbundi	\N	5	142990
149403	\N	\N	\N	\N	90220211	Bishi Ndashi	\N	5	142990
149404	\N	\N	\N	\N	90220212	Bishi Shawo	\N	5	142990
149405	\N	\N	\N	\N	90220213	Bishi Yamvu	\N	5	142990
149406	\N	\N	\N	\N	90220301	Ana Kabinda	\N	5	142991
149407	\N	\N	\N	\N	90220302	Ana Kasenga	\N	5	142991
149408	\N	\N	\N	\N	90220303	Ana Kazadi	\N	5	142991
149409	\N	\N	\N	\N	90220304	Ana Ndolo	\N	5	142991
149410	\N	\N	\N	\N	90220305	Ana Ntanda	\N	5	142991
149411	\N	\N	\N	\N	90220306	Abna Nzazi	\N	5	142991
149412	\N	\N	\N	\N	90220401	Akampanza	\N	5	142992
149413	\N	\N	\N	\N	90220402	Ana Isele	\N	5	142992
149414	\N	\N	\N	\N	90220403	Ana Lumbu	\N	5	142992
149415	\N	\N	\N	\N	90220404	Ana Mamba	\N	5	142992
149416	\N	\N	\N	\N	90220405	Ana Yangala	\N	5	142992
149417	\N	\N	\N	\N	90220406	Bajila Nyoka	\N	5	142992
149418	\N	\N	\N	\N	90220407	Kata Muanza	\N	5	142992
149419	\N	\N	\N	\N	90220501	Aka Muangala	\N	5	142993
149420	\N	\N	\N	\N	90220502	Aka Nsagayi	\N	5	142993
149421	\N	\N	\N	\N	90220503	Ana Kabanda	\N	5	142993
149422	\N	\N	\N	\N	90220504	Ana Kisamba	\N	5	142993
149423	\N	\N	\N	\N	90220505	Ana Lumba	\N	5	142993
149424	\N	\N	\N	\N	90220506	Ana Mpashi	\N	5	142993
149425	\N	\N	\N	\N	90220507	Ana Ulamba	\N	5	142993
149426	\N	\N	\N	\N	90220601	Aka Kaya	\N	5	142994
149427	\N	\N	\N	\N	90220602	Aka mulamu	\N	5	142994
149428	\N	\N	\N	\N	90220603	Aka Nama	\N	5	142994
149429	\N	\N	\N	\N	90220604	Aka Ngambu	\N	5	142994
149430	\N	\N	\N	\N	90220605	Aka Tshionga	\N	5	142994
149431	\N	\N	\N	\N	90220606	Aka Tshisewu	\N	5	142994
149432	\N	\N	\N	\N	90220607	Akanga	\N	5	142994
149433	\N	\N	\N	\N	90220608	Akuma Nsanji	\N	5	142994
149434	\N	\N	\N	\N	90220609	Ana Matumba	\N	5	142994
149435	\N	\N	\N	\N	90220610	Ana Ngoma	\N	5	142994
149436	\N	\N	\N	\N	90220611	Ana Nkumba	\N	5	142994
149437	\N	\N	\N	\N	90220612	Ana Tshinyama	\N	5	142994
149438	\N	\N	\N	\N	90220701	Aka Kandondo	\N	5	142995
149439	\N	\N	\N	\N	90220702	Aka Muala	\N	5	142995
149440	\N	\N	\N	\N	90220703	Akume Mpembe	\N	5	142995
149441	\N	\N	\N	\N	90220704	Ana Kajimbi Kat.	\N	5	142995
149442	\N	\N	\N	\N	90220705	Ana Kajimbi Lam.	\N	5	142995
149443	\N	\N	\N	\N	90220706	Ana Kalunga	\N	5	142995
149444	\N	\N	\N	\N	90220707	Ana Mbungu	\N	5	142995
149445	\N	\N	\N	\N	90220708	Ana Muangala	\N	5	142995
149446	\N	\N	\N	\N	90220709	Ana muilu	\N	5	142995
149447	\N	\N	\N	\N	90220710	Ana Muipata	\N	5	142995
149448	\N	\N	\N	\N	90220711	Ana Mumbia	\N	5	142995
149449	\N	\N	\N	\N	90220712	Ana Tshiwanu	\N	5	142995
149450	\N	\N	\N	\N	90230101	Bakwa Mbuyi	\N	5	142997
149451	\N	\N	\N	\N	90230102	Bakwa Njiba	\N	5	142997
149452	\N	\N	\N	\N	90230103	Bakwa tshienza	\N	5	142997
149453	\N	\N	\N	\N	90230104	Bakwa Tshimba	\N	5	142997
149454	\N	\N	\N	\N	90230105	Bashi Kabala	\N	5	142997
149455	\N	\N	\N	\N	90230106	Bashi Tshilunda	\N	5	142997
149456	\N	\N	\N	\N	90230107	Ba-Busongo	\N	5	142997
149457	\N	\N	\N	\N	90230108	Ba-Kuba	\N	5	142997
149458	\N	\N	\N	\N	90230109	Ba-Nkuba	\N	5	142997
149459	\N	\N	\N	\N	90230110	Tshisanga Mpata	\N	5	142997
149460	\N	\N	\N	\N	90230201	Bakwa musenga	\N	5	142998
149461	\N	\N	\N	\N	90230202	Bakwa Tshiuya	\N	5	142998
149462	\N	\N	\N	\N	90230203	Bena Biduaya	\N	5	142998
149463	\N	\N	\N	\N	90230204	Bena Kapuki	\N	5	142998
149464	\N	\N	\N	\N	90230205	Bena Mukangala	\N	5	142998
149465	\N	\N	\N	\N	90230301	Bakwa Ndye	\N	5	142999
149466	\N	\N	\N	\N	90230302	Bakwa Tshilonda	\N	5	142999
149467	\N	\N	\N	\N	90230303	Bena Mbuyi	\N	5	142999
149468	\N	\N	\N	\N	90230304	Bena Tshitudi	\N	5	142999
149469	\N	\N	\N	\N	90230305	Bena nganza	\N	5	142999
149470	\N	\N	\N	\N	90230306	Bena Nyanga	\N	5	142999
149471	\N	\N	\N	\N	90230401	Bena Kalembue	\N	5	143000
149472	\N	\N	\N	\N	90230402	Bena kashiye	\N	5	143000
149473	\N	\N	\N	\N	90230403	Bena Mukadi	\N	5	143000
149474	\N	\N	\N	\N	90230404	Bena Mutshipayi	\N	5	143000
149475	\N	\N	\N	\N	90230405	Bimbadi	\N	5	143000
149476	\N	\N	\N	\N	90230501	Bakwa Meshi	\N	5	143001
149477	\N	\N	\N	\N	90230502	Bakwa Ntumba	\N	5	143001
149478	\N	\N	\N	\N	90230503	Bakwa Tsijkota	\N	5	143001
149479	\N	\N	\N	\N	90230504	Beana Katempa	\N	5	143001
149480	\N	\N	\N	\N	90230505	Bena Kawaya	\N	5	143001
149481	\N	\N	\N	\N	90230506	Bena Mulumba	\N	5	143001
149482	\N	\N	\N	\N	90230507	Bena Ngoshi	\N	5	143001
149483	\N	\N	\N	\N	90230601	Bena Diyaya	\N	5	143002
149484	\N	\N	\N	\N	90230602	Bakwa Kepi	\N	5	143002
149485	\N	\N	\N	\N	90230603	Bakwa Mwanza	\N	5	143002
149486	\N	\N	\N	\N	90230604	Bakwa Ngandu	\N	5	143002
149487	\N	\N	\N	\N	90230605	Bakwa Tembo	\N	5	143002
149488	\N	\N	\N	\N	90230701	Bakwa Odile	\N	5	143003
149489	\N	\N	\N	\N	90230702	Bakwa Nzeba	\N	5	143003
149490	\N	\N	\N	\N	90230703	Bena Binku	\N	5	143003
149491	\N	\N	\N	\N	90230801	Bakw Mbuyi	\N	5	143004
149492	\N	\N	\N	\N	90230802	Bakwa Mutshima	\N	5	143004
149493	\N	\N	\N	\N	90230803	Bashi Balendu	\N	5	143004
149494	\N	\N	\N	\N	90230804	Bashi Kapela	\N	5	143004
149495	\N	\N	\N	\N	90230805	Bashi Katsiena	\N	5	143004
149496	\N	\N	\N	\N	90230806	Bashi Kenda Mbusa	\N	5	143004
149497	\N	\N	\N	\N	90230807	Bashi Musenga	\N	5	143004
149498	\N	\N	\N	\N	90230808	Bayombo	\N	5	143004
149499	\N	\N	\N	\N	90230901	Bakwa Kumba	\N	5	143005
149500	\N	\N	\N	\N	90230902	Bakwa Mpombo	\N	5	143005
149501	\N	\N	\N	\N	90230903	Bakwa Lubuta	\N	5	143005
149502	\N	\N	\N	\N	90230904	Bashi Bandaba	\N	5	143005
149503	\N	\N	\N	\N	90230905	Bashi Kalunga	\N	5	143005
149504	\N	\N	\N	\N	90230906	Bashi Kashiwu	\N	5	143005
149505	\N	\N	\N	\N	90230907	Bashi Mbangu	\N	5	143005
149506	\N	\N	\N	\N	90230908	Bashi Mboyi	\N	5	143005
149507	\N	\N	\N	\N	90230909	Bashi Mujinga	\N	5	143005
149508	\N	\N	\N	\N	90230910	Basi Munyinga	\N	5	143005
149509	\N	\N	\N	\N	90230911	Bshi Tshibayi	\N	5	143005
149510	\N	\N	\N	\N	90230912	Bena Manga	\N	5	143005
149511	\N	\N	\N	\N	90240101	Bisamba	\N	5	143007
149512	\N	\N	\N	\N	90240102	Dibanda	\N	5	143007
149513	\N	\N	\N	\N	90240103	Kalunga	\N	5	143007
149514	\N	\N	\N	\N	90240104	Mbongo	\N	5	143007
149515	\N	\N	\N	\N	90240105	Mbulamayi	\N	5	143007
149516	\N	\N	\N	\N	90240106	Nkobe	\N	5	143007
149517	\N	\N	\N	\N	90240107	Lukoto	\N	5	143007
149518	\N	\N	\N	\N	90240108	Nkolongo	\N	5	143007
149519	\N	\N	\N	\N	90240109	Tshimbumba	\N	5	143007
149520	\N	\N	\N	\N	90240110	Tshinsense	\N	5	143007
149521	\N	\N	\N	\N	90240201	Bakwa Longo	\N	5	143008
149522	\N	\N	\N	\N	90240202	Bakwa lusabi	\N	5	143008
149523	\N	\N	\N	\N	90240203	Bakwa Mbalayi (Kasasa)	\N	5	143008
149524	\N	\N	\N	\N	90240204	Bansangana (Mukombela)	\N	5	143008
149525	\N	\N	\N	\N	90240205	Bena Mbala	\N	5	143008
149526	\N	\N	\N	\N	90240301	Bakwa Mbuyi	\N	5	143009
149527	\N	\N	\N	\N	90240302	Bakwa Muanza	\N	5	143009
149528	\N	\N	\N	\N	90240303	Bakwa Ntamba	\N	5	143009
149529	\N	\N	\N	\N	90240304	Bena Djulu	\N	5	143009
149530	\N	\N	\N	\N	90240305	Bena Milombe	\N	5	143009
149531	\N	\N	\N	\N	90240306	Bena Mukamba	\N	5	143009
149532	\N	\N	\N	\N	90240307	Bena Tshijiba	\N	5	143009
149533	\N	\N	\N	\N	90240308	Diangani	\N	5	143009
149534	\N	\N	\N	\N	90240309	Nganga Muela	\N	5	143009
149535	\N	\N	\N	\N	90240310	Tshimanga	\N	5	143009
149536	\N	\N	\N	\N	90240311	Mabenga	\N	5	143009
149537	\N	\N	\N	\N	90240401	Kabasele Tsh.	\N	5	143010
149538	\N	\N	\N	\N	90240402	Lomba Bua Beya	\N	5	143010
149539	\N	\N	\N	\N	90240403	Nduaya Mbumba	\N	5	143010
149540	\N	\N	\N	\N	90240404	Tshidia Mbowa	\N	5	143010
149541	\N	\N	\N	\N	90240405	Kansele	\N	5	143010
149542	\N	\N	\N	\N	90240501	Bakwa Kunda	\N	5	143011
149543	\N	\N	\N	\N	90240502	Baka Lusabi	\N	5	143011
149544	\N	\N	\N	\N	90240503	Bena Kamwanga	\N	5	143011
149545	\N	\N	\N	\N	90240504	Bena Mpeta	\N	5	143011
149546	\N	\N	\N	\N	90240505	Bena Tshikulu	\N	5	143011
149547	\N	\N	\N	\N	90240601	Bakwa Mpia	\N	5	143012
149548	\N	\N	\N	\N	90240602	Bambu	\N	5	143012
149549	\N	\N	\N	\N	90240603	Bashila Mpampi	\N	5	143012
149550	\N	\N	\N	\N	90240604	Batetela	\N	5	143012
149551	\N	\N	\N	\N	90240605	Bena Kabasele	\N	5	143012
149552	\N	\N	\N	\N	90240606	Bena Kayembe	\N	5	143012
149553	\N	\N	\N	\N	90240607	Bena Konji	\N	5	143012
149554	\N	\N	\N	\N	90240608	Bena Nsapo	\N	5	143012
149555	\N	\N	\N	\N	90240609	Bena Tshipamba	\N	5	143012
149556	\N	\N	\N	\N	90240610	Bakwa Lule	\N	5	143012
149557	\N	\N	\N	\N	90240611	Bakwa Mbayi	\N	5	143012
149558	\N	\N	\N	\N	90240612	Bakwa Mwashi	\N	5	143012
149559	\N	\N	\N	\N	90240613	Bakwa Tshishimbula	\N	5	143012
149560	\N	\N	\N	\N	90240614	Tshikua Mukalenge	\N	5	143012
149561	\N	\N	\N	\N	90240701	Bakwa Kadiebwe	\N	5	143013
149562	\N	\N	\N	\N	90240702	Bakwa Tshidila	\N	5	143013
149563	\N	\N	\N	\N	90240703	Bakwa Tshitadi	\N	5	143013
149564	\N	\N	\N	\N	90240704	Bakwa Mpika	\N	5	143013
149565	\N	\N	\N	\N	90240705	Bakwa Mulamba	\N	5	143013
149566	\N	\N	\N	\N	90240706	Bakwa Kabunda	\N	5	143013
149567	\N	\N	\N	\N	90240707	Nkanga	\N	5	143013
149568	\N	\N	\N	\N	90250101	Bakwa Lukusa	\N	5	143015
149569	\N	\N	\N	\N	90250102	Bakwa Mayi 1	\N	5	143015
149570	\N	\N	\N	\N	90250103	Bakwa Mayi 2	\N	5	143015
149571	\N	\N	\N	\N	90250104	Bakwa Mukala	\N	5	143015
149572	\N	\N	\N	\N	90250105	Bakwa Tshibasu	\N	5	143015
149573	\N	\N	\N	\N	90250106	Bakwa Tshilamba	\N	5	143015
149574	\N	\N	\N	\N	90250107	Bakwa Tshilumba	\N	5	143015
149575	\N	\N	\N	\N	90250108	Bashila Kasanga	\N	5	143015
149576	\N	\N	\N	\N	90250109	Basonge	\N	5	143015
149577	\N	\N	\N	\N	90250110	Bena Bela	\N	5	143015
149578	\N	\N	\N	\N	90250111	Bena Kamba Kalele	\N	5	143015
149579	\N	\N	\N	\N	90250112	Bena Kapuki	\N	5	143015
149580	\N	\N	\N	\N	90250113	BenaLumonyo	\N	5	143015
149581	\N	\N	\N	\N	90250114	Bena Nkelende	\N	5	143015
149582	\N	\N	\N	\N	90250115	Bena Nkoma	\N	5	143015
149583	\N	\N	\N	\N	90250116	Bena Tshiadi	\N	5	143015
149584	\N	\N	\N	\N	90250117	Bakwa Katulayi	\N	5	143015
149585	\N	\N	\N	\N	90250118	Bakwa Loko 1	\N	5	143015
149586	\N	\N	\N	\N	90250119	Bakwa Loko 2	\N	5	143015
149587	\N	\N	\N	\N	90250120	Bakwa Mfike	\N	5	143015
149588	\N	\N	\N	\N	90250121	Bakwa Mwabayi	\N	5	143015
149589	\N	\N	\N	\N	90250122	Bakwa Ngombe	\N	5	143015
149590	\N	\N	\N	\N	90250123	BakwaNgoyi	\N	5	143015
149591	\N	\N	\N	\N	90250201	Bakwa Balela	\N	5	143016
149592	\N	\N	\N	\N	90250202	Bakwa Mputu	\N	5	143016
149593	\N	\N	\N	\N	90250203	Bakwa Tshikandu	\N	5	143016
149594	\N	\N	\N	\N	90250204	Bakwa Tshisumba	\N	5	143016
149595	\N	\N	\N	\N	90250301	Bakwa Kamuna 1	\N	5	143017
149596	\N	\N	\N	\N	90250302	Bakwa Kamuna 2	\N	5	143017
149597	\N	\N	\N	\N	90250303	Bakwa Kanyinda 1	\N	5	143017
149598	\N	\N	\N	\N	90250304	Bakwa Kanyinda 2	\N	5	143017
149599	\N	\N	\N	\N	90250305	Bakwa Kanyinda 3	\N	5	143017
149600	\N	\N	\N	\N	90250306	Bakwa Ndaye	\N	5	143017
149601	\N	\N	\N	\N	90250307	Bena Mpungu	\N	5	143017
149602	\N	\N	\N	\N	90250401	Bakwa Indu	\N	5	143018
149603	\N	\N	\N	\N	90250402	Bakwa Nganza	\N	5	143018
149604	\N	\N	\N	\N	90250403	Bakwa Ngula	\N	5	143018
149605	\N	\N	\N	\N	90250404	Basonge	\N	5	143018
149606	\N	\N	\N	\N	90250405	Bena Kalombo	\N	5	143018
149607	\N	\N	\N	\N	90250406	Bena Musenga	\N	5	143018
149608	\N	\N	\N	\N	90250501	Bena Meta	\N	5	143019
149609	\N	\N	\N	\N	90250502	Bakwa Ndumbi	\N	5	143019
149610	\N	\N	\N	\N	90250503	Bakwa Nsangua	\N	5	143019
149611	\N	\N	\N	\N	90250504	Bakwa Nselenge	\N	5	143019
149612	\N	\N	\N	\N	90250505	Bakwa Nshiba	\N	5	143019
149613	\N	\N	\N	\N	90250506	bena Bele	\N	5	143019
149614	\N	\N	\N	\N	90250507	Bena Kabuenge	\N	5	143019
149615	\N	\N	\N	\N	90250508	Bena Kapele Ntumba	\N	5	143019
149616	\N	\N	\N	\N	90250509	Bena Mbiye	\N	5	143019
149617	\N	\N	\N	\N	90250510	Bena Mbule	\N	5	143019
149618	\N	\N	\N	\N	90250511	Bena Miango	\N	5	143019
149619	\N	\N	\N	\N	90250512	Bena Mingu	\N	5	143019
149620	\N	\N	\N	\N	90250513	Bena Mpemba	\N	5	143019
149621	\N	\N	\N	\N	90250514	Bena Mpolo	\N	5	143019
149622	\N	\N	\N	\N	90250515	Bena Nkana	\N	5	143019
149623	\N	\N	\N	\N	90250516	Bena Nsamba	\N	5	143019
149624	\N	\N	\N	\N	90250517	Bena Tshiadi	\N	5	143019
149625	\N	\N	\N	\N	90250518	Bena Tshibamba	\N	5	143019
149626	\N	\N	\N	\N	90250519	Bakwa Bashi	\N	5	143019
149627	\N	\N	\N	\N	90250520	Bakwa Bashi	\N	5	143019
149628	\N	\N	\N	\N	90250521	Bakwa Muandu	\N	5	143019
149629	\N	\N	\N	\N	90250522	Bakwa Ngashi	\N	5	143019
149630	\N	\N	\N	\N	90250523	Bakwa Tshipanda	\N	5	143019
149631	\N	\N	\N	\N	90310101	Bakwa katana	\N	5	143021
149632	\N	\N	\N	\N	90310102	Bakwa Mukuna	\N	5	143021
149633	\N	\N	\N	\N	90310103	Bakwa Ndaye	\N	5	143021
149634	\N	\N	\N	\N	90310104	Bakwa Tshidimu	\N	5	143021
149635	\N	\N	\N	\N	90310105	Bakwa Tshitshimbule	\N	5	143021
149636	\N	\N	\N	\N	90310106	Bena Kasako 1	\N	5	143021
149637	\N	\N	\N	\N	90310107	Bena kasoko 2	\N	5	143021
149638	\N	\N	\N	\N	90310108	Bena Lombe	\N	5	143021
149639	\N	\N	\N	\N	90310109	Bena Mande	\N	5	143021
149640	\N	\N	\N	\N	90310110	Bena Musenga (Musenge)	\N	5	143021
149641	\N	\N	\N	\N	90310111	Bena Nsanda	\N	5	143021
149642	\N	\N	\N	\N	90310112	Bena Tshitoka	\N	5	143021
149643	\N	\N	\N	\N	90310201	Bakete	\N	5	143022
149644	\N	\N	\N	\N	90310202	Bakwa Mfunyi	\N	5	143022
149645	\N	\N	\N	\N	90310203	Bakwa Nsumpi	\N	5	143022
149646	\N	\N	\N	\N	90310204	Bakwanga	\N	5	143022
149647	\N	\N	\N	\N	90310205	Bashi Bienga	\N	5	143022
149648	\N	\N	\N	\N	90310206	Bena Konji	\N	5	143022
149649	\N	\N	\N	\N	90310207	Bena Nshimba	\N	5	143022
149650	\N	\N	\N	\N	90310208	Kalonji Kampuka	\N	5	143022
149651	\N	\N	\N	\N	90310209	Kalonji Katshimanga	\N	5	143022
149652	\N	\N	\N	\N	90310301	Bakwa	\N	5	143023
149653	\N	\N	\N	\N	90310302	Bakwa Dishi	\N	5	143023
149654	\N	\N	\N	\N	90310303	Bakwa Manyanga	\N	5	143023
149655	\N	\N	\N	\N	90310304	Bakwa Mbombo	\N	5	143023
149656	\N	\N	\N	\N	90310305	Bakwa Ndoba	\N	5	143023
149657	\N	\N	\N	\N	90310306	Bakwa Ntombolo	\N	5	143023
149658	\N	\N	\N	\N	90310307	Bashila Kapumbu	\N	5	143023
149659	\N	\N	\N	\N	90310308	Bena Kinyembue	\N	5	143023
149660	\N	\N	\N	\N	90310309	Bena Luamba(Lumba)	\N	5	143023
149661	\N	\N	\N	\N	90310310	Bena Muanyika	\N	5	143023
149662	\N	\N	\N	\N	90310401	Bakwa Kaswa	\N	5	143024
149663	\N	\N	\N	\N	90310402	Bakwa Meta	\N	5	143024
149664	\N	\N	\N	\N	90310403	Bakwa Muamba	\N	5	143024
149665	\N	\N	\N	\N	90310404	Bashila Kapumbu 1	\N	5	143024
149666	\N	\N	\N	\N	90310405	Bashila Kapumbu 2	\N	5	143024
149667	\N	\N	\N	\N	90310406	Batetela Kashiya	\N	5	143024
149668	\N	\N	\N	\N	90310407	Bena Tsiadi	\N	5	143024
149669	\N	\N	\N	\N	90310408	Bena Tshibashi	\N	5	143024
149670	\N	\N	\N	\N	90315101	Bisanga	\N	5	143025
149671	\N	\N	\N	\N	90315102	E.P.ZA.	\N	5	143025
149672	\N	\N	\N	\N	90320101	Kamba Kapele	\N	5	143026
149673	\N	\N	\N	\N	90320102	Kamba Nsapo	\N	5	143026
149674	\N	\N	\N	\N	90320103	Kamba Shatshionga	\N	5	143026
149675	\N	\N	\N	\N	90320104	Kamba Sola	\N	5	143026
149676	\N	\N	\N	\N	90320105	Kamba Tshime	\N	5	143026
149677	\N	\N	\N	\N	90320106	Kamba Muatshikumba	\N	5	143026
149678	\N	\N	\N	\N	90320107	Kamba Tshisanda	\N	5	143026
149679	\N	\N	\N	\N	90320108	Kamba Kotshi	\N	5	143026
149680	\N	\N	\N	\N	90320109	Luena Kayihase	\N	5	143026
149681	\N	\N	\N	\N	90320110	Mbumba Ntumba	\N	5	143026
149682	\N	\N	\N	\N	90320111	Shamutoma	\N	5	143026
149683	\N	\N	\N	\N	90320112	Mwasamba	\N	5	143026
149684	\N	\N	\N	\N	90320113	Muyombo	\N	5	143026
149685	\N	\N	\N	\N	90320114	Shamungamba	\N	5	143026
149686	\N	\N	\N	\N	90320201	Ba Songo	\N	5	143027
149687	\N	\N	\N	\N	90320202	Buatakapala (Kamba Kapele)	\N	5	143027
149688	\N	\N	\N	\N	90320203	Kamba Lemba	\N	5	143027
149689	\N	\N	\N	\N	90320204	Luatshiandeku	\N	5	143027
149690	\N	\N	\N	\N	90320205	Lunda Bungulu	\N	5	143027
149691	\N	\N	\N	\N	90320206	Lunda Kumbana	\N	5	143027
149692	\N	\N	\N	\N	90320207	Lunda Lukokesha	\N	5	143027
149693	\N	\N	\N	\N	90320208	Lunda Luweja	\N	5	143027
149694	\N	\N	\N	\N	90320209	Lunda Tujiji	\N	5	143027
149695	\N	\N	\N	\N	90320301	Ba Kunda Muk.	\N	5	143028
149696	\N	\N	\N	\N	90320302	Ba Kilundu	\N	5	143028
149697	\N	\N	\N	\N	90320303	Ba Kisamba	\N	5	143028
149698	\N	\N	\N	\N	90320304	Ba Lemba	\N	5	143028
149699	\N	\N	\N	\N	90320305	Ba Lukianda	\N	5	143028
149700	\N	\N	\N	\N	90320306	Ba Muangalala	\N	5	143028
149701	\N	\N	\N	\N	90320307	Ba Muta	\N	5	143028
149702	\N	\N	\N	\N	90320308	Ba Ngombe	\N	5	143028
149703	\N	\N	\N	\N	90320309	Ba Ngondji	\N	5	143028
149704	\N	\N	\N	\N	90320310	Ba Njila	\N	5	143028
149705	\N	\N	\N	\N	90320311	Ba Nyama	\N	5	143028
149706	\N	\N	\N	\N	90320312	Ba Nzumba	\N	5	143028
149707	\N	\N	\N	\N	90320313	Ba Samba	\N	5	143028
149708	\N	\N	\N	\N	90320314	Ba Tule	\N	5	143028
149709	\N	\N	\N	\N	90320315	Ba Tunda	\N	5	143028
149710	\N	\N	\N	\N	90320316	Bena Kitombe	\N	5	143028
149711	\N	\N	\N	\N	90320317	Katshiaba	\N	5	143028
149712	\N	\N	\N	\N	90320318	Bena kombo	\N	5	143028
149713	\N	\N	\N	\N	90320319	Ingungu-a -Kasha	\N	5	143028
149714	\N	\N	\N	\N	90320320	Kabulungu	\N	5	143028
149715	\N	\N	\N	\N	90320321	Bakwa Luwamba	\N	5	143028
149716	\N	\N	\N	\N	90320322	Bena Lenda	\N	5	143028
149717	\N	\N	\N	\N	90320323	Bena kisenzele	\N	5	143028
149718	\N	\N	\N	\N	90320324	Bakwa Ngoyi	\N	5	143028
149719	\N	\N	\N	\N	90320401	Bakwa Mfunyi	\N	5	143029
149720	\N	\N	\N	\N	90320402	Bakwa Ndaye	\N	5	143029
149721	\N	\N	\N	\N	90320403	Bakwa Nkoyi	\N	5	143029
149722	\N	\N	\N	\N	90320404	Bena Tshipamba	\N	5	143029
149723	\N	\N	\N	\N	90320405	Bena Mukuna	\N	5	143029
149724	\N	\N	\N	\N	90320501	Bajila Kasanga	\N	5	143030
149725	\N	\N	\N	\N	90320502	Bakwa Mukuna	\N	5	143030
149726	\N	\N	\N	\N	90320503	Bakwa Tshikoro	\N	5	143030
149727	\N	\N	\N	\N	90320504	Bena Kalombo	\N	5	143030
149728	\N	\N	\N	\N	90320505	Bena Kasuba	\N	5	143030
149729	\N	\N	\N	\N	90320506	Bena Lunda	\N	5	143030
149730	\N	\N	\N	\N	90320507	Bena Mayi	\N	5	143030
149731	\N	\N	\N	\N	90320508	Bena Nkoyi	\N	5	143030
149732	\N	\N	\N	\N	90320509	Kankonde Ketshi	\N	5	143030
149733	\N	\N	\N	\N	90320601	Bakwa Bowa	\N	5	143031
149734	\N	\N	\N	\N	90320602	Bakwa Lukudi	\N	5	143031
149735	\N	\N	\N	\N	90320603	Bakwa Muya 1	\N	5	143031
149736	\N	\N	\N	\N	90320604	Bakwa Muya 2	\N	5	143031
149737	\N	\N	\N	\N	90320605	Bakwa Nkala	\N	5	143031
149738	\N	\N	\N	\N	90320606	Bakwanga	\N	5	143031
149739	\N	\N	\N	\N	90320607	Bena Kalenga	\N	5	143031
149740	\N	\N	\N	\N	90320608	Bena Mbiye	\N	5	143031
149741	\N	\N	\N	\N	90320609	Bena Kalume	\N	5	143031
149742	\N	\N	\N	\N	90320610	Bena Kaluwa	\N	5	143031
149743	\N	\N	\N	\N	90320611	Bena Mboyi	\N	5	143031
149744	\N	\N	\N	\N	90320612	Bena kazadi	\N	5	143031
149745	\N	\N	\N	\N	90320613	Bashila Mpampi	\N	5	143031
149746	\N	\N	\N	\N	90320701	Bakwa Mulume	\N	5	143032
149747	\N	\N	\N	\N	90320702	Bakwa Tshikoba	\N	5	143032
149748	\N	\N	\N	\N	90320703	Bakwa Tshilambo	\N	5	143032
149749	\N	\N	\N	\N	90320704	Ba Katawa	\N	5	143032
149750	\N	\N	\N	\N	90320705	Bakwa Muadi	\N	5	143032
149751	\N	\N	\N	\N	90320706	Bakwa Mulumba Katua	\N	5	143032
149752	\N	\N	\N	\N	90320707	Bena Mulabi	\N	5	143032
149753	\N	\N	\N	\N	90320801	Bakw Mfunya	\N	5	143033
149754	\N	\N	\N	\N	90320802	Bakwa Nsongo 1	\N	5	143033
149755	\N	\N	\N	\N	90320803	Bakwa Nsongo 2	\N	5	143033
149756	\N	\N	\N	\N	90320804	Kamba Ngoyi	\N	5	143033
149757	\N	\N	\N	\N	90320805	Kamba Nkulu	\N	5	143033
149758	\N	\N	\N	\N	90320806	Kamba Tshiako	\N	5	143033
149759	\N	\N	\N	\N	90320807	Kamba Tshintu	\N	5	143033
149760	\N	\N	\N	\N	90320808	Kamba Tshisanda	\N	5	143033
149761	\N	\N	\N	\N	90320809	Kamba Wono	\N	5	143033
149762	\N	\N	\N	\N	90320810	Mua Tshisanga	\N	5	143033
149763	\N	\N	\N	\N	90320811	Bakwa Shamupelete	\N	5	143033
149764	\N	\N	\N	\N	90320812	Bakwa Mukaniya	\N	5	143033
149765	\N	\N	\N	\N	90320813	Bakwa Muyombo	\N	5	143033
149766	\N	\N	\N	\N	90320814	Bakwa Mputu	\N	5	143033
149767	\N	\N	\N	\N	90320815	Bakwa Tshiyota	\N	5	143033
149768	\N	\N	\N	\N	90320901	Badinga	\N	5	143034
149769	\N	\N	\N	\N	90320902	Bena Kambulu	\N	5	143034
149770	\N	\N	\N	\N	90320903	Bena Ndambu	\N	5	143034
149771	\N	\N	\N	\N	90330101	Banfunyi	\N	5	143035
149772	\N	\N	\N	\N	90330102	Bandjembe	\N	5	143035
149773	\N	\N	\N	\N	90330103	Batshioko	\N	5	143035
149774	\N	\N	\N	\N	90330104	Bena Konji	\N	5	143035
149775	\N	\N	\N	\N	90330105	Kateya	\N	5	143035
149776	\N	\N	\N	\N	90330106	Nyate Nandjumba	\N	5	143035
149777	\N	\N	\N	\N	90330201	Badinga	\N	5	143036
149778	\N	\N	\N	\N	90330202	Bakumi	\N	5	143036
149779	\N	\N	\N	\N	90330203	Batshioko	\N	5	143036
149780	\N	\N	\N	\N	90330301	Bakwa Luntu	\N	5	143037
149781	\N	\N	\N	\N	90330302	Kambolo	\N	5	143037
149782	\N	\N	\N	\N	90330303	Kasambi	\N	5	143037
149783	\N	\N	\N	\N	90330304	Kazaba	\N	5	143037
149784	\N	\N	\N	\N	90330305	Lunda	\N	5	143037
149785	\N	\N	\N	\N	90330306	Masaki	\N	5	143037
149786	\N	\N	\N	\N	90330307	Muakongolo	\N	5	143037
149787	\N	\N	\N	\N	90330308	Ndomandjare	\N	5	143037
149788	\N	\N	\N	\N	90330309	Nyamandele	\N	5	143037
149789	\N	\N	\N	\N	90330310	Nyate	\N	5	143037
149790	\N	\N	\N	\N	90330311	Perominenge	\N	5	143037
149791	\N	\N	\N	\N	90330312	Songo	\N	5	143037
149792	\N	\N	\N	\N	90330313	Tundu Matamasi	\N	5	143037
149793	\N	\N	\N	\N	90330314	Tundu Ngembo	\N	5	143037
149794	\N	\N	\N	\N	90330401	Bakela	\N	5	143038
149795	\N	\N	\N	\N	90330402	Bakwa Dishi	\N	5	143038
149796	\N	\N	\N	\N	90330403	Bakwa Luntu	\N	5	143038
149797	\N	\N	\N	\N	90330404	Bakwanga	\N	5	143038
149798	\N	\N	\N	\N	90330405	Bashi Bambange (Kapata)	\N	5	143038
149799	\N	\N	\N	\N	90330406	Bashi Ilebo	\N	5	143038
149800	\N	\N	\N	\N	90330407	Bena Bilenga	\N	5	143038
149801	\N	\N	\N	\N	90330408	Bena Mulombo	\N	5	143038
149802	\N	\N	\N	\N	90330409	Bena Mulumba	\N	5	143038
149803	\N	\N	\N	\N	90335101	Chemin de Fer	\N	5	143039
149804	\N	\N	\N	\N	90335102	Commecial	\N	5	143039
149805	\N	\N	\N	\N	90335103	Kasa-vubu	\N	5	143039
149806	\N	\N	\N	\N	90335104	Kimbanguiste	\N	5	143039
149807	\N	\N	\N	\N	90335105	Kinkole	\N	5	143039
149808	\N	\N	\N	\N	90335106	Lumumba	\N	5	143039
149809	\N	\N	\N	\N	90335107	Wenze	\N	5	143039
149810	\N	\N	\N	\N	90335108	Congo (ZaÃ¯re)	\N	5	143039
149811	\N	\N	\N	\N	90340101	Bakele	\N	5	143040
149812	\N	\N	\N	\N	90340102	Bakete Tshofua	\N	5	143040
149813	\N	\N	\N	\N	90340103	Bambalayi	\N	5	143040
149814	\N	\N	\N	\N	90340104	Bangombe	\N	5	143040
149815	\N	\N	\N	\N	90340105	Bangongo Matuma	\N	5	143040
149816	\N	\N	\N	\N	90340106	Bangongo Mitsumb	\N	5	143040
149817	\N	\N	\N	\N	90340107	Bansueba	\N	5	143040
149818	\N	\N	\N	\N	90340108	Bashobua	\N	5	143040
149819	\N	\N	\N	\N	90340109	Batanda	\N	5	143040
149820	\N	\N	\N	\N	90340110	Batuakadimba	\N	5	143040
149821	\N	\N	\N	\N	90340111	Bulangu	\N	5	143040
149822	\N	\N	\N	\N	90340112	Bulembo	\N	5	143040
149823	\N	\N	\N	\N	90340113	Bushanga	\N	5	143040
149824	\N	\N	\N	\N	90340114	Bushanga Bushongo	\N	5	143040
149825	\N	\N	\N	\N	90340115	Kalambamba	\N	5	143040
149826	\N	\N	\N	\N	90340116	Kasuambambi	\N	5	143040
149827	\N	\N	\N	\N	90340117	Kasuambengi	\N	5	143040
149828	\N	\N	\N	\N	90340118	Lonalakadinga	\N	5	143040
149829	\N	\N	\N	\N	90340119	Maluku	\N	5	143040
149830	\N	\N	\N	\N	90340120	Mombo Lona	\N	5	143040
149831	\N	\N	\N	\N	90340121	Mpanga Mbanthi	\N	5	143040
149832	\N	\N	\N	\N	90340122	Mpiana Matadi	\N	5	143040
149833	\N	\N	\N	\N	90340123	Piana Makeshi	\N	5	143040
149834	\N	\N	\N	\N	90340124	Popoloma Lombelo	\N	5	143040
149835	\N	\N	\N	\N	90340125	Popoloma Luembe	\N	5	143040
149836	\N	\N	\N	\N	90340126	Popoloma Lukadi	\N	5	143040
149837	\N	\N	\N	\N	90340127	Popoloma Sud	\N	5	143040
149838	\N	\N	\N	\N	90340128	Tshiabushobe	\N	5	143040
149839	\N	\N	\N	\N	90345101	Lukaka	\N	5	143041
149840	\N	\N	\N	\N	90345102	Lumumba	\N	5	143041
149841	\N	\N	\N	\N	90345103	Vile	\N	5	143041
149842	\N	\N	\N	\N	90350101	Idiki	\N	5	143042
149843	\N	\N	\N	\N	90350102	Impenga	\N	5	143042
149844	\N	\N	\N	\N	90350103	Sankuru	\N	5	143042
149845	\N	\N	\N	\N	90350104	Yaelima	\N	5	143042
149846	\N	\N	\N	\N	90350201	Batshike	\N	5	143043
149847	\N	\N	\N	\N	90350202	Ikolombe	\N	5	143043
149848	\N	\N	\N	\N	90350203	Ikongolo	\N	5	143043
149849	\N	\N	\N	\N	90350204	Isolu	\N	5	143043
149850	\N	\N	\N	\N	90350205	Itende	\N	5	143043
149851	\N	\N	\N	\N	90350206	Ndombongo	\N	5	143043
149852	\N	\N	\N	\N	90350207	Nganeolo	\N	5	143043
149853	\N	\N	\N	\N	90350208	Ngele Ndjale	\N	5	143043
149854	\N	\N	\N	\N	90350209	Ngel'Okeni	\N	5	143043
149855	\N	\N	\N	\N	90350210	Wekulu	\N	5	143043
212668	\N	\N	\N	\N	\N	Djalo-Ndjeka	\N	7	141805
212669	\N	\N	\N	\N	\N	Kamana	\N	7	141805
212670	\N	\N	\N	\N	\N	Mongbwalu	\N	7	141800
212671	\N	\N	\N	\N	\N	Ango	\N	7	141800
212672	\N	\N	\N	\N	\N	Ntand Embelo	\N	7	141798
212673	\N	\N	\N	\N	\N	Luozi	\N	7	141797
212674	\N	\N	\N	\N	6005007	Lulingu	\N	7	141803
212675	\N	\N	\N	\N	\N	Gombe-Matadi	\N	7	141797
212676	\N	\N	\N	\N	\N	Bikoro	\N	7	141799
212677	\N	\N	\N	\N	\N	Kanzala	\N	7	141806
212678	\N	\N	\N	\N	\N	Kamonia	\N	7	141806
212679	\N	\N	\N	\N	\N	Rutshuru	\N	7	141801
212680	\N	\N	\N	\N	\N	Boma Mangbetu	\N	7	141800
212681	\N	\N	\N	\N	6001002	Ibanda	\N	7	141803
212682	\N	\N	\N	\N	\N	Mont-ngafula I	\N	7	141796
212683	\N	\N	\N	\N	\N	Lolo (Itimbiri)	\N	7	141799
212684	\N	\N	\N	\N	\N	Kabongo	\N	7	141804
212685	\N	\N	\N	\N	\N	Wikong	\N	7	141805
212686	\N	\N	\N	\N	\N	Doruma	\N	7	141800
212687	\N	\N	\N	\N	\N	Lubudi	\N	7	141804
212688	\N	\N	\N	\N	\N	Sia	\N	7	141798
212689	\N	\N	\N	\N	\N	Poko	\N	7	141800
212690	\N	\N	\N	\N	\N	Lwamba	\N	7	141804
212691	\N	\N	\N	\N	\N	Diulu	\N	7	141805
212692	\N	\N	\N	\N	6004002	Fizi	\N	7	141803
212693	\N	\N	\N	\N	\N	Logo	\N	7	141800
212694	\N	\N	\N	\N	\N	Bena-Dibele	\N	7	141805
212695	\N	\N	\N	\N	6003004	Miti - Murhesa	\N	7	141803
212696	\N	\N	\N	\N	\N	Kimbau	\N	7	141798
212697	\N	\N	\N	\N	\N	Yalimbongo	\N	7	141800
212698	\N	\N	\N	\N	\N	Dibaya	\N	7	141806
212699	\N	\N	\N	\N	\N	Vanga	\N	7	141798
212700	\N	\N	\N	\N	\N	Bulape	\N	7	141806
212701	\N	\N	\N	\N	\N	Kalamu I	\N	7	141796
212702	\N	\N	\N	\N	\N	Kasa-Vubu	\N	7	141796
212703	\N	\N	\N	\N	\N	Oicha	\N	7	141801
212704	\N	\N	\N	\N	\N	Dibindi	\N	7	141805
212705	\N	\N	\N	\N	\N	Salamabila	\N	7	141802
212706	\N	\N	\N	\N	\N	Biringi	\N	7	141800
212707	\N	\N	\N	\N	\N	Makiso	\N	7	141800
212708	\N	\N	\N	\N	\N	Kole 	\N	7	141805
212709	\N	\N	\N	\N	\N	Gemena	\N	7	141799
212710	\N	\N	\N	\N	\N	Businga	\N	7	141799
212711	\N	\N	\N	\N	\N	Walikale	\N	7	141801
212712	\N	\N	\N	\N	\N	Kanzenze	\N	7	141804
212713	\N	\N	\N	\N	\N	Yumbi	\N	7	141798
212714	\N	\N	\N	\N	\N	Makala	\N	7	141796
212715	\N	\N	\N	\N	\N	Ngiri-ngiri	\N	7	141796
212716	\N	\N	\N	\N	\N	Binza-ozone	\N	7	141796
212717	\N	\N	\N	\N	\N	Viadana	\N	7	141800
212718	\N	\N	\N	\N	\N	Kimpangu	\N	7	141797
212719	\N	\N	\N	\N	\N	Mahagi	\N	7	141800
212720	\N	\N	\N	\N	\N	Lusanga	\N	7	141798
212721	\N	\N	\N	\N	\N	Mangurejipa	\N	7	141801
212722	\N	\N	\N	\N	\N	Kirotshe	\N	7	141801
212723	\N	\N	\N	\N	\N	Dilala	\N	7	141804
212724	\N	\N	\N	\N	\N	Inongo	\N	7	141798
212725	\N	\N	\N	\N	\N	Vangu	\N	7	141804
212726	\N	\N	\N	\N	\N	Police 	\N	7	141796
212727	\N	\N	\N	\N	\N	Ilebo	\N	7	141806
212728	\N	\N	\N	\N	\N	Adi	\N	7	141800
212729	\N	\N	\N	\N	6003002	Idjwi	\N	7	141803
212730	\N	\N	\N	\N	\N	Buta	\N	7	141800
212731	\N	\N	\N	\N	\N	Mangala	\N	7	141800
212732	\N	\N	\N	\N	\N	Kintambo	\N	7	141796
212733	\N	\N	\N	\N	\N	Tshudi-Loto	\N	7	141805
212734	\N	\N	\N	\N	\N	Kalomba	\N	7	141806
212735	\N	\N	\N	\N	\N	Kabeya-Kamuanga	\N	7	141805
212736	\N	\N	\N	\N	\N	Mulongo	\N	7	141804
212737	\N	\N	\N	\N	\N	Panda	\N	7	141804
212738	\N	\N	\N	\N	6004008	Uvira	\N	7	141803
212739	\N	\N	\N	\N	\N	Yamaluka(Molua)	\N	7	141799
212740	\N	\N	\N	\N	\N	Kampemba 	\N	7	141804
212741	\N	\N	\N	\N	\N	Lukula	\N	7	141797
212742	\N	\N	\N	\N	\N	Bilomba	\N	7	141806
212743	\N	\N	\N	\N	\N	Luiza	\N	7	141806
212744	\N	\N	\N	\N	\N	Kasongo	\N	7	141802
212745	\N	\N	\N	\N	\N	Sandoa	\N	7	141804
212746	\N	\N	\N	\N	\N	Kinkondja	\N	7	141804
212747	\N	\N	\N	\N	\N	Bipemba	\N	7	141805
212748	\N	\N	\N	\N	\N	Pinga	\N	7	141801
212749	\N	\N	\N	\N	6004006	Lemera	\N	7	141803
212750	\N	\N	\N	\N	\N	Karawa	\N	7	141799
212751	\N	\N	\N	\N	\N	Kalemie	\N	7	141804
212752	\N	\N	\N	\N	\N	Kayna	\N	7	141801
212753	\N	\N	\N	\N	\N	Yaleko	\N	7	141800
212754	\N	\N	\N	\N	\N	Kenya 	\N	7	141804
212755	\N	\N	\N	\N	\N	Kiri	\N	7	141798
212756	\N	\N	\N	\N	\N	Lingwala	\N	7	141796
212757	\N	\N	\N	\N	\N	Kisenso	\N	7	141796
212758	\N	\N	\N	\N	\N	Luambo	\N	7	141806
212759	\N	\N	\N	\N	\N	Kasenga	\N	7	141804
212760	\N	\N	\N	\N	\N	Alunguli	\N	7	141802
212761	\N	\N	\N	\N	\N	Ndekesha	\N	7	141806
212762	\N	\N	\N	\N	\N	Ariwara	\N	7	141800
212763	\N	\N	\N	\N	\N	Karisimbi	\N	7	141801
212764	\N	\N	\N	\N	\N	Bolomba	\N	7	141799
212765	\N	\N	\N	\N	6004001	Minembwe	\N	7	141803
212766	\N	\N	\N	\N	\N	Ipamu	\N	7	141798
212767	\N	\N	\N	\N	\N	Bwamanda	\N	7	141799
212768	\N	\N	\N	\N	\N	Sakania	\N	7	141804
212769	\N	\N	\N	\N	\N	Bili	\N	7	141799
212770	\N	\N	\N	\N	\N	Boga	\N	7	141800
212771	\N	\N	\N	\N	\N	Lubondayi	\N	7	141806
212772	\N	\N	\N	\N	\N	Wamba luadi	\N	7	141798
212773	\N	\N	\N	\N	\N	Gungu	\N	7	141798
212774	\N	\N	\N	\N	\N	Mikalayi	\N	7	141806
212775	\N	\N	\N	\N	6003001	Bunyakiri	\N	7	141803
212776	\N	\N	\N	\N	\N	Kingabwa	\N	7	141796
212777	\N	\N	\N	\N	\N	Kananga	\N	7	141806
212778	\N	\N	\N	\N	\N	Kisandji	\N	7	141798
212779	\N	\N	\N	\N	6005004	Mwana	\N	7	141803
212780	\N	\N	\N	\N	\N	Abuzi	\N	7	141799
212781	\N	\N	\N	\N	\N	Kabondo-dianda	\N	7	141804
212782	\N	\N	\N	\N	\N	Dilolo	\N	7	141804
212783	\N	\N	\N	\N	\N	Gombari	\N	7	141800
212784	\N	\N	\N	\N	\N	Wasolo	\N	7	141799
212785	\N	\N	\N	\N	\N	Moanza	\N	7	141798
212786	\N	\N	\N	\N	\N	Damas	\N	7	141800
212787	\N	\N	\N	\N	\N	Nyankunde	\N	7	141800
212788	\N	\N	\N	\N	\N	Minga	\N	7	141805
212789	\N	\N	\N	\N	\N	Kimbanseke	\N	7	141796
212790	\N	\N	\N	\N	\N	Kansele	\N	7	141805
212791	\N	\N	\N	\N	\N	Basankusu 	\N	7	141799
212792	\N	\N	\N	\N	\N	Kikwit-sud	\N	7	141798
212793	\N	\N	\N	\N	\N	Djombo	\N	7	141799
212794	\N	\N	\N	\N	\N	Angumu	\N	7	141800
212795	\N	\N	\N	\N	\N	Bili	\N	7	141800
212796	\N	\N	\N	\N	\N	Miabi	\N	7	141805
212797	\N	\N	\N	\N	\N	Aru	\N	7	141800
212798	\N	\N	\N	\N	\N	Basali	\N	7	141800
212799	\N	\N	\N	\N	\N	Kitenda	\N	7	141798
212800	\N	\N	\N	\N	\N	Mushenge	\N	7	141806
212801	\N	\N	\N	\N	\N	Kipushi	\N	7	141804
212802	\N	\N	\N	\N	\N	Pendjua	\N	7	141798
212803	\N	\N	\N	\N	\N	Kajiji	\N	7	141798
212804	\N	\N	\N	\N	\N	Maluku I	\N	7	141796
212805	\N	\N	\N	\N	\N	Kimputu	\N	7	141798
212806	\N	\N	\N	\N	\N	Boto	\N	7	141799
212807	\N	\N	\N	\N	\N	Songa	\N	7	141804
212808	\N	\N	\N	\N	\N	Bolenge	\N	7	141799
212809	\N	\N	\N	\N	\N	Mawiya	\N	7	141799
212810	\N	\N	\N	\N	\N	Bosomanzi	\N	7	141799
212811	\N	\N	\N	\N	\N	Mukumbi	\N	7	141805
212812	\N	\N	\N	\N	\N	Kikongo	\N	7	141798
212813	\N	\N	\N	\N	\N	Kakenge	\N	7	141806
212814	\N	\N	\N	\N	6005006	Kalole	\N	7	141803
212815	\N	\N	\N	\N	\N	Sona-Bata	\N	7	141797
212816	\N	\N	\N	\N	\N	Yahuma	\N	7	141800
212817	\N	\N	\N	\N	\N	Butembo	\N	7	141801
212818	\N	\N	\N	\N	\N	Malemba-Nkulu 	\N	7	141804
212819	\N	\N	\N	\N	\N	Kitenge	\N	7	141804
212820	\N	\N	\N	\N	6001001	Bagira-Kasha 	\N	7	141803
212821	\N	\N	\N	\N	\N	Mambasa	\N	7	141800
212822	\N	\N	\N	\N	6002006	Nyangezi	\N	7	141803
212823	\N	\N	\N	\N	\N	Musienene	\N	7	141801
212824	\N	\N	\N	\N	\N	Ubundu	\N	7	141800
212825	\N	\N	\N	\N	\N	Tshibala	\N	7	141806
212826	\N	\N	\N	\N	\N	Kingandu	\N	7	141798
212827	\N	\N	\N	\N	\N	Lita	\N	7	141800
212828	\N	\N	\N	\N	\N	Nzaba	\N	7	141805
212829	\N	\N	\N	\N	\N	Wema	\N	7	141799
212830	\N	\N	\N	\N	\N	Butumba	\N	7	141804
212831	\N	\N	\N	\N	\N	Biyela	\N	7	141796
212832	\N	\N	\N	\N	\N	Bambu	\N	7	141800
212833	\N	\N	\N	\N	6001003	Kadutu	\N	7	141803
212834	\N	\N	\N	\N	\N	Monkoto	\N	7	141799
212835	\N	\N	\N	\N	\N	Kimvula	\N	7	141797
212836	\N	\N	\N	\N	\N	Kayamba	\N	7	141804
212837	\N	\N	\N	\N	\N	Punia	\N	7	141802
212838	\N	\N	\N	\N	\N	Tshamilemba	\N	7	141804
212839	\N	\N	\N	\N	\N	Titule	\N	7	141800
212840	\N	\N	\N	\N	\N	Mumbunda	\N	7	141804
212841	\N	\N	\N	\N	\N	Bolobo	\N	7	141798
212842	\N	\N	\N	\N	\N	Banalia	\N	7	141800
212843	\N	\N	\N	\N	\N	Kilwa	\N	7	141804
212844	\N	\N	\N	\N	\N	Popokabaka	\N	7	141798
212845	\N	\N	\N	\N	6004005	Bijombo	\N	7	141803
212846	\N	\N	\N	\N	\N	Banga Lubaka	\N	7	141806
212847	\N	\N	\N	\N	\N	Rungu	\N	7	141800
212848	\N	\N	\N	\N	\N	Matete	\N	7	141796
212849	\N	\N	\N	\N	\N	Ndjoku Punda	\N	7	141806
212850	\N	\N	\N	\N	\N	Faradje	\N	7	141800
212851	\N	\N	\N	\N	\N	Kalima	\N	7	141802
212852	\N	\N	\N	\N	\N	Lusambo	\N	7	141805
212853	\N	\N	\N	\N	\N	Mbulula 	\N	7	141804
212854	\N	\N	\N	\N	\N	Feshi	\N	7	141798
212855	\N	\N	\N	\N	\N	Kamina	\N	7	141804
212856	\N	\N	\N	\N	\N	Kafubu	\N	7	141804
212857	\N	\N	\N	\N	\N	Rwanguba	\N	7	141801
212858	\N	\N	\N	\N	\N	Bosobolo	\N	7	141799
212859	\N	\N	\N	\N	6004007	Ruzizi	\N	7	141803
212860	\N	\N	\N	\N	\N	Mpokolo	\N	7	141805
212861	\N	\N	\N	\N	\N	Pawa	\N	7	141800
212862	\N	\N	\N	\N	\N	Selembao	\N	7	141796
212863	\N	\N	\N	\N	\N	Bosobe	\N	7	141798
212864	\N	\N	\N	\N	\N	Yangala	\N	7	141806
212865	\N	\N	\N	\N	\N	Fataki	\N	7	141800
212866	\N	\N	\N	\N	\N	Yabaondo	\N	7	141800
212867	\N	\N	\N	\N	\N	Monga	\N	7	141800
212868	\N	\N	\N	\N	\N	Aungba	\N	7	141800
212869	\N	\N	\N	\N	\N	Lemba	\N	7	141796
212870	\N	\N	\N	\N	\N	Boma	\N	7	141797
212871	\N	\N	\N	\N	\N	Mutena	\N	7	141806
212872	\N	\N	\N	\N	\N	Matadi	\N	7	141797
212873	\N	\N	\N	\N	\N	Banjow Moke	\N	7	141798
212874	\N	\N	\N	\N	\N	Mompono	\N	7	141799
212875	\N	\N	\N	\N	\N	Mimia	\N	7	141798
212876	\N	\N	\N	\N	\N	Laybo	\N	7	141800
212877	\N	\N	\N	\N	\N	Tshikula	\N	7	141806
212878	\N	\N	\N	\N	\N	Kasaji	\N	7	141804
212879	\N	\N	\N	\N	\N	Kilela Balanda	\N	7	141804
212880	\N	\N	\N	\N	\N	Luebo	\N	7	141806
212881	\N	\N	\N	\N	\N	Kisantu	\N	7	141797
212882	\N	\N	\N	\N	\N	Tchomia	\N	7	141800
212883	\N	\N	\N	\N	\N	Loko	\N	7	141799
212884	\N	\N	\N	\N	\N	Lomela	\N	7	141805
212885	\N	\N	\N	\N	\N	Komanda 	\N	7	141800
212886	\N	\N	\N	\N	\N	Makanza	\N	7	141799
212887	\N	\N	\N	\N	6005008	Mulungu	\N	7	141803
212888	\N	\N	\N	\N	\N	Pay Kongila	\N	7	141798
212889	\N	\N	\N	\N	\N	Lubumbashi 	\N	7	141804
212890	\N	\N	\N	\N	\N	Mutshatsha	\N	7	141804
212891	\N	\N	\N	\N	\N	Katako-Kombe	\N	7	141805
212892	\N	\N	\N	\N	\N	Barumbu	\N	7	141796
212893	\N	\N	\N	\N	\N	Mikope	\N	7	141806
212894	\N	\N	\N	\N	\N	Kwamouth	\N	7	141798
212895	\N	\N	\N	\N	\N	Kinda	\N	7	141804
212896	\N	\N	\N	\N	\N	Bulungu	\N	7	141798
212897	\N	\N	\N	\N	\N	Libenge	\N	7	141799
212898	\N	\N	\N	\N	\N	Cilundu	\N	7	141805
212899	\N	\N	\N	\N	\N	Adja	\N	7	141800
212900	\N	\N	\N	\N	\N	Mwela Lembwa	\N	7	141798
212901	\N	\N	\N	\N	\N	Opala	\N	7	141800
212902	\N	\N	\N	\N	\N	Kalambayi Kabanga	\N	7	141805
212903	\N	\N	\N	\N	\N	Bondo	\N	7	141800
212904	\N	\N	\N	\N	\N	Mwene-Ditu	\N	7	141805
212905	\N	\N	\N	\N	\N	Bokungu	\N	7	141799
212906	\N	\N	\N	\N	\N	Ngidinga	\N	7	141797
212907	\N	\N	\N	\N	6003007	Minova	\N	7	141803
212908	\N	\N	\N	\N	\N	Basoko	\N	7	141800
212909	\N	\N	\N	\N	\N	Bukonde	\N	7	141806
212910	\N	\N	\N	\N	\N	Birambizo	\N	7	141801
212911	\N	\N	\N	\N	\N	Masina II	\N	7	141796
212912	\N	\N	\N	\N	\N	Manika	\N	7	141804
212913	\N	\N	\N	\N	\N	Muanda	\N	7	141797
212914	\N	\N	\N	\N	\N	Isiro	\N	7	141800
212915	\N	\N	\N	\N	\N	Yamongili(Loeka)	\N	7	141799
212916	\N	\N	\N	\N	\N	Katuba	\N	7	141804
212917	\N	\N	\N	\N	\N	Kahemba	\N	7	141798
212918	\N	\N	\N	\N	\N	Bosomodanda	\N	7	141799
212919	\N	\N	\N	\N	6002005	Mubumbano	\N	7	141803
212920	\N	\N	\N	\N	\N	Mungindu	\N	7	141798
212921	\N	\N	\N	\N	\N	Bokoro	\N	7	141798
212922	\N	\N	\N	\N	\N	Watsa	\N	7	141800
212923	\N	\N	\N	\N	\N	Gbadolite	\N	7	141799
212924	\N	\N	\N	\N	\N	Tshikaji	\N	7	141806
212925	\N	\N	\N	\N	\N	Kibombo	\N	7	141802
212926	\N	\N	\N	\N	\N	Bibanga	\N	7	141805
212927	\N	\N	\N	\N	\N	Lilanga Bobanga	\N	7	141799
212928	\N	\N	\N	\N	\N	Ikela	\N	7	141799
212929	\N	\N	\N	\N	\N	Boende	\N	7	141799
212930	\N	\N	\N	\N	\N	Kailo	\N	7	141802
212931	\N	\N	\N	\N	\N	Nyemba	\N	7	141804
212932	\N	\N	\N	\N	\N	Katende	\N	7	141806
212933	\N	\N	\N	\N	6003006	Kalonge	\N	7	141803
212934	\N	\N	\N	\N	\N	Likasi 	\N	7	141804
212935	\N	\N	\N	\N	\N	Yasa-Bonga	\N	7	141798
212936	\N	\N	\N	\N	\N	Kanda Kanda	\N	7	141805
212937	\N	\N	\N	\N	\N	Bagata	\N	7	141798
212938	\N	\N	\N	\N	\N	Yakusu	\N	7	141800
212939	\N	\N	\N	\N	\N	Lualaba	\N	7	141804
212940	\N	\N	\N	\N	\N	Lukolela 	\N	7	141799
212941	\N	\N	\N	\N	\N	Masisi	\N	7	141801
212942	\N	\N	\N	\N	\N	Mbaya	\N	7	141799
212943	\N	\N	\N	\N	\N	Lusangi	\N	7	141802
212944	\N	\N	\N	\N	\N	Baka	\N	7	141804
212945	\N	\N	\N	\N	\N	Kyondo	\N	7	141801
212946	\N	\N	\N	\N	\N	Lingomo	\N	7	141799
212947	\N	\N	\N	\N	\N	Mobayi	\N	7	141799
212948	\N	\N	\N	\N	\N	Befale	\N	7	141799
212949	\N	\N	\N	\N	\N	Tshumbe	\N	7	141805
212950	\N	\N	\N	\N	\N	Makoro	\N	7	141800
212951	\N	\N	\N	\N	\N	Lolanga Mampoko	\N	7	141799
212952	\N	\N	\N	\N	\N	Ototo	\N	7	141805
212953	\N	\N	\N	\N	\N	Kalamba	\N	7	141804
212954	\N	\N	\N	\N	\N	Rimba	\N	7	141800
212955	\N	\N	\N	\N	\N	Opienge	\N	7	141800
212956	\N	\N	\N	\N	\N	Ngaba	\N	7	141796
212957	\N	\N	\N	\N	\N	Ingende	\N	7	141799
212958	\N	\N	\N	\N	\N	Manono	\N	7	141804
212959	\N	\N	\N	\N	\N	Mosango	\N	7	141798
212960	\N	\N	\N	\N	\N	Ndage	\N	7	141799
212961	\N	\N	\N	\N	\N	Kindu	\N	7	141802
212962	\N	\N	\N	\N	\N	Drodro	\N	7	141800
212963	\N	\N	\N	\N	\N	Kasongolunda	\N	7	141798
212964	\N	\N	\N	\N	\N	Linga	\N	7	141800
212965	\N	\N	\N	\N	\N	Pimu	\N	7	141799
212966	\N	\N	\N	\N	\N	Kitangwa	\N	7	141806
212967	\N	\N	\N	\N	\N	Nyunzu	\N	7	141804
212968	\N	\N	\N	\N	\N	Kaniama	\N	7	141804
212969	\N	\N	\N	\N	\N	Mondombe	\N	7	141799
212970	\N	\N	\N	\N	\N	Kongolo	\N	7	141804
212971	\N	\N	\N	\N	\N	Mweka	\N	7	141806
212972	\N	\N	\N	\N	\N	Kisanga	\N	7	141804
212973	\N	\N	\N	\N	6005005	Mwenga	\N	7	141803
212974	\N	\N	\N	\N	\N	Mangobo	\N	7	141800
212975	\N	\N	\N	\N	\N	Kunda	\N	7	141802
212976	\N	\N	\N	\N	\N	Mukanga	\N	7	141804
212977	\N	\N	\N	\N	\N	Mutoto	\N	7	141806
212978	\N	\N	\N	\N	\N	Mitwaba	\N	7	141804
212979	\N	\N	\N	\N	\N	Bunia	\N	7	141800
212980	\N	\N	\N	\N	\N	Bandundu	\N	7	141798
212981	\N	\N	\N	\N	\N	Kwilu-Ngongo	\N	7	141797
212982	\N	\N	\N	\N	\N	Bosondjo	\N	7	141799
212983	\N	\N	\N	\N	\N	Rwashi 	\N	7	141804
212984	\N	\N	\N	\N	\N	Nsele	\N	7	141796
212985	\N	\N	\N	\N	\N	Bokonzi	\N	7	141799
212986	\N	\N	\N	\N	\N	Vaku	\N	7	141797
212987	\N	\N	\N	\N	\N	Tshopo	\N	7	141800
212988	\N	\N	\N	\N	\N	Kasansa	\N	7	141805
212989	\N	\N	\N	\N	\N	Lubunga	\N	7	141800
212990	\N	\N	\N	\N	\N	Binza-meteo	\N	7	141796
212991	\N	\N	\N	\N	\N	Nyarambe	\N	7	141800
212992	\N	\N	\N	\N	\N	Bunkeya	\N	7	141804
212993	\N	\N	\N	\N	\N	Irebu	\N	7	141799
212994	\N	\N	\N	\N	\N	Iboko	\N	7	141799
212995	\N	\N	\N	\N	\N	Pangi	\N	7	141802
212996	\N	\N	\N	\N	\N	Bomongo	\N	7	141799
212997	\N	\N	\N	\N	\N	Nzanza	\N	7	141797
212998	\N	\N	\N	\N	\N	Vanga-Kete	\N	7	141805
212999	\N	\N	\N	\N	\N	Gethy	\N	7	141800
213000	\N	\N	\N	\N	\N	Djolu	\N	7	141799
213001	\N	\N	\N	\N	\N	Kansimba	\N	7	141804
213002	\N	\N	\N	\N	\N	Idiofa	\N	7	141798
213003	\N	\N	\N	\N	\N	Bonzola	\N	7	141805
213004	\N	\N	\N	\N	\N	Rwampara	\N	7	141800
213005	\N	\N	\N	\N	\N	Tshilenge	\N	7	141805
213006	\N	\N	\N	\N	\N	Lubero	\N	7	141801
213007	\N	\N	\N	\N	\N	Kingasani	\N	7	141796
213008	\N	\N	\N	\N	\N	Mweso	\N	7	141801
213009	\N	\N	\N	\N	\N	Mandima	\N	7	141800
213010	\N	\N	\N	\N	\N	Nsona-Pangu	\N	7	141797
213011	\N	\N	\N	\N	\N	Mangembo	\N	7	141797
213012	\N	\N	\N	\N	\N	Luputa	\N	7	141805
213013	\N	\N	\N	\N	\N	Lisala	\N	7	141799
213014	\N	\N	\N	\N	\N	Bumba	\N	7	141799
213015	\N	\N	\N	\N	\N	Demba	\N	7	141806
213016	\N	\N	\N	\N	\N	Mbanza-Ngungu	\N	7	141797
213017	\N	\N	\N	\N	\N	Isangi	\N	7	141800
213018	\N	\N	\N	\N	\N	Kabalo	\N	7	141804
213019	\N	\N	\N	\N	\N	Kalonda-Ouest	\N	7	141806
213020	\N	\N	\N	\N	\N	Kizu	\N	7	141797
213021	\N	\N	\N	\N	\N	Likati	\N	7	141800
213022	\N	\N	\N	\N	\N	Moba	\N	7	141804
213023	\N	\N	\N	\N	\N	Dungu	\N	7	141800
213024	\N	\N	\N	\N	6002003	Kaniola	\N	7	141803
213025	\N	\N	\N	\N	\N	Kabondo	\N	7	141800
213026	\N	\N	\N	\N	\N	Bandalungwa	\N	7	141796
213027	\N	\N	\N	\N	\N	Mutwanga	\N	7	141801
213028	\N	\N	\N	\N	\N	Maluku II	\N	7	141796
213029	\N	\N	\N	\N	\N	Mukedi	\N	7	141798
213030	\N	\N	\N	\N	\N	Lubao	\N	7	141805
213031	\N	\N	\N	\N	6002001	Kabare	\N	7	141803
213032	\N	\N	\N	\N	\N	Ludimbi Lukula	\N	7	141805
213033	\N	\N	\N	\N	\N	Dekese	\N	7	141806
213034	\N	\N	\N	\N	\N	Zongo	\N	7	141799
213035	\N	\N	\N	\N	\N	Bafwagbogbo	\N	7	141800
213036	\N	\N	\N	\N	\N	Mushie	\N	7	141798
213037	\N	\N	\N	\N	\N	Yakoma	\N	7	141799
213038	\N	\N	\N	\N	\N	Kalonda-Est	\N	7	141805
213039	\N	\N	\N	\N	\N	Bangabola	\N	7	141799
213040	\N	\N	\N	\N	\N	Kikula 	\N	7	141804
213041	\N	\N	\N	\N	\N	Gandajika	\N	7	141805
213042	\N	\N	\N	\N	\N	Goma	\N	7	141801
213043	\N	\N	\N	\N	\N	Pania Mutombo	\N	7	141805
213044	\N	\N	\N	\N	\N	Binga	\N	7	141799
213045	\N	\N	\N	\N	\N	Tembo	\N	7	141798
213046	\N	\N	\N	\N	\N	Katoka	\N	7	141806
213047	\N	\N	\N	\N	\N	Rethy	\N	7	141800
213048	\N	\N	\N	\N	\N	Aketi	\N	7	141800
213049	\N	\N	\N	\N	\N	Yambuku	\N	7	141799
213050	\N	\N	\N	\N	6002002	Nyantende	\N	7	141803
213051	\N	\N	\N	\N	\N	Kungu	\N	7	141799
213052	\N	\N	\N	\N	\N	Lubunga	\N	7	141806
213053	\N	\N	\N	\N	\N	Tshikapa	\N	7	141806
213054	\N	\N	\N	\N	\N	Lukalenge	\N	7	141805
213055	\N	\N	\N	\N	\N	Tunda	\N	7	141802
213056	\N	\N	\N	\N	\N	Ndjili	\N	7	141796
213057	\N	\N	\N	\N	\N	Kabambare	\N	7	141802
213058	\N	\N	\N	\N	\N	Kilo	\N	7	141800
213059	\N	\N	\N	\N	\N	Kapanga	\N	7	141804
213060	\N	\N	\N	\N	\N	Mokala	\N	7	141798
213061	\N	\N	\N	\N	\N	Kapolowe	\N	7	141804
213062	\N	\N	\N	\N	\N	Kibunzi	\N	7	141797
213063	\N	\N	\N	\N	\N	Kinkonzi	\N	7	141797
213064	\N	\N	\N	\N	\N	Kitona	\N	7	141797
213065	\N	\N	\N	\N	\N	Kangu	\N	7	141797
213066	\N	\N	\N	\N	\N	Kokolo	\N	7	141796
213067	\N	\N	\N	\N	\N	Lotumbe	\N	7	141799
213068	\N	\N	\N	\N	\N	Yalifafu	\N	7	141799
213069	\N	\N	\N	\N	\N	Kimpese	\N	7	141797
213070	\N	\N	\N	\N	\N	Lodja 	\N	7	141805
213071	\N	\N	\N	\N	\N	Dingila	\N	7	141800
213072	\N	\N	\N	\N	\N	Boko-Kivulu	\N	7	141797
213073	\N	\N	\N	\N	\N	Oshwe	\N	7	141798
213074	\N	\N	\N	\N	\N	Inga	\N	7	141797
213075	\N	\N	\N	\N	\N	Wembo-Nyama	\N	7	141805
213076	\N	\N	\N	\N	\N	Lukonga	\N	7	141806
213077	\N	\N	\N	\N	\N	Boko	\N	7	141798
213078	\N	\N	\N	\N	\N	Nizi	\N	7	141800
213079	\N	\N	\N	\N	\N	Lowa	\N	7	141800
213080	\N	\N	\N	\N	6003005	Kalehe 	\N	7	141803
213081	\N	\N	\N	\N	\N	Boma Bungu	\N	7	141797
213082	\N	\N	\N	\N	\N	Muya	\N	7	141805
213083	\N	\N	\N	\N	\N	Jiba	\N	7	141800
213084	\N	\N	\N	\N	\N	Tshela	\N	7	141797
213085	\N	\N	\N	\N	6004004	Nundu	\N	7	141803
213086	\N	\N	\N	\N	\N	Tshishimbi	\N	7	141805
213087	\N	\N	\N	\N	\N	Nyanga	\N	7	141806
213088	\N	\N	\N	\N	\N	Masi-manimba	\N	7	141798
213089	\N	\N	\N	\N	\N	Tshofa	\N	7	141805
213090	\N	\N	\N	\N	\N	Muetshi	\N	7	141806
213091	\N	\N	\N	\N	\N	Katwa	\N	7	141801
213092	\N	\N	\N	\N	\N	Aba	\N	7	141800
213093	\N	\N	\N	\N	\N	Kikimi	\N	7	141796
213094	\N	\N	\N	\N	\N	Masa	\N	7	141797
213095	\N	\N	\N	\N	\N	Ferekeni	\N	7	141802
213096	\N	\N	\N	\N	\N	Kalend	\N	7	141805
213097	\N	\N	\N	\N	6003003	Katana	\N	7	141803
213098	\N	\N	\N	\N	\N	Makota	\N	7	141805
213099	\N	\N	\N	\N	\N	Kamiji	\N	7	141805
213100	\N	\N	\N	\N	\N	Omendjadi	\N	7	141805
213101	\N	\N	\N	\N	\N	Ankoro	\N	7	141804
213102	\N	\N	\N	\N	6002004	Kaziba	\N	7	141803
213103	\N	\N	\N	\N	\N	Lolwa	\N	7	141800
213104	\N	\N	\N	\N	\N	Kiambi	\N	7	141804
213105	\N	\N	\N	\N	\N	Wangata	\N	7	141799
213106	\N	\N	\N	\N	\N	Kikwit-Nord	\N	7	141798
213107	\N	\N	\N	\N	\N	Nioki	\N	7	141798
213108	\N	\N	\N	\N	\N	Bobozo	\N	7	141806
213109	\N	\N	\N	\N	\N	Koshibanda	\N	7	141798
213110	\N	\N	\N	\N	\N	Yahisuli	\N	7	141800
213111	\N	\N	\N	\N	\N	Dikungu	\N	7	141805
213112	\N	\N	\N	\N	\N	Kenge	\N	7	141798
213113	\N	\N	\N	\N	\N	Bososenuba	\N	7	141799
213114	\N	\N	\N	\N	\N	Bafwasende	\N	7	141800
213115	\N	\N	\N	\N	\N	Obokote	\N	7	141802
213116	\N	\N	\N	\N	\N	Bongandanga	\N	7	141799
213117	\N	\N	\N	\N	\N	Bulu	\N	7	141799
213118	\N	\N	\N	\N	\N	Kinshasa	\N	7	141796
213119	\N	\N	\N	\N	\N	Masuika	\N	7	141806
213120	\N	\N	\N	\N	\N	Budjala	\N	7	141799
213121	\N	\N	\N	\N	\N	Ntondo	\N	7	141799
213122	\N	\N	\N	\N	\N	Bengamisa	\N	7	141800
213123	\N	\N	\N	\N	\N	Fungurume	\N	7	141804
213124	\N	\N	\N	\N	\N	Citenge	\N	7	141805
213125	\N	\N	\N	\N	\N	Pweto	\N	7	141804
213126	\N	\N	\N	\N	\N	Gombe	\N	7	141796
213127	\N	\N	\N	\N	\N	Bena-leka	\N	7	141806
213128	\N	\N	\N	\N	\N	Kalamu II	\N	7	141796
213129	\N	\N	\N	\N	\N	Kambove	\N	7	141804
213130	\N	\N	\N	\N	\N	Kuimba	\N	7	141797
213131	\N	\N	\N	\N	6002007	Walungu	\N	7	141803
213132	\N	\N	\N	\N	\N	Panzi	\N	7	141798
213133	\N	\N	\N	\N	\N	Ndesha	\N	7	141806
213134	\N	\N	\N	\N	6004003	Kimbi Lulenge	\N	7	141803
213135	\N	\N	\N	\N	\N	Kamuesha	\N	7	141806
213136	\N	\N	\N	\N	6005009	Shabunda	\N	7	141803
213137	\N	\N	\N	\N	\N	Kabinda	\N	7	141805
213138	\N	\N	\N	\N	\N	Bukama 	\N	7	141804
213139	\N	\N	\N	\N	\N	Mufunga-Sampwe 	\N	7	141804
213140	\N	\N	\N	\N	\N	Wamba	\N	7	141800
213141	\N	\N	\N	\N	\N	Kafakumba	\N	7	141804
213142	\N	\N	\N	\N	\N	Kowe	\N	7	141804
213143	\N	\N	\N	\N	6005001	Itombwe	\N	7	141803
213144	\N	\N	\N	\N	\N	Niania	\N	7	141800
213145	\N	\N	\N	\N	\N	Mbandaka 	\N	7	141799
213146	\N	\N	\N	\N	\N	Kamalondo	\N	7	141804
213147	\N	\N	\N	\N	\N	Sekebanza	\N	7	141797
213148	\N	\N	\N	\N	\N	LimetÃ©	\N	7	141796
213149	\N	\N	\N	\N	\N	Kampene	\N	7	141802
213150	\N	\N	\N	\N	\N	Kambala	\N	7	141800
213151	\N	\N	\N	\N	\N	Samba	\N	7	141802
213152	\N	\N	\N	\N	6005002	Kamituga	\N	7	141803
213153	\N	\N	\N	\N	\N	Lubilanji	\N	7	141805
213154	\N	\N	\N	\N	\N	Nselo	\N	7	141797
213155	\N	\N	\N	\N	\N	Beni	\N	7	141801
213156	\N	\N	\N	\N	6005003	Kitutu	\N	7	141803
213157	\N	\N	\N	\N	\N	Niangara	\N	7	141800
213158	\N	\N	\N	\N	\N	Djuma	\N	7	141798
213159	\N	\N	\N	\N	\N	Mont-ngafula II	\N	7	141796
213160	\N	\N	\N	\N	\N	Wapinda	\N	7	141799
213161	\N	\N	\N	\N	\N	Mulumba	\N	7	141805
213162	\N	\N	\N	\N	\N	Lukafu	\N	7	141804
213163	\N	\N	\N	\N	\N	Bumbu	\N	7	141796
213164	\N	\N	\N	\N	\N	Boninenge	\N	7	141799
213165	\N	\N	\N	\N	\N	Lubutu	\N	7	141802
213166	\N	\N	\N	\N	\N	Tandala	\N	7	141799
213167	\N	\N	\N	\N	\N	Monieka	\N	7	141799
213168	\N	\N	\N	\N	\N	Wanie Rukula	\N	7	141800
213169	\N	\N	\N	\N	\N	Masina I	\N	7	141796
213170	\N	\N	\N	\N	\N	Busanga	\N	7	141799
213171	\N	\N	\N	\N	\N	Barbados	\N	8	212671
213172	\N	\N	\N	\N	\N	Lugungu	\N	8	212674
213173	\N	\N	\N	\N	\N	?? Katsiru	\N	8	212679
213174	\N	\N	\N	\N	\N	?? katwiguru	\N	8	212679
213175	\N	\N	\N	\N	\N	?? Buganza	\N	8	212679
213176	\N	\N	\N	\N	\N	Ishasha	\N	8	212679
213177	\N	\N	\N	\N	\N	Lwamba	\N	8	212690
213178	\N	\N	\N	\N	\N	Malindi	\N	8	212692
213179	\N	\N	\N	\N	\N	BEDJU	\N	8	212693
213180	\N	\N	\N	\N	\N	WI GHII	\N	8	212693
213181	\N	\N	\N	\N	\N	Djalusene	\N	8	212693
213182	\N	\N	\N	\N	\N	Nyaa	\N	8	212693
213183	\N	\N	\N	\N	\N	KAHONDO	\N	8	212703
213184	\N	\N	\N	\N	\N	Kainama	\N	8	212703
213185	\N	\N	\N	\N	\N	Kokola	\N	8	212703
213186	\N	\N	\N	\N	\N	KAMANGO	\N	8	212703
213187	\N	\N	\N	\N	\N	Liva (Mayi moya)	\N	8	212703
213188	\N	\N	\N	\N	\N	Kainama	\N	8	212703
213189	\N	\N	\N	\N	\N	Kahondo	\N	8	212703
213190	\N	\N	\N	\N	\N	Mambabio	\N	8	212703
213191	\N	\N	\N	\N	\N	Totolito	\N	8	212703
213192	\N	\N	\N	\N	\N	Kithevya	\N	8	212703
213193	\N	\N	\N	\N	\N	LUANOLI	\N	8	212703
213194	\N	\N	\N	\N	\N	Mbutaba	\N	8	212703
213195	\N	\N	\N	\N	\N	Eringeti	\N	8	212703
213196	\N	\N	\N	\N	\N	BOLI	\N	8	212706
213197	\N	\N	\N	\N	\N	RUNGU	\N	8	212706
213198	\N	\N	\N	\N	\N	Eliba	\N	8	212711
213199	\N	\N	\N	\N	\N	Rumbwa	\N	8	212711
213200	\N	\N	\N	\N	\N	NDJINGALA	\N	8	212711
213201	\N	\N	\N	\N	\N	BILOBILO	\N	8	212711
213202	\N	\N	\N	\N	\N	Nyasi	\N	8	212711
213203	\N	\N	\N	\N	\N	MUTAKATO	\N	8	212711
213204	\N	\N	\N	\N	\N	Moswa	\N	8	212719
213205	\N	\N	\N	\N	\N	Kambau	\N	8	212721
213206	\N	\N	\N	\N	\N	Malunguma	\N	8	212721
213207	\N	\N	\N	\N	\N	Liboyo	\N	8	212721
213208	\N	\N	\N	\N	\N	ngungu	\N	8	212722
213209	\N	\N	\N	\N	\N	Karuba	\N	8	212722
213210	\N	\N	\N	\N	\N	mitumbala	\N	8	212722
213211	\N	\N	\N	\N	\N	Kafumbe	\N	8	212736
213212	\N	\N	\N	\N	\N	Lemera	\N	8	212749
213214	\N	\N	\N	\N	\N	Luofu	\N	8	212752
213215	\N	\N	\N	\N	\N	Kabango	\N	8	212759
213216	\N	\N	\N	\N	\N	Minwembwe	\N	8	212765
213217	\N	\N	\N	\N	\N	Boga	\N	8	212770
213218	\N	\N	\N	\N	\N	Rubingo	\N	8	212770
213219	\N	\N	\N	\N	\N	Bitobolo	\N	8	212775
213220	\N	\N	\N	\N	\N	Ciburi	\N	8	212779
213221	\N	\N	\N	\N	\N	MAKOFI	\N	8	212786
213222	\N	\N	\N	\N	\N	Damas	\N	8	212786
213223	\N	\N	\N	\N	\N	Gengere	\N	8	212794
213224	\N	\N	\N	\N	\N	Musongwa	\N	8	212794
213226	\N	\N	\N	\N	\N	LUKUMBA	\N	8	212814
213227	\N	\N	\N	\N	\N	MWAMBA	\N	8	212814
213228	\N	\N	\N	\N	\N	Nyalukungu	\N	8	212814
213229	\N	\N	\N	\N	\N	Penenkusu	\N	8	212814
213230	\N	\N	\N	\N	\N	Kyavisogho	\N	8	212817
213231	\N	\N	\N	\N	\N	NGAZI	\N	8	212817
213232	\N	\N	\N	\N	\N	Amani	\N	8	212817
213233	\N	\N	\N	\N	\N	Rwarhwa	\N	8	212817
213234	\N	\N	\N	\N	\N	Kisungo	\N	8	212817
213235	\N	\N	\N	\N	\N	KANYATSI	\N	8	212817
213236	\N	\N	\N	\N	\N	VUSAYIRO	\N	8	212817
213237	\N	\N	\N	\N	\N	Mbilinga	\N	8	212817
213238	\N	\N	\N	\N	\N	Kahamba	\N	8	212817
213239	\N	\N	\N	\N	\N	Mateto	\N	8	212817
213240	\N	\N	\N	\N	\N	KIRIMA	\N	8	212817
213241	\N	\N	\N	\N	\N	Masoya	\N	8	212817
213242	\N	\N	\N	\N	\N	Mabuku	\N	8	212817
213243	\N	\N	\N	\N	\N	Mambingi	\N	8	212817
213244	\N	\N	\N	\N	\N	Pombi	\N	8	212817
213245	\N	\N	\N	\N	\N	visiki	\N	8	212817
213246	\N	\N	\N	\N	\N	Mabuku	\N	8	212817
213247	\N	\N	\N	\N	\N	Kabuya	\N	8	212818
213248	\N	\N	\N	\N	\N	Anuarite	\N	8	212819
213249	\N	\N	\N	\N	\N	Bekisha	\N	8	212819
213250	\N	\N	\N	\N	\N	Kaloko	\N	8	212819
213251	\N	\N	\N	\N	\N	Budi	\N	8	212819
213252	\N	\N	\N	\N	\N	Bermuda	\N	8	212821
213253	\N	\N	\N	\N	\N	Vuhinga	\N	8	212823
213254	\N	\N	\N	\N	\N	Ndungbe	\N	8	212827
213255	\N	\N	\N	\N	\N	LITA	\N	8	212827
213256	\N	\N	\N	\N	\N	Loga	\N	8	212827
213257	\N	\N	\N	\N	\N	Jili	\N	8	212827
213258	\N	\N	\N	\N	\N	Kilumbe	\N	8	212830
213259	\N	\N	\N	\N	\N	Katondo	\N	8	212830
213260	\N	\N	\N	\N	\N	Kisungi	\N	8	212830
213261	\N	\N	\N	\N	\N	Misebo	\N	8	212830
213262	\N	\N	\N	\N	\N	Kapando	\N	8	212830
213263	\N	\N	\N	\N	\N	Banana - Loda	\N	8	212832
213264	\N	\N	\N	\N	\N	DALA	\N	8	212832
213265	\N	\N	\N	\N	\N	ZENGO	\N	8	212832
213268	\N	\N	\N	\N	\N	Zani	\N	8	212868
213269	\N	\N	\N	\N	\N	Mont ZEU	\N	8	212868
213270	\N	\N	\N	\N	\N	Ngbiki	\N	8	212868
213271	\N	\N	\N	\N	\N	Djalasiga	\N	8	212868
213272	\N	\N	\N	\N	\N	ANYARA	\N	8	212868
213273	\N	\N	\N	\N	\N	Nyamamba	\N	8	212882
213274	\N	\N	\N	\N	\N	KILUMA	\N	8	212887
213275	\N	\N	\N	\N	\N	Kigulube	\N	8	212887
213276	\N	\N	\N	\N	\N	NYALUBEMBA	\N	8	212887
213277	\N	\N	\N	\N	\N	Minova	\N	8	212907
213278	\N	\N	\N	\N	\N	Muzinzi	\N	8	212919
213279	\N	\N	\N	\N	\N	Kitoke	\N	8	212931
213280	\N	\N	\N	\N	\N	MaÃ¯baridi	\N	8	212931
213281	\N	\N	\N	\N	\N	Kyoko	\N	8	212931
213282	\N	\N	\N	\N	\N	Kalonge	\N	8	212933
213283	\N	\N	\N	\N	\N	Kashesha	\N	8	212933
213284	\N	\N	\N	\N	\N	Bumoga	\N	8	212933
213285	\N	\N	\N	\N	\N	?? Katembe	\N	8	212941
213286	\N	\N	\N	\N	\N	Mbungwe	\N	8	212945
213287	\N	\N	\N	\N	\N	Vutumbi	\N	8	212945
213288	\N	\N	\N	\N	\N	Kalivuli	\N	8	212945
213289	\N	\N	\N	\N	\N	Kirindera	\N	8	212945
213290	\N	\N	\N	\N	\N	Kyaghendi	\N	8	212945
213291	\N	\N	\N	\N	\N	Kyalumba	\N	8	212945
213292	\N	\N	\N	\N	\N	KIVUWE	\N	8	212945
213293	\N	\N	\N	\N	\N	Gwok'nyeri	\N	8	212954
213294	\N	\N	\N	\N	\N	Terususa	\N	8	212954
213295	\N	\N	\N	\N	\N	Uwilo	\N	8	212954
213296	\N	\N	\N	\N	\N	Ngote	\N	8	212954
213297	\N	\N	\N	\N	\N	Panyabiu	\N	8	212954
213298	\N	\N	\N	\N	\N	Aredju	\N	8	212954
213299	\N	\N	\N	\N	\N	Muyumba	\N	8	212958
213300	\N	\N	\N	\N	\N	Saliboko	\N	8	212962
213301	\N	\N	\N	\N	\N	Logo - Takpa	\N	8	212962
213302	\N	\N	\N	\N	\N	Kpalo	\N	8	212962
213303	\N	\N	\N	\N	\N	Masumbuku	\N	8	212962
213304	\N	\N	\N	\N	\N	Lwizi	\N	8	212967
213305	\N	\N	\N	\N	\N	KITAGANA 	\N	8	212973
213306	\N	\N	\N	\N	\N	Chowe	\N	8	212973
213307	\N	\N	\N	\N	\N	Shele	\N	8	212976
213308	\N	\N	\N	\N	\N	Kasenga	\N	8	212976
213309	\N	\N	\N	\N	\N	Centrale Soleniama	\N	8	212979
213310	\N	\N	\N	\N	\N	Kagoro	\N	8	212999
213311	\N	\N	\N	\N	\N	Gethy Etat	\N	8	212999
213312	\N	\N	\N	\N	\N	Kazana (Ngasu odje)	\N	8	212999
213313	\N	\N	\N	\N	\N	Zitono	\N	8	212999
213314	\N	\N	\N	\N	\N	Kagaba	\N	8	212999
213315	\N	\N	\N	\N	\N	Kinyomubaya	\N	8	212999
213316	\N	\N	\N	\N	\N	Kaguma	\N	8	212999
213317	\N	\N	\N	\N	\N	Kabona	\N	8	212999
213318	\N	\N	\N	\N	\N	Aveba	\N	8	212999
213319	\N	\N	\N	\N	\N	CHYEKELE	\N	8	212999
213320	\N	\N	\N	\N	\N	Chekele	\N	8	212999
213321	\N	\N	\N	\N	\N	Aveba	\N	8	212999
213322	\N	\N	\N	\N	\N	Gethy	\N	8	212999
213323	\N	\N	\N	\N	\N	Kansabala	\N	8	213001
213324	\N	\N	\N	\N	\N	Kabwela	\N	8	213001
213325	\N	\N	\N	\N	\N	Mupanga	\N	8	213001
213326	\N	\N	\N	\N	\N	Kavukwa	\N	8	213001
213327	\N	\N	\N	\N	\N	Lungulungu	\N	8	213001
213328	\N	\N	\N	\N	\N	Kasesa-Ngani	\N	8	213001
213329	\N	\N	\N	\N	\N	Lambo	\N	8	213001
213330	\N	\N	\N	\N	\N	Kamena	\N	8	213001
213331	\N	\N	\N	\N	\N	Mwanga	\N	8	213004
213332	\N	\N	\N	\N	\N	?	\N	8	213018
213333	\N	\N	\N	\N	\N	Kakuyu	\N	8	213018
213334	\N	\N	\N	\N	\N	Mwirama	\N	8	213024
213335	\N	\N	\N	\N	\N	Kaniola	\N	8	213024
213336	\N	\N	\N	\N	\N	Nyamarege	\N	8	213024
213337	\N	\N	\N	\N	\N	Nzibra	\N	8	213024
213338	\N	\N	\N	\N	\N	Luntukulu	\N	8	213024
213339	\N	\N	\N	\N	\N	Kikura	\N	8	213027
213340	\N	\N	\N	\N	\N	??	\N	8	213031
213341	\N	\N	\N	\N	\N	Uketha	\N	8	213047
213342	\N	\N	\N	\N	\N	Uketha	\N	8	213047
213343	\N	\N	\N	\N	\N	Aboro test	\N	8	213047
213344	\N	\N	\N	\N	\N	Aboro-Mission	\N	8	213047
213345	\N	\N	\N	\N	\N	Maraybrima	\N	8	213048
213346	\N	\N	\N	\N	\N	LINGO	\N	8	213078
213347	\N	\N	\N	\N	\N	LOPA - TSIKU	\N	8	213078
213348	\N	\N	\N	\N	\N	Sange	\N	8	213104
213349	\N	\N	\N	\N	\N	Kyungu	\N	8	213104
213350	\N	\N	\N	\N	\N	Mwenge	\N	8	213125
213351	\N	\N	\N	\N	\N	Mulamba	\N	8	213131
213352	\N	\N	\N	\N	\N	Lusilu	\N	8	213134
213353	\N	\N	\N	\N	\N	Bibizi, Lusilu	\N	8	213134
213354	\N	\N	\N	\N	\N	?\\	\N	8	213136
213355	\N	\N	\N	\N	\N	Kipupu	\N	8	213143
213356	\N	\N	\N	\N	\N	Mikenge	\N	8	213143
213357	\N	\N	\N	\N	\N	Berunda	\N	8	213150
213358	\N	\N	\N	\N	\N	KOTO	\N	8	213150
213359	\N	\N	\N	\N	\N	BAKU	\N	8	213150
213360	\N	\N	\N	\N	\N	Kahando	\N	8	213155
213361	\N	\N	\N	\N	\N	Mutendero 	\N	8	213155
213362	\N	\N	\N	\N	\N	Amani	\N	8	213155
213363	\N	\N	\N	\N	\N	Espoir	\N	8	213156
213364	\N	\N	\N	\N	\N	Mwangaza	\N	8	213156
213365	\N	\N	\N	\N	\N	Busakizi Mission catholique	\N	8	213156
213366	\N	\N	\N	\N	\N	Artibonite	\N	10	\N
213367	\N	\N	\N	\N	\N	Centre	\N	10	\N
213368	\N	\N	\N	\N	\N	Grand'Anse	\N	10	\N
213369	\N	\N	\N	\N	\N	Nippes	\N	10	\N
213370	\N	\N	\N	\N	\N	Nord	\N	10	\N
213371	\N	\N	\N	\N	\N	Nord-Est	\N	10	\N
213372	\N	\N	\N	\N	\N	Ouest	\N	10	\N
213373	\N	\N	\N	\N	\N	Sud-Est	\N	10	\N
213374	\N	\N	\N	\N	\N	Sud	\N	10	\N
213375	\N	\N	\N	\N	\N	Bitale	\N	8	212775
213377	\N	\N	\N	\N	\N	Bunyakiri	\N	8	212775
213378	\N	\N	\N	\N	\N	Fumya	\N	8	212775
213379	\N	\N	\N	\N	\N	Maibano	\N	8	212775
213380	\N	\N	\N	\N	\N	Mingazi	\N	8	212775
213381	\N	\N	\N	\N	\N	Muoma	\N	8	212775
\.


--
-- TOC entry 2591 (class 0 OID 113849)
-- Dependencies: 163
-- Data for Name: adminlevel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY adminlevel (adminlevelid, allowadd, name, countryid, parentid) FROM stdin;
1	f	Province	1	\N
2	f	District	1	1
3	f	Territoire	1	2
4	f	Secteur	1	3
5	t	Groupement	1	4
7	f	Zone de Santé	1	1
8	t	Aire de Santé	1	7
9	f	Province	322	\N
10	f	District	322	9
11	f	Territoire	322	10
12	f	Secteur	322	11
13	t	Groupement	322	12
14	f	Zone de Santé	322	9
15	t	Aire de Santé	322	14
\.


--
-- TOC entry 2592 (class 0 OID 113852)
-- Dependencies: 164
-- Data for Name: amendment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY amendment (id_amendment, history_date, revision, status, version, id_log_frame, id_project) FROM stdin;
\.


--
-- TOC entry 2593 (class 0 OID 113855)
-- Dependencies: 165
-- Data for Name: amendment_history_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY amendment_history_token (amendment_id_amendment, values_id_history_token) FROM stdin;
\.


--
-- TOC entry 2594 (class 0 OID 113858)
-- Dependencies: 166
-- Data for Name: attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY attribute (attributeid, datedeleted, name, sortorder, attributegroupid) FROM stdin;
\.


--
-- TOC entry 2595 (class 0 OID 113861)
-- Dependencies: 167
-- Data for Name: attributegroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY attributegroup (attributegroupid, category, datedeleted, multipleallowed, name, sortorder) FROM stdin;
\.


--
-- TOC entry 2596 (class 0 OID 113864)
-- Dependencies: 168
-- Data for Name: attributegroupinactivity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY attributegroupinactivity (attributegroupid, activityid) FROM stdin;
\.


--
-- TOC entry 2597 (class 0 OID 113867)
-- Dependencies: 169
-- Data for Name: attributevalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY attributevalue (attributeid, siteid, value) FROM stdin;
\.


--
-- TOC entry 2598 (class 0 OID 113870)
-- Dependencies: 170
-- Data for Name: authentication; Type: TABLE DATA; Schema: public; Owner: -
--

COPY authentication (authtoken, datecreated, datelastactive, userid) FROM stdin;
6cb96f6f0f1c7e9ea1c017b5a38be337	2012-11-19 15:03:16.645	2012-11-19 15:03:16.645	35
6e7b1ec4733229d8f1066555288a5d37	2012-11-21 12:06:18.191	2012-11-21 12:06:18.191	35
66ae6c36ec4a7b93166591dda8b00508	2012-11-23 21:54:04.948	2012-11-23 21:54:04.948	35
effdc731fd0614f8a61ed717f9d53ad4	2012-11-23 21:55:14.556	2012-11-23 21:55:14.556	35
d2aad3522dbebff52181027692c6e0b7	2012-11-26 15:45:35.195	2012-11-26 15:45:35.195	35
b1f8d86bf0aca9156223a7f4995d15b7	2012-11-26 15:56:01.174	2012-11-26 15:56:01.174	35
9046033027d8f0c05bb210345a703480	2012-11-27 22:06:59.863	2012-11-27 22:06:59.863	35
bec9005a8342802dd76cf9106d2abf64	2012-11-27 23:25:50.961	2012-11-27 23:25:50.961	924
f48bd9c66a981ea3a1ecb9001949af19	2012-11-27 23:26:12.368	2012-11-27 23:26:12.368	35
ffc85b93bd48d5a44acdab8a52479cdb	2012-11-28 00:14:02.914	2012-11-28 00:14:02.914	890
1ae350216e0b8d1b40ea8f81bc67d132	2012-11-28 00:14:51.35	2012-11-28 00:14:51.35	35
fb6a27a70cc6c820fb77f56644617db5	2012-11-28 00:36:15.645	2012-11-28 00:36:15.645	918
eaee5705e1ea23ab2179defaf83f2a63	2012-11-28 01:10:00.726	2012-11-28 01:10:00.726	35
0ca34df279dc41ef2a765125804faa60	2012-12-05 12:39:14.369	2012-12-05 12:39:14.369	35
1e30a1d5b64cb02c98b964c228b6ed66	2012-12-05 12:58:23.26	2012-12-05 12:58:23.26	35
5886e95e856dabf4011bb2ce9c83dbe2	2012-12-05 13:00:24.981	2012-12-05 13:00:24.981	35
40b054c54f64fda1747c2ca2191421f7	2012-12-05 13:00:55.452	2012-12-05 13:00:55.452	35
97f799d10c46a34c223fb66ee1771617	2012-12-05 13:02:09.032	2012-12-05 13:02:09.032	35
f1197b8aa3b5adb33ca99954799225fd	2012-12-05 13:02:47.044	2012-12-05 13:02:47.044	1540
623697eddc9e9c5adef4b5d60f5f6f2d	2012-12-05 13:05:18.113	2012-12-05 13:05:18.113	35
f21255789526efe70e6569625ab1ccd0	2013-02-05 16:40:19.927	2013-02-05 16:40:19.927	1540
8e7d34a8461e176ce80b2a08cb878d6b	2013-02-05 16:58:16.357	2013-02-05 16:58:16.357	1540
613c07993236869a0b87550e384e33c6	2013-02-08 12:29:44.55	2013-02-08 12:29:44.55	35
\.


--
-- TOC entry 2599 (class 0 OID 113873)
-- Dependencies: 171
-- Data for Name: budget; Type: TABLE DATA; Schema: public; Owner: -
--

COPY budget (id_budget, total_amount) FROM stdin;
\.


--
-- TOC entry 2600 (class 0 OID 113876)
-- Dependencies: 172
-- Data for Name: budget_distribution_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY budget_distribution_element (id_flexible_element) FROM stdin;
\.


--
-- TOC entry 2601 (class 0 OID 113879)
-- Dependencies: 173
-- Data for Name: budget_part; Type: TABLE DATA; Schema: public; Owner: -
--

COPY budget_part (id_budget_part, amount, label, id_budget_parts_list) FROM stdin;
\.


--
-- TOC entry 2602 (class 0 OID 113885)
-- Dependencies: 174
-- Data for Name: budget_parts_list_value; Type: TABLE DATA; Schema: public; Owner: -
--

COPY budget_parts_list_value (id_budget_parts_list, id_budget) FROM stdin;
\.


--
-- TOC entry 2603 (class 0 OID 113888)
-- Dependencies: 175
-- Data for Name: category_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_element (id_category_element, color_hex, label, id_organization, id_category_type) FROM stdin;
822	FAAD63	Réduction des désastres	1	821
823	969696	Formation au secourisme	1	821
824	CC99FF	Santé publique	1	821
825	3366FF	Soutien psychosocial	1	821
826	003366	Lutte contre le sida	1	821
827	FFFF00	Eau et assainissement	1	821
828	993300	Réhabilitation	1	821
829	99CC00	Développement économique et social	1	821
830	800080	Développement organisationnel	1	821
831	FF0000	Urgence	1	821
833	FFFF00	IDP	1	832
834	FF9900	Réfugiés	1	832
835	FFCC99	Rapatriés	1	832
836	993300	Populations locales	1	832
837	808080	Autres	1	832
1370	800080	Développement organisationnel	\N	1369
1371	FFFF00	Eau et assainissement	\N	1369
1372	969696	Formation au secourisme	\N	1369
1373	003366	Lutte contre le sida	\N	1369
1374	FAAD63	Réduction des désastres	\N	1369
1375	993300	Réhabilitation	\N	1369
1376	CC99FF	Santé publique	\N	1369
1377	3366FF	Soutien psychosocial	\N	1369
1378	FF0000	Urgence	\N	1369
1379	99CC00	Développement économique et social	\N	1369
1380	99CC00	Développement économique et social	\N	1369
1393	FFFF00	IDP	\N	1392
1394	993300	Populations locales	\N	1392
1395	FFCC99	Rapatriés	\N	1392
1396	FF9900	Réfugiés	\N	1392
1397	808080	Autres	\N	1392
1398	808080	Autres	\N	1392
\.


--
-- TOC entry 2604 (class 0 OID 113894)
-- Dependencies: 176
-- Data for Name: category_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_type (id_category_type, icon_name, label, id_organization) FROM stdin;
821	SQUARE	Thématique	1
832	CIRCLE	Bénéficiaires	1
1369	SQUARE	Thématique	\N
1392	CIRCLE	Bénéficiaires	\N
\.


--
-- TOC entry 2605 (class 0 OID 113900)
-- Dependencies: 177
-- Data for Name: checkbox_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY checkbox_element (id_flexible_element) FROM stdin;
141
1312
\.


--
-- TOC entry 2606 (class 0 OID 113903)
-- Dependencies: 178
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: -
--

COPY country (countryid, x1, x2, y1, y2, iso2, name) FROM stdin;
1	12.187941840000001	31.306000000000001	-13.45599996	5.3860981539999999	CD	Congo, RD
249	-180	180	-90	180	AF	Afghanistan
250	-180	180	-90	180	AX	Åland Islands
251	-180	180	-90	180	AL	Albania
252	-180	180	-90	180	DZ	Algeria
253	-180	180	-90	180	AS	American Samoa
254	-180	180	-90	180	AD	Andorra
255	-180	180	-90	180	AO	Angola
256	-180	180	-90	180	AI	Anguilla
257	-180	180	-90	180	AQ	Antarctica
258	-180	180	-90	180	AG	Antigua and Barbuda
259	-180	180	-90	180	AR	Argentina
260	-180	180	-90	180	AM	Armenia
261	-180	180	-90	180	AW	Aruba
262	-180	180	-90	180	AU	Australia
263	-180	180	-90	180	AT	Austria
264	-180	180	-90	180	AZ	Azerbaijan
265	-180	180	-90	180	BS	Bahamas
266	-180	180	-90	180	BH	Bahrain
267	-180	180	-90	180	BD	Bangladesh
268	-180	180	-90	180	BB	Barbados
269	-180	180	-90	180	BY	Belarus
270	-180	180	-90	180	BE	Belgium
271	-180	180	-90	180	BZ	Belize
272	-180	180	-90	180	BJ	Benin
273	-180	180	-90	180	BM	Bermuda
274	-180	180	-90	180	BT	Bhutan
275	-180	180	-90	180	BO	Bolivia
276	-180	180	-90	180	BA	Bosnia And Herzegovina
277	-180	180	-90	180	BW	Botswana
278	-180	180	-90	180	BV	Bouvet Island
279	-180	180	-90	180	BR	Brazil
280	-180	180	-90	180	IO	British Indian Ocean Territory
281	-180	180	-90	180	B	Brunei Darussalam
282	-180	180	-90	180	BG	Bulgaria
283	-180	180	-90	180	BF	Burkina Faso
284	-180	180	-90	180	BI	Burundi
285	-180	180	-90	180	KH	Cambodia
286	-180	180	-90	180	CM	Cameroon
287	-180	180	-90	180	CA	Canada
288	-180	180	-90	180	CV	Cape Verde
289	-180	180	-90	180	KY	Cayman Islands
290	-180	180	-90	180	CF	Central African Republic
291	-180	180	-90	180	TD	Chad
292	-180	180	-90	180	CL	Chile
293	-180	180	-90	180	C	China
294	-180	180	-90	180	CX	Christmas Island
295	-180	180	-90	180	CC	Cocos (Keeling) Islands
296	-180	180	-90	180	CO	Colombia
297	-180	180	-90	180	KM	Comoros
298	-180	180	-90	180	CG	Congo
300	-180	180	-90	180	CK	Cook Islands
301	-180	180	-90	180	CR	Costa Rica
302	-180	180	-90	180	CI	Côte D'Ivoire
303	-180	180	-90	180	HR	Croatia
304	-180	180	-90	180	CU	Cuba
305	-180	180	-90	180	CY	Cyprus
306	-180	180	-90	180	CZ	Czech Republic
307	-180	180	-90	180	DK	Denmark
308	-180	180	-90	180	DJ	Djibouti
309	-180	180	-90	180	DM	Dominica
310	-180	180	-90	180	DO	Dominican Republic
311	-180	180	-90	180	EC	Ecuador
312	-180	180	-90	180	EG	Egypt
313	-180	180	-90	180	SV	El Salvador
314	-180	180	-90	180	GQ	Equatorial Guinea
315	-180	180	-90	180	ER	Eritrea
316	-180	180	-90	180	EE	Estonia
317	-180	180	-90	180	ET	Ethiopia
318	-180	180	-90	180	FK	Falkland Islands (Malvinas)
319	-180	180	-90	180	FO	Faroe Islands
320	-180	180	-90	180	FJ	Fiji
321	-180	180	-90	180	FI	Finland
322	-180	180	-90	180	FR	France
323	-180	180	-90	180	GF	French Guiana
324	-180	180	-90	180	PF	French Polynesia
325	-180	180	-90	180	TF	French Southern Territories
326	-180	180	-90	180	GA	Gabo
327	-180	180	-90	180	GM	Gambia
328	-180	180	-90	180	GE	Georgia
329	-180	180	-90	180	DE	Germany
330	-180	180	-90	180	GH	Ghana
331	-180	180	-90	180	GI	Gibraltar
332	-180	180	-90	180	GR	Greece
333	-180	180	-90	180	GL	Greenland
334	-180	180	-90	180	GD	Grenada
335	-180	180	-90	180	GP	Guadeloupe
336	-180	180	-90	180	GU	Guam
337	-180	180	-90	180	GT	Guatemala
338	-180	180	-90	180	GG	Guernsey
339	-180	180	-90	180	G	Guinea
340	-180	180	-90	180	GW	Guinea-Bissau
341	-180	180	-90	180	GY	Guyana
342	-180	180	-90	180	HT	Haiti
343	-180	180	-90	180	HM	Heard Island and Mcdonald Islands
344	-180	180	-90	180	VA	Vatican City
345	-180	180	-90	180	H	Honduras
346	-180	180	-90	180	HK	Hong Kong
347	-180	180	-90	180	HU	Hungary
348	-180	180	-90	180	IS	Iceland
349	-180	180	-90	180	I	India
350	-180	180	-90	180	ID	Indonesia
351	-180	180	-90	180	IR	Iran
352	-180	180	-90	180	IQ	Iraq
353	-180	180	-90	180	IE	Ireland
354	-180	180	-90	180	IM	Isle of Man
355	-180	180	-90	180	IL	Israel
356	-180	180	-90	180	IT	Italy
357	-180	180	-90	180	JM	Jamaica
358	-180	180	-90	180	JP	Japan
359	-180	180	-90	180	JE	Jersey
360	-180	180	-90	180	JO	Jordan
361	-180	180	-90	180	KZ	Kazakhstan
362	-180	180	-90	180	KE	Kenya
363	-180	180	-90	180	KI	Kiribati
364	-180	180	-90	180	KP	Democratic People's Republic of Korea
365	-180	180	-90	180	KR	Republic of Korea
366	-180	180	-90	180	KW	Kuwait
367	-180	180	-90	180	KG	Kyrgyzstan
368	-180	180	-90	180	LA	Laos
369	-180	180	-90	180	LV	Latvia
370	-180	180	-90	180	LB	Lebanon
371	-180	180	-90	180	LS	Lesotho
372	-180	180	-90	180	LR	Liberia
373	-180	180	-90	180	LY	Libyan Arab Jamahiriya
374	-180	180	-90	180	LI	Liechtenstein
375	-180	180	-90	180	LT	Lithuania
376	-180	180	-90	180	LU	Luxembourg
377	-180	180	-90	180	MO	Macao
378	-180	180	-90	180	MK	Macedonia, FYRO
379	-180	180	-90	180	MG	Madagascar
380	-180	180	-90	180	MW	Malawi
381	-180	180	-90	180	MY	Malaysia
382	-180	180	-90	180	MV	Maldives
383	-180	180	-90	180	ML	Mali
384	-180	180	-90	180	MT	Malta
385	-180	180	-90	180	MH	Marshall Islands
386	-180	180	-90	180	MQ	Martinique
387	-180	180	-90	180	MR	Mauritania
388	-180	180	-90	180	MU	Mauritius
389	-180	180	-90	180	YT	Mayotte
390	-180	180	-90	180	MX	Mexico
391	-180	180	-90	180	FM	Micronesia
392	-180	180	-90	180	MD	Moldova
393	-180	180	-90	180	MC	Monaco
394	-180	180	-90	180	M	Mongolia
395	-180	180	-90	180	ME	Montenegro
396	-180	180	-90	180	MS	Montserrat
397	-180	180	-90	180	MA	Morocco
398	-180	180	-90	180	MZ	Mozambique
399	-180	180	-90	180	MM	Myanmar
400	-180	180	-90	180	NA	Namibia
401	-180	180	-90	180	NR	Nauru
402	-180	180	-90	180	NP	Nepal
403	-180	180	-90	180	NL	Netherlands
404	-180	180	-90	180	A	Netherlands Antilles
405	-180	180	-90	180	NC	New Caledonia
406	-180	180	-90	180	NZ	New Zealand
407	-180	180	-90	180	NI	Nicaragua
408	-180	180	-90	180	NE	Niger
409	-180	180	-90	180	NG	Nigeria
410	-180	180	-90	180	NU	Niue
411	-180	180	-90	180	NF	Norfolk Island
412	-180	180	-90	180	MP	Northern Mariana Islands
413	-180	180	-90	180	NO	Norway
414	-180	180	-90	180	OM	Oman
415	-180	180	-90	180	PK	Pakistan
416	-180	180	-90	180	PW	Palau
417	-180	180	-90	180	PS	Palestinian Territory, Occupied
418	-180	180	-90	180	PA	Panama
419	-180	180	-90	180	PG	Papua New Guinea
420	-180	180	-90	180	PY	Paraguay
421	-180	180	-90	180	PE	Peru
422	-180	180	-90	180	PH	Philippines
423	-180	180	-90	180	P	Pitcair
424	-180	180	-90	180	PL	Poland
425	-180	180	-90	180	PT	Portugal
426	-180	180	-90	180	PR	Puerto Rico
427	-180	180	-90	180	QA	Qatar
428	-180	180	-90	180	RE	Réunion
429	-180	180	-90	180	RO	Romania
430	-180	180	-90	180	RU	Russian Federation
431	-180	180	-90	180	RW	Rwanda
432	-180	180	-90	180	BL	Saint Barthélemy
433	-180	180	-90	180	SH	Saint Helena
434	-180	180	-90	180	K	Saint Kitts And Nevis
435	-180	180	-90	180	LC	Saint Lucia
436	-180	180	-90	180	MF	Saint Martin
437	-180	180	-90	180	PM	Saint Pierre And Miquelon
438	-180	180	-90	180	VC	Saint Vincent And The Grenadines
439	-180	180	-90	180	WS	Samoa
440	-180	180	-90	180	SM	San Marino
441	-180	180	-90	180	ST	Sao Tome And Principe
442	-180	180	-90	180	SA	Saudi Arabia
443	-180	180	-90	180	S	Senegal
444	-180	180	-90	180	RS	Serbia
445	-180	180	-90	180	SC	Seychelles
446	-180	180	-90	180	SL	Sierra Leone
447	-180	180	-90	180	SG	Singapore
448	-180	180	-90	180	SK	Slovakia
449	-180	180	-90	180	SI	Slovenia
450	-180	180	-90	180	SB	Solomon Islands
451	-180	180	-90	180	SO	Somalia
452	-180	180	-90	180	ZA	South Africa
453	-180	180	-90	180	GS	South Georgia And The South Sandwich Islands
454	-180	180	-90	180	ES	Spain
455	-180	180	-90	180	LK	Sri Lanka
456	-180	180	-90	180	SD	Sudan
457	-180	180	-90	180	SR	Suriname
458	-180	180	-90	180	SJ	Svalbard And Jan Maye
459	-180	180	-90	180	SZ	Swaziland
460	-180	180	-90	180	SE	Sweden
461	-180	180	-90	180	CH	Switzerland
462	-180	180	-90	180	SY	Syrian Arab Republic
463	-180	180	-90	180	TW	Taiwan, Province Of China
464	-180	180	-90	180	TJ	Tajikistan
465	-180	180	-90	180	TZ	Tanzania, United Republic Of
466	-180	180	-90	180	TH	Thailand
467	-180	180	-90	180	TL	Timor-Leste
468	-180	180	-90	180	TG	Togo
469	-180	180	-90	180	TK	Tokelau
470	-180	180	-90	180	TO	Tonga
471	-180	180	-90	180	TT	Trinidad And Tobago
472	-180	180	-90	180	T	Tunisia
473	-180	180	-90	180	TR	Turkey
474	-180	180	-90	180	TM	Turkmenistan
475	-180	180	-90	180	TC	Turks And Caicos Islands
476	-180	180	-90	180	TV	Tuvalu
477	-180	180	-90	180	UG	Uganda
478	-180	180	-90	180	UA	Ukraine
479	-180	180	-90	180	AE	United Arab Emirates
480	-180	180	-90	180	GB	United Kingdom
481	-180	180	-90	180	US	United States
482	-180	180	-90	180	UM	United States Minor Outlying Islands
483	-180	180	-90	180	UY	Uruguay
484	-180	180	-90	180	UZ	Uzbekistan
485	-180	180	-90	180	VU	Vanuatu
486	-180	180	-90	180	VE	Venezuela, Bolivarian Republic Of
487	-180	180	-90	180	V	Viet Nam
488	-180	180	-90	180	VG	Virgin Islands, British
489	-180	180	-90	180	VI	Virgin Islands, U.S.
490	-180	180	-90	180	WF	Wallis And Futuna
491	-180	180	-90	180	EH	Western Sahara
492	-180	180	-90	180	YE	Yemen
493	-180	180	-90	180	ZM	Zambia
494	-180	180	-90	180	ZW	Zimbabwe
\.


--
-- TOC entry 2607 (class 0 OID 113906)
-- Dependencies: 179
-- Data for Name: default_flexible_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY default_flexible_element (type, id_flexible_element) FROM stdin;
CODE	3
TITLE	4
COUNTRY	5
CODE	41
TITLE	42
COUNTRY	43
MANAGER	44
ORG_UNIT	45
CODE	69
TITLE	70
BUDGET	71
COUNTRY	72
MANAGER	73
ORG_UNIT	74
START_DATE	110
END_DATE	111
ORG_UNIT	112
TITLE	113
BUDGET	114
CODE	115
COUNTRY	119
MANAGER	120
OWNER	121
START_DATE	322
END_DATE	323
ORG_UNIT	324
BUDGET	325
CODE	326
TITLE	327
COUNTRY	328
OWNER	329
MANAGER	330
START_DATE	439
END_DATE	440
ORG_UNIT	441
BUDGET	442
CODE	443
TITLE	444
COUNTRY	445
OWNER	446
MANAGER	447
START_DATE	1135
END_DATE	1136
ORG_UNIT	1137
BUDGET	1138
CODE	1139
TITLE	1140
COUNTRY	1141
OWNER	1142
MANAGER	1143
START_DATE	1281
END_DATE	1282
TITLE	1283
ORG_UNIT	1284
BUDGET	1285
CODE	1286
COUNTRY	1290
MANAGER	1291
OWNER	1292
\.


--
-- TOC entry 2608 (class 0 OID 113909)
-- Dependencies: 180
-- Data for Name: file_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY file_meta (id_file, datedeleted, name) FROM stdin;
1626	\N	PlaquetteSigmahA5
1629	\N	PosterSigmah_inEnglish
1632	\N	PosterSigmah_inEnglish
\.


--
-- TOC entry 2609 (class 0 OID 113915)
-- Dependencies: 181
-- Data for Name: file_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY file_version (id_file_version, added_date, comments, datedeleted, extension, name, path, size, version_number, id_author, id_file) FROM stdin;
1627	2013-02-05 16:42:08.662	\N	\N	pdf	PlaquetteSigmahA5	f79f15b3-45d3-420b-b77b-e9e91dad28b01360078928663	628330	1	1540	1626
1630	2013-02-05 16:45:13.8	\N	\N	pdf	PosterSigmah_inEnglish	2bcc2713-79eb-4c63-926a-cc725eeb664e1360079113800	1716685	1	1540	1629
1633	2013-02-05 16:46:20.731	\N	\N	pdf	PosterSigmah_inEnglish	7c7a7651-04c3-4e71-9a8d-31d3847bf9e41360079180731	1716685	1	1540	1632
1635	2013-02-05 16:46:31.331	\N	\N	pdf	PosterSigmah_enFrancais	9aef3390-9f3d-4510-a575-94a5579921c31360079191331	1726994	2	1540	1632
\.


--
-- TOC entry 2610 (class 0 OID 113921)
-- Dependencies: 182
-- Data for Name: files_list_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY files_list_element (max_limit, id_flexible_element) FROM stdin;
\N	64
\N	67
\N	94
1	184
4	189
1	211
1	225
4	226
5	227
3	239
4	293
1	307
1	356
\N	374
\N	375
\N	376
\N	377
\N	378
1	379
\N	380
\N	381
\N	382
\N	383
\N	384
\N	385
\N	386
\N	387
1	414
1	415
1	416
1	417
2	475
\N	476
\N	477
\N	478
\N	479
\N	480
1	481
\N	482
\N	589
2	590
5	591
2	592
5	593
5	594
5	595
5	596
5	597
5	598
5	599
10	600
1	647
\N	648
\N	649
\N	757
\N	758
\N	759
\N	760
1	761
5	762
5	763
5	764
5	765
5	766
5	767
5	768
5	769
5	770
10	771
1	772
\N	1018
\N	1145
1	1176
\N	1196
\N	1197
\N	1198
\N	1199
\N	1200
1	1201
\N	1202
\N	1203
\N	1204
\N	1205
\N	1206
\N	1207
\N	1208
\N	1209
1	1236
1	1237
1	1238
1	1239
1	1357
4	1362
1	1403
1	1417
4	1418
5	1419
3	1431
4	1485
1	1499
\.


--
-- TOC entry 2611 (class 0 OID 113924)
-- Dependencies: 183
-- Data for Name: flexible_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY flexible_element (id_flexible_element, amendable, label, validates, id_privacy_group, exportable, globally_exportable) FROM stdin;
3	f	DefaultEmptyOrgUnit-code	t	\N	t	t
4	f	DefaultEmptyOrgUnit-title	t	\N	t	t
5	f	DefaultEmptyOrgUnit-country	t	\N	t	t
41	f	\N	f	\N	t	t
42	f	\N	f	\N	t	t
43	f	\N	f	\N	t	t
44	f	\N	f	\N	t	t
45	f	\N	f	\N	t	t
64	f	​Stratégie régionale	f	\N	t	t
67	f	​Plan stratégique annuel	f	\N	t	t
69	f	\N	f	\N	t	t
70	f	\N	f	\N	t	t
71	f	\N	f	\N	t	t
72	f	\N	f	\N	t	t
73	f	\N	f	\N	t	t
74	f	\N	f	\N	t	t
110	t	Date de dbut	t	\N	t	t
111	t	\N	t	\N	t	t
112	f	Zone dintervention	f	\N	t	t
113	f	\N	f	\N	t	t
114	f	\N	t	\N	t	t
115	f	\N	f	\N	t	t
116	f	Numéro de contrat	t	\N	t	t
117	t	Date de début d'éligibilité	t	\N	t	t
118	t	Nombre de mois	t	\N	t	t
119	f	\N	f	\N	t	t
120	f	\N	f	\N	t	t
121	f	\N	f	\N	t	t
122	f	Devise	t	\N	t	t
126	t	% de prise en charge frais de gestion	t	\N	t	t
127	t	Montant de la subvention	t	\N	t	t
128	t	Montant du projet	t	\N	t	t
129	t	Pourcentage de cofinancement	t	\N	t	t
130	f	Autres contributeurs	f	\N	t	t
141	f	Prise en charge TVA	t	\N	t	t
142	f	Taux de change applicable	t	\N	t	t
184	t	Concept Note	f	\N	t	t
185	t	Statut Concept Note	f	\N	t	t
189	t	Proposal et Annexes	t	\N	t	t
190	t	Statut proposal	t	\N	t	t
194	f	Thématique du projet	t	\N	t	t
205	t	Type de bénéficiaires	t	\N	t	t
211	t	Contrat de financement	t	\N	t	t
225	t	Notes de suivi contractuel	t	\N	t	t
226	t	Cover letter	f	\N	t	t
227	t	Autres documents	f	\N	t	t
228	f	Versements prévus	t	\N	t	t
231	t	Paiement 1  Date	f	\N	t	t
232	t	Paiement 1  Montant	f	\N	t	t
233	t	Paiement 2 Date	f	\N	t	t
234	t	Paiement 2 Montant	f	\N	t	t
235	t	Paiement 3 Date	f	\N	t	t
236	t	Paiement 3 Montant	f	\N	t	t
237	t	Paiement 4 Date	f	\N	t	t
238	t	Paiement 4 Montant	f	\N	t	t
239	t	RI	t	\N	t	t
240	t	Statut	f	\N	t	t
244	f	Nombre prévu	f	\N	t	t
245	f	Echéances	f	\N	t	t
249	f	Supports à  fournir   (cocher pour valider)	f	\N	t	t
259	f	Audit bailleur terrain	f	\N	t	t
262	t	Objet	f	\N	t	t
263	t	Date	f	\N	t	t
293	t	Rapport final	t	\N	t	t
294	f	Statut rapport final	t	\N	t	t
299	f	Nombre prévu	f	\N	t	t
300	f	Echéances	f	\N	t	t
304	t	Paiement final	t	\N	t	t
307	t	Note finale	t	\N	t	t
322	f	Date de dbut	f	\N	t	t
323	f	\N	f	\N	t	t
324	f	Zone dintervention	f	\N	t	t
325	f	\N	f	\N	t	t
326	f	\N	f	\N	t	t
327	f	\N	f	\N	t	t
328	f	\N	f	\N	t	t
329	f	\N	f	\N	t	t
330	f	\N	f	\N	t	t
356	f	Fiche de risque	f	\N	t	t
357	f	Zone d'intervention	f	\N	t	t
366	f	Contexte et champs d'intervention	f	\N	t	t
374	f	Accords de coopération, proposition et budget des partenaires	f	\N	t	t
375	f	Etudes préliminaires	f	\N	t	t
376	f	Evaluation des partenaires	f	\N	t	t
377	f	Rapports d'activités des partenaires	f	\N	t	t
378	f	Rapports et communication autres acteurs	f	\N	t	t
379	f	Budget	f	\N	t	t
380	f	Documents stratégiques annuels / pluriannuels	f	\N	t	t
381	f	Documents stratégiques programmes	f	\N	t	t
382	f	Monitoring des activités	f	\N	t	t
383	f	Rapports de distribution et listes d'émargement	f	\N	t	t
384	f	Informations techniques essentielles	f	\N	t	t
385	f	Support de sensibilisation	f	\N	t	t
386	f	Externe	f	\N	t	t
387	f	Interne	f	\N	t	t
411	f	Date de début	f	\N	t	t
412	f	Date de fin	f	\N	t	t
413	f	Nom de l'évaluateur	f	\N	t	t
414	f	CV	f	\N	t	t
415	f	TDR	f	\N	t	t
416	f	Budget de l'évaluation	f	\N	t	t
417	f	Rapport d'évaluation	f	\N	t	t
418	f	Validation des financements	t	\N	t	t
439	f	\N	f	\N	t	t
440	f	\N	f	\N	t	t
441	f	\N	f	\N	t	t
442	f	\N	f	\N	t	t
443	f	\N	f	\N	t	t
444	f	\N	f	\N	t	t
445	f	\N	f	\N	t	t
446	f	\N	f	\N	t	t
447	f	\N	f	\N	t	t
474	f	Rapport Mensuel	f	\N	t	t
475	f	Suivi des échéances bailleurs	f	\N	t	t
476	f	Rapports autres acteurs	f	\N	t	t
477	f	Communication stratégique	f	\N	t	t
478	f	CR réunion de coordination	f	\N	t	t
479	f	Documents juridiques	f	\N	t	t
480	f	CR réunions stratégiques	f	\N	t	t
481	f	Plan sécurité	f	\N	t	t
482	f	Autres documents	f	\N	t	t
483	f	Nom de la mission financière 1	f	\N	t	t
484	f	Saisie en cours	f	\N	t	t
497	f	Clôture provisoire électronique envoyée	f	\N	t	t
510	f	Clôture définitive reçue	f	\N	t	t
523	f	Clôture extracomptable reçue	f	\N	t	t
536	f	Nom de la mission financière 2	f	\N	t	t
537	f	Saisie en cours	f	\N	t	t
550	f	Clôture provisoire électronique envoyée	f	\N	t	t
563	f	Clôture définitive reçue	f	\N	t	t
576	f	Clôture extracomptable reçue	f	\N	t	t
589	f	Suivi comptabilité papier	f	\N	t	t
590	f	BFU	f	\N	t	t
591	f	Pilotage terrain / siège	f	\N	t	t
592	f	Tableau d'affectation des coûts	f	\N	t	t
1491	f	Nombre prévu	f	\N	t	t
593	f	Suivi stock (hebdo et mensuel)	f	\N	t	t
594	f	Suivi des BDR	f	\N	t	t
595	f	Inventaire des équipements	f	\N	t	t
596	f	Suivi des contrats	f	\N	t	t
597	f	Suivi des consommations	f	\N	t	t
598	f	TPM	f	\N	t	t
599	f	Liste des moyens de communication	f	\N	t	t
600	f	Organigramme	f	\N	t	t
647	f	Suivi échéances bailleurs	f	\N	t	t
648	f	Rapports autres acteurs	f	\N	t	t
649	f	Communication	f	\N	t	t
650	f	Rapport Mensuel	f	\N	t	t
651	f	Nom de la mission financière 1	f	\N	t	t
652	f	Saisie en cours	f	\N	t	t
665	f	Clôture provisoire électronique envoyée	f	\N	t	t
678	f	Clôture définitive reçue	f	\N	t	t
691	f	Extracomptable reçue	f	\N	t	t
704	f	Nom de la mission financière 2 	f	\N	t	t
705	f	Saisie en cours	f	\N	t	t
718	f	Clôture provisoire électronique envoyée	f	\N	t	t
731	f	Clôture définitive reçue	f	\N	t	t
744	f	Extracomptable reçue	f	\N	t	t
757	f	Suivi comptabilité papier	f	\N	t	t
758	f	CR réunions de coordination	f	\N	t	t
759	f	Documents juridiques	f	\N	t	t
760	f	CR réunions stratégiques	f	\N	t	t
761	f	BFU	f	\N	t	t
762	f	Pilotage terrain/siège	f	\N	t	t
763	f	Tableau d'affectation des coûts	f	\N	t	t
764	f	Suivi des stocks (hebdo+mensuel)	f	\N	t	t
765	f	Suivi des BDR	f	\N	t	t
766	f	Inventaire des équipements	f	\N	t	t
767	f	Suivi des contrats	f	\N	t	t
768	f	TPM	f	\N	t	t
769	f	Suivi des consommations	f	\N	t	t
770	f	Liste des moyens de communication	f	\N	t	t
771	f	Organigrammes	f	\N	t	t
772	f	Plan sécurité	f	\N	t	t
94	f	​Rapports de mission mensuels	f	\N	t	t
933	f	​Rapport de mission	f	\N	t	t
1018	f	​Evaluations des membres de l'équipe	f	996	t	t
994	f	​Taille de l'équipe projet	f	32	t	t
1135	f	Date de dbut	f	\N	t	t
1136	f	\N	f	\N	t	t
1137	f	Zone dintervention	f	\N	t	t
1138	f	\N	f	\N	t	t
1139	f	\N	f	\N	t	t
1140	f	\N	f	\N	t	t
1141	f	\N	f	\N	t	t
1142	f	\N	f	\N	t	t
1143	f	\N	f	\N	t	t
1144	f	​Taille de l'équipe projet	f	\N	t	t
1145	f	​Evaluations des membres de l'équipe	f	\N	t	t
1176	f	Fiche de risque	f	\N	t	t
1177	f	Zone d'intervention	f	\N	t	t
1186	f	Contexte et champs d'intervention	f	\N	t	t
1187	f	​Rapport de mission	f	\N	t	t
1196	f	Accords de coopération, proposition et budget des partenaires	f	\N	t	t
1197	f	Etudes préliminaires	f	\N	t	t
1198	f	Evaluation des partenaires	f	\N	t	t
1199	f	Rapports d'activités des partenaires	f	\N	t	t
1200	f	Rapports et communication autres acteurs	f	\N	t	t
1201	f	Budget	f	\N	t	t
1202	f	Documents stratégiques annuels / pluriannuels	f	\N	t	t
1203	f	Documents stratégiques programmes	f	\N	t	t
1204	f	Monitoring des activités	f	\N	t	t
1205	f	Rapports de distribution et listes d'émargement	f	\N	t	t
1206	f	Informations techniques essentielles	f	\N	t	t
1207	f	Support de sensibilisation	f	\N	t	t
1208	f	Externe	f	\N	t	t
1209	f	Interne	f	\N	t	t
1233	f	Date de début	f	\N	t	t
1234	f	Date de fin	f	\N	t	t
1235	f	Nom de l'évaluateur	f	\N	t	t
1236	f	CV	f	\N	t	t
1237	f	TDR	f	\N	t	t
1238	f	Budget de l'évaluation	f	\N	t	t
1239	f	Rapport d'évaluation	f	\N	t	t
1240	f	Validation des financements	t	\N	t	t
1281	t	Date de dbut	t	\N	t	t
1282	t	\N	t	\N	t	t
1283	f	\N	f	\N	t	t
1284	f	Zone dintervention	f	\N	t	t
1285	f	\N	t	\N	t	t
1286	f	\N	f	\N	t	t
1287	f	Numéro de contrat	t	\N	t	t
1288	t	Date de début d'éligibilité	t	\N	t	t
1289	t	Nombre de mois	t	\N	t	t
1290	f	\N	f	\N	t	t
1291	f	\N	f	\N	t	t
1292	f	\N	f	\N	t	t
1293	f	Devise	t	\N	t	t
1297	t	% de prise en charge frais de gestion	t	\N	t	t
1298	t	Montant de la subvention	t	\N	t	t
1299	t	Montant du projet	t	\N	t	t
1300	t	Pourcentage de cofinancement	t	\N	t	t
1301	f	Autres contributeurs	f	\N	t	t
1312	f	Prise en charge TVA	t	\N	t	t
1313	f	Taux de change applicable	t	\N	t	t
1357	t	Concept Note	f	\N	t	t
1358	t	Statut Concept Note	f	\N	t	t
1362	t	Proposal et Annexes	t	\N	t	t
1363	t	Statut proposal	t	\N	t	t
1367	f	Thématique du projet	t	\N	t	t
1390	t	Type de bénéficiaires	t	\N	t	t
1403	t	Contrat de financement	t	\N	t	t
1417	t	Notes de suivi contractuel	t	\N	t	t
1418	t	Cover letter	f	\N	t	t
1419	t	Autres documents	f	\N	t	t
1420	f	Versements prévus	t	\N	t	t
1423	t	Paiement 1  Date	f	\N	t	t
1424	t	Paiement 1  Montant	f	\N	t	t
1425	t	Paiement 2 Date	f	\N	t	t
1426	t	Paiement 2 Montant	f	\N	t	t
1427	t	Paiement 3 Date	f	\N	t	t
1428	t	Paiement 3 Montant	f	\N	t	t
1429	t	Paiement 4 Date	f	\N	t	t
1430	t	Paiement 4 Montant	f	\N	t	t
1431	t	RI	t	\N	t	t
1432	t	Statut	f	\N	t	t
1436	f	Nombre prévu	f	\N	t	t
1437	f	Echéances	f	\N	t	t
1441	f	Supports à  fournir   (cocher pour valider)	f	\N	t	t
1451	f	Audit bailleur terrain	f	\N	t	t
1454	t	Objet	f	\N	t	t
1455	t	Date	f	\N	t	t
1485	t	Rapport final	t	\N	t	t
1486	f	Statut rapport final	t	\N	t	t
1492	f	Echéances	f	\N	t	t
1496	t	Paiement final	t	\N	t	t
1499	t	Note finale	t	\N	t	t
\.


--
-- TOC entry 2612 (class 0 OID 113932)
-- Dependencies: 184
-- Data for Name: global_export; Type: TABLE DATA; Schema: public; Owner: -
--

COPY global_export (id, generated_date, organization_id) FROM stdin;
\.


--
-- TOC entry 2613 (class 0 OID 113935)
-- Dependencies: 185
-- Data for Name: global_export_content; Type: TABLE DATA; Schema: public; Owner: -
--

COPY global_export_content (id, csv_content, project_model_name, global_export_id) FROM stdin;
\.


--
-- TOC entry 2614 (class 0 OID 113941)
-- Dependencies: 186
-- Data for Name: global_export_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY global_export_settings (id, auto_delete_frequency, auto_export_frequency, default_organization_export_format, export_format, last_export_date, locale_string, organization_id) FROM stdin;
1539	\N	\N	XLS	XLS	\N	fr	1
\.


--
-- TOC entry 2615 (class 0 OID 113947)
-- Dependencies: 187
-- Data for Name: global_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY global_permission (id_global_permission, permission, id_profile) FROM stdin;
1552	MANAGE_UNIT	22
1553	MANAGE_USER	22
1554	VIEW_ADMIN	22
1555	CHANGE_PHASE	22
1556	EDIT_PROJECT	22
1557	DELETE_PROJECT	22
1558	REMOVE_FILE	22
1559	CREATE_PROJECT	22
1560	VIEW_PROJECT	22
1561	GLOBAL_EXPORT	22
1562	VALID_AMENDEMENT	22
1575	MANAGE_UNIT	880
1576	MANAGE_USER	880
1577	VIEW_ADMIN	880
1578	CHANGE_PHASE	880
1579	EDIT_PROJECT	880
1580	REMOVE_FILE	880
1581	CREATE_PROJECT	880
1582	VIEW_PROJECT	880
1583	GLOBAL_EXPORT	880
1584	VALID_AMENDEMENT	880
\.


--
-- TOC entry 2616 (class 0 OID 113952)
-- Dependencies: 189
-- Data for Name: history_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY history_token (id_history_token, history_date, id_element, id_project, change_type, value, id_user) FROM stdin;
37	2012-11-19 15:40:27.548	3	21	ADD	emptyHQ	\N
38	2012-11-19 15:40:27.549	3	21	EDIT	HQ	35
39	2012-11-19 15:40:27.548	4	21	ADD	Empty HeadQuarters	\N
40	2012-11-19 15:40:27.549	4	21	EDIT	Siège (Bordeaux)	35
866	2012-11-21 17:27:09.72	194	854	EDIT	839~838	35
868	2012-11-21 17:27:09.72	205	854	EDIT	850~848	35
1046	2012-11-28 00:38:29.669	322	1034	ADD	1354057200000	918
1047	2012-11-28 00:39:05.324	322	1034	EDIT	1333231200000	918
1048	2012-11-28 00:39:05.324	323	1034	EDIT	1419980400000	918
1062	2012-11-28 00:38:29.669	325	1034	ADD	35000.0~	918
1063	2012-11-28 00:40:22.233	325	1034	EDIT	350000~0~0	918
1064	2012-11-28 00:40:07.026	110	1050	ADD	1354057200000	918
1065	2012-11-28 00:41:40.406	110	1050	EDIT	1338501600000	918
1066	2012-11-28 00:41:40.406	117	1050	EDIT	1372543200000	918
1081	2012-11-28 00:40:07.026	115	1050	ADD	UNH1203	918
1082	2012-11-28 00:43:15.149	115	1050	EDIT	HAB1203	918
1083	2012-11-28 00:44:04.342	111	1050	EDIT	1372543200000	918
1084	2012-11-28 00:44:04.342	117	1050	EDIT	1338501600000	918
1085	2012-11-28 00:43:02.839	110	1069	ADD	1354057200000	918
1086	2012-11-28 00:45:07.498	110	1069	EDIT	1356994800000	918
1087	2012-11-28 00:45:07.498	111	1069	EDIT	1419980400000	918
1088	2012-11-28 00:43:02.839	115	1069	ADD	UCF	918
1089	2012-11-28 00:45:07.498	115	1069	EDIT	UCF1217	918
1090	2012-11-28 00:46:17.964	194	1050	EDIT	838	918
1092	2012-11-28 00:46:17.964	205	1050	EDIT	850	918
1094	2012-11-28 00:46:46.899	194	1069	EDIT	838	918
1096	2012-11-28 00:46:46.899	205	1069	EDIT	850	918
1111	2012-11-28 00:48:34.739	110	1099	ADD	1354057200000	918
1112	2012-11-28 00:49:26.401	110	1099	EDIT	1293836400000	918
1113	2012-11-28 00:49:26.401	111	1099	EDIT	1388444400000	918
1128	2012-11-28 00:50:53.049	439	1115	ADD	1354057200000	918
1129	2012-11-28 00:52:04.957	439	1115	EDIT	1333231200000	918
1130	2012-11-28 00:52:04.957	440	1115	EDIT	1419980400000	918
1131	2012-11-28 00:53:09.876	194	1099	EDIT	838~839~841	918
1133	2012-11-28 00:53:09.876	205	1099	EDIT	850	918
\.


--
-- TOC entry 2617 (class 0 OID 113958)
-- Dependencies: 190
-- Data for Name: indicator; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indicator (indicatorid, aggregation, category, listheader, collectintervention, collectmonitoring, datedeleted, description, name, objective, sortorder, units, activityid, databaseid, id_quality_criterion, sourceofverification, directdataentryenabled) FROM stdin;
1273	0	\N	i1	t	f	\N	\N	indic	\N	0	m	\N	1261	\N	\N	t
1526	0	A. couou	i2	f	f	\N	\N	indic2	\N	0	kg	\N	1261	\N	\N	t
1534	0	A. couou	i2	f	f	\N	\N	indic2	\N	0	kg	\N	1514	\N	\N	t
\.


--
-- TOC entry 2618 (class 0 OID 113965)
-- Dependencies: 191
-- Data for Name: indicator_datasource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indicator_datasource (indicatorid, indicatorsourceid) FROM stdin;
\.


--
-- TOC entry 2619 (class 0 OID 113968)
-- Dependencies: 192
-- Data for Name: indicator_labels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indicator_labels (indicator_indicatorid, element, code) FROM stdin;
\.


--
-- TOC entry 2620 (class 0 OID 113971)
-- Dependencies: 193
-- Data for Name: indicatordatasource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indicatordatasource (indicatorid, indicatorsourceid) FROM stdin;
\.


--
-- TOC entry 2621 (class 0 OID 113974)
-- Dependencies: 194
-- Data for Name: indicators_list_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indicators_list_element (id_flexible_element) FROM stdin;
\.


--
-- TOC entry 2622 (class 0 OID 113977)
-- Dependencies: 195
-- Data for Name: indicators_list_value; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indicators_list_value (id_indicators_list, id_indicator) FROM stdin;
\.


--
-- TOC entry 2623 (class 0 OID 113980)
-- Dependencies: 196
-- Data for Name: indicatorvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indicatorvalue (indicatorid, reportingperiodid, value) FROM stdin;
1273	1279	5
1273	1280	10
1526	1279	30
1526	1280	800
\.


--
-- TOC entry 2624 (class 0 OID 113983)
-- Dependencies: 197
-- Data for Name: keyquestion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY keyquestion (id, sort_order, label, sectionid, qualitycriterion_id_quality_criterion) FROM stdin;
\.


--
-- TOC entry 2625 (class 0 OID 113986)
-- Dependencies: 198
-- Data for Name: layout; Type: TABLE DATA; Schema: public; Owner: -
--

COPY layout (id_layout, columns_count, rows_count) FROM stdin;
6	3	2
48	3	2
56	1	2
14	1	2
77	3	2
85	1	2
148	3	2
161	1	2
213	1	3
265	1	6
309	1	4
333	3	2
368	1	1
389	1	6
422	1	3
436	1	1
451	3	2
463	1	1
602	1	12
774	1	11
818	1	1
345	1	2
1150	3	2
1162	1	2
1189	1	1
1211	1	6
1244	1	3
1258	1	1
1321	3	2
1334	1	2
1405	1	3
1457	1	6
1501	1	4
\.


--
-- TOC entry 2626 (class 0 OID 113989)
-- Dependencies: 199
-- Data for Name: layout_constraint; Type: TABLE DATA; Schema: public; Owner: -
--

COPY layout_constraint (id_layout_constraint, sort_order, id_flexible_element, id_layout_group) FROM stdin;
8	0	3	7
10	0	4	9
12	0	5	11
16	1	3	15
17	2	4	15
18	3	5	15
58	0	41	57
59	1	42	57
60	2	43	57
61	3	44	57
62	4	45	57
65	10	64	63
68	10	67	66
87	0	69	86
88	1	70	86
89	2	71	86
90	3	72	86
91	4	73	86
92	5	74	86
95	10	94	93
150	1	110	149
152	2	111	151
154	3	112	153
155	3	113	153
157	4	114	156
163	0	115	162
164	1	113	162
165	3	116	162
166	4	110	162
167	5	117	162
168	6	111	162
169	7	118	162
170	8	119	162
171	9	120	162
172	10	121	162
173	11	112	162
175	0	114	174
176	0	122	174
177	1	126	174
178	2	127	174
179	3	128	174
180	4	129	174
181	5	130	174
182	6	141	174
183	7	142	174
216	0	184	215
217	1	185	215
218	2	189	215
219	3	190	215
221	0	194	220
222	1	205	220
224	0	211	223
268	0	225	267
270	0	226	269
271	1	227	269
273	0	228	272
274	1	231	272
275	2	232	272
276	3	233	272
277	4	234	272
278	5	235	272
279	6	236	272
280	7	237	272
281	8	238	272
283	0	239	282
284	1	240	282
286	0	244	285
287	1	245	285
288	2	249	285
290	0	259	289
291	1	262	289
292	2	263	289
312	0	293	311
313	1	294	311
316	0	299	315
317	1	300	315
319	0	304	318
320	1	307	318
335	1	322	334
337	2	323	336
339	3	324	338
341	4	325	340
347	0	326	346
348	1	327	346
349	2	325	346
350	3	322	346
351	4	323	346
352	5	328	346
353	6	329	346
354	7	330	346
355	8	324	346
371	0	356	370
372	1	357	370
373	2	366	370
392	0	374	391
393	1	375	391
394	2	376	391
395	3	377	391
397	4	378	396
399	0	379	398
401	0	380	400
402	1	381	400
404	0	382	403
405	1	383	403
406	2	384	403
407	3	385	403
409	0	386	408
410	1	387	408
425	0	411	424
426	1	412	424
427	2	413	424
428	3	414	424
429	4	415	424
430	5	416	424
431	5	417	424
433	0	418	432
453	1	439	452
455	2	440	454
457	3	441	456
459	4	442	458
465	0	443	464
466	1	444	464
467	2	442	464
468	3	439	464
469	4	440	464
470	5	445	464
471	6	446	464
472	7	447	464
473	8	441	464
605	0	474	604
607	0	475	606
608	1	476	606
609	2	477	606
611	0	478	610
612	50	479	610
613	100	480	610
618	0	481	617
620	0	482	619
622	0	483	621
623	1	484	621
624	2	497	621
625	3	510	621
626	4	523	621
627	5	536	621
628	6	537	621
629	6	550	621
630	7	563	621
631	8	576	621
632	9	589	621
634	0	590	633
635	1	591	633
636	3	592	633
638	0	593	637
639	1	594	637
640	2	595	637
641	3	596	637
642	4	597	637
643	4	598	637
644	6	599	637
646	0	600	645
777	0	647	776
778	1	648	776
779	2	649	776
781	0	650	780
786	0	651	785
787	1	652	785
788	2	665	785
789	3	678	785
790	4	691	785
791	6	704	785
792	7	705	785
793	8	718	785
794	9	731	785
795	10	744	785
796	11	757	785
798	0	758	797
799	50	759	797
800	100	760	797
802	0	761	801
803	1	762	801
804	2	763	801
806	0	764	805
807	1	765	805
808	2	766	805
809	3	767	805
810	4	768	805
811	6	769	805
812	6	770	805
814	0	771	813
816	0	772	815
934	100	933	370
995	10	994	993
1019	20	1018	993
1152	1	1135	1151
1154	2	1136	1153
1156	3	1137	1155
1158	4	1138	1157
1164	0	1139	1163
1165	1	1140	1163
1166	2	1138	1163
1167	3	1135	1163
1168	4	1136	1163
1169	5	1141	1163
1170	6	1142	1163
1171	7	1143	1163
1172	8	1137	1163
1174	10	1144	1173
1175	20	1145	1173
1192	0	1176	1191
1193	1	1177	1191
1194	2	1186	1191
1195	100	1187	1191
1214	0	1196	1213
1215	1	1197	1213
1216	2	1198	1213
1217	3	1199	1213
1219	4	1200	1218
1221	0	1201	1220
1223	0	1202	1222
1224	1	1203	1222
1226	0	1204	1225
1227	1	1205	1225
1228	2	1206	1225
1229	3	1207	1225
1231	0	1208	1230
1232	1	1209	1230
1247	0	1233	1246
1248	1	1234	1246
1249	2	1235	1246
1250	3	1236	1246
1251	4	1237	1246
1252	5	1238	1246
1253	5	1239	1246
1256	0	1240	1255
1323	1	1281	1322
1325	2	1282	1324
1327	3	1283	1326
1328	3	1284	1326
1330	4	1285	1329
1336	0	1286	1335
1337	1	1283	1335
1338	3	1287	1335
1339	4	1281	1335
1340	5	1288	1335
1341	6	1282	1335
1342	7	1289	1335
1343	8	1290	1335
1344	9	1291	1335
1345	10	1292	1335
1346	11	1284	1335
1348	0	1285	1347
1349	0	1293	1347
1350	1	1297	1347
1351	2	1298	1347
1352	3	1299	1347
1353	4	1300	1347
1354	5	1301	1347
1355	6	1312	1347
1356	7	1313	1347
1408	0	1357	1407
1409	1	1358	1407
1410	2	1362	1407
1411	3	1363	1407
1413	0	1367	1412
1414	1	1390	1412
1416	0	1403	1415
1460	0	1417	1459
1462	0	1418	1461
1463	1	1419	1461
1465	0	1420	1464
1466	1	1423	1464
1467	2	1424	1464
1468	3	1425	1464
1469	4	1426	1464
1470	5	1427	1464
1471	6	1428	1464
1472	7	1429	1464
1473	8	1430	1464
1475	0	1431	1474
1476	1	1432	1474
1478	0	1436	1477
1479	1	1437	1477
1480	2	1441	1477
1482	0	1451	1481
1483	1	1454	1481
1484	2	1455	1481
1504	0	1485	1503
1505	1	1486	1503
1508	0	1491	1507
1509	1	1492	1507
1511	0	1496	1510
1512	1	1499	1510
\.


--
-- TOC entry 2627 (class 0 OID 113992)
-- Dependencies: 200
-- Data for Name: layout_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY layout_group (id_layout_group, column_index, row_index, title, id_layout) FROM stdin;
7	0	0	\N	6
9	0	1	\N	6
11	1	0	\N	6
49	0	0	\N	48
50	0	1	\N	48
51	1	0	\N	48
52	1	1	\N	48
53	2	0	\N	48
54	2	1	\N	48
63	0	1	Autres documents	56
57	0	0	Informations de base	56
15	0	0	Informations de base	14
66	0	1	Autres documents	14
78	0	0	\N	77
79	0	1	\N	77
80	1	0	\N	77
81	1	1	\N	77
82	2	0	\N	77
83	2	1	\N	77
86	0	0	Informations de base	85
93	0	1	Autres documents	85
149	0	0	\N	148
151	0	1	\N	148
153	1	0	\N	148
156	1	1	\N	148
158	2	0	\N	148
159	2	1	\N	148
162	0	0	Informations générales	161
174	0	1	Informations budget	161
214	0	0	Default phase group	213
215	0	0	Informations générales	213
220	0	1	Secteur d'intervention	213
223	0	2	Autres	213
266	0	0	Phase de suivi default group	265
267	0	0	Informations générales	265
269	0	1	Demandes de modifications	265
272	0	2	Trésorerie	265
282	0	3	Rapports Intermédiaires	265
285	0	4	Vérification des dépenses	265
289	0	5	Monitoring et audits	265
310	0	0	Liquidation default group	309
311	0	0	Rapport final	309
314	0	1	Statut du rapport final	309
315	0	1	Vérification des dépenses	309
318	0	3	Clotûre	309
334	0	0	\N	333
336	0	1	\N	333
338	1	0	\N	333
340	1	1	\N	333
342	2	0	\N	333
343	2	1	\N	333
346	0	0	Informations générales	345
369	0	0	Default phase group	368
370	0	0	Informations générales	368
390	0	0	Mise en oeuvre et suivi du projet default group	389
391	0	0	Coordination avec les partenaires	389
396	0	1	Coordination	389
398	0	2	Finances	389
400	0	3	Stratégie	389
403	0	4	Opérationnel	389
408	0	5	Etudes d'impact / Evaluation 	389
423	0	0	Evaluation	422
424	0	0	Informations principales evaluation	422
434	0	1	Informations principales projet	422
437	0	0	Liquidation default group	436
452	2	1	\N	451
454	2	0	\N	451
456	1	1	\N	451
458	1	0	\N	451
460	0	0	\N	451
461	0	1	\N	451
464	0	0	Informations générales	463
603	0	0	Default phase group	602
604	0	0	Rapports internes	602
606	0	1	Rapports externes	602
610	0	2	Coordination interne	602
614	0	3	Coopération SN	602
615	0	4	Coopération Mouvement	602
616	0	5	Coopération hors Mouvement	602
617	0	8	Sécurité	602
619	0	9	Autres documents	602
621	0	3	Comptabilité	602
633	0	4	Finances	602
637	0	5	Logistique	602
645	0	6	RH	602
775	0	0	N+1 default group	774
776	0	1	Rapports externes	774
780	0	0	Rapports internes	774
782	0	3	Coopération SN	774
783	0	4	Coopération Mouvement	774
784	0	5	Coopération Hors Mouvement	774
785	0	3	Comptabilité	774
797	0	2	Coordination interne	774
801	0	4	Finances	774
805	0	5	Logistique	774
813	0	6	RH	774
815	0	7	Sécurité	774
819	0	0	N+2 default group	818
432	0	1	Validation des financements	422
993	0	1	Suivi RH	345
1151	0	0	\N	1150
1153	0	1	\N	1150
1155	1	0	\N	1150
1157	1	1	\N	1150
1159	2	0	\N	1150
1160	2	1	\N	1150
1163	0	0	Informations générales	1162
1173	0	1	Suivi RH	1162
1190	0	0	Default phase group	1189
1191	0	0	Informations générales	1189
1212	0	0	Mise en oeuvre et suivi du projet default group	1211
1213	0	0	Coordination avec les partenaires	1211
1218	0	1	Coordination	1211
1220	0	2	Finances	1211
1222	0	3	Stratégie	1211
1225	0	4	Opérationnel	1211
1230	0	5	Etudes d'impact / Evaluation 	1211
1245	0	0	Evaluation	1244
1246	0	0	Informations principales evaluation	1244
1254	0	1	Informations principales projet	1244
1255	0	1	Validation des financements	1244
1259	0	0	Liquidation default group	1258
1322	0	0	\N	1321
1324	0	1	\N	1321
1326	1	0	\N	1321
1329	1	1	\N	1321
1331	2	0	\N	1321
1332	2	1	\N	1321
1335	0	0	Informations générales	1334
1347	0	1	Informations budget	1334
1406	0	0	Default phase group	1405
1407	0	0	Informations générales	1405
1412	0	1	Secteur d'intervention	1405
1415	0	2	Autres	1405
1458	0	0	Phase de suivi default group	1457
1459	0	0	Informations générales	1457
1461	0	1	Demandes de modifications	1457
1464	0	2	Trésorerie	1457
1474	0	3	Rapports Intermédiaires	1457
1477	0	4	Vérification des dépenses	1457
1481	0	5	Monitoring et audits	1457
1502	0	0	Liquidation default group	1501
1503	0	0	Rapport final	1501
1506	0	1	Statut du rapport final	1501
1507	0	1	Vérification des dépenses	1501
1510	0	3	Clotûre	1501
\.


--
-- TOC entry 2628 (class 0 OID 113998)
-- Dependencies: 201
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY location (locationid, axe, datecreated, dateedited, locationguid, name, x, y, locationtypeid) FROM stdin;
1275	\N	2012-11-28 01:00:08.38	2012-11-28 01:00:08.38	\N	IFAID	\N	\N	1274
1277	\N	2012-11-28 01:00:23.293	2012-11-28 01:00:23.293	\N	G.URD	5.6030277777777773	44.182202777777775	1274
1535	\N	2012-11-28 01:03:47.834	2012-11-28 01:03:47.834	\N	aride	\N	\N	1274
1537	\N	2012-11-28 01:03:59.803	2012-11-28 01:03:59.803	\N	humide	0.74706944444444434	44.543505555555555	1274
\.


--
-- TOC entry 2629 (class 0 OID 114001)
-- Dependencies: 202
-- Data for Name: locationadminlink; Type: TABLE DATA; Schema: public; Owner: -
--

COPY locationadminlink (adminentityid, locationid) FROM stdin;
\.


--
-- TOC entry 2630 (class 0 OID 114004)
-- Dependencies: 203
-- Data for Name: locationtype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY locationtype (locationtypeid, name, reuse, boundadminlevelid, countryid) FROM stdin;
1	Localité	f	\N	1
2	Ecole Primaire	t	\N	1
3	Centre de Santé	t	\N	1
4	Aire de Santé	t	8	1
5	Territoire	t	3	1
6	Localité	t	\N	322
7	Ecole Primaire	t	\N	322
8	Centre de Santé	t	\N	322
9	Aire de Santé	t	8	322
10	Territoire	t	3	322
1274	$DEFAULT$	f	\N	322
\.


--
-- TOC entry 2631 (class 0 OID 114007)
-- Dependencies: 204
-- Data for Name: log_frame; Type: TABLE DATA; Schema: public; Owner: -
--

COPY log_frame (id_log_frame, main_objective, id_log_frame_model, id_project) FROM stdin;
860	\N	861	854
943	\N	926	936
972	\N	449	966
1028	\N	926	1021
1041	\N	926	1034
1056	\N	927	1050
1075	\N	927	1069
1105	\N	927	1099
1121	\N	449	1115
1268	\N	1148	1261
1528	\N	1148	1514
1646	\N	926	1639
\.


--
-- TOC entry 2632 (class 0 OID 114013)
-- Dependencies: 205
-- Data for Name: log_frame_activity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY log_frame_activity (advancement, enddate, startdate, title, id_element, id_result) FROM stdin;
\.


--
-- TOC entry 2633 (class 0 OID 114019)
-- Dependencies: 206
-- Data for Name: log_frame_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY log_frame_element (id_element, code, "position", id_group, risksandassumptions) FROM stdin;
1527	1	1	1269	\N
1533	1	1	1529	\N
\.


--
-- TOC entry 2634 (class 0 OID 114025)
-- Dependencies: 207
-- Data for Name: log_frame_expected_result; Type: TABLE DATA; Schema: public; Owner: -
--

COPY log_frame_expected_result (intervention_logic, id_element, id_specific_objective) FROM stdin;
\.


--
-- TOC entry 2635 (class 0 OID 114031)
-- Dependencies: 208
-- Data for Name: log_frame_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY log_frame_group (id_group, label, type, id_log_frame) FROM stdin;
862	-	SPECIFIC_OBJECTIVE	860
863	-	EXPECTED_RESULT	860
864	-	ACTIVITY	860
865	-	PREREQUISITE	860
944	-	SPECIFIC_OBJECTIVE	943
945	-	EXPECTED_RESULT	943
946	-	ACTIVITY	943
947	-	PREREQUISITE	943
973	-	SPECIFIC_OBJECTIVE	972
974	-	EXPECTED_RESULT	972
975	-	ACTIVITY	972
976	-	PREREQUISITE	972
1029	-	SPECIFIC_OBJECTIVE	1028
1030	-	EXPECTED_RESULT	1028
1031	-	ACTIVITY	1028
1032	-	PREREQUISITE	1028
1042	-	SPECIFIC_OBJECTIVE	1041
1043	-	EXPECTED_RESULT	1041
1044	-	ACTIVITY	1041
1045	-	PREREQUISITE	1041
1057	-	SPECIFIC_OBJECTIVE	1056
1058	-	EXPECTED_RESULT	1056
1059	-	ACTIVITY	1056
1060	-	PREREQUISITE	1056
1076	-	SPECIFIC_OBJECTIVE	1075
1077	-	EXPECTED_RESULT	1075
1078	-	ACTIVITY	1075
1079	-	PREREQUISITE	1075
1106	-	SPECIFIC_OBJECTIVE	1105
1107	-	EXPECTED_RESULT	1105
1108	-	ACTIVITY	1105
1109	-	PREREQUISITE	1105
1122	-	SPECIFIC_OBJECTIVE	1121
1123	-	EXPECTED_RESULT	1121
1124	-	ACTIVITY	1121
1125	-	PREREQUISITE	1121
1269	-	SPECIFIC_OBJECTIVE	1268
1270	-	EXPECTED_RESULT	1268
1271	-	ACTIVITY	1268
1272	-	PREREQUISITE	1268
1529	-	SPECIFIC_OBJECTIVE	1528
1530	-	EXPECTED_RESULT	1528
1531	-	ACTIVITY	1528
1532	-	PREREQUISITE	1528
1647	-	SPECIFIC_OBJECTIVE	1646
1648	-	EXPECTED_RESULT	1646
1649	-	ACTIVITY	1646
1650	-	PREREQUISITE	1646
\.


--
-- TOC entry 2636 (class 0 OID 114037)
-- Dependencies: 209
-- Data for Name: log_frame_indicators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY log_frame_indicators (log_frame_element_id_element, indicators_indicatorid) FROM stdin;
1527	1526
1533	1534
\.


--
-- TOC entry 2637 (class 0 OID 114040)
-- Dependencies: 210
-- Data for Name: log_frame_model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY log_frame_model (id_log_frame, a_gp_max, a_max, a_per_er_max, a_per_gp_max, a_enable_groups, er_enable_groups, p_enable_groups, so_enable_groups, er_gp_max, er_max, er_per_gp_max, er_per_so_max, name, p_gp_max, p_max, p_per_gp_max, so_gp_max, so_max, so_per_gp_max, id_project_model) FROM stdin;
861	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Auto-created default model at Wed Nov 21 17:23:16 CET 2012	\N	\N	\N	\N	\N	\N	\N
926	\N	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	Cadre logique IFAID	\N	\N	\N	\N	\N	\N	331
927	\N	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	Cadre logique financement IFAID	\N	\N	\N	\N	\N	\N	146
449	\N	\N	\N	\N	f	t	f	t	\N	\N	\N	\N	Cadre logique partenaire local	\N	\N	\N	\N	\N	\N	448
1319	\N	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	Cadre logique financement IFAID	\N	\N	\N	\N	\N	\N	1317
1148	\N	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	Cadre logique IFAID	\N	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 2638 (class 0 OID 114046)
-- Dependencies: 211
-- Data for Name: log_frame_prerequisite; Type: TABLE DATA; Schema: public; Owner: -
--

COPY log_frame_prerequisite (id_prerequisite, code, content, "position", id_group, id_log_frame) FROM stdin;
\.


--
-- TOC entry 2639 (class 0 OID 114052)
-- Dependencies: 212
-- Data for Name: log_frame_specific_objective; Type: TABLE DATA; Schema: public; Owner: -
--

COPY log_frame_specific_objective (intervention_logic, id_element, id_log_frame) FROM stdin;
couou\n	1527	1268
couou\n	1533	1528
\.


--
-- TOC entry 2640 (class 0 OID 114058)
-- Dependencies: 213
-- Data for Name: message_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY message_element (id_flexible_element) FROM stdin;
\.


--
-- TOC entry 2641 (class 0 OID 114061)
-- Dependencies: 214
-- Data for Name: monitored_point; Type: TABLE DATA; Schema: public; Owner: -
--

COPY monitored_point (id_monitored_point, completion_date, deleted, expected_date, label, id_file, id_list) FROM stdin;
\.


--
-- TOC entry 2642 (class 0 OID 114067)
-- Dependencies: 215
-- Data for Name: monitored_point_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY monitored_point_list (id_monitored_point_list) FROM stdin;
855
937
967
1022
1035
1051
1070
1100
1116
1262
1515
1640
\.


--
-- TOC entry 2643 (class 0 OID 114070)
-- Dependencies: 216
-- Data for Name: org_unit_banner; Type: TABLE DATA; Schema: public; Owner: -
--

COPY org_unit_banner (banner_id, id_layout, id_org_unit_model) FROM stdin;
13	6	2
47	48	46
76	77	75
\.


--
-- TOC entry 2644 (class 0 OID 114073)
-- Dependencies: 217
-- Data for Name: org_unit_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY org_unit_details (details_id, id_layout, id_org_unit_model) FROM stdin;
19	14	2
55	56	46
84	85	75
\.


--
-- TOC entry 2645 (class 0 OID 114076)
-- Dependencies: 218
-- Data for Name: org_unit_model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY org_unit_model (org_unit_model_id, can_contain_projects, has_budget, name, status, title, id_organization, date_deleted) FROM stdin;
46	t	f	Desk v1	USED	Desk	1	\N
75	t	t	Mission v1	USED	Mission	1	\N
2	t	f	HQ model	DRAFT	 	1	\N
\.


--
-- TOC entry 2646 (class 0 OID 114082)
-- Dependencies: 219
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY organization (id_organization, logo, name, id_root_org_unit) FROM stdin;
1	crf.png	Croix-Rouge Française	21
\.


--
-- TOC entry 2647 (class 0 OID 114088)
-- Dependencies: 220
-- Data for Name: orgunitpermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY orgunitpermission (id, editall, viewall, unit_id, user_userid) FROM stdin;
\.


--
-- TOC entry 2648 (class 0 OID 114091)
-- Dependencies: 221
-- Data for Name: partner; Type: TABLE DATA; Schema: public; Owner: -
--

COPY partner (partnerid, calendarid, deleted, fullname, name, planned_budget, received_budget, spend_budget, location_locationid, office_country_id, id_org_unit_model, organization_id_organization, parent_partnerid) FROM stdin;
97	96	\N	Asie	ASI	0	0	0	\N	466	46	\N	21
99	98	2012-11-21 16:39:40.4	Asie	ASI	0	0	0	\N	466	46	\N	21
101	100	\N	Afrique	AFR	0	0	0	\N	443	46	\N	21
103	102	\N	Sénégal	SE	0	0	0	\N	443	75	\N	101
105	104	\N	Ghana	GH	0	0	0	\N	330	75	\N	101
107	106	\N	Thaïlande	TH	0	0	0	\N	466	75	\N	97
109	108	\N	Myanmar	MY	0	0	0	\N	399	75	\N	97
21	20	\N	Siège (Paris)	HQ	0	0	0	\N	322	2	1	\N
1637	1636	\N	République Démocratique du Congo	CD	0	0	0	\N	1	75	\N	101
\.


--
-- TOC entry 2649 (class 0 OID 114094)
-- Dependencies: 222
-- Data for Name: partnerindatabase; Type: TABLE DATA; Schema: public; Owner: -
--

COPY partnerindatabase (partnerid, databaseid) FROM stdin;
109	1034
109	1050
109	1069
109	1099
109	1115
1637	1639
\.


--
-- TOC entry 2650 (class 0 OID 114097)
-- Dependencies: 223
-- Data for Name: personalcalendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY personalcalendar (id, name) FROM stdin;
20	Événements
96	Evénements
98	Evénements
100	Evénements
102	Evénements
104	Evénements
106	Evénements
108	Evénements
853	Evénements
935	Evénements
965	Evénements
1020	Evénements
1033	Evénements
1049	Evénements
1068	Evénements
1098	Evénements
1114	Evénements
1260	Evénements
1513	Evénements
1636	Evénements
1638	Evénements
\.


--
-- TOC entry 2651 (class 0 OID 114100)
-- Dependencies: 224
-- Data for Name: personalevent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY personalevent (id, calendarid, datecreated, datedeleted, description, enddate, startdate, summary) FROM stdin;
\.


--
-- TOC entry 2652 (class 0 OID 114106)
-- Dependencies: 225
-- Data for Name: phase; Type: TABLE DATA; Schema: public; Owner: -
--

COPY phase (id_phase, end_date, start_date, id_phase_model, id_project) FROM stdin;
857	\N	2012-11-21 17:23:16.354	212	854
858	\N	\N	264	854
859	\N	\N	308	854
940	\N	\N	388	936
942	\N	\N	435	936
939	2012-11-27 23:55:38.166	2012-11-27 23:34:37.818	367	936
941	\N	2012-11-27 23:55:38.172	421	936
969	\N	2012-11-28 00:01:34.602	601	966
970	\N	\N	773	966
971	\N	\N	817	966
1024	\N	2012-11-28 00:14:20.715	367	1021
1025	\N	\N	388	1021
1026	\N	\N	421	1021
1027	\N	\N	435	1021
1037	\N	2012-11-28 00:38:29.683	367	1034
1038	\N	\N	388	1034
1039	\N	\N	421	1034
1040	\N	\N	435	1034
1053	\N	2012-11-28 00:40:07.036	212	1050
1054	\N	\N	264	1050
1055	\N	\N	308	1050
1072	\N	2012-11-28 00:43:02.846	212	1069
1073	\N	\N	264	1069
1074	\N	\N	308	1069
1102	\N	2012-11-28 00:48:34.745	212	1099
1103	\N	\N	264	1099
1104	\N	\N	308	1099
1118	\N	2012-11-28 00:50:53.056	601	1115
1119	\N	\N	773	1115
1120	\N	\N	817	1115
1264	\N	2012-11-28 00:58:41.028	1188	1261
1265	\N	\N	1210	1261
1266	\N	\N	1243	1261
1267	\N	\N	1257	1261
1517	\N	2012-11-28 01:01:01.675	1404	1514
1518	\N	\N	1456	1514
1519	\N	\N	1500	1514
1642	\N	2013-02-08 12:33:58.681	367	1639
1643	\N	\N	388	1639
1644	\N	\N	421	1639
1645	\N	\N	435	1639
\.


--
-- TOC entry 2653 (class 0 OID 114109)
-- Dependencies: 226
-- Data for Name: phase_model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY phase_model (id_phase_model, display_order, guide, name, definition_id, id_layout, id_project_model) FROM stdin;
212	0	\N	Phase préliminaire	\N	213	146
264	1	\N	Phase de suivi	\N	265	146
308	2	\N	Liquidation	\N	309	146
367	0	\N	Programmation	\N	368	331
388	2	\N	Mise en oeuvre et suivi du projet	\N	389	331
421	1	\N	Evaluation Initiale	\N	422	331
435	3	\N	Liquidation	\N	436	331
601	0	\N	N	\N	602	448
773	1	\N	N+1	\N	774	448
817	2	\N	N+2	\N	818	448
1188	0	\N	Programmation	\N	1189	1146
1210	2	\N	Mise en oeuvre et suivi du projet	\N	1211	1146
1243	1	\N	Evaluation Initiale	\N	1244	1146
1257	3	\N	Liquidation	\N	1258	1146
1404	0	\N	Phase préliminaire	\N	1405	1317
1456	1	\N	Phase de suivi	\N	1457	1317
1500	2	\N	Liquidation	\N	1501	1317
\.


--
-- TOC entry 2654 (class 0 OID 114115)
-- Dependencies: 227
-- Data for Name: phase_model_definition; Type: TABLE DATA; Schema: public; Owner: -
--

COPY phase_model_definition (id_phase_model_definition) FROM stdin;
\.


--
-- TOC entry 2655 (class 0 OID 114118)
-- Dependencies: 228
-- Data for Name: phase_model_sucessors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY phase_model_sucessors (id_phase_model, id_phase_model_successor) FROM stdin;
212	264
264	308
367	421
388	435
421	388
601	773
773	817
1188	1243
1210	1257
1243	1210
1404	1456
1456	1500
\.


--
-- TOC entry 2656 (class 0 OID 114121)
-- Dependencies: 229
-- Data for Name: privacy_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY privacy_group (id_privacy_group, code, title, id_organization) FROM stdin;
32	0	Suivi RH	1
996	1	Suivi RH sensible	1
\.


--
-- TOC entry 2657 (class 0 OID 114127)
-- Dependencies: 230
-- Data for Name: privacy_group_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY privacy_group_permission (id_permission, permission, id_privacy_group, id_profile) FROM stdin;
1563	WRITE	32	22
1564	WRITE	996	22
1585	READ	32	880
\.


--
-- TOC entry 2658 (class 0 OID 114130)
-- Dependencies: 231
-- Data for Name: profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY profile (id_profile, name, id_organization) FROM stdin;
880	Utilisateur	1
22	Administrateur	1
\.


--
-- TOC entry 2659 (class 0 OID 114136)
-- Dependencies: 232
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY project (activity_advancement, amendment_revision, amendment_status, amendment_version, calendarid, close_date, end_date, planned_budget, received_budget, spend_budget, databaseid, id_current_phase, id_manager, id_monitored_points_list, id_project_model, id_reminder_list) FROM stdin;
\N	1	DRAFT	1	853	\N	\N	0	\N	\N	854	857	35	855	146	856
\N	1	DRAFT	1	935	\N	\N	0	\N	\N	936	941	35	937	331	938
\N	1	DRAFT	1	965	\N	\N	0	\N	\N	966	969	35	967	448	968
\N	1	DRAFT	1	1020	\N	\N	0	\N	\N	1021	1024	890	1022	331	1023
\N	1	DRAFT	1	1033	\N	2014-12-31 00:00:00	350000	0	0	1034	1037	918	1035	331	1036
\N	1	DRAFT	1	1049	\N	2013-06-30 00:00:00	150000	\N	\N	1050	1053	918	1051	146	1052
\N	1	DRAFT	1	1068	\N	2014-12-31 00:00:00	100000	\N	\N	1069	1072	918	1070	146	1071
\N	1	DRAFT	1	1098	\N	2013-12-31 00:00:00	500000	\N	\N	1099	1102	918	1100	146	1101
\N	1	DRAFT	1	1114	\N	2014-12-31 00:00:00	100000	\N	\N	1115	1118	918	1116	448	1117
0	1	DRAFT	1	1260	\N	\N	0	\N	\N	1261	1264	918	1262	1146	1263
0	1	DRAFT	1	1513	\N	\N	0	\N	\N	1514	1517	918	1515	1317	1516
\N	1	DRAFT	1	1638	\N	\N	100000	0	0	1639	1642	35	1640	331	1641
\.


--
-- TOC entry 2660 (class 0 OID 114139)
-- Dependencies: 233
-- Data for Name: project_banner; Type: TABLE DATA; Schema: public; Owner: -
--

COPY project_banner (id, id_layout, id_project_model) FROM stdin;
147	148	146
332	333	331
450	451	448
1149	1150	1146
1320	1321	1317
\.


--
-- TOC entry 2661 (class 0 OID 114142)
-- Dependencies: 234
-- Data for Name: project_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY project_details (id, id_layout, id_project_model) FROM stdin;
160	161	146
344	345	331
462	463	448
1161	1162	1146
1333	1334	1317
\.


--
-- TOC entry 2662 (class 0 OID 114145)
-- Dependencies: 235
-- Data for Name: project_funding; Type: TABLE DATA; Schema: public; Owner: -
--

COPY project_funding (id_funding, percentage, id_project_funded, id_project_funding) FROM stdin;
1061	150000	1034	1050
1080	100000	1034	1069
1110	100000	1034	1099
1126	20000	1115	1034
1127	80000	1115	1099
1525	1	1261	1514
\.


--
-- TOC entry 2663 (class 0 OID 114148)
-- Dependencies: 236
-- Data for Name: project_model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY project_model (id_project_model, name, status, id_root_phase_model, date_deleted) FROM stdin;
331	Projet propre v1	USED	367	\N
146	Contrat de financement v1	USED	212	\N
448	Projet partenaire local v1	USED	601	\N
1317	Contrat de financement v2	DRAFT	1404	\N
1146	Projet propre v2	DRAFT	1188	\N
\.


--
-- TOC entry 2664 (class 0 OID 114154)
-- Dependencies: 237
-- Data for Name: project_model_visibility; Type: TABLE DATA; Schema: public; Owner: -
--

COPY project_model_visibility (id_visibility, type, id_project_model, id_organization) FROM stdin;
321	FUNDING	146	1
438	NGO	331	1
820	LOCAL_PARTNER	448	1
1147	NGO	1146	1
1318	FUNDING	1317	1
\.


--
-- TOC entry 2665 (class 0 OID 114157)
-- Dependencies: 238
-- Data for Name: project_userlogin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY project_userlogin (project_databaseid, favoriteusers_userid) FROM stdin;
\.


--
-- TOC entry 2666 (class 0 OID 114160)
-- Dependencies: 239
-- Data for Name: projectreport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY projectreport (id, datedeleted, name, currentversion_id, flexibleelement_id_flexible_element, model_id, orgunit_partnerid, project_databaseid) FROM stdin;
948	\N	test	960	933	928	\N	936
977	\N	mars	978	474	928	\N	966
\.


--
-- TOC entry 2667 (class 0 OID 114163)
-- Dependencies: 240
-- Data for Name: projectreportmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY projectreportmodel (id, name, id_organization) FROM stdin;
928	Rapport mensuel de partenariat local	1
\.


--
-- TOC entry 2668 (class 0 OID 114166)
-- Dependencies: 241
-- Data for Name: projectreportmodelsection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY projectreportmodelsection (id, sort_order, name, numberoftextarea, parentsectionmodelid, projectmodelid) FROM stdin;
929	10	Evolution du contexte	1	\N	928
930	20	Situation du projet	1	\N	928
931	30	Relation avec le partenaire	1	\N	928
932	40	Nouvelles opportunités ?	1	\N	928
\.


--
-- TOC entry 2669 (class 0 OID 114169)
-- Dependencies: 242
-- Data for Name: projectreportversion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY projectreportversion (id, editdate, phasename, version, editor_userid, report_id) FROM stdin;
949	2012-11-27 23:35:10.72	Programmation	1	35	948
955	2012-11-27 23:50:09.553	Programmation	2	35	948
960	2012-11-27 23:50:22.666	Programmation	3	35	948
978	2012-11-28 00:02:13.13	N	1	35	977
\.


--
-- TOC entry 2670 (class 0 OID 114172)
-- Dependencies: 243
-- Data for Name: quality_criterion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY quality_criterion (id_quality_criterion, code, label, id_organization, id_quality_framework) FROM stdin;
1	A	The project responds to a demonstrated need	\N	1
2	B	The project achieves its objectives	\N	1
3	C	The project removes or reduces the risk of negativ	\N	1
4	D	The project aims for positive impacts beyond imple	\N	1
5	E	The project is consistent with the agency’s mandat	\N	1
6	F	The project respects the population	\N	1
7	G	The project is flexible	\N	1
8	H	The project is integrated in its institutional con	\N	1
9	I	The agency has the necessary resources and experti	\N	1
10	J	The agency has the appropriate management capacity	\N	1
11	K	The agency makes optimal use of resources	\N	1
12	L	The agency uses lessons drawn from experience	\N	1
13	A1	People's needs are identified and monitored	\N	1
14	A2	The origins of people's needs are analysed and tak	\N	1
15	A3	The project responds to clearly defined needs	\N	1
16	A4	The decision not to address all of the identified 	\N	1
17	B1	Several operational strategies are explored	\N	1
18	B2	Constraints are analysed and taken into account	\N	1
19	B3	The project measures its progress towards achievin	\N	1
20	C1	The risk of negative impacts on the environment is	\N	1
21	C2	The risk of negative impacts on local economy and 	\N	1
22	C3	The risk of negative impacts on the social and pol	\N	1
23	C4	The risk of negative impacts on people's security 	\N	1
24	D1	The project purpose is identified	\N	1
25	D2	The project strengthens people's capacity to cope 	\N	1
26	D3	The post-project period is thought about and plann	\N	1
27	D4	Where appropriate, disaster-preparedness and/or pr	\N	1
28	D5	Where appropriate, the project aims for economic a	\N	1
29	E1	The agency's mandate and principles are clearly de	\N	1
30	E2	Political and legal issues relating to the crisis 	\N	1
31	E3	The agency makes its position on the crisis clear	\N	1
32	E4	The risk of the project being manipulated is ident	\N	1
33	F1	Teams are aware of the appropriate behaviour they 	\N	1
34	F2	The population is informed, consulted and involved	\N	1
35	F3	The project takes into account the cultural, socia	\N	1
36	F4	Necessary measures are taken to remove or reduce t	\N	1
37	G1	Context changes are anticipated and monitored (ant	\N	1
38	G2	The project is adapted in relation to context chan	\N	1
39	H1	Actors and their activities are identified	\N	1
40	H2	Effective coordination links the project with othe	\N	1
41	H3	Opportunities to cooperate with other actors are e	\N	1
42	I1	Necessary and available resources are estimated co	\N	1
43	I2	Staff and other people involved in the project hav	\N	1
44	I3	An appropriate amount of time is allocated to each	\N	1
45	I4	The project is compatible with available resources	\N	1
46	J1	Reporting lines and decision-making responsibiliti	\N	1
47	J2	Good team management enables the project to run sm	\N	1
48	J3	The methods used for collecting and processing inf	\N	1
49	J4	Administrative, financial and logistics management	\N	1
50	J5	The risks affecting project equipment are identifi	\N	1
51	J6	The risks faced by your team are identified, taken	\N	1
52	K1	The chosen strategy ensures optimal impact	\N	1
53	K2	Project coverage is optimal	\N	1
54	K3	Available resources are mobilised and used rationa	\N	1
55	L1	The agency records relevant information over the c	\N	1
56	L2	The agency learns lessons from experience	\N	1
57	L3	The agency uses lessons learnt from experience	\N	1
\.


--
-- TOC entry 2671 (class 0 OID 114178)
-- Dependencies: 244
-- Data for Name: quality_criterion_children; Type: TABLE DATA; Schema: public; Owner: -
--

COPY quality_criterion_children (id_quality_criterion, id_quality_criterion_child) FROM stdin;
1	13
1	14
1	15
1	16
2	17
2	18
2	19
3	20
3	21
3	22
3	23
4	24
4	25
4	26
4	27
4	28
5	29
5	30
5	31
5	32
6	33
6	34
6	35
6	36
7	37
7	38
8	39
8	40
8	41
9	42
9	43
9	44
9	45
10	46
10	47
10	48
10	49
10	50
10	51
11	52
11	53
11	54
12	55
12	56
12	57
\.


--
-- TOC entry 2672 (class 0 OID 114181)
-- Dependencies: 245
-- Data for Name: quality_criterion_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY quality_criterion_type (id_criterion_type, label, level, id_quality_framework) FROM stdin;
1	Criterion	0	1
2	Key process	1	1
\.


--
-- TOC entry 2673 (class 0 OID 114187)
-- Dependencies: 246
-- Data for Name: quality_framework; Type: TABLE DATA; Schema: public; Owner: -
--

COPY quality_framework (id_quality_framework, label, id_organization) FROM stdin;
1	Quality COMPAS	\N
\.


--
-- TOC entry 2674 (class 0 OID 114193)
-- Dependencies: 247
-- Data for Name: question_choice_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY question_choice_element (id_choice, label, sort_order, id_category_element, id_question) FROM stdin;
123	Euro	0	\N	122
124	Dollars	1	\N	122
125	FCH	2	\N	122
131	ECHO	0	\N	130
132	Europaid	1	\N	130
133	AFD	2	\N	130
134	Nations Unies	3	\N	130
135	Mouvement	4	\N	130
136	Fonds propres	5	\N	130
137	Fonds dédiés	6	\N	130
138	CDC	7	\N	130
139	Fondations	8	\N	130
140	AID	9	\N	130
143	Taux Nations Unies	0	\N	142
144	Taux Banque de France	1	\N	142
145	Taux Inforeuro	2	\N	142
186	Draft	0	\N	185
187	Soumise	1	\N	185
188	Acceptée	2	\N	185
191	Draft	0	\N	190
192	Soumise	1	\N	190
193	Acceptée	2	\N	190
229	Terrain	0	\N	228
230	Siège	1	\N	228
241	Draft Terrain	0	\N	240
242	Draft Siège	1	\N	240
243	Envoyé	2	\N	240
246	Mensuelles	0	\N	245
247	Trimestrielles	1	\N	245
248	Annuelles	2	\N	245
250	Preuve de réception des fonds	0	\N	249
251	Journaux de caisse	1	\N	249
252	Pièces et justificatifs comptables	2	\N	249
253	Dossiers d'achats complets (AO et achat commun)	3	\N	249
254	Dossiers du personnel national	4	\N	249
255	Dossiers du personnel DMI/ERU	5	\N	249
256	Bulletins de salaires et preuves de paiement journalier	6	\N	249
257	MoU avec les partenaires	7	\N	249
258	Rapports intermédiaires et finaux	8	\N	249
260	Oui	0	\N	259
261	Non	1	\N	259
295	Draft	0	\N	294
296	Envoyé	1	\N	294
297	Révisé	2	\N	294
298	Validé bailleur	3	\N	294
301	Mensuelles	0	\N	300
302	Trimestrielles	1	\N	300
303	Annuelles	2	\N	300
305	Oui	0	\N	304
306	Non	1	\N	304
358	Afrique de l'Est	0	\N	357
359	Afrique de l'Ouest	1	\N	357
360	Afrique Centrale	2	\N	357
361	Europe	3	\N	357
362	Asie	4	\N	357
363	Amériques Caraïbes	5	\N	357
364	Océan Pacifique	6	\N	357
365	Océan Indien	7	\N	357
419	Oui	0	\N	418
420	Non	1	\N	418
485	janvier	0	\N	484
486	février	1	\N	484
487	mars	2	\N	484
488	avril	3	\N	484
489	mai	4	\N	484
490	juin	5	\N	484
491	juillet	6	\N	484
492	août	7	\N	484
493	septembre	8	\N	484
494	octobre	9	\N	484
495	novembre	10	\N	484
496	décembre	11	\N	484
498	janvier	0	\N	497
499	février	1	\N	497
500	mars	2	\N	497
501	avril	3	\N	497
502	mai	4	\N	497
503	juin	5	\N	497
504	juillet	6	\N	497
505	août	7	\N	497
506	septembre	8	\N	497
507	octobre	9	\N	497
508	novembre	10	\N	497
509	décembre	11	\N	497
511	janvier	0	\N	510
512	février	1	\N	510
513	mars	2	\N	510
514	avril	3	\N	510
515	mai	4	\N	510
516	juin	5	\N	510
517	juillet	6	\N	510
518	août	7	\N	510
519	septembre	8	\N	510
520	octobre	9	\N	510
521	novembre	10	\N	510
522	décembre	11	\N	510
524	janvier	0	\N	523
525	février	1	\N	523
526	mars	2	\N	523
527	avril	3	\N	523
528	mai	4	\N	523
529	juin	5	\N	523
530	juillet	6	\N	523
531	août	7	\N	523
532	septembre	8	\N	523
533	octobre	9	\N	523
534	novembre	10	\N	523
535	décembre	11	\N	523
538	Janvier	0	\N	537
539	Février	1	\N	537
540	Mars	2	\N	537
541	Avril	3	\N	537
542	Mai	4	\N	537
543	Juin	5	\N	537
544	Juillet	6	\N	537
545	Août	7	\N	537
546	Septembre	8	\N	537
547	Octobre	9	\N	537
548	Novembre	10	\N	537
549	Décembre	11	\N	537
551	janvier	0	\N	550
552	février	1	\N	550
553	mars	2	\N	550
554	avril	3	\N	550
555	mai	4	\N	550
556	juin	5	\N	550
557	juillet	6	\N	550
558	août	7	\N	550
559	septembre	8	\N	550
560	octobre	9	\N	550
561	novembre	10	\N	550
562	décembre	11	\N	550
564	janvier	0	\N	563
565	février	1	\N	563
566	mars	2	\N	563
567	avril	3	\N	563
568	mai	4	\N	563
569	juin	5	\N	563
570	juillet	6	\N	563
571	août	7	\N	563
572	septembre	8	\N	563
573	octobre	9	\N	563
574	novembre	10	\N	563
575	décembre	11	\N	563
577	janvier	0	\N	576
578	février	1	\N	576
579	mars	2	\N	576
580	avril	3	\N	576
581	mai	4	\N	576
582	juin	5	\N	576
583	juillet	6	\N	576
584	août	7	\N	576
585	septembre	8	\N	576
586	octobre	9	\N	576
587	novembre	10	\N	576
588	décembre	11	\N	576
653	Janvier	0	\N	652
654	Février	1	\N	652
655	Mars	2	\N	652
656	Avril	3	\N	652
657	Mai	4	\N	652
658	Juin	5	\N	652
659	Juillet	6	\N	652
660	Août	7	\N	652
661	Septembre	8	\N	652
662	Octobre	9	\N	652
663	Novembre	10	\N	652
664	Décembre	11	\N	652
666	Janvier	0	\N	665
667	Février	1	\N	665
668	Mars	2	\N	665
669	Avril	3	\N	665
670	Mai	4	\N	665
671	Juin	5	\N	665
672	Juillet	6	\N	665
673	Août	7	\N	665
674	Septembre	8	\N	665
675	Octobre	9	\N	665
676	Novembre	10	\N	665
677	Décembre	11	\N	665
679	Janvier	0	\N	678
680	Février	1	\N	678
681	Mars	2	\N	678
682	Avril 	3	\N	678
683	Mai	4	\N	678
684	Juin	5	\N	678
685	Juillet	6	\N	678
686	Août	7	\N	678
687	Septembre	8	\N	678
688	Octobre	9	\N	678
689	Novembre	10	\N	678
690	Décembre	11	\N	678
692	Janvier	0	\N	691
693	Février	1	\N	691
694	Mars	2	\N	691
695	Avril	3	\N	691
696	Mai	4	\N	691
697	Juin	5	\N	691
698	Juillet	6	\N	691
699	Août	7	\N	691
700	Septembre	8	\N	691
701	Octobre	9	\N	691
702	Novembre	10	\N	691
703	Décembre	11	\N	691
706	Janvier	0	\N	705
707	Février	1	\N	705
708	Mars	2	\N	705
709	Avril	3	\N	705
710	Mai	4	\N	705
711	Juin	5	\N	705
712	Juillet	6	\N	705
713	Août	7	\N	705
714	Septembre	8	\N	705
715	Octobre	9	\N	705
716	Novembre	10	\N	705
717	Décembre	11	\N	705
719	Janvier	0	\N	718
720	Février	1	\N	718
721	Mars	2	\N	718
722	Avril	3	\N	718
723	Mai	4	\N	718
724	Juin	5	\N	718
725	Juillet	6	\N	718
726	Août	7	\N	718
727	Septembre	8	\N	718
728	Octobre	9	\N	718
729	Novembre	10	\N	718
730	Décembre	11	\N	718
732	Janvier	0	\N	731
733	Février	1	\N	731
734	Mars	2	\N	731
735	Avril	3	\N	731
736	Mai	4	\N	731
737	Juin	5	\N	731
738	Juillet	6	\N	731
739	Août	7	\N	731
740	Septembre	8	\N	731
741	Octobre	9	\N	731
742	Novembre	10	\N	731
743	Décembre	11	\N	731
745	Janvier	0	\N	744
746	Février	1	\N	744
747	Mars	2	\N	744
748	Avril	3	\N	744
749	Mai	4	\N	744
750	Juin	5	\N	744
751	Juillet	6	\N	744
752	Août	7	\N	744
753	Septembre	8	\N	744
754	Octobre	9	\N	744
755	Novembre	10	\N	744
756	Décembre	11	\N	744
838		0	829	194
839		1	830	194
840		2	827	194
841		3	823	194
842		4	826	194
843		5	822	194
844		6	828	194
845		7	824	194
846		8	825	194
847		9	831	194
848		0	837	205
849		1	833	205
850		2	836	205
851		3	835	205
852		4	834	205
1178	Afrique de l'Est	0	\N	1177
1179	Afrique de l'Ouest	1	\N	1177
1180	Afrique Centrale	2	\N	1177
1181	Europe	3	\N	1177
1182	Asie	4	\N	1177
1183	Amériques Caraïbes	5	\N	1177
1184	Océan Pacifique	6	\N	1177
1185	Océan Indien	7	\N	1177
1241	Oui	0	\N	1240
1242	Non	1	\N	1240
1294	Euro	0	\N	1293
1295	Dollars	1	\N	1293
1296	FCH	2	\N	1293
1302	ECHO	0	\N	1301
1303	Europaid	1	\N	1301
1304	AFD	2	\N	1301
1305	Nations Unies	3	\N	1301
1306	Mouvement	4	\N	1301
1307	Fonds propres	5	\N	1301
1308	Fonds dédiés	6	\N	1301
1309	CDC	7	\N	1301
1310	Fondations	8	\N	1301
1311	AID	9	\N	1301
1314	Taux Nations Unies	0	\N	1313
1315	Taux Banque de France	1	\N	1313
1316	Taux Inforeuro	2	\N	1313
1359	Draft	0	\N	1358
1360	Soumise	1	\N	1358
1361	Acceptée	2	\N	1358
1364	Draft	0	\N	1363
1365	Soumise	1	\N	1363
1366	Acceptée	2	\N	1363
1421	Terrain	0	\N	1420
1422	Siège	1	\N	1420
1433	Draft Terrain	0	\N	1432
1434	Draft Siège	1	\N	1432
1435	Envoyé	2	\N	1432
1438	Mensuelles	0	\N	1437
1439	Trimestrielles	1	\N	1437
1440	Annuelles	2	\N	1437
1442	Preuve de réception des fonds	0	\N	1441
1443	Journaux de caisse	1	\N	1441
1444	Pièces et justificatifs comptables	2	\N	1441
1445	Dossiers d'achats complets (AO et achat commun)	3	\N	1441
1446	Dossiers du personnel national	4	\N	1441
1447	Dossiers du personnel DMI/ERU	5	\N	1441
1448	Bulletins de salaires et preuves de paiement journalier	6	\N	1441
1449	MoU avec les partenaires	7	\N	1441
1450	Rapports intermédiaires et finaux	8	\N	1441
1452	Oui	0	\N	1451
1453	Non	1	\N	1451
1487	Draft	0	\N	1486
1488	Envoyé	1	\N	1486
1489	Révisé	2	\N	1486
1490	Validé bailleur	3	\N	1486
1493	Mensuelles	0	\N	1492
1494	Trimestrielles	1	\N	1492
1495	Annuelles	2	\N	1492
1497	Oui	0	\N	1496
1498	Non	1	\N	1496
1368		0	1380	1367
1381		1	1370	1367
1382		2	1371	1367
1383		3	1372	1367
1384		4	1373	1367
1385		5	1374	1367
1386		6	1375	1367
1387		7	1376	1367
1388		8	1377	1367
1389		9	1378	1367
1391		0	1398	1390
1399		1	1393	1390
1400		2	1394	1390
1401		3	1395	1390
1402		4	1396	1390
\.


--
-- TOC entry 2675 (class 0 OID 114199)
-- Dependencies: 248
-- Data for Name: question_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY question_element (is_multiple, id_flexible_element, id_category_type, id_quality_criterion) FROM stdin;
f	122	\N	\N
t	130	\N	\N
f	142	\N	\N
f	185	\N	\N
f	190	\N	\N
f	228	\N	\N
f	240	\N	\N
f	245	\N	\N
t	249	\N	\N
f	259	\N	\N
f	294	\N	\N
f	300	\N	\N
f	304	\N	\N
f	357	\N	\N
f	418	\N	\N
f	484	\N	\N
f	497	\N	\N
f	510	\N	\N
f	523	\N	\N
f	537	\N	\N
f	550	\N	\N
f	563	\N	\N
f	576	\N	\N
f	652	\N	\N
f	665	\N	\N
f	678	\N	\N
f	691	\N	\N
f	705	\N	\N
f	718	\N	\N
f	731	\N	\N
f	744	\N	\N
t	194	821	\N
t	205	832	\N
f	1177	\N	\N
f	1240	\N	\N
f	1293	\N	\N
t	1301	\N	\N
f	1313	\N	\N
f	1358	\N	\N
f	1363	\N	\N
f	1420	\N	\N
f	1432	\N	\N
f	1437	\N	\N
t	1441	\N	\N
f	1451	\N	\N
f	1486	\N	\N
f	1492	\N	\N
f	1496	\N	\N
t	1367	1369	\N
t	1390	1392	\N
\.


--
-- TOC entry 2676 (class 0 OID 114202)
-- Dependencies: 249
-- Data for Name: reminder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY reminder (id_reminder, completion_date, deleted, expected_date, label, id_list) FROM stdin;
\.


--
-- TOC entry 2677 (class 0 OID 114208)
-- Dependencies: 250
-- Data for Name: reminder_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY reminder_list (id_reminder_list) FROM stdin;
856
938
968
1023
1036
1052
1071
1101
1117
1263
1516
1641
\.


--
-- TOC entry 2678 (class 0 OID 114211)
-- Dependencies: 251
-- Data for Name: report_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY report_element (model_id, id_flexible_element) FROM stdin;
928	933
928	1187
\.


--
-- TOC entry 2679 (class 0 OID 114214)
-- Dependencies: 252
-- Data for Name: report_list_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY report_list_element (model_id, id_flexible_element) FROM stdin;
928	474
928	650
\.


--
-- TOC entry 2680 (class 0 OID 114217)
-- Dependencies: 253
-- Data for Name: reportingperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY reportingperiod (reportingperiodid, comments, date1, date2, datecreated, datedeleted, dateedited, monitoring, siteid) FROM stdin;
1279	\N	2012-11-01	2012-11-30	2012-11-28 01:00:36.581	\N	2012-11-28 01:00:36.581	f	1278
1280	\N	2012-11-01	2012-11-30	2012-11-28 01:00:36.627	\N	2012-11-28 01:00:36.627	f	1276
\.


--
-- TOC entry 2681 (class 0 OID 114223)
-- Dependencies: 254
-- Data for Name: reportsubscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY reportsubscription (reporttemplateid, userid, subscribed, invitinguserid) FROM stdin;
\.


--
-- TOC entry 2682 (class 0 OID 114226)
-- Dependencies: 255
-- Data for Name: reporttemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY reporttemplate (reporttemplateid, datedeleted, day, description, frequency, title, visibility, xml, databaseid, owneruserid) FROM stdin;
\.


--
-- TOC entry 2683 (class 0 OID 114232)
-- Dependencies: 256
-- Data for Name: richtextelement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY richtextelement (id, sort_order, sectionid, text, version_id) FROM stdin;
950	0	929	\N	949
951	0	930	\N	949
952	0	931	\N	949
953	0	932	\N	949
959	0	932		955
958	0	931		955
957	0	930		955
956	0	929		955
962	0	930		960
963	0	931		960
964	0	932		960
961	0	929	test	960
979	0	929	\N	978
980	0	930	\N	978
981	0	931	\N	978
982	0	932	\N	978
\.


--
-- TOC entry 2684 (class 0 OID 114238)
-- Dependencies: 257
-- Data for Name: site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY site (siteid, comments, date1, date2, datecreated, datedeleted, dateedited, datesynchronized, siteguid, status, target, activityid, assessmentsiteid, databaseid, locationid, partnerid) FROM stdin;
1276	\N	\N	\N	2012-11-28 01:00:08.381	\N	2012-11-28 01:00:08.381	\N	\N	0	0	\N	\N	1261	1275	21
1278	\N	\N	\N	2012-11-28 01:00:23.294	\N	2012-11-28 01:00:23.294	\N	\N	0	0	\N	\N	1261	1277	21
1536	\N	\N	\N	2012-11-28 01:03:47.835	\N	2012-11-28 01:03:47.835	\N	\N	0	0	\N	\N	1514	1535	21
1538	\N	\N	\N	2012-11-28 01:03:59.803	\N	2012-11-28 01:03:59.803	\N	\N	0	0	\N	\N	1514	1537	21
\.


--
-- TOC entry 2685 (class 0 OID 114244)
-- Dependencies: 258
-- Data for Name: textarea_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY textarea_element (is_decimal, length, max_value, min_value, type, id_flexible_element) FROM stdin;
f	\N	\N	\N	T	116
f	\N	\N	\N	D	117
f	2	\N	\N	N	118
t	\N	\N	\N	N	126
f	\N	\N	\N	N	127
f	\N	\N	\N	N	128
t	\N	\N	\N	N	129
f	6	\N	\N	D	231
f	\N	\N	\N	N	232
f	6	\N	\N	D	233
f	\N	\N	\N	N	234
f	\N	\N	\N	D	235
f	\N	\N	\N	N	236
f	\N	\N	\N	D	237
f	\N	\N	\N	N	238
f	\N	\N	\N	N	244
f	2000	\N	\N	T	262
f	\N	\N	\N	D	263
f	\N	\N	\N	N	299
f	\N	\N	\N	P	366
f	\N	\N	\N	D	411
f	\N	\N	\N	D	412
f	\N	\N	\N	T	413
f	10	\N	\N	T	483
f	10	\N	\N	T	536
f	10	\N	\N	T	651
f	10	\N	\N	T	704
f	\N	\N	\N	N	994
f	\N	\N	\N	N	1144
f	\N	\N	\N	P	1186
f	\N	\N	\N	D	1233
f	\N	\N	\N	D	1234
f	\N	\N	\N	T	1235
f	\N	\N	\N	T	1287
f	\N	\N	\N	D	1288
f	2	\N	\N	N	1289
t	\N	\N	\N	N	1297
f	\N	\N	\N	N	1298
f	\N	\N	\N	N	1299
t	\N	\N	\N	N	1300
f	6	\N	\N	D	1423
f	\N	\N	\N	N	1424
f	6	\N	\N	D	1425
f	\N	\N	\N	N	1426
f	\N	\N	\N	D	1427
f	\N	\N	\N	N	1428
f	\N	\N	\N	D	1429
f	\N	\N	\N	N	1430
f	\N	\N	\N	N	1436
f	2000	\N	\N	T	1454
f	\N	\N	\N	D	1455
f	\N	\N	\N	N	1491
\.


--
-- TOC entry 2686 (class 0 OID 114247)
-- Dependencies: 259
-- Data for Name: triplet_value; Type: TABLE DATA; Schema: public; Owner: -
--

COPY triplet_value (id_triplet, code, datedeleted, name, period) FROM stdin;
\.


--
-- TOC entry 2687 (class 0 OID 114253)
-- Dependencies: 260
-- Data for Name: triplets_list_element; Type: TABLE DATA; Schema: public; Owner: -
--

COPY triplets_list_element (id_flexible_element) FROM stdin;
\.


--
-- TOC entry 2688 (class 0 OID 114256)
-- Dependencies: 261
-- Data for Name: user_unit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_unit (id_user_unit, id_org_unit, id_user) FROM stdin;
36	21	35
891	21	890
913	21	912
915	21	914
917	21	916
919	21	918
921	21	920
923	21	922
925	21	924
1541	21	1540
\.


--
-- TOC entry 2689 (class 0 OID 114259)
-- Dependencies: 262
-- Data for Name: user_unit_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_unit_profiles (id_user_unit, id_profile) FROM stdin;
36	22
891	880
913	880
915	880
917	880
919	880
921	880
923	880
925	880
1541	22
\.


--
-- TOC entry 2690 (class 0 OID 114262)
-- Dependencies: 263
-- Data for Name: userdatabase; Type: TABLE DATA; Schema: public; Owner: -
--

COPY userdatabase (databaseid, datedeleted, fullname, lastschemaupdate, name, startdate, countryid, owneruserid) FROM stdin;
854	2012-11-21 17:27:47.39	t	2012-11-21 17:27:47.39	t	2012-11-21 00:00:00	322	35
1021	2012-11-28 00:14:37.263	pp2	2012-11-28 00:14:37.263	pp2	2012-11-28 00:00:00	322	890
936	2012-11-28 00:19:12.096	pp	2012-11-28 00:19:12.096	pp	2012-11-27 00:00:00	322	35
966	2012-11-28 00:19:14.506	ppl	2012-11-28 00:19:14.506	ppl	2012-11-28 00:00:00	322	35
1034	\N	Enseignement durable au Myanmar	2012-11-28 00:38:29.669	IF1247	2012-04-01 00:00:00	399	918
1050	\N	Une école au Myanmar	2012-11-28 00:40:07.026	HAB1203	2012-06-01 00:00:00	399	918
1069	\N	Enseigner au Myanmar	2012-11-28 00:43:02.839	UCF1217	2013-01-01 00:00:00	399	918
1099	\N	Education pour tous au Myanmar	2012-11-28 00:48:34.739	EUR1109	2011-01-01 00:00:00	399	918
1115	\N	Formation locale birmane	2012-11-28 00:50:53.049	LOC1274	2012-04-01 00:00:00	399	918
1514	2012-11-28 01:09:17.373	fin3	2012-11-28 01:09:17.373	fin3	2012-11-28 00:00:00	322	918
1261	2012-11-28 01:09:19.792	pp3	2012-11-28 01:09:19.792	pp3	2012-11-28 00:00:00	322	918
1639	\N	Formation des cadres congolais	2013-02-08 12:33:58.669	IF1389	2013-02-08 12:33:58.663	1	35
\.


--
-- TOC entry 2691 (class 0 OID 114268)
-- Dependencies: 264
-- Data for Name: userlogin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY userlogin (userid, active, changepasswordkey, datechangepasswordkeyissued, email, firstname, password, locale, name, newuser, id_organization) FROM stdin;
35	\N	\N	\N	admin@sigmah.org	Admin	$2a$10$pMcTA1p9fefR8U9NoOPei.H0eq/TbbdSF27M0tn9iDWBrA4JHeCDC	fr	Sigmah	t	1
890	\N	\N	2012-11-27 22:13:34.784	user1@sigmah.org	User	$2a$10$1MeQYWP1yQA/UOwzfySFPOVZclVKVh7N1luLPv4i0HqLkda.XLZdG	fr	Un	t	1
912	\N	\N	2012-11-27 22:14:02.405	user2@sigmah.org	User	$2a$10$YrDuG.9cl4YAGwy8XCd.Ge8S8jp.wqabc3NbrAKOHFRPzyd5iDl5W	fr	Deux	t	1
914	\N	\N	2012-11-27 22:14:18.13	user3@sigmah.org	User	$2a$10$nTPXo.aRjI0GcX0vINbdP.N/kLXjdOWvXAynwETaChFVTFJHMlmmC	fr	Trois	t	1
916	\N	\N	2012-11-27 22:14:27.668	user4@sigmah.org	User	$2a$10$I2XQNhc6UuIt9wUh.BMSX.xEUiRQrQWT4egwNUXFYnlacQYa7wiCe	fr	Quatre	t	1
918	\N	\N	2012-11-27 22:14:37.576	user5@sigmah.org	User	$2a$10$FdVFuh.ObEfMdKIx83q4I.RwQZaSdevLsBN4f6yJUjaOpZ7wYzmrG	fr	Cinq	t	1
920	\N	\N	2012-11-27 22:14:46.745	user6@sigmah.org	User	$2a$10$WUQkYwhwOAqBuntQJ0bQEOyUbTyu8S3wVRKHker.tSxcEmXT/n9RO	fr	Six	t	1
922	\N	\N	2012-11-27 22:14:54.691	user7@sigmah.org	User	$2a$10$eplobKExDhpCmsk.L8SwVutxQMsXzoHsVHn2GAmG4yD3VgRzPtylK	fr	Sept	t	1
924	\N	\N	2012-11-27 22:15:08.465	user8@sigmah.org	User	$2a$10$ClHZ/lf4stlIFBQSFU8MZe1dv3HAuCpA6wOAM3cAKkhvpGPF.mgRO	fr	Huit	t	1
1540	\N	\N	2012-12-05 13:02:36.755	demo@sigmah.org	User	$2a$10$3LxG6x2xirf50mHrg7gFjuGvvW0ZP9Y6ER8qeRRjEx66.ewmFrkj2	fr	Demo	t	1
\.


--
-- TOC entry 2692 (class 0 OID 114271)
-- Dependencies: 265
-- Data for Name: userpermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY userpermission (userpermissionid, allowdesign, allowedit, alloweditall, allowmanageallusers, allowmanageusers, allowview, allowviewall, lastschemaupdate, databaseid, partnerid, userid) FROM stdin;
1651	t	t	t	t	t	t	t	2013-02-08 12:33:59.101	1034	21	35
1652	t	t	t	t	t	t	t	2013-02-08 12:33:59.102	1050	21	35
1653	t	t	t	t	t	t	t	2013-02-08 12:33:59.102	1115	21	35
1654	t	t	t	t	t	t	t	2013-02-08 12:33:59.103	1099	21	35
1655	t	t	t	t	t	t	t	2013-02-08 12:33:59.103	1069	21	35
1656	t	t	t	t	t	t	t	2013-02-08 12:33:59.103	1639	21	35
1657	t	t	t	t	t	t	t	2013-02-08 12:33:59.174	1034	21	890
1658	t	t	t	t	t	t	t	2013-02-08 12:33:59.174	1050	21	890
1659	t	t	t	t	t	t	t	2013-02-08 12:33:59.175	1115	21	890
1660	t	t	t	t	t	t	t	2013-02-08 12:33:59.175	1099	21	890
1661	t	t	t	t	t	t	t	2013-02-08 12:33:59.175	1069	21	890
1662	t	t	t	t	t	t	t	2013-02-08 12:33:59.176	1639	21	890
1663	t	t	t	t	t	t	t	2013-02-08 12:33:59.224	1034	21	912
1664	t	t	t	t	t	t	t	2013-02-08 12:33:59.225	1050	21	912
1665	t	t	t	t	t	t	t	2013-02-08 12:33:59.225	1115	21	912
1666	t	t	t	t	t	t	t	2013-02-08 12:33:59.225	1099	21	912
1667	t	t	t	t	t	t	t	2013-02-08 12:33:59.226	1069	21	912
1668	t	t	t	t	t	t	t	2013-02-08 12:33:59.227	1639	21	912
1669	t	t	t	t	t	t	t	2013-02-08 12:33:59.287	1034	21	914
1670	t	t	t	t	t	t	t	2013-02-08 12:33:59.288	1050	21	914
1671	t	t	t	t	t	t	t	2013-02-08 12:33:59.288	1115	21	914
1672	t	t	t	t	t	t	t	2013-02-08 12:33:59.289	1099	21	914
1673	t	t	t	t	t	t	t	2013-02-08 12:33:59.289	1069	21	914
1674	t	t	t	t	t	t	t	2013-02-08 12:33:59.29	1639	21	914
1675	t	t	t	t	t	t	t	2013-02-08 12:33:59.336	1034	21	916
1676	t	t	t	t	t	t	t	2013-02-08 12:33:59.337	1050	21	916
1677	t	t	t	t	t	t	t	2013-02-08 12:33:59.337	1115	21	916
1678	t	t	t	t	t	t	t	2013-02-08 12:33:59.337	1099	21	916
1679	t	t	t	t	t	t	t	2013-02-08 12:33:59.338	1069	21	916
1680	t	t	t	t	t	t	t	2013-02-08 12:33:59.338	1639	21	916
1681	t	t	t	t	t	t	t	2013-02-08 12:33:59.384	1034	21	918
1682	t	t	t	t	t	t	t	2013-02-08 12:33:59.385	1050	21	918
1683	t	t	t	t	t	t	t	2013-02-08 12:33:59.385	1115	21	918
1684	t	t	t	t	t	t	t	2013-02-08 12:33:59.385	1099	21	918
1685	t	t	t	t	t	t	t	2013-02-08 12:33:59.386	1069	21	918
1686	t	t	t	t	t	t	t	2013-02-08 12:33:59.386	1639	21	918
1687	t	t	t	t	t	t	t	2013-02-08 12:33:59.426	1034	21	920
1688	t	t	t	t	t	t	t	2013-02-08 12:33:59.427	1050	21	920
1689	t	t	t	t	t	t	t	2013-02-08 12:33:59.427	1115	21	920
1690	t	t	t	t	t	t	t	2013-02-08 12:33:59.427	1099	21	920
1691	t	t	t	t	t	t	t	2013-02-08 12:33:59.428	1069	21	920
1692	t	t	t	t	t	t	t	2013-02-08 12:33:59.428	1639	21	920
1693	t	t	t	t	t	t	t	2013-02-08 12:33:59.518	1034	21	922
1694	t	t	t	t	t	t	t	2013-02-08 12:33:59.519	1050	21	922
1695	t	t	t	t	t	t	t	2013-02-08 12:33:59.519	1115	21	922
1696	t	t	t	t	t	t	t	2013-02-08 12:33:59.519	1099	21	922
1697	t	t	t	t	t	t	t	2013-02-08 12:33:59.52	1069	21	922
1698	t	t	t	t	t	t	t	2013-02-08 12:33:59.52	1639	21	922
1699	t	t	t	t	t	t	t	2013-02-08 12:33:59.553	1034	21	924
1700	t	t	t	t	t	t	t	2013-02-08 12:33:59.554	1050	21	924
1701	t	t	t	t	t	t	t	2013-02-08 12:33:59.554	1115	21	924
1702	t	t	t	t	t	t	t	2013-02-08 12:33:59.554	1099	21	924
1703	t	t	t	t	t	t	t	2013-02-08 12:33:59.555	1069	21	924
1704	t	t	t	t	t	t	t	2013-02-08 12:33:59.555	1639	21	924
1705	t	t	t	t	t	t	t	2013-02-08 12:33:59.588	1034	21	1540
1706	t	t	t	t	t	t	t	2013-02-08 12:33:59.588	1050	21	1540
1707	t	t	t	t	t	t	t	2013-02-08 12:33:59.589	1115	21	1540
1708	t	t	t	t	t	t	t	2013-02-08 12:33:59.589	1099	21	1540
1709	t	t	t	t	t	t	t	2013-02-08 12:33:59.589	1069	21	1540
1710	t	t	t	t	t	t	t	2013-02-08 12:33:59.59	1639	21	1540
\.


--
-- TOC entry 2693 (class 0 OID 114274)
-- Dependencies: 266
-- Data for Name: value; Type: TABLE DATA; Schema: public; Owner: -
--

COPY value (id_value, id_project, action_last_modif, date_last_modif, value, id_flexible_element, id_user_last_modif) FROM stdin;
867	854	C	2012-11-21 17:27:09.838	839~838	194	35
869	854	C	2012-11-21 17:27:10.075	850~848	205	35
954	936	C	2012-11-27 23:35:10.759	948	933	35
983	966	C	2012-11-28 00:02:13.168	977	474	35
1067	1050	U	2012-11-28 00:44:04.404	1338501600000	117	918
1091	1050	C	2012-11-28 00:46:17.992	838	194	918
1093	1050	C	2012-11-28 00:46:18.02	850	205	918
1095	1069	C	2012-11-28 00:46:46.93	838	194	918
1097	1069	C	2012-11-28 00:46:46.96	850	205	918
1132	1099	C	2012-11-28 00:53:09.908	838~839~841	194	918
1134	1099	C	2012-11-28 00:53:09.939	850	205	918
1628	1034	C	2013-02-05 16:42:08.751	1626	356	1540
1631	101	C	2013-02-05 16:45:13.85	1629	64	1540
1634	1050	C	2013-02-05 16:46:20.785	1632	184	1540
\.


--
-- TOC entry 2203 (class 2606 OID 114281)
-- Dependencies: 161 161
-- Name: activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (activityid);


--
-- TOC entry 2205 (class 2606 OID 114283)
-- Dependencies: 162 162
-- Name: adminentity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY adminentity
    ADD CONSTRAINT adminentity_pkey PRIMARY KEY (adminentityid);


--
-- TOC entry 2207 (class 2606 OID 114285)
-- Dependencies: 163 163
-- Name: adminlevel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY adminlevel
    ADD CONSTRAINT adminlevel_pkey PRIMARY KEY (adminlevelid);


--
-- TOC entry 2209 (class 2606 OID 114287)
-- Dependencies: 164 164
-- Name: amendment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY amendment
    ADD CONSTRAINT amendment_pkey PRIMARY KEY (id_amendment);


--
-- TOC entry 2211 (class 2606 OID 114289)
-- Dependencies: 166 166
-- Name: attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attribute
    ADD CONSTRAINT attribute_pkey PRIMARY KEY (attributeid);


--
-- TOC entry 2213 (class 2606 OID 114291)
-- Dependencies: 167 167
-- Name: attributegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attributegroup
    ADD CONSTRAINT attributegroup_pkey PRIMARY KEY (attributegroupid);


--
-- TOC entry 2215 (class 2606 OID 114293)
-- Dependencies: 168 168 168
-- Name: attributegroupinactivity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attributegroupinactivity
    ADD CONSTRAINT attributegroupinactivity_pkey PRIMARY KEY (activityid, attributegroupid);


--
-- TOC entry 2217 (class 2606 OID 114295)
-- Dependencies: 169 169 169
-- Name: attributevalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attributevalue
    ADD CONSTRAINT attributevalue_pkey PRIMARY KEY (attributeid, siteid);


--
-- TOC entry 2219 (class 2606 OID 114297)
-- Dependencies: 170 170
-- Name: authentication_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY authentication
    ADD CONSTRAINT authentication_pkey PRIMARY KEY (authtoken);


--
-- TOC entry 2223 (class 2606 OID 114299)
-- Dependencies: 172 172
-- Name: budget_distribution_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY budget_distribution_element
    ADD CONSTRAINT budget_distribution_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2225 (class 2606 OID 114301)
-- Dependencies: 173 173
-- Name: budget_part_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY budget_part
    ADD CONSTRAINT budget_part_pkey PRIMARY KEY (id_budget_part);


--
-- TOC entry 2227 (class 2606 OID 114303)
-- Dependencies: 174 174
-- Name: budget_parts_list_value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY budget_parts_list_value
    ADD CONSTRAINT budget_parts_list_value_pkey PRIMARY KEY (id_budget_parts_list);


--
-- TOC entry 2221 (class 2606 OID 114305)
-- Dependencies: 171 171
-- Name: budget_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY budget
    ADD CONSTRAINT budget_pkey PRIMARY KEY (id_budget);


--
-- TOC entry 2229 (class 2606 OID 114307)
-- Dependencies: 175 175
-- Name: category_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_element
    ADD CONSTRAINT category_element_pkey PRIMARY KEY (id_category_element);


--
-- TOC entry 2231 (class 2606 OID 114309)
-- Dependencies: 176 176
-- Name: category_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_type
    ADD CONSTRAINT category_type_pkey PRIMARY KEY (id_category_type);


--
-- TOC entry 2233 (class 2606 OID 114311)
-- Dependencies: 177 177
-- Name: checkbox_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY checkbox_element
    ADD CONSTRAINT checkbox_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2235 (class 2606 OID 114313)
-- Dependencies: 178 178
-- Name: country_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (countryid);


--
-- TOC entry 2237 (class 2606 OID 114315)
-- Dependencies: 179 179
-- Name: default_flexible_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY default_flexible_element
    ADD CONSTRAINT default_flexible_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2239 (class 2606 OID 114317)
-- Dependencies: 180 180
-- Name: file_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_meta
    ADD CONSTRAINT file_meta_pkey PRIMARY KEY (id_file);


--
-- TOC entry 2241 (class 2606 OID 114319)
-- Dependencies: 181 181 181
-- Name: file_version_id_file_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_version
    ADD CONSTRAINT file_version_id_file_key UNIQUE (id_file, version_number);


--
-- TOC entry 2243 (class 2606 OID 114321)
-- Dependencies: 181 181
-- Name: file_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_version
    ADD CONSTRAINT file_version_pkey PRIMARY KEY (id_file_version);


--
-- TOC entry 2245 (class 2606 OID 114323)
-- Dependencies: 182 182
-- Name: files_list_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY files_list_element
    ADD CONSTRAINT files_list_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2247 (class 2606 OID 114325)
-- Dependencies: 183 183
-- Name: flexible_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY flexible_element
    ADD CONSTRAINT flexible_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2251 (class 2606 OID 114327)
-- Dependencies: 185 185
-- Name: global_export_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY global_export_content
    ADD CONSTRAINT global_export_content_pkey PRIMARY KEY (id);


--
-- TOC entry 2249 (class 2606 OID 114329)
-- Dependencies: 184 184
-- Name: global_export_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY global_export
    ADD CONSTRAINT global_export_pkey PRIMARY KEY (id);


--
-- TOC entry 2253 (class 2606 OID 114331)
-- Dependencies: 186 186
-- Name: global_export_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY global_export_settings
    ADD CONSTRAINT global_export_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 2255 (class 2606 OID 114333)
-- Dependencies: 187 187
-- Name: global_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY global_permission
    ADD CONSTRAINT global_permission_pkey PRIMARY KEY (id_global_permission);


--
-- TOC entry 2257 (class 2606 OID 114335)
-- Dependencies: 189 189
-- Name: history_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY history_token
    ADD CONSTRAINT history_token_pkey PRIMARY KEY (id_history_token);


--
-- TOC entry 2261 (class 2606 OID 114337)
-- Dependencies: 191 191 191
-- Name: indicator_datasource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicator_datasource
    ADD CONSTRAINT indicator_datasource_pkey PRIMARY KEY (indicatorid, indicatorsourceid);


--
-- TOC entry 2263 (class 2606 OID 114339)
-- Dependencies: 192 192 192
-- Name: indicator_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicator_labels
    ADD CONSTRAINT indicator_labels_pkey PRIMARY KEY (indicator_indicatorid, code);


--
-- TOC entry 2259 (class 2606 OID 114341)
-- Dependencies: 190 190
-- Name: indicator_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicator
    ADD CONSTRAINT indicator_pkey PRIMARY KEY (indicatorid);


--
-- TOC entry 2265 (class 2606 OID 114343)
-- Dependencies: 193 193 193
-- Name: indicatordatasource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicatordatasource
    ADD CONSTRAINT indicatordatasource_pkey PRIMARY KEY (indicatorid, indicatorsourceid);


--
-- TOC entry 2267 (class 2606 OID 114345)
-- Dependencies: 194 194
-- Name: indicators_list_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicators_list_element
    ADD CONSTRAINT indicators_list_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2269 (class 2606 OID 114347)
-- Dependencies: 195 195 195
-- Name: indicators_list_value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicators_list_value
    ADD CONSTRAINT indicators_list_value_pkey PRIMARY KEY (id_indicators_list, id_indicator);


--
-- TOC entry 2271 (class 2606 OID 114349)
-- Dependencies: 196 196 196
-- Name: indicatorvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicatorvalue
    ADD CONSTRAINT indicatorvalue_pkey PRIMARY KEY (indicatorid, reportingperiodid);


--
-- TOC entry 2273 (class 2606 OID 114351)
-- Dependencies: 197 197
-- Name: keyquestion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY keyquestion
    ADD CONSTRAINT keyquestion_pkey PRIMARY KEY (id);


--
-- TOC entry 2277 (class 2606 OID 114353)
-- Dependencies: 199 199
-- Name: layout_constraint_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY layout_constraint
    ADD CONSTRAINT layout_constraint_pkey PRIMARY KEY (id_layout_constraint);


--
-- TOC entry 2279 (class 2606 OID 114355)
-- Dependencies: 200 200
-- Name: layout_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY layout_group
    ADD CONSTRAINT layout_group_pkey PRIMARY KEY (id_layout_group);


--
-- TOC entry 2275 (class 2606 OID 114357)
-- Dependencies: 198 198
-- Name: layout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY layout
    ADD CONSTRAINT layout_pkey PRIMARY KEY (id_layout);


--
-- TOC entry 2281 (class 2606 OID 114359)
-- Dependencies: 201 201
-- Name: location_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY location
    ADD CONSTRAINT location_pkey PRIMARY KEY (locationid);


--
-- TOC entry 2283 (class 2606 OID 114361)
-- Dependencies: 202 202 202
-- Name: locationadminlink_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY locationadminlink
    ADD CONSTRAINT locationadminlink_pkey PRIMARY KEY (locationid, adminentityid);


--
-- TOC entry 2285 (class 2606 OID 114363)
-- Dependencies: 203 203
-- Name: locationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY locationtype
    ADD CONSTRAINT locationtype_pkey PRIMARY KEY (locationtypeid);


--
-- TOC entry 2289 (class 2606 OID 114365)
-- Dependencies: 205 205
-- Name: log_frame_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_activity
    ADD CONSTRAINT log_frame_activity_pkey PRIMARY KEY (id_element);


--
-- TOC entry 2291 (class 2606 OID 114367)
-- Dependencies: 206 206
-- Name: log_frame_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_element
    ADD CONSTRAINT log_frame_element_pkey PRIMARY KEY (id_element);


--
-- TOC entry 2293 (class 2606 OID 114369)
-- Dependencies: 207 207
-- Name: log_frame_expected_result_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_expected_result
    ADD CONSTRAINT log_frame_expected_result_pkey PRIMARY KEY (id_element);


--
-- TOC entry 2295 (class 2606 OID 114371)
-- Dependencies: 208 208
-- Name: log_frame_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_group
    ADD CONSTRAINT log_frame_group_pkey PRIMARY KEY (id_group);


--
-- TOC entry 2297 (class 2606 OID 114373)
-- Dependencies: 209 209 209
-- Name: log_frame_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_indicators
    ADD CONSTRAINT log_frame_indicators_pkey PRIMARY KEY (log_frame_element_id_element, indicators_indicatorid);


--
-- TOC entry 2299 (class 2606 OID 114375)
-- Dependencies: 210 210
-- Name: log_frame_model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_model
    ADD CONSTRAINT log_frame_model_pkey PRIMARY KEY (id_log_frame);


--
-- TOC entry 2287 (class 2606 OID 114377)
-- Dependencies: 204 204
-- Name: log_frame_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame
    ADD CONSTRAINT log_frame_pkey PRIMARY KEY (id_log_frame);


--
-- TOC entry 2301 (class 2606 OID 114379)
-- Dependencies: 211 211
-- Name: log_frame_prerequisite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_prerequisite
    ADD CONSTRAINT log_frame_prerequisite_pkey PRIMARY KEY (id_prerequisite);


--
-- TOC entry 2303 (class 2606 OID 114381)
-- Dependencies: 212 212
-- Name: log_frame_specific_objective_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_specific_objective
    ADD CONSTRAINT log_frame_specific_objective_pkey PRIMARY KEY (id_element);


--
-- TOC entry 2305 (class 2606 OID 114383)
-- Dependencies: 213 213
-- Name: message_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY message_element
    ADD CONSTRAINT message_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2309 (class 2606 OID 114385)
-- Dependencies: 215 215
-- Name: monitored_point_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY monitored_point_list
    ADD CONSTRAINT monitored_point_list_pkey PRIMARY KEY (id_monitored_point_list);


--
-- TOC entry 2307 (class 2606 OID 114387)
-- Dependencies: 214 214
-- Name: monitored_point_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY monitored_point
    ADD CONSTRAINT monitored_point_pkey PRIMARY KEY (id_monitored_point);


--
-- TOC entry 2311 (class 2606 OID 114389)
-- Dependencies: 216 216
-- Name: org_unit_banner_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY org_unit_banner
    ADD CONSTRAINT org_unit_banner_pkey PRIMARY KEY (banner_id);


--
-- TOC entry 2313 (class 2606 OID 114391)
-- Dependencies: 217 217
-- Name: org_unit_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY org_unit_details
    ADD CONSTRAINT org_unit_details_pkey PRIMARY KEY (details_id);


--
-- TOC entry 2315 (class 2606 OID 114393)
-- Dependencies: 218 218
-- Name: org_unit_model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY org_unit_model
    ADD CONSTRAINT org_unit_model_pkey PRIMARY KEY (org_unit_model_id);


--
-- TOC entry 2317 (class 2606 OID 114395)
-- Dependencies: 219 219
-- Name: organization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id_organization);


--
-- TOC entry 2319 (class 2606 OID 114397)
-- Dependencies: 220 220
-- Name: orgunitpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY orgunitpermission
    ADD CONSTRAINT orgunitpermission_pkey PRIMARY KEY (id);


--
-- TOC entry 2321 (class 2606 OID 114399)
-- Dependencies: 221 221
-- Name: partner_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partner
    ADD CONSTRAINT partner_pkey PRIMARY KEY (partnerid);


--
-- TOC entry 2323 (class 2606 OID 114401)
-- Dependencies: 222 222 222
-- Name: partnerindatabase_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partnerindatabase
    ADD CONSTRAINT partnerindatabase_pkey PRIMARY KEY (databaseid, partnerid);


--
-- TOC entry 2325 (class 2606 OID 114403)
-- Dependencies: 223 223
-- Name: personalcalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY personalcalendar
    ADD CONSTRAINT personalcalendar_pkey PRIMARY KEY (id);


--
-- TOC entry 2327 (class 2606 OID 114405)
-- Dependencies: 224 224
-- Name: personalevent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY personalevent
    ADD CONSTRAINT personalevent_pkey PRIMARY KEY (id);


--
-- TOC entry 2333 (class 2606 OID 114407)
-- Dependencies: 227 227
-- Name: phase_model_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase_model_definition
    ADD CONSTRAINT phase_model_definition_pkey PRIMARY KEY (id_phase_model_definition);


--
-- TOC entry 2331 (class 2606 OID 114409)
-- Dependencies: 226 226
-- Name: phase_model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase_model
    ADD CONSTRAINT phase_model_pkey PRIMARY KEY (id_phase_model);


--
-- TOC entry 2335 (class 2606 OID 114411)
-- Dependencies: 228 228 228
-- Name: phase_model_sucessors_id_phase_model_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase_model_sucessors
    ADD CONSTRAINT phase_model_sucessors_id_phase_model_key UNIQUE (id_phase_model, id_phase_model_successor);


--
-- TOC entry 2337 (class 2606 OID 114413)
-- Dependencies: 228 228
-- Name: phase_model_sucessors_id_phase_model_successor_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase_model_sucessors
    ADD CONSTRAINT phase_model_sucessors_id_phase_model_successor_key UNIQUE (id_phase_model_successor);


--
-- TOC entry 2329 (class 2606 OID 114415)
-- Dependencies: 225 225
-- Name: phase_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase
    ADD CONSTRAINT phase_pkey PRIMARY KEY (id_phase);


--
-- TOC entry 2341 (class 2606 OID 114417)
-- Dependencies: 230 230
-- Name: privacy_group_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY privacy_group_permission
    ADD CONSTRAINT privacy_group_permission_pkey PRIMARY KEY (id_permission);


--
-- TOC entry 2339 (class 2606 OID 114419)
-- Dependencies: 229 229
-- Name: privacy_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY privacy_group
    ADD CONSTRAINT privacy_group_pkey PRIMARY KEY (id_privacy_group);


--
-- TOC entry 2343 (class 2606 OID 114421)
-- Dependencies: 231 231
-- Name: profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY profile
    ADD CONSTRAINT profile_pkey PRIMARY KEY (id_profile);


--
-- TOC entry 2347 (class 2606 OID 114423)
-- Dependencies: 233 233
-- Name: project_banner_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_banner
    ADD CONSTRAINT project_banner_pkey PRIMARY KEY (id);


--
-- TOC entry 2349 (class 2606 OID 114425)
-- Dependencies: 234 234
-- Name: project_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_details
    ADD CONSTRAINT project_details_pkey PRIMARY KEY (id);


--
-- TOC entry 2351 (class 2606 OID 114427)
-- Dependencies: 235 235
-- Name: project_funding_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_funding
    ADD CONSTRAINT project_funding_pkey PRIMARY KEY (id_funding);


--
-- TOC entry 2353 (class 2606 OID 114429)
-- Dependencies: 236 236
-- Name: project_model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_model
    ADD CONSTRAINT project_model_pkey PRIMARY KEY (id_project_model);


--
-- TOC entry 2355 (class 2606 OID 114431)
-- Dependencies: 237 237
-- Name: project_model_visibility_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_model_visibility
    ADD CONSTRAINT project_model_visibility_pkey PRIMARY KEY (id_visibility);


--
-- TOC entry 2345 (class 2606 OID 114433)
-- Dependencies: 232 232
-- Name: project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_pkey PRIMARY KEY (databaseid);


--
-- TOC entry 2357 (class 2606 OID 114435)
-- Dependencies: 238 238 238
-- Name: project_userlogin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_userlogin
    ADD CONSTRAINT project_userlogin_pkey PRIMARY KEY (project_databaseid, favoriteusers_userid);


--
-- TOC entry 2359 (class 2606 OID 114437)
-- Dependencies: 239 239
-- Name: projectreport_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreport
    ADD CONSTRAINT projectreport_pkey PRIMARY KEY (id);


--
-- TOC entry 2361 (class 2606 OID 114439)
-- Dependencies: 240 240
-- Name: projectreportmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreportmodel
    ADD CONSTRAINT projectreportmodel_pkey PRIMARY KEY (id);


--
-- TOC entry 2363 (class 2606 OID 114441)
-- Dependencies: 241 241
-- Name: projectreportmodelsection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreportmodelsection
    ADD CONSTRAINT projectreportmodelsection_pkey PRIMARY KEY (id);


--
-- TOC entry 2365 (class 2606 OID 114443)
-- Dependencies: 242 242
-- Name: projectreportversion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreportversion
    ADD CONSTRAINT projectreportversion_pkey PRIMARY KEY (id);


--
-- TOC entry 2369 (class 2606 OID 114445)
-- Dependencies: 244 244 244
-- Name: quality_criterion_children_id_quality_criterion_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_criterion_children
    ADD CONSTRAINT quality_criterion_children_id_quality_criterion_key UNIQUE (id_quality_criterion, id_quality_criterion_child);


--
-- TOC entry 2371 (class 2606 OID 114447)
-- Dependencies: 244 244
-- Name: quality_criterion_children_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_criterion_children
    ADD CONSTRAINT quality_criterion_children_pkey PRIMARY KEY (id_quality_criterion_child);


--
-- TOC entry 2367 (class 2606 OID 114449)
-- Dependencies: 243 243
-- Name: quality_criterion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_criterion
    ADD CONSTRAINT quality_criterion_pkey PRIMARY KEY (id_quality_criterion);


--
-- TOC entry 2373 (class 2606 OID 114451)
-- Dependencies: 245 245
-- Name: quality_criterion_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_criterion_type
    ADD CONSTRAINT quality_criterion_type_pkey PRIMARY KEY (id_criterion_type);


--
-- TOC entry 2375 (class 2606 OID 114453)
-- Dependencies: 246 246
-- Name: quality_framework_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_framework
    ADD CONSTRAINT quality_framework_pkey PRIMARY KEY (id_quality_framework);


--
-- TOC entry 2377 (class 2606 OID 114455)
-- Dependencies: 247 247
-- Name: question_choice_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY question_choice_element
    ADD CONSTRAINT question_choice_element_pkey PRIMARY KEY (id_choice);


--
-- TOC entry 2379 (class 2606 OID 114457)
-- Dependencies: 248 248
-- Name: question_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY question_element
    ADD CONSTRAINT question_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2383 (class 2606 OID 114459)
-- Dependencies: 250 250
-- Name: reminder_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reminder_list
    ADD CONSTRAINT reminder_list_pkey PRIMARY KEY (id_reminder_list);


--
-- TOC entry 2381 (class 2606 OID 114461)
-- Dependencies: 249 249
-- Name: reminder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reminder
    ADD CONSTRAINT reminder_pkey PRIMARY KEY (id_reminder);


--
-- TOC entry 2385 (class 2606 OID 114463)
-- Dependencies: 251 251
-- Name: report_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY report_element
    ADD CONSTRAINT report_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2387 (class 2606 OID 114465)
-- Dependencies: 252 252
-- Name: report_list_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY report_list_element
    ADD CONSTRAINT report_list_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2389 (class 2606 OID 114467)
-- Dependencies: 253 253
-- Name: reportingperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reportingperiod
    ADD CONSTRAINT reportingperiod_pkey PRIMARY KEY (reportingperiodid);


--
-- TOC entry 2391 (class 2606 OID 114469)
-- Dependencies: 254 254 254
-- Name: reportsubscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reportsubscription
    ADD CONSTRAINT reportsubscription_pkey PRIMARY KEY (reporttemplateid, userid);


--
-- TOC entry 2393 (class 2606 OID 114471)
-- Dependencies: 255 255
-- Name: reporttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reporttemplate
    ADD CONSTRAINT reporttemplate_pkey PRIMARY KEY (reporttemplateid);


--
-- TOC entry 2395 (class 2606 OID 114473)
-- Dependencies: 256 256
-- Name: richtextelement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY richtextelement
    ADD CONSTRAINT richtextelement_pkey PRIMARY KEY (id);


--
-- TOC entry 2397 (class 2606 OID 114475)
-- Dependencies: 257 257
-- Name: site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY site
    ADD CONSTRAINT site_pkey PRIMARY KEY (siteid);


--
-- TOC entry 2399 (class 2606 OID 114477)
-- Dependencies: 258 258
-- Name: textarea_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY textarea_element
    ADD CONSTRAINT textarea_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2401 (class 2606 OID 114479)
-- Dependencies: 259 259
-- Name: triplet_value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY triplet_value
    ADD CONSTRAINT triplet_value_pkey PRIMARY KEY (id_triplet);


--
-- TOC entry 2403 (class 2606 OID 114481)
-- Dependencies: 260 260
-- Name: triplets_list_element_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY triplets_list_element
    ADD CONSTRAINT triplets_list_element_pkey PRIMARY KEY (id_flexible_element);


--
-- TOC entry 2405 (class 2606 OID 114483)
-- Dependencies: 261 261
-- Name: user_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_unit
    ADD CONSTRAINT user_unit_pkey PRIMARY KEY (id_user_unit);


--
-- TOC entry 2407 (class 2606 OID 114485)
-- Dependencies: 262 262 262
-- Name: user_unit_profiles_id_user_unit_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_unit_profiles
    ADD CONSTRAINT user_unit_profiles_id_user_unit_key UNIQUE (id_user_unit, id_profile);


--
-- TOC entry 2409 (class 2606 OID 114487)
-- Dependencies: 263 263
-- Name: userdatabase_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userdatabase
    ADD CONSTRAINT userdatabase_pkey PRIMARY KEY (databaseid);


--
-- TOC entry 2411 (class 2606 OID 114489)
-- Dependencies: 264 264
-- Name: userlogin_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userlogin
    ADD CONSTRAINT userlogin_email_key UNIQUE (email);


--
-- TOC entry 2413 (class 2606 OID 114491)
-- Dependencies: 264 264
-- Name: userlogin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userlogin
    ADD CONSTRAINT userlogin_pkey PRIMARY KEY (userid);


--
-- TOC entry 2415 (class 2606 OID 114493)
-- Dependencies: 265 265
-- Name: userpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userpermission
    ADD CONSTRAINT userpermission_pkey PRIMARY KEY (userpermissionid);


--
-- TOC entry 2417 (class 2606 OID 114495)
-- Dependencies: 266 266 266
-- Name: value_id_flexible_element_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY value
    ADD CONSTRAINT value_id_flexible_element_key UNIQUE (id_flexible_element, id_project);


--
-- TOC entry 2419 (class 2606 OID 114497)
-- Dependencies: 266 266
-- Name: value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY value
    ADD CONSTRAINT value_pkey PRIMARY KEY (id_value);


--
-- TOC entry 2441 (class 2606 OID 114498)
-- Dependencies: 2316 219 176
-- Name: fk1432f9db87d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_type
    ADD CONSTRAINT fk1432f9db87d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2577 (class 2606 OID 114503)
-- Dependencies: 2320 261 221
-- Name: fk143d4d78b7206e89; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_unit
    ADD CONSTRAINT fk143d4d78b7206e89 FOREIGN KEY (id_org_unit) REFERENCES partner(partnerid) DEFERRABLE;


--
-- TOC entry 2578 (class 2606 OID 114508)
-- Dependencies: 2412 264 261
-- Name: fk143d4d78dd0ca99c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_unit
    ADD CONSTRAINT fk143d4d78dd0ca99c FOREIGN KEY (id_user) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2497 (class 2606 OID 114513)
-- Dependencies: 219 218 2316
-- Name: fk15d234e987d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY org_unit_model
    ADD CONSTRAINT fk15d234e987d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2553 (class 2606 OID 114518)
-- Dependencies: 175 247 2228
-- Name: fk17871bd711158eaf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY question_choice_element
    ADD CONSTRAINT fk17871bd711158eaf FOREIGN KEY (id_category_element) REFERENCES category_element(id_category_element) DEFERRABLE;


--
-- TOC entry 2554 (class 2606 OID 114523)
-- Dependencies: 247 248 2378
-- Name: fk17871bd7d92f832c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY question_choice_element
    ADD CONSTRAINT fk17871bd7d92f832c FOREIGN KEY (id_question) REFERENCES question_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2483 (class 2606 OID 114528)
-- Dependencies: 209 190 2258
-- Name: fk17e5a9f1a023ddc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_indicators
    ADD CONSTRAINT fk17e5a9f1a023ddc FOREIGN KEY (indicators_indicatorid) REFERENCES indicator(indicatorid) DEFERRABLE;


--
-- TOC entry 2484 (class 2606 OID 114533)
-- Dependencies: 206 209 2290
-- Name: fk17e5a9f1f6e4c4b8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_indicators
    ADD CONSTRAINT fk17e5a9f1f6e4c4b8 FOREIGN KEY (log_frame_element_id_element) REFERENCES log_frame_element(id_element) DEFERRABLE;


--
-- TOC entry 2525 (class 2606 OID 114538)
-- Dependencies: 198 233 2274
-- Name: fk1bc8331244f6265a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_banner
    ADD CONSTRAINT fk1bc8331244f6265a FOREIGN KEY (id_layout) REFERENCES layout(id_layout) DEFERRABLE;


--
-- TOC entry 2526 (class 2606 OID 114543)
-- Dependencies: 2352 236 233
-- Name: fk1bc83312d196f951; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_banner
    ADD CONSTRAINT fk1bc83312d196f951 FOREIGN KEY (id_project_model) REFERENCES project_model(id_project_model) DEFERRABLE;


--
-- TOC entry 2570 (class 2606 OID 114548)
-- Dependencies: 2396 257 257
-- Name: fk2753671fcde08d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY site
    ADD CONSTRAINT fk2753671fcde08d FOREIGN KEY (assessmentsiteid) REFERENCES site(siteid) DEFERRABLE;


--
-- TOC entry 2571 (class 2606 OID 114553)
-- Dependencies: 2280 201 257
-- Name: fk275367368ddfa7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY site
    ADD CONSTRAINT fk275367368ddfa7 FOREIGN KEY (locationid) REFERENCES location(locationid) DEFERRABLE;


--
-- TOC entry 2572 (class 2606 OID 114558)
-- Dependencies: 263 257 2408
-- Name: fk275367494bd9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY site
    ADD CONSTRAINT fk275367494bd9e FOREIGN KEY (databaseid) REFERENCES userdatabase(databaseid) DEFERRABLE;


--
-- TOC entry 2573 (class 2606 OID 114563)
-- Dependencies: 221 2320 257
-- Name: fk27536779d901c9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY site
    ADD CONSTRAINT fk27536779d901c9 FOREIGN KEY (partnerid) REFERENCES partner(partnerid) DEFERRABLE;


--
-- TOC entry 2574 (class 2606 OID 114568)
-- Dependencies: 2202 257 161
-- Name: fk27536780bf17db; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY site
    ADD CONSTRAINT fk27536780bf17db FOREIGN KEY (activityid) REFERENCES activity(activityid) DEFERRABLE;


--
-- TOC entry 2422 (class 2606 OID 114573)
-- Dependencies: 2206 163 162
-- Name: fk2e3083f227f5cac7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY adminentity
    ADD CONSTRAINT fk2e3083f227f5cac7 FOREIGN KEY (adminlevelid) REFERENCES adminlevel(adminlevelid) DEFERRABLE;


--
-- TOC entry 2423 (class 2606 OID 114578)
-- Dependencies: 2204 162 162
-- Name: fk2e3083f2ff2bada7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY adminentity
    ADD CONSTRAINT fk2e3083f2ff2bada7 FOREIGN KEY (adminentityparentid) REFERENCES adminentity(adminentityid) DEFERRABLE;


--
-- TOC entry 2450 (class 2606 OID 114583)
-- Dependencies: 2316 219 186
-- Name: fk2fb477b2f85c2c3c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY global_export_settings
    ADD CONSTRAINT fk2fb477b2f85c2c3c FOREIGN KEY (organization_id) REFERENCES organization(id_organization);


--
-- TOC entry 2501 (class 2606 OID 114588)
-- Dependencies: 221 201 2280
-- Name: fk33f574a8350d2271; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partner
    ADD CONSTRAINT fk33f574a8350d2271 FOREIGN KEY (location_locationid) REFERENCES location(locationid) DEFERRABLE;


--
-- TOC entry 2502 (class 2606 OID 114593)
-- Dependencies: 2314 221 218
-- Name: fk33f574a84ba27d70; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partner
    ADD CONSTRAINT fk33f574a84ba27d70 FOREIGN KEY (id_org_unit_model) REFERENCES org_unit_model(org_unit_model_id) DEFERRABLE;


--
-- TOC entry 2503 (class 2606 OID 114598)
-- Dependencies: 2320 221 221
-- Name: fk33f574a85179b874; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partner
    ADD CONSTRAINT fk33f574a85179b874 FOREIGN KEY (parent_partnerid) REFERENCES partner(partnerid) DEFERRABLE;


--
-- TOC entry 2504 (class 2606 OID 114603)
-- Dependencies: 219 2316 221
-- Name: fk33f574a8cf94c360; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partner
    ADD CONSTRAINT fk33f574a8cf94c360 FOREIGN KEY (organization_id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2505 (class 2606 OID 114608)
-- Dependencies: 2234 178 221
-- Name: fk33f574a8faec4abb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partner
    ADD CONSTRAINT fk33f574a8faec4abb FOREIGN KEY (office_country_id) REFERENCES country(countryid) DEFERRABLE;


--
-- TOC entry 2564 (class 2606 OID 114613)
-- Dependencies: 2392 254 255
-- Name: fk35f790911741f030; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reportsubscription
    ADD CONSTRAINT fk35f790911741f030 FOREIGN KEY (reporttemplateid) REFERENCES reporttemplate(reporttemplateid) DEFERRABLE;


--
-- TOC entry 2565 (class 2606 OID 114618)
-- Dependencies: 2412 254 264
-- Name: fk35f7909148b34b53; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reportsubscription
    ADD CONSTRAINT fk35f7909148b34b53 FOREIGN KEY (userid) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2566 (class 2606 OID 114623)
-- Dependencies: 2412 254 264
-- Name: fk35f7909173633c59; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reportsubscription
    ADD CONSTRAINT fk35f7909173633c59 FOREIGN KEY (invitinguserid) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2555 (class 2606 OID 114628)
-- Dependencies: 2246 183 248
-- Name: fk3d05bba320d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY question_element
    ADD CONSTRAINT fk3d05bba320d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2556 (class 2606 OID 114633)
-- Dependencies: 243 2366 248
-- Name: fk3d05bba370812310; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY question_element
    ADD CONSTRAINT fk3d05bba370812310 FOREIGN KEY (id_quality_criterion) REFERENCES quality_criterion(id_quality_criterion) DEFERRABLE;


--
-- TOC entry 2557 (class 2606 OID 114638)
-- Dependencies: 2230 248 176
-- Name: fk3d05bba3b6ab611d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY question_element
    ADD CONSTRAINT fk3d05bba3b6ab611d FOREIGN KEY (id_category_type) REFERENCES category_type(id_category_type) DEFERRABLE;


--
-- TOC entry 2498 (class 2606 OID 114643)
-- Dependencies: 2320 221 219
-- Name: fk4644ed33754a9e7e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY organization
    ADD CONSTRAINT fk4644ed33754a9e7e FOREIGN KEY (id_root_org_unit) REFERENCES partner(partnerid) DEFERRABLE;


--
-- TOC entry 2581 (class 2606 OID 114648)
-- Dependencies: 263 264 2412
-- Name: fk46aeba86a5c52bc6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userdatabase
    ADD CONSTRAINT fk46aeba86a5c52bc6 FOREIGN KEY (owneruserid) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2582 (class 2606 OID 114653)
-- Dependencies: 178 263 2234
-- Name: fk46aeba86b6676e25; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userdatabase
    ADD CONSTRAINT fk46aeba86b6676e25 FOREIGN KEY (countryid) REFERENCES country(countryid) DEFERRABLE;


--
-- TOC entry 2443 (class 2606 OID 114658)
-- Dependencies: 2246 183 179
-- Name: fk48d914c620d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY default_flexible_element
    ADD CONSTRAINT fk48d914c620d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2549 (class 2606 OID 114663)
-- Dependencies: 2366 244 243
-- Name: fk4a73751d70812310; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_criterion_children
    ADD CONSTRAINT fk4a73751d70812310 FOREIGN KEY (id_quality_criterion) REFERENCES quality_criterion(id_quality_criterion) DEFERRABLE;


--
-- TOC entry 2550 (class 2606 OID 114668)
-- Dependencies: 2366 243 244
-- Name: fk4a73751dfe03d96d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_criterion_children
    ADD CONSTRAINT fk4a73751dfe03d96d FOREIGN KEY (id_quality_criterion_child) REFERENCES quality_criterion(id_quality_criterion) DEFERRABLE;


--
-- TOC entry 2453 (class 2606 OID 114673)
-- Dependencies: 190 2408 263
-- Name: fk4d01ddef494bd9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicator
    ADD CONSTRAINT fk4d01ddef494bd9e FOREIGN KEY (databaseid) REFERENCES userdatabase(databaseid) DEFERRABLE;


--
-- TOC entry 2454 (class 2606 OID 114678)
-- Dependencies: 2366 190 243
-- Name: fk4d01ddef70812310; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicator
    ADD CONSTRAINT fk4d01ddef70812310 FOREIGN KEY (id_quality_criterion) REFERENCES quality_criterion(id_quality_criterion) DEFERRABLE;


--
-- TOC entry 2455 (class 2606 OID 114683)
-- Dependencies: 161 190 2202
-- Name: fk4d01ddef80bf17db; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicator
    ADD CONSTRAINT fk4d01ddef80bf17db FOREIGN KEY (activityid) REFERENCES activity(activityid) DEFERRABLE;


--
-- TOC entry 2433 (class 2606 OID 114688)
-- Dependencies: 257 169 2396
-- Name: fk4ed7045544c2434b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attributevalue
    ADD CONSTRAINT fk4ed7045544c2434b FOREIGN KEY (siteid) REFERENCES site(siteid) DEFERRABLE;


--
-- TOC entry 2434 (class 2606 OID 114693)
-- Dependencies: 2210 169 166
-- Name: fk4ed70455afed0b31; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attributevalue
    ADD CONSTRAINT fk4ed70455afed0b31 FOREIGN KEY (attributeid) REFERENCES attribute(attributeid) DEFERRABLE;


--
-- TOC entry 2471 (class 2606 OID 114698)
-- Dependencies: 202 201 2280
-- Name: fk50408394368ddfa7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY locationadminlink
    ADD CONSTRAINT fk50408394368ddfa7 FOREIGN KEY (locationid) REFERENCES location(locationid) DEFERRABLE;


--
-- TOC entry 2472 (class 2606 OID 114703)
-- Dependencies: 2204 162 202
-- Name: fk50408394cd1204fd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY locationadminlink
    ADD CONSTRAINT fk50408394cd1204fd FOREIGN KEY (adminentityid) REFERENCES adminentity(adminentityid) DEFERRABLE;


--
-- TOC entry 2519 (class 2606 OID 114708)
-- Dependencies: 232 263 2408
-- Name: fk50c8e2f9494bd9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT fk50c8e2f9494bd9e FOREIGN KEY (databaseid) REFERENCES userdatabase(databaseid) DEFERRABLE;


--
-- TOC entry 2520 (class 2606 OID 114713)
-- Dependencies: 232 264 2412
-- Name: fk50c8e2f955bb91b6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT fk50c8e2f955bb91b6 FOREIGN KEY (id_manager) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2521 (class 2606 OID 114718)
-- Dependencies: 232 215 2308
-- Name: fk50c8e2f9b07b74ff; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT fk50c8e2f9b07b74ff FOREIGN KEY (id_monitored_points_list) REFERENCES monitored_point_list(id_monitored_point_list) DEFERRABLE;


--
-- TOC entry 2522 (class 2606 OID 114723)
-- Dependencies: 232 236 2352
-- Name: fk50c8e2f9d196f951; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT fk50c8e2f9d196f951 FOREIGN KEY (id_project_model) REFERENCES project_model(id_project_model) DEFERRABLE;


--
-- TOC entry 2523 (class 2606 OID 114728)
-- Dependencies: 232 225 2328
-- Name: fk50c8e2f9dffa476a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT fk50c8e2f9dffa476a FOREIGN KEY (id_current_phase) REFERENCES phase(id_phase) DEFERRABLE;


--
-- TOC entry 2524 (class 2606 OID 114733)
-- Dependencies: 232 250 2382
-- Name: fk50c8e2f9e2910b71; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT fk50c8e2f9e2910b71 FOREIGN KEY (id_reminder_list) REFERENCES reminder_list(id_reminder_list) DEFERRABLE;


--
-- TOC entry 2444 (class 2606 OID 114738)
-- Dependencies: 181 264 2412
-- Name: fk52157d152c2c465c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_version
    ADD CONSTRAINT fk52157d152c2c465c FOREIGN KEY (id_author) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2445 (class 2606 OID 114743)
-- Dependencies: 181 180 2238
-- Name: fk52157d15d4cd29db; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_version
    ADD CONSTRAINT fk52157d15d4cd29db FOREIGN KEY (id_file) REFERENCES file_meta(id_file) DEFERRABLE;


--
-- TOC entry 2529 (class 2606 OID 114748)
-- Dependencies: 235 232 2344
-- Name: fk52f38bd74485e32a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_funding
    ADD CONSTRAINT fk52f38bd74485e32a FOREIGN KEY (id_project_funding) REFERENCES project(databaseid) DEFERRABLE;


--
-- TOC entry 2530 (class 2606 OID 114753)
-- Dependencies: 235 235 2350
-- Name: fk52f38bd7597e985f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_funding
    ADD CONSTRAINT fk52f38bd7597e985f FOREIGN KEY (id_funding) REFERENCES project_funding(id_funding) DEFERRABLE;


--
-- TOC entry 2531 (class 2606 OID 114758)
-- Dependencies: 235 232 2344
-- Name: fk52f38bd7c908f825; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_funding
    ADD CONSTRAINT fk52f38bd7c908f825 FOREIGN KEY (id_project_funded) REFERENCES project(databaseid) DEFERRABLE;


--
-- TOC entry 2576 (class 2606 OID 114763)
-- Dependencies: 260 183 2246
-- Name: fk532b05fd20d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY triplets_list_element
    ADD CONSTRAINT fk532b05fd20d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2490 (class 2606 OID 114768)
-- Dependencies: 213 183 2246
-- Name: fk553ccec420d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY message_element
    ADD CONSTRAINT fk553ccec420d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2479 (class 2606 OID 114773)
-- Dependencies: 206 208 2294
-- Name: fk5a2e206f4f6005ee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_element
    ADD CONSTRAINT fk5a2e206f4f6005ee FOREIGN KEY (id_group) REFERENCES log_frame_group(id_group) DEFERRABLE;


--
-- TOC entry 2437 (class 2606 OID 114778)
-- Dependencies: 173 174 2226
-- Name: fk5a830ade653f90a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY budget_part
    ADD CONSTRAINT fk5a830ade653f90a FOREIGN KEY (id_budget_parts_list) REFERENCES budget_parts_list_value(id_budget_parts_list) DEFERRABLE;


--
-- TOC entry 2446 (class 2606 OID 114783)
-- Dependencies: 182 183 2246
-- Name: fk6459a12320d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY files_list_element
    ADD CONSTRAINT fk6459a12320d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2473 (class 2606 OID 114788)
-- Dependencies: 203 163 2206
-- Name: fk65214af20feb745; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY locationtype
    ADD CONSTRAINT fk65214af20feb745 FOREIGN KEY (boundadminlevelid) REFERENCES adminlevel(adminlevelid) DEFERRABLE;


--
-- TOC entry 2474 (class 2606 OID 114793)
-- Dependencies: 203 178 2234
-- Name: fk65214afb6676e25; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY locationtype
    ADD CONSTRAINT fk65214afb6676e25 FOREIGN KEY (countryid) REFERENCES country(countryid) DEFERRABLE;


--
-- TOC entry 2508 (class 2606 OID 114798)
-- Dependencies: 225 232 2344
-- Name: fk65b097bb13b3e6c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase
    ADD CONSTRAINT fk65b097bb13b3e6c FOREIGN KEY (id_project) REFERENCES project(databaseid) DEFERRABLE;


--
-- TOC entry 2509 (class 2606 OID 114803)
-- Dependencies: 225 226 2330
-- Name: fk65b097bc9c78c91; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase
    ADD CONSTRAINT fk65b097bc9c78c91 FOREIGN KEY (id_phase_model) REFERENCES phase_model(id_phase_model) DEFERRABLE;


--
-- TOC entry 2463 (class 2606 OID 114808)
-- Dependencies: 196 190 2258
-- Name: fk676020c247c62157; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicatorvalue
    ADD CONSTRAINT fk676020c247c62157 FOREIGN KEY (indicatorid) REFERENCES indicator(indicatorid) DEFERRABLE;


--
-- TOC entry 2464 (class 2606 OID 114813)
-- Dependencies: 196 253 2388
-- Name: fk676020c284811db7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicatorvalue
    ADD CONSTRAINT fk676020c284811db7 FOREIGN KEY (reportingperiodid) REFERENCES reportingperiod(reportingperiodid) DEFERRABLE;


--
-- TOC entry 2439 (class 2606 OID 114818)
-- Dependencies: 175 219 2316
-- Name: fk67dfa4bb87d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_element
    ADD CONSTRAINT fk67dfa4bb87d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2440 (class 2606 OID 114823)
-- Dependencies: 175 176 2230
-- Name: fk67dfa4bbb6ab611d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_element
    ADD CONSTRAINT fk67dfa4bbb6ab611d FOREIGN KEY (id_category_type) REFERENCES category_type(id_category_type) DEFERRABLE;


--
-- TOC entry 2438 (class 2606 OID 114828)
-- Dependencies: 174 171 2220
-- Name: fk69676b09c9ce70ad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY budget_parts_list_value
    ADD CONSTRAINT fk69676b09c9ce70ad FOREIGN KEY (id_budget) REFERENCES budget(id_budget) DEFERRABLE;


--
-- TOC entry 2587 (class 2606 OID 114833)
-- Dependencies: 266 183 2246
-- Name: fk6ac917120d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY value
    ADD CONSTRAINT fk6ac917120d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2588 (class 2606 OID 114838)
-- Dependencies: 266 264 2412
-- Name: fk6ac91712922bbb3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY value
    ADD CONSTRAINT fk6ac91712922bbb3 FOREIGN KEY (id_user_last_modif) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2515 (class 2606 OID 114843)
-- Dependencies: 229 219 2316
-- Name: fk74e7b70887d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY privacy_group
    ADD CONSTRAINT fk74e7b70887d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2470 (class 2606 OID 114848)
-- Dependencies: 201 203 2284
-- Name: fk752a03d58c0165bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY location
    ADD CONSTRAINT fk752a03d58c0165bb FOREIGN KEY (locationtypeid) REFERENCES locationtype(locationtypeid) DEFERRABLE;


--
-- TOC entry 2547 (class 2606 OID 114853)
-- Dependencies: 243 246 2374
-- Name: fk76d1d76183d8e9ca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_criterion
    ADD CONSTRAINT fk76d1d76183d8e9ca FOREIGN KEY (id_quality_framework) REFERENCES quality_framework(id_quality_framework) DEFERRABLE;


--
-- TOC entry 2548 (class 2606 OID 114858)
-- Dependencies: 243 219 2316
-- Name: fk76d1d76187d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_criterion
    ADD CONSTRAINT fk76d1d76187d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2430 (class 2606 OID 114863)
-- Dependencies: 166 167 2212
-- Name: fk7839ca7cda7c5e3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attribute
    ADD CONSTRAINT fk7839ca7cda7c5e3 FOREIGN KEY (attributegroupid) REFERENCES attributegroup(attributegroupid) DEFERRABLE;


--
-- TOC entry 2513 (class 2606 OID 114868)
-- Dependencies: 228 226 2330
-- Name: fk7a142472181ec2f8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase_model_sucessors
    ADD CONSTRAINT fk7a142472181ec2f8 FOREIGN KEY (id_phase_model_successor) REFERENCES phase_model(id_phase_model) DEFERRABLE;


--
-- TOC entry 2514 (class 2606 OID 114873)
-- Dependencies: 228 226 2330
-- Name: fk7a142472c9c78c91; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase_model_sucessors
    ADD CONSTRAINT fk7a142472c9c78c91 FOREIGN KEY (id_phase_model) REFERENCES phase_model(id_phase_model) DEFERRABLE;


--
-- TOC entry 2456 (class 2606 OID 114878)
-- Dependencies: 191 190 2258
-- Name: fk7a87f87547c62157; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicator_datasource
    ADD CONSTRAINT fk7a87f87547c62157 FOREIGN KEY (indicatorid) REFERENCES indicator(indicatorid);


--
-- TOC entry 2457 (class 2606 OID 114883)
-- Dependencies: 191 190 2258
-- Name: fk7a87f8755038b772; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicator_datasource
    ADD CONSTRAINT fk7a87f8755038b772 FOREIGN KEY (indicatorsourceid) REFERENCES indicator(indicatorid);


--
-- TOC entry 2535 (class 2606 OID 114888)
-- Dependencies: 238 232 2344
-- Name: fk8076a4d884058733; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_userlogin
    ADD CONSTRAINT fk8076a4d884058733 FOREIGN KEY (project_databaseid) REFERENCES project(databaseid);


--
-- TOC entry 2536 (class 2606 OID 114893)
-- Dependencies: 238 264 2412
-- Name: fk8076a4d8efbea106; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_userlogin
    ADD CONSTRAINT fk8076a4d8efbea106 FOREIGN KEY (favoriteusers_userid) REFERENCES userlogin(userid);


--
-- TOC entry 2552 (class 2606 OID 114898)
-- Dependencies: 246 219 2316
-- Name: fk807dbabe87d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_framework
    ADD CONSTRAINT fk807dbabe87d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2426 (class 2606 OID 114903)
-- Dependencies: 164 204 2286
-- Name: fk807f02ed9bc5c4da; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY amendment
    ADD CONSTRAINT fk807f02ed9bc5c4da FOREIGN KEY (id_log_frame) REFERENCES log_frame(id_log_frame) DEFERRABLE;


--
-- TOC entry 2427 (class 2606 OID 114908)
-- Dependencies: 164 232 2344
-- Name: fk807f02edb13b3e6c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY amendment
    ADD CONSTRAINT fk807f02edb13b3e6c FOREIGN KEY (id_project) REFERENCES project(databaseid) DEFERRABLE;


--
-- TOC entry 2561 (class 2606 OID 114913)
-- Dependencies: 252 183 2246
-- Name: fk8104218620d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY report_list_element
    ADD CONSTRAINT fk8104218620d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2562 (class 2606 OID 114918)
-- Dependencies: 240 252 2360
-- Name: fk8104218654081a85; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY report_list_element
    ADD CONSTRAINT fk8104218654081a85 FOREIGN KEY (model_id) REFERENCES projectreportmodel(id);


--
-- TOC entry 2469 (class 2606 OID 114923)
-- Dependencies: 200 198 2274
-- Name: fk8435cd2a44f6265a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY layout_group
    ADD CONSTRAINT fk8435cd2a44f6265a FOREIGN KEY (id_layout) REFERENCES layout(id_layout) DEFERRABLE;


--
-- TOC entry 2542 (class 2606 OID 114928)
-- Dependencies: 240 219 2316
-- Name: fk85b7359c87d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreportmodel
    ADD CONSTRAINT fk85b7359c87d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2475 (class 2606 OID 114933)
-- Dependencies: 204 232 2344
-- Name: fk88122cb2b13b3e6c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame
    ADD CONSTRAINT fk88122cb2b13b3e6c FOREIGN KEY (id_project) REFERENCES project(databaseid) DEFERRABLE;


--
-- TOC entry 2476 (class 2606 OID 114938)
-- Dependencies: 210 204 2298
-- Name: fk88122cb2eee3ae75; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame
    ADD CONSTRAINT fk88122cb2eee3ae75 FOREIGN KEY (id_log_frame_model) REFERENCES log_frame_model(id_log_frame) DEFERRABLE;


--
-- TOC entry 2436 (class 2606 OID 114943)
-- Dependencies: 172 183 2246
-- Name: fk881d68fb20d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY budget_distribution_element
    ADD CONSTRAINT fk881d68fb20d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2486 (class 2606 OID 114948)
-- Dependencies: 211 208 2294
-- Name: fk88c951234f6005ee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_prerequisite
    ADD CONSTRAINT fk88c951234f6005ee FOREIGN KEY (id_group) REFERENCES log_frame_group(id_group) DEFERRABLE;


--
-- TOC entry 2487 (class 2606 OID 114953)
-- Dependencies: 211 204 2286
-- Name: fk88c951239bc5c4da; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_prerequisite
    ADD CONSTRAINT fk88c951239bc5c4da FOREIGN KEY (id_log_frame) REFERENCES log_frame(id_log_frame) DEFERRABLE;


--
-- TOC entry 2477 (class 2606 OID 114958)
-- Dependencies: 205 207 2292
-- Name: fk89611ffc8012bc39; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_activity
    ADD CONSTRAINT fk89611ffc8012bc39 FOREIGN KEY (id_result) REFERENCES log_frame_expected_result(id_element) DEFERRABLE;


--
-- TOC entry 2478 (class 2606 OID 114963)
-- Dependencies: 206 205 2290
-- Name: fk89611ffce41dae8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_activity
    ADD CONSTRAINT fk89611ffce41dae8 FOREIGN KEY (id_element) REFERENCES log_frame_element(id_element) DEFERRABLE;


--
-- TOC entry 2583 (class 2606 OID 114968)
-- Dependencies: 264 2316 219
-- Name: fk8aa0da3e87d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userlogin
    ADD CONSTRAINT fk8aa0da3e87d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2575 (class 2606 OID 114973)
-- Dependencies: 2246 258 183
-- Name: fk8d80a2f720d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY textarea_element
    ADD CONSTRAINT fk8d80a2f720d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2491 (class 2606 OID 114978)
-- Dependencies: 214 215 2308
-- Name: fk8df3554a3dc0a3b1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY monitored_point
    ADD CONSTRAINT fk8df3554a3dc0a3b1 FOREIGN KEY (id_list) REFERENCES monitored_point_list(id_monitored_point_list) DEFERRABLE;


--
-- TOC entry 2492 (class 2606 OID 114983)
-- Dependencies: 2238 180 214
-- Name: fk8df3554ad4cd29db; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY monitored_point
    ADD CONSTRAINT fk8df3554ad4cd29db FOREIGN KEY (id_file) REFERENCES file_meta(id_file) DEFERRABLE;


--
-- TOC entry 2493 (class 2606 OID 114988)
-- Dependencies: 216 2274 198
-- Name: fk90ee7d6c44f6265a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY org_unit_banner
    ADD CONSTRAINT fk90ee7d6c44f6265a FOREIGN KEY (id_layout) REFERENCES layout(id_layout) DEFERRABLE;


--
-- TOC entry 2494 (class 2606 OID 114993)
-- Dependencies: 216 2314 218
-- Name: fk90ee7d6c4ba27d70; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY org_unit_banner
    ADD CONSTRAINT fk90ee7d6c4ba27d70 FOREIGN KEY (id_org_unit_model) REFERENCES org_unit_model(org_unit_model_id) DEFERRABLE;


--
-- TOC entry 2447 (class 2606 OID 114998)
-- Dependencies: 183 229 2338
-- Name: fk91725e88e25e8842; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY flexible_element
    ADD CONSTRAINT fk91725e88e25e8842 FOREIGN KEY (id_privacy_group) REFERENCES privacy_group(id_privacy_group) DEFERRABLE;


--
-- TOC entry 2569 (class 2606 OID 115003)
-- Dependencies: 256 2364 242
-- Name: fk9752ca7398d45965; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY richtextelement
    ADD CONSTRAINT fk9752ca7398d45965 FOREIGN KEY (version_id) REFERENCES projectreportversion(id) DEFERRABLE;


--
-- TOC entry 2480 (class 2606 OID 115008)
-- Dependencies: 212 2302 207
-- Name: fk99d3ddf7d88379d4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_expected_result
    ADD CONSTRAINT fk99d3ddf7d88379d4 FOREIGN KEY (id_specific_objective) REFERENCES log_frame_specific_objective(id_element) DEFERRABLE;


--
-- TOC entry 2481 (class 2606 OID 115013)
-- Dependencies: 207 206 2290
-- Name: fk99d3ddf7e41dae8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_expected_result
    ADD CONSTRAINT fk99d3ddf7e41dae8 FOREIGN KEY (id_element) REFERENCES log_frame_element(id_element) DEFERRABLE;


--
-- TOC entry 2467 (class 2606 OID 115018)
-- Dependencies: 199 2246 183
-- Name: fk9bb4b21220d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY layout_constraint
    ADD CONSTRAINT fk9bb4b21220d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2468 (class 2606 OID 115023)
-- Dependencies: 199 200 2278
-- Name: fk9bb4b212da924c21; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY layout_constraint
    ADD CONSTRAINT fk9bb4b212da924c21 FOREIGN KEY (id_layout_group) REFERENCES layout_group(id_layout_group) DEFERRABLE;


--
-- TOC entry 2448 (class 2606 OID 115028)
-- Dependencies: 219 184 2316
-- Name: fk9e763fd0f85c2c3c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY global_export
    ADD CONSTRAINT fk9e763fd0f85c2c3c FOREIGN KEY (organization_id) REFERENCES organization(id_organization);


--
-- TOC entry 2424 (class 2606 OID 115033)
-- Dependencies: 178 163 2234
-- Name: fk9ec33d95b6676e25; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY adminlevel
    ADD CONSTRAINT fk9ec33d95b6676e25 FOREIGN KEY (countryid) REFERENCES country(countryid) DEFERRABLE;


--
-- TOC entry 2425 (class 2606 OID 115038)
-- Dependencies: 163 163 2206
-- Name: fk9ec33d95e01b109c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY adminlevel
    ADD CONSTRAINT fk9ec33d95e01b109c FOREIGN KEY (parentid) REFERENCES adminlevel(adminlevelid) DEFERRABLE;


--
-- TOC entry 2420 (class 2606 OID 115043)
-- Dependencies: 263 161 2408
-- Name: fka126572f494bd9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY activity
    ADD CONSTRAINT fka126572f494bd9e FOREIGN KEY (databaseid) REFERENCES userdatabase(databaseid) DEFERRABLE;


--
-- TOC entry 2421 (class 2606 OID 115048)
-- Dependencies: 2284 203 161
-- Name: fka126572f8c0165bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY activity
    ADD CONSTRAINT fka126572f8c0165bb FOREIGN KEY (locationtypeid) REFERENCES locationtype(locationtypeid) DEFERRABLE;


--
-- TOC entry 2516 (class 2606 OID 115053)
-- Dependencies: 231 230 2342
-- Name: fka1812f6692e83e47; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY privacy_group_permission
    ADD CONSTRAINT fka1812f6692e83e47 FOREIGN KEY (id_profile) REFERENCES profile(id_profile) DEFERRABLE;


--
-- TOC entry 2517 (class 2606 OID 115058)
-- Dependencies: 2338 230 229
-- Name: fka1812f66e25e8842; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY privacy_group_permission
    ADD CONSTRAINT fka1812f66e25e8842 FOREIGN KEY (id_privacy_group) REFERENCES privacy_group(id_privacy_group) DEFERRABLE;


--
-- TOC entry 2506 (class 2606 OID 115063)
-- Dependencies: 2408 222 263
-- Name: fka9a62c88494bd9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partnerindatabase
    ADD CONSTRAINT fka9a62c88494bd9e FOREIGN KEY (databaseid) REFERENCES userdatabase(databaseid) DEFERRABLE;


--
-- TOC entry 2507 (class 2606 OID 115068)
-- Dependencies: 2320 222 221
-- Name: fka9a62c8879d901c9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partnerindatabase
    ADD CONSTRAINT fka9a62c8879d901c9 FOREIGN KEY (partnerid) REFERENCES partner(partnerid) DEFERRABLE;


--
-- TOC entry 2551 (class 2606 OID 115073)
-- Dependencies: 246 2374 245
-- Name: fkb0b3e55883d8e9ca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY quality_criterion_type
    ADD CONSTRAINT fkb0b3e55883d8e9ca FOREIGN KEY (id_quality_framework) REFERENCES quality_framework(id_quality_framework) DEFERRABLE;


--
-- TOC entry 2543 (class 2606 OID 115078)
-- Dependencies: 241 2360 240
-- Name: fkb29299a98fa2795f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreportmodelsection
    ADD CONSTRAINT fkb29299a98fa2795f FOREIGN KEY (projectmodelid) REFERENCES projectreportmodel(id) DEFERRABLE;


--
-- TOC entry 2544 (class 2606 OID 115083)
-- Dependencies: 241 241 2362
-- Name: fkb29299a9ae53865a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreportmodelsection
    ADD CONSTRAINT fkb29299a9ae53865a FOREIGN KEY (parentsectionmodelid) REFERENCES projectreportmodelsection(id) DEFERRABLE;


--
-- TOC entry 2482 (class 2606 OID 115088)
-- Dependencies: 208 204 2286
-- Name: fkb4d3b8b29bc5c4da; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_group
    ADD CONSTRAINT fkb4d3b8b29bc5c4da FOREIGN KEY (id_log_frame) REFERENCES log_frame(id_log_frame) DEFERRABLE;


--
-- TOC entry 2485 (class 2606 OID 115093)
-- Dependencies: 210 236 2352
-- Name: fkb526bd5cd196f951; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_model
    ADD CONSTRAINT fkb526bd5cd196f951 FOREIGN KEY (id_project_model) REFERENCES project_model(id_project_model) DEFERRABLE;


--
-- TOC entry 2559 (class 2606 OID 115098)
-- Dependencies: 2246 251 183
-- Name: fkbc80a6f120d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY report_element
    ADD CONSTRAINT fkbc80a6f120d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2560 (class 2606 OID 115103)
-- Dependencies: 2360 251 240
-- Name: fkbc80a6f154081a85; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY report_element
    ADD CONSTRAINT fkbc80a6f154081a85 FOREIGN KEY (model_id) REFERENCES projectreportmodel(id);


--
-- TOC entry 2545 (class 2606 OID 115108)
-- Dependencies: 2358 242 239
-- Name: fkc093868b39413f9b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreportversion
    ADD CONSTRAINT fkc093868b39413f9b FOREIGN KEY (report_id) REFERENCES projectreport(id) DEFERRABLE;


--
-- TOC entry 2546 (class 2606 OID 115113)
-- Dependencies: 2412 242 264
-- Name: fkc093868b54402265; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreportversion
    ADD CONSTRAINT fkc093868b54402265 FOREIGN KEY (editor_userid) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2533 (class 2606 OID 115118)
-- Dependencies: 219 2316 237
-- Name: fkc10e64e87d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_model_visibility
    ADD CONSTRAINT fkc10e64e87d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2534 (class 2606 OID 115123)
-- Dependencies: 236 2352 237
-- Name: fkc10e64ed196f951; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_model_visibility
    ADD CONSTRAINT fkc10e64ed196f951 FOREIGN KEY (id_project_model) REFERENCES project_model(id_project_model) DEFERRABLE;


--
-- TOC entry 2510 (class 2606 OID 115128)
-- Dependencies: 2274 226 198
-- Name: fkc11f1f6544f6265a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase_model
    ADD CONSTRAINT fkc11f1f6544f6265a FOREIGN KEY (id_layout) REFERENCES layout(id_layout) DEFERRABLE;


--
-- TOC entry 2511 (class 2606 OID 115133)
-- Dependencies: 2352 226 236
-- Name: fkc11f1f65d196f951; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase_model
    ADD CONSTRAINT fkc11f1f65d196f951 FOREIGN KEY (id_project_model) REFERENCES project_model(id_project_model) DEFERRABLE;


--
-- TOC entry 2512 (class 2606 OID 115138)
-- Dependencies: 2332 226 227
-- Name: fkc11f1f65e0174a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phase_model
    ADD CONSTRAINT fkc11f1f65e0174a FOREIGN KEY (definition_id) REFERENCES phase_model_definition(id_phase_model_definition) DEFERRABLE;


--
-- TOC entry 2579 (class 2606 OID 115143)
-- Dependencies: 2342 262 231
-- Name: fkc37e36d192e83e47; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_unit_profiles
    ADD CONSTRAINT fkc37e36d192e83e47 FOREIGN KEY (id_profile) REFERENCES profile(id_profile) DEFERRABLE;


--
-- TOC entry 2580 (class 2606 OID 115148)
-- Dependencies: 261 2404 262
-- Name: fkc37e36d1b3ab1d1c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_unit_profiles
    ADD CONSTRAINT fkc37e36d1b3ab1d1c FOREIGN KEY (id_user_unit) REFERENCES user_unit(id_user_unit) DEFERRABLE;


--
-- TOC entry 2428 (class 2606 OID 115153)
-- Dependencies: 164 2208 165
-- Name: fkc514f4bc7b49ebc6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY amendment_history_token
    ADD CONSTRAINT fkc514f4bc7b49ebc6 FOREIGN KEY (amendment_id_amendment) REFERENCES amendment(id_amendment) DEFERRABLE;


--
-- TOC entry 2429 (class 2606 OID 115158)
-- Dependencies: 165 189 2256
-- Name: fkc514f4bcbc854628; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY amendment_history_token
    ADD CONSTRAINT fkc514f4bcbc854628 FOREIGN KEY (values_id_history_token) REFERENCES history_token(id_history_token) DEFERRABLE;


--
-- TOC entry 2567 (class 2606 OID 115163)
-- Dependencies: 2408 255 263
-- Name: fkc69ddee494bd9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reporttemplate
    ADD CONSTRAINT fkc69ddee494bd9e FOREIGN KEY (databaseid) REFERENCES userdatabase(databaseid) DEFERRABLE;


--
-- TOC entry 2568 (class 2606 OID 115168)
-- Dependencies: 264 255 2412
-- Name: fkc69ddeea5c52bc6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reporttemplate
    ADD CONSTRAINT fkc69ddeea5c52bc6 FOREIGN KEY (owneruserid) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2532 (class 2606 OID 115173)
-- Dependencies: 226 236 2330
-- Name: fkc7b83283792a5c7c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_model
    ADD CONSTRAINT fkc7b83283792a5c7c FOREIGN KEY (id_root_phase_model) REFERENCES phase_model(id_phase_model) DEFERRABLE;


--
-- TOC entry 2488 (class 2606 OID 115178)
-- Dependencies: 204 212 2286
-- Name: fkc979ef199bc5c4da; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_specific_objective
    ADD CONSTRAINT fkc979ef199bc5c4da FOREIGN KEY (id_log_frame) REFERENCES log_frame(id_log_frame) DEFERRABLE;


--
-- TOC entry 2489 (class 2606 OID 115183)
-- Dependencies: 206 212 2290
-- Name: fkc979ef19e41dae8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log_frame_specific_objective
    ADD CONSTRAINT fkc979ef19e41dae8 FOREIGN KEY (id_element) REFERENCES log_frame_element(id_element) DEFERRABLE;


--
-- TOC entry 2451 (class 2606 OID 115188)
-- Dependencies: 231 187 2342
-- Name: fkcb8783eb92e83e47; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY global_permission
    ADD CONSTRAINT fkcb8783eb92e83e47 FOREIGN KEY (id_profile) REFERENCES profile(id_profile) DEFERRABLE;


--
-- TOC entry 2527 (class 2606 OID 115193)
-- Dependencies: 234 198 2274
-- Name: fkce2cbb1c44f6265a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_details
    ADD CONSTRAINT fkce2cbb1c44f6265a FOREIGN KEY (id_layout) REFERENCES layout(id_layout) DEFERRABLE;


--
-- TOC entry 2528 (class 2606 OID 115198)
-- Dependencies: 236 2352 234
-- Name: fkce2cbb1cd196f951; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_details
    ADD CONSTRAINT fkce2cbb1cd196f951 FOREIGN KEY (id_project_model) REFERENCES project_model(id_project_model) DEFERRABLE;


--
-- TOC entry 2584 (class 2606 OID 115203)
-- Dependencies: 265 2412 264
-- Name: fkd265581a48b34b53; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userpermission
    ADD CONSTRAINT fkd265581a48b34b53 FOREIGN KEY (userid) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2585 (class 2606 OID 115208)
-- Dependencies: 2408 263 265
-- Name: fkd265581a494bd9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userpermission
    ADD CONSTRAINT fkd265581a494bd9e FOREIGN KEY (databaseid) REFERENCES userdatabase(databaseid) DEFERRABLE;


--
-- TOC entry 2586 (class 2606 OID 115213)
-- Dependencies: 2320 221 265
-- Name: fkd265581a79d901c9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY userpermission
    ADD CONSTRAINT fkd265581a79d901c9 FOREIGN KEY (partnerid) REFERENCES partner(partnerid) DEFERRABLE;


--
-- TOC entry 2465 (class 2606 OID 115218)
-- Dependencies: 243 2366 197
-- Name: fkd2af174536d186ad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY keyquestion
    ADD CONSTRAINT fkd2af174536d186ad FOREIGN KEY (qualitycriterion_id_quality_criterion) REFERENCES quality_criterion(id_quality_criterion) DEFERRABLE;


--
-- TOC entry 2466 (class 2606 OID 115223)
-- Dependencies: 197 2362 241
-- Name: fkd2af1745d8178e71; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY keyquestion
    ADD CONSTRAINT fkd2af1745d8178e71 FOREIGN KEY (sectionid) REFERENCES projectreportmodelsection(id) DEFERRABLE;


--
-- TOC entry 2452 (class 2606 OID 115228)
-- Dependencies: 264 2412 189
-- Name: fkd692428edd0ca99c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY history_token
    ADD CONSTRAINT fkd692428edd0ca99c FOREIGN KEY (id_user) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2449 (class 2606 OID 115233)
-- Dependencies: 2248 185 184
-- Name: fkdca84b0af33647b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY global_export_content
    ADD CONSTRAINT fkdca84b0af33647b9 FOREIGN KEY (global_export_id) REFERENCES global_export(id);


--
-- TOC entry 2563 (class 2606 OID 115238)
-- Dependencies: 257 253 2396
-- Name: fkdcfe056f44c2434b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reportingperiod
    ADD CONSTRAINT fkdcfe056f44c2434b FOREIGN KEY (siteid) REFERENCES site(siteid) DEFERRABLE;


--
-- TOC entry 2431 (class 2606 OID 115243)
-- Dependencies: 161 2202 168
-- Name: fkdd8c951780bf17db; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attributegroupinactivity
    ADD CONSTRAINT fkdd8c951780bf17db FOREIGN KEY (activityid) REFERENCES activity(activityid) DEFERRABLE;


--
-- TOC entry 2432 (class 2606 OID 115248)
-- Dependencies: 2212 168 167
-- Name: fkdd8c9517da7c5e3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attributegroupinactivity
    ADD CONSTRAINT fkdd8c9517da7c5e3 FOREIGN KEY (attributegroupid) REFERENCES attributegroup(attributegroupid) DEFERRABLE;


--
-- TOC entry 2435 (class 2606 OID 115253)
-- Dependencies: 2412 264 170
-- Name: fkddeeae9848b34b53; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY authentication
    ADD CONSTRAINT fkddeeae9848b34b53 FOREIGN KEY (userid) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2537 (class 2606 OID 115258)
-- Dependencies: 239 2246 183
-- Name: fke0b8458d3cdc69db; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreport
    ADD CONSTRAINT fke0b8458d3cdc69db FOREIGN KEY (flexibleelement_id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2538 (class 2606 OID 115263)
-- Dependencies: 2360 240 239
-- Name: fke0b8458d54081a85; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreport
    ADD CONSTRAINT fke0b8458d54081a85 FOREIGN KEY (model_id) REFERENCES projectreportmodel(id) DEFERRABLE;


--
-- TOC entry 2539 (class 2606 OID 115268)
-- Dependencies: 242 239 2364
-- Name: fke0b8458d5a50539e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreport
    ADD CONSTRAINT fke0b8458d5a50539e FOREIGN KEY (currentversion_id) REFERENCES projectreportversion(id) DEFERRABLE;


--
-- TOC entry 2540 (class 2606 OID 115273)
-- Dependencies: 2344 232 239
-- Name: fke0b8458d84058733; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreport
    ADD CONSTRAINT fke0b8458d84058733 FOREIGN KEY (project_databaseid) REFERENCES project(databaseid) DEFERRABLE;


--
-- TOC entry 2541 (class 2606 OID 115278)
-- Dependencies: 221 239 2320
-- Name: fke0b8458db2590b2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projectreport
    ADD CONSTRAINT fke0b8458db2590b2 FOREIGN KEY (orgunit_partnerid) REFERENCES partner(partnerid) DEFERRABLE;


--
-- TOC entry 2558 (class 2606 OID 115283)
-- Dependencies: 249 2382 250
-- Name: fke116c072e22ec8c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reminder
    ADD CONSTRAINT fke116c072e22ec8c FOREIGN KEY (id_list) REFERENCES reminder_list(id_reminder_list) DEFERRABLE;


--
-- TOC entry 2442 (class 2606 OID 115288)
-- Dependencies: 177 2246 183
-- Name: fke1e36e8020d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY checkbox_element
    ADD CONSTRAINT fke1e36e8020d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2461 (class 2606 OID 115293)
-- Dependencies: 2246 194 183
-- Name: fkeb796c7620d5ae49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicators_list_element
    ADD CONSTRAINT fkeb796c7620d5ae49 FOREIGN KEY (id_flexible_element) REFERENCES flexible_element(id_flexible_element) DEFERRABLE;


--
-- TOC entry 2518 (class 2606 OID 115298)
-- Dependencies: 219 2316 231
-- Name: fked8e89a987d1466c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY profile
    ADD CONSTRAINT fked8e89a987d1466c FOREIGN KEY (id_organization) REFERENCES organization(id_organization) DEFERRABLE;


--
-- TOC entry 2499 (class 2606 OID 115303)
-- Dependencies: 220 2412 264
-- Name: fkf10e425774ec9247; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY orgunitpermission
    ADD CONSTRAINT fkf10e425774ec9247 FOREIGN KEY (user_userid) REFERENCES userlogin(userid) DEFERRABLE;


--
-- TOC entry 2500 (class 2606 OID 115308)
-- Dependencies: 2320 221 220
-- Name: fkf10e4257d3cc239c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY orgunitpermission
    ADD CONSTRAINT fkf10e4257d3cc239c FOREIGN KEY (unit_id) REFERENCES partner(partnerid) DEFERRABLE;


--
-- TOC entry 2459 (class 2606 OID 115313)
-- Dependencies: 190 2258 193
-- Name: fkf23eb7b447c62157; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicatordatasource
    ADD CONSTRAINT fkf23eb7b447c62157 FOREIGN KEY (indicatorid) REFERENCES indicator(indicatorid) DEFERRABLE;


--
-- TOC entry 2460 (class 2606 OID 115318)
-- Dependencies: 190 2258 193
-- Name: fkf23eb7b45038b772; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicatordatasource
    ADD CONSTRAINT fkf23eb7b45038b772 FOREIGN KEY (indicatorsourceid) REFERENCES indicator(indicatorid) DEFERRABLE;


--
-- TOC entry 2462 (class 2606 OID 115323)
-- Dependencies: 195 190 2258
-- Name: fkf8bf56b6530fdd8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicators_list_value
    ADD CONSTRAINT fkf8bf56b6530fdd8 FOREIGN KEY (id_indicator) REFERENCES indicator(indicatorid) DEFERRABLE;


--
-- TOC entry 2495 (class 2606 OID 115328)
-- Dependencies: 217 198 2274
-- Name: fkfdcfbc0244f6265a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY org_unit_details
    ADD CONSTRAINT fkfdcfbc0244f6265a FOREIGN KEY (id_layout) REFERENCES layout(id_layout) DEFERRABLE;


--
-- TOC entry 2496 (class 2606 OID 115333)
-- Dependencies: 217 218 2314
-- Name: fkfdcfbc024ba27d70; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY org_unit_details
    ADD CONSTRAINT fkfdcfbc024ba27d70 FOREIGN KEY (id_org_unit_model) REFERENCES org_unit_model(org_unit_model_id) DEFERRABLE;


--
-- TOC entry 2458 (class 2606 OID 115338)
-- Dependencies: 190 2258 192
-- Name: fkfe14c44f52429f27; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indicator_labels
    ADD CONSTRAINT fkfe14c44f52429f27 FOREIGN KEY (indicator_indicatorid) REFERENCES indicator(indicatorid) DEFERRABLE;


-- Completed on 2013-02-08 12:36:11

--
-- PostgreSQL database dump complete
--

